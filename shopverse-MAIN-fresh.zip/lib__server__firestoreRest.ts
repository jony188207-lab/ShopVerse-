/** Reads ONE Firestore document through the REST API using the CALLER'S OWN Firebase ID token, so the normal Firestore security rules decide what they may read. No service account. */
export async function getDocAsUser(projectId: string, path: string, idToken: string, f: typeof fetch = fetch): Promise<Record<string, unknown> | null> {
  const segs = path.split('/').map(encodeURIComponent).join('/');
  const res = await f(`https://firestore.googleapis.com/v1/projects/${encodeURIComponent(projectId)}/databases/(default)/documents/${segs}`, { headers: { Authorization: `Bearer ${idToken}` }, cache: 'no-store' });
  if (res.status === 404 || res.status === 403) return null;      // missing, or the rules say this user may not read it => treat as "not theirs"
  if (!res.ok) throw new Error(`firestore read failed (${res.status})`);
  const j = (await res.json()) as { fields?: Record<string, { stringValue?: string }> };
  return Object.fromEntries(Object.entries(j.fields ?? {}).map(([k, v]) => [k, v.stringValue ?? null]));
}
