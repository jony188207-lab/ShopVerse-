import { handleSign } from '@/lib/server/mediaApi';
import { realDeps, run } from '@/lib/server/respond';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const POST = (req: Request) => run(req, (auth, input) => handleSign(realDeps(), auth, input));
