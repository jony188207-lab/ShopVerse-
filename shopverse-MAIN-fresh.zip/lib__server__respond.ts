import { NextResponse } from 'next/server';
import { cloudinaryEnv } from './cloudinary';
import { getDocAsUser } from './firestoreRest';
import { MediaError } from './mediaPlan';
import type { Deps } from './mediaApi';

export const realDeps = (): Deps => {
  const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID ?? '';
  return { projectId, cloudinary: cloudinaryEnv(), getDoc: (path, token) => getDocAsUser(projectId, path, token) };
};
const STATUS: Record<string, number> = { 'invalid-argument': 400, unauthenticated: 401, 'permission-denied': 403, 'not-found': 404, internal: 500 };

/** Shared wrapper: parses JSON, runs the handler, returns {error:{message}} with a safe status. Never leaks stack traces or secrets. */
export async function run(req: Request, fn: (auth: string | null, input: Record<string, unknown>) => Promise<unknown>): Promise<NextResponse> {
  try {
    const ct = req.headers.get('content-type') ?? '';
    if (!ct.includes('application/json')) throw new MediaError('invalid-argument', 'Send JSON.');
    const raw = await req.text();
    if (raw.length > 4000) throw new MediaError('invalid-argument', 'Request too large.');
    const input = JSON.parse(raw) as Record<string, unknown>;
    return NextResponse.json(await fn(req.headers.get('authorization'), input && typeof input === 'object' ? input : {}), { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) {
    if (e instanceof MediaError) return NextResponse.json({ error: { message: e.message } }, { status: STATUS[e.code] ?? 500 });
    console.error('media api error', e instanceof Error ? e.message : 'unknown');
    return NextResponse.json({ error: { message: 'Something went wrong. Try again.' } }, { status: 500 });
  }
}
