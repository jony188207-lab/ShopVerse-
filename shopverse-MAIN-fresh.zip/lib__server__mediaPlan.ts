/** Pure upload planning (no network, no secrets): decides if a signed Cloudinary upload may be issued and what exactly it may contain. Unit-tested. */
export const MB = 1024 * 1024;
const IMG_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const VID_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
const IMG_FMT = 'jpg,jpeg,png,webp,gif';
const VID_FMT = 'mp4,webm,mov';
type Role = 'user' | 'seller' | 'moderator' | 'admin' | 'super_admin' | string;

interface Rule {
  roles: Role[] | null;                       // null = any signed-in user
  resource: 'image' | 'video';
  types: string[]; formats: string; max: number;
  ids: number;                                // folder segments after the kind: uid [+ id]
  verified?: boolean; review?: boolean;
}
const SELLER: Role[] = ['seller', 'admin', 'super_admin'];
/** logical path prefix (the same paths the app always used) -> rule. Cloudinary free plan limits: images 10 MB, videos 100 MB. */
export const MEDIA: Record<string, Rule> = {
  profiles: { roles: null, resource: 'image', types: IMG_TYPES, formats: IMG_FMT, max: 5 * MB, ids: 1 },
  applications: { roles: null, resource: 'image', types: IMG_TYPES, formats: IMG_FMT, max: 8 * MB, ids: 1, verified: true },
  stores: { roles: SELLER, resource: 'image', types: IMG_TYPES, formats: IMG_FMT, max: 8 * MB, ids: 1 },
  products: { roles: SELLER, resource: 'image', types: IMG_TYPES, formats: IMG_FMT, max: 10 * MB, ids: 2 },
  productVideos: { roles: SELLER, resource: 'video', types: VID_TYPES, formats: VID_FMT, max: 100 * MB, ids: 2 },
  videos: { roles: ['seller'], resource: 'video', types: [...VID_TYPES, ...IMG_TYPES.slice(0, 3)], formats: `${VID_FMT},jpg,jpeg,png,webp`, max: 100 * MB, ids: 2, verified: true },
  reviews: { roles: null, resource: 'image', types: IMG_TYPES.slice(0, 3), formats: 'jpg,jpeg,png,webp', max: 5 * MB, ids: 2, verified: true, review: true },
};
export const SEG = /^[A-Za-z0-9_-]{1,128}$/;
export const FOLDER_ROOT = 'shopverse';

export type MediaCode = 'invalid-argument' | 'permission-denied' | 'unauthenticated' | 'internal' | 'not-found';
export class MediaError extends Error { code: MediaCode; constructor(code: MediaCode, message: string) { super(message); this.code = code; } }
const fail = (code: MediaCode, m: string): never => { throw new MediaError(code, m); };

export interface PlanInput { uid: string; emailVerified: boolean; role: Role; input: { path?: unknown; contentType?: unknown; size?: unknown }; reviewOwner?: string; rand: string; stamp: string }
export interface Plan { kind: string; resourceType: 'image' | 'video'; folder: string; publicId: string; allowedFormats: string; max: number }

/** `rand` and `stamp` are passed in so the function stays pure and testable. */
export function planMedia(p: PlanInput): Plan {
  const path = typeof p.input.path === 'string' ? p.input.path.trim().slice(0, 400) : '';
  const logical = path.split('/');
  const kind = logical[0];
  const rule = Object.prototype.hasOwnProperty.call(MEDIA, kind) ? MEDIA[kind] : undefined;
  if (!rule) return fail('invalid-argument', 'Unknown upload type.');
  const ids = logical.slice(1, 1 + rule.ids);
  const file = logical.slice(1 + rule.ids).join('_');
  if (ids.length !== rule.ids || !ids.every((x) => SEG.test(x)) || !file) return fail('invalid-argument', 'Invalid upload path.');
  if (ids[0] !== p.uid) return fail('permission-denied', 'You can only upload your own files.');
  if (rule.roles && !rule.roles.includes(p.role)) return fail('permission-denied', 'Your account is not allowed to upload this kind of file.');
  if (rule.verified && !p.emailVerified) return fail('permission-denied', 'Verify your email before uploading.');
  if (rule.review && p.reviewOwner !== p.uid) return fail('permission-denied', 'Post the review first, then add photos to it.');
  const type = typeof p.input.contentType === 'string' ? p.input.contentType.trim().toLowerCase().slice(0, 100) : '';
  if (!rule.types.includes(type)) return fail('invalid-argument', 'This file type is not allowed here.');
  const size = Number(p.input.size);
  if (!Number.isFinite(size) || size <= 0) return fail('invalid-argument', 'Missing file size.');
  if (size > rule.max) return fail('invalid-argument', `This file is larger than ${Math.round(rule.max / MB)} MB.`);
  // Cloudinary resource type follows the file type (a video-kind upload may also carry a thumbnail image).
  const resourceType: 'image' | 'video' = type.startsWith('video/') ? 'video' : 'image';
  const vid = VID_FMT.split(',');
  const allowedFormats = rule.formats.split(',').filter((f) => (resourceType === 'video' ? vid.includes(f) : !vid.includes(f))).join(',');
  const folder = `${FOLDER_ROOT}/${kind}/${ids.join('/')}`;
  return { kind, resourceType, folder, publicId: `${folder}/${p.stamp}-${p.rand}`, allowedFormats, max: rule.max };
}

/** Who owns a Cloudinary public id like shopverse/products/<uid>/<productId>/<file>? Returns null when the id is not one of ours. */
export function ownerOfPublicId(publicId: string): { kind: string; uid: string } | null {
  const s = publicId.split('/');
  if (s.length < 4 || s[0] !== FOLDER_ROOT || !Object.prototype.hasOwnProperty.call(MEDIA, s[1])) return null;
  if (s.some((x) => !x || x === '.' || x === '..' || !/^[A-Za-z0-9_.-]+$/.test(x))) return null;
  return { kind: s[1], uid: s[2] };
}
export type { Rule };
