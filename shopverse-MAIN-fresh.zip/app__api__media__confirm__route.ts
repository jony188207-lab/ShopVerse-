import { handleConfirm } from '@/lib/server/mediaApi';
import { realDeps, run } from '@/lib/server/respond';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const POST = (req: Request) => run(req, (auth, input) => handleConfirm(realDeps(), auth, input));
