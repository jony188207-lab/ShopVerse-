import { collection, deleteDoc, doc, getCountFromServer, getDoc, getDocs, limit, query, serverTimestamp, setDoc, where } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Review } from '@/types';
import { mapReview } from './mappers';

export interface PersonRow { uid: string; name: string; username: string; photoURL: string }

/** Live counts straight from the follow list (no server-maintained counter, so they are always right and work without Cloud Functions). */
export async function followCounts(uid: string): Promise<{ followers: number; following: number }> {
  const [a, b] = await Promise.all([
    getCountFromServer(query(collection(db(), 'follows'), where('followingId', '==', uid))),
    getCountFromServer(query(collection(db(), 'follows'), where('followerId', '==', uid))),
  ]);
  return { followers: a.data().count, following: b.data().count };
}
export interface PublicProfile { uid: string; name: string; username: string; photoURL: string; bio: string }
/** Public profile = name, username, picture, bio only (rules: profiles are public by design; email/phone/addresses live elsewhere and stay private). */
export async function getPublicProfile(uid: string): Promise<PublicProfile | null> {
  const s = await getDoc(doc(db(), 'profiles', uid));
  if (!s.exists()) return null;
  const d = s.data();
  return { uid, name: String(d.displayName ?? 'ShopVerse user'), username: String(d.username ?? ''), photoURL: String(d.photoURL ?? ''), bio: String(d.bio ?? '') };
}
export const followId = (me: string, target: string) => `${me}_${target}`;
export async function isFollowing(me: string, target: string): Promise<boolean> { return (await getDoc(doc(db(), 'follows', followId(me, target)))).exists(); }
/** The document id is me_target, so following twice is impossible; the rules also refuse self-follows and unknown users. */
export async function followUser(me: string, target: string): Promise<void> {
  if (me === target) throw new Error('You cannot follow yourself.');
  if (await isFollowing(me, target)) return;
  await setDoc(doc(db(), 'follows', followId(me, target)), { followerId: me, followingId: target, createdAt: serverTimestamp() });
}
export async function unfollowUser(me: string, target: string): Promise<void> { await deleteDoc(doc(db(), 'follows', followId(me, target))); }

async function people(ids: string[]): Promise<PersonRow[]> {
  const rows = await Promise.all(ids.map(async (uid) => {
    try { const d = (await getDoc(doc(db(), 'profiles', uid))).data(); return { uid, name: String(d?.displayName ?? 'ShopVerse user'), username: String(d?.username ?? ''), photoURL: String(d?.photoURL ?? '') }; }
    catch { return { uid, name: 'ShopVerse user', username: '', photoURL: '' }; }
  }));
  return rows;
}
/** Public lists: who this user follows / who follows them (newest first is not guaranteed; capped at 50). */
export async function listFollowing(uid: string, size = 50): Promise<PersonRow[]> {
  const s = await getDocs(query(collection(db(), 'follows'), where('followerId', '==', uid), limit(size)));
  return people(s.docs.map((d) => String(d.get('followingId'))));
}
export async function listFollowers(uid: string, size = 50): Promise<PersonRow[]> {
  const s = await getDocs(query(collection(db(), 'follows'), where('followingId', '==', uid), limit(size)));
  return people(s.docs.map((d) => String(d.get('followerId'))));
}
/** My own reviews (newest first, sorted on the client so no extra index is needed). */
export async function listMyReviews(uid: string, size = 50): Promise<Review[]> {
  const s = await getDocs(query(collection(db(), 'reviews'), where('userId', '==', uid), limit(size)));
  return s.docs.map((d) => mapReview(d.id, d.data())).sort((a, b) => (b.createdAt?.getTime() ?? 0) - (a.createdAt?.getTime() ?? 0));
}

const photoCache = new Map<string, string>();
/** Profile pictures for a set of user ids (public profiles; cached). */
export async function profilePhotos(uids: string[]): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  await Promise.all([...new Set(uids)].map(async (u) => {
    if (!photoCache.has(u)) photoCache.set(u, String((await getDoc(doc(db(), 'profiles', u)).catch(() => null))?.data()?.photoURL ?? ''));
    out[u] = photoCache.get(u)!;
  }));
  return out;
}
