import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import { storage } from '@/lib/firebase/config';
import { cloudinaryEnabled, uploadViaCloudinary } from './cloudinaryStorage';

/** Phone photos are often 3-10 MB. Shrinking them in the browser before upload is the biggest speed-up for products, profile pictures and reviews.
 *  Skips GIFs (animation), small files and anything that fails, in which case the original is uploaded unchanged. */
export async function shrinkImage(file: File, maxSide = 1280, quality = 0.8): Promise<File> {
  try {
    if (typeof document === 'undefined' || file.type === 'image/gif' || file.size < 150 * 1024) return file;
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * k)), h = Math.max(1, Math.round(bmp.height * k));
    const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d'); if (!ctx) return file;
    ctx.drawImage(bmp, 0, 0, w, h); bmp.close?.();
    const blob: Blob | null = await new Promise((res) => canvas.toBlob(res, 'image/webp', quality));
    if (!blob || blob.type !== 'image/webp' || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.\w+$/, '') + '.webp', { type: 'image/webp' });
  } catch { return file; }
}

/** Firebase Storage upload with a stall watchdog, so a stuck upload fails with a clear message instead of spinning forever. */
function storageUpload(path: string, file: File): Promise<string> {
  const r = ref(storage(), path);
  return new Promise<string>((resolve, reject) => {
    const task = uploadBytesResumable(r, file, { contentType: file.type, cacheControl: 'public,max-age=31536000' });
    let last = Date.now(); let lastBytes = -1;
    const dog = setInterval(() => { if (Date.now() - last > 45_000) { clearInterval(dog); task.cancel(); reject(new Error('The upload is not moving. Firebase Storage may not be enabled for this project (it needs the Blaze plan), or your connection dropped.')); } }, 5000);
    task.on('state_changed', (s) => { if (s.bytesTransferred !== lastBytes) { lastBytes = s.bytesTransferred; last = Date.now(); } }, (e) => {
      clearInterval(dog);
      const code = (e as { code?: string }).code ?? '';
      if (code === 'storage/canceled') return;
      reject(new Error(code === 'storage/unauthorized' ? 'You are not allowed to upload this file (check your role and that the latest storage.rules are published).'
        : code === 'storage/bucket-not-found' || code === 'storage/project-not-found' ? 'Firebase Storage is not set up for this project (new projects need the Blaze plan for Storage).'
        : code === 'storage/retry-limit-exceeded' ? 'The upload kept failing. Check your connection and try again.' : e.message));
    }, () => { clearInterval(dog); getDownloadURL(task.snapshot.ref).then(resolve, reject); });
  });
}

/** Client-side guard (Storage rules are the real enforcement). Returns the public download URL. */
export async function uploadFile(path: string, file: File, opts: { maxMB: number; image?: boolean; video?: boolean; maxSide?: number; onProgress?: (pct: number) => void }): Promise<string> {
  if (file.size > opts.maxMB * 1024 * 1024) throw new Error(`“${file.name}” is larger than ${opts.maxMB} MB.`);
  if (opts.image && !/^image\/(jpeg|png|webp|gif)$/.test(file.type)) throw new Error(`“${file.name}” must be a JPG, PNG, WebP or GIF image.`);
  if (opts.video && !/^video\/(mp4|webm|quicktime)$/.test(file.type)) throw new Error(`“${file.name}” must be an MP4, WebM or MOV video.`);
  const up = opts.image ? await shrinkImage(file, opts.maxSide ?? 1280) : file;
  const safe = path.replace(/[^\w./-]+/g, '_').replace(/\.(jpe?g|png)$/i, up.type === 'image/webp' ? '.webp' : '.$1');
  // Cloudinary when NEXT_PUBLIC_CLOUDINARY_ENABLED=true (free plan, no Blaze); otherwise Firebase Storage exactly as before. Old Firebase and Supabase URLs keep working either way.
  return cloudinaryEnabled() ? (await uploadViaCloudinary(safe, up, opts.onProgress)).url : storageUpload(safe, up);
}
