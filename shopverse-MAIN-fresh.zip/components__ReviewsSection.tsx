'use client';
import { useCallback, useEffect, useState } from 'react';
import Image from 'next/image';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { BadgeCheck, Flag } from 'lucide-react';
import Link from 'next/link';
import { createOpenReview, getMyProductReview, listReviews, reportReview, reviewStats, type ReviewStats } from '@/services/reviewService';
import { profilePhotos } from '@/services/socialService';
import { Avatar } from './Avatar';
import { StarInput } from './StarRating';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { StarRating } from './StarRating';
import { Button } from './ui/Button';
import { EmptyState } from './ui/States';
import type { Product, Review } from '@/types';

export function ReviewsSection({ product }: { product: Product }) {
  const { user } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState<Review[]>([]);
  const [cursor, setCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [more, setMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState<ReviewStats | null>(null); const [photos, setPhotos] = useState<Record<string, string>>({});
  const [mine, setMine] = useState<Review | null | undefined>(undefined);
  const [rating, setRating] = useState(0); const [text, setText] = useState(''); const [busy, setBusy] = useState(false);

  const load = useCallback(async (cur: QueryDocumentSnapshot | null) => {
    setLoading(true); setError('');
    try { const p = await listReviews(product.id, cur); setItems((x) => (cur ? [...x, ...p.items] : p.items)); setCursor(p.cursor); setMore(p.hasMore); profilePhotos(p.items.map((r) => r.userId)).then((m) => setPhotos((o) => ({ ...o, ...m }))).catch(() => undefined); }
    catch (e) { setError(friendlyError(e)); } finally { setLoading(false); }
  }, [product.id]);
  const loadStats = useCallback(() => { reviewStats(product.id).then(setStats).catch(() => setStats(null)); }, [product.id]);
  useEffect(() => { void load(null); loadStats(); }, [load, loadStats]);
  useEffect(() => { if (user) getMyProductReview(user.uid, product.id).then(setMine).catch(() => setMine(null)); else setMine(null); }, [user, product.id]);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); if (!user) return;
    if (rating < 1) return toast('Choose a star rating', 'info');
    setBusy(true);
    try { await createOpenReview(user.uid, user.displayName ?? '', product, rating, text); toast('Thanks for your review', 'success'); setRating(0); setText(''); setMine(await getMyProductReview(user.uid, product.id)); await load(null); loadStats(); }
    catch (x) { toast(friendlyError(x), 'error'); } finally { setBusy(false); }
  };

  const report = async (r: Review) => {
    if (!user) return toast('Sign in to report a review', 'info');
    try { await reportReview(user.uid, r.id, 'Reported by a buyer'); toast('Thanks — our team will take a look', 'success'); }
    catch (e) { toast((e as { code?: string }).code === 'permission-denied' ? 'You already reported this review' : friendlyError(e), 'error'); }
  };
  const total = stats?.count ?? product.reviewCount; const avg = stats ? stats.average : product.rating;
  return (
    <section aria-labelledby="reviews" className="space-y-4">
      <h2 id="reviews" className="text-xl font-bold">Reviews</h2>
      {total > 0 ? (
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div><p className="text-4xl font-extrabold">{avg.toFixed(1)}</p><StarRating value={avg} /><p className="text-sm text-navy-500 dark:text-navy-100">{total} review{total > 1 ? 's' : ''}</p></div>
          <ul className="flex-1 space-y-1" aria-label="Rating distribution">
            {([5, 4, 3, 2, 1] as const).map((n) => {
              const c = (stats?.distribution ?? product.ratingDistribution)[String(n) as '1'];
              return (
                <li key={n} className="flex items-center gap-2 text-sm"><span className="w-10">{n} star</span>
                  <span className="h-2 flex-1 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-700"><span className="block h-full bg-brand-orange" style={{ width: `${total ? (c / total) * 100 : 0}%` }} /></span>
                  <span className="w-8 text-right">{c}</span></li>
              );
            })}
          </ul>
        </div>
      ) : null}
      {user && mine === null && user.uid !== product.sellerId ? (
        user.emailVerified ? (
          <form onSubmit={submit} className="space-y-2 rounded-xl border border-navy-100 p-3 dark:border-navy-500">
            <p className="text-sm font-semibold">Write a review</p>
            <StarInput value={rating} onChange={setRating} />
            <textarea aria-label="Your review" rows={3} maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} placeholder="What did you think? (optional)" className="w-full rounded-xl border border-navy-100 bg-white p-3 text-base text-navy-900 dark:border-navy-500 dark:bg-navy-900 dark:text-white" />
            <p className="text-xs text-navy-500 dark:text-navy-100">Reviews from people without a delivered order are marked “Not a verified purchase”. To add photos, review from your delivered order.</p>
            <Button type="submit" loading={busy}>Submit review</Button>
          </form>
        ) : <p className="text-sm"><Link className="underline" href="/verify-email">Verify your email</Link> to write a review.</p>
      ) : mine ? <p className="text-sm">You reviewed this product. Thank you!</p> : null}
      {!user ? <p className="text-sm"><Link className="underline" href="/login">Sign in</Link> to write a review.</p> : null}
      {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
      {!loading && !items.length && !error ? <EmptyState title="No reviews yet">Be the first to review this product.</EmptyState> : null}
      <ul className="space-y-4">
        {items.map((r) => (
          <li key={r.id} className="space-y-1 border-b border-navy-100 pb-4 dark:border-navy-500">
            <div className="flex flex-wrap items-center gap-2"><Link href={`/user/${r.userId}`} className="flex items-center gap-2"><Avatar name={r.userName} src={photos[r.userId]} size={32} /><span className="text-sm font-semibold">{r.userName}</span></Link><StarRating value={r.rating} /><span className="text-xs text-navy-500 dark:text-navy-100">{r.createdAt ? r.createdAt.toLocaleDateString() : ''}</span>
              {r.verifiedPurchase ? <span className="inline-flex items-center gap-1 text-xs font-semibold text-green-700 dark:text-green-400"><BadgeCheck className="h-4 w-4" aria-hidden />Verified purchase</span> : <span className="text-xs text-navy-500 dark:text-navy-100">Not a verified purchase</span>}</div>
            {r.text ? <p className="text-sm">{r.text}</p> : null}
            {r.images.length ? <div className="flex gap-2">{r.images.map((u) => <div key={u} className="relative h-20 w-20 overflow-hidden rounded-lg"><Image src={u} alt="Review photo" fill sizes="80px" className="object-cover" /></div>)}</div> : null}
            {r.sellerResponse ? <p className="rounded-lg bg-navy-50 p-2 text-sm dark:bg-navy-700"><strong>Seller response:</strong> {r.sellerResponse}</p> : null}
            <button onClick={() => report(r)} className="inline-flex min-h-11 items-center gap-1 text-xs text-navy-500 underline dark:text-navy-100"><Flag className="h-3.5 w-3.5" aria-hidden />Report</button>
          </li>
        ))}
      </ul>
      {more ? <Button variant="secondary" loading={loading} onClick={() => load(cursor)}>Load more reviews</Button> : null}
    </section>
  );
}
