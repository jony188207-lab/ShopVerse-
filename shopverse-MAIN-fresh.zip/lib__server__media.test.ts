import { describe, expect, it } from 'vitest';
import { generateKeyPairSync, createSign } from 'node:crypto';
import { planMedia, ownerOfPublicId, MB, MediaError } from './mediaPlan';
import { signParams, signUpload, cloudinaryEnv } from './cloudinary';
import { verifyIdToken, resetKeyCache } from './idToken';
import { handleConfirm, handleDelete, handleSign, type Deps } from './mediaApi';

const base = { emailVerified: true, role: 'user', rand: 'abc123', stamp: 'lx' };
const plan = (path: string, over: Record<string, unknown> = {}, who: Partial<{ uid: string; role: string; emailVerified: boolean; reviewOwner: string }> = {}) =>
  planMedia({ ...base, uid: 'u1', ...who, input: { path, contentType: 'image/jpeg', size: 1000, ...over } } as never);
const code = (fn: () => unknown): string => { try { fn(); return 'ok'; } catch (e) { return e instanceof MediaError ? e.code : 'other'; } };

describe('planMedia (who may upload what)', () => {
  it('own profile picture: folder and public id are server-chosen and namespaced by uid', () => {
    const p = plan('profiles/u1/photo.jpg');
    expect(p.folder).toBe('shopverse/profiles/u1');
    expect(p.publicId).toBe('shopverse/profiles/u1/lx-abc123');
    expect(p.resourceType).toBe('image');
  });
  it('refuses another user\'s folder, path tricks, unknown kinds', () => {
    expect(code(() => plan('profiles/u2/a.jpg'))).toBe('permission-denied');
    expect(code(() => plan('profiles/../u2/a.jpg'))).toBe('invalid-argument');
    expect(code(() => plan('secrets/u1/a.jpg'))).toBe('invalid-argument');
    expect(code(() => plan('__proto__/u1/a.jpg'))).toBe('invalid-argument');
    expect(code(() => plan('profiles/u1'))).toBe('invalid-argument');
  });
  it('validates type and size', () => {
    expect(code(() => plan('profiles/u1/a.exe', { contentType: 'application/x-msdownload' }))).toBe('invalid-argument');
    expect(code(() => plan('profiles/u1/a.jpg', { size: 5 * MB + 1 }))).toBe('invalid-argument');
    expect(code(() => plan('profiles/u1/a.jpg', { size: 0 }))).toBe('invalid-argument');
    expect(code(() => plan('profiles/u1/a.mp4', { contentType: 'video/mp4' }))).toBe('invalid-argument');
  });
  it('products and videos need the seller role; a sender cannot claim a role in the input', () => {
    expect(code(() => plan('products/u1/p1/a.jpg'))).toBe('permission-denied');
    expect(code(() => plan('products/u1/p1/a.jpg', { role: 'admin' }))).toBe('permission-denied');
    expect(plan('products/u1/p1/a.jpg', {}, { role: 'seller' }).folder).toBe('shopverse/products/u1/p1');
    const v = plan('productVideos/u1/p1/v.mp4', { contentType: 'video/mp4', size: 100 * MB }, { role: 'seller' });
    expect([v.resourceType, v.allowedFormats]).toEqual(['video', 'mp4,webm,mov']);
    expect(code(() => plan('productVideos/u1/p1/v.mp4', { contentType: 'video/mp4', size: 100 * MB + 1 }, { role: 'seller' }))).toBe('invalid-argument');
  });
  it('applications and review photos need a verified email; review photos need the review to be yours', () => {
    expect(code(() => plan('applications/u1/logo.jpg', {}, { emailVerified: false }))).toBe('permission-denied');
    expect(code(() => plan('reviews/u1/r1/a.jpg'))).toBe('permission-denied');
    expect(code(() => plan('reviews/u1/r1/a.jpg', {}, { reviewOwner: 'someone-else' }))).toBe('permission-denied');
    expect(plan('reviews/u1/r1/a.jpg', {}, { reviewOwner: 'u1' }).folder).toBe('shopverse/reviews/u1/r1');
  });
  it('seller videos: a thumbnail image is an image upload in the video folder', () => {
    const t = plan('videos/u1/v1/thumb.jpg', {}, { role: 'seller' });
    expect([t.resourceType, t.allowedFormats]).toEqual(['image', 'jpg,jpeg,png,webp']);
  });
});

describe('ownerOfPublicId', () => {
  it('reads the owner from our folder layout only', () => {
    expect(ownerOfPublicId('shopverse/products/u1/p1/lx-abc')).toEqual({ kind: 'products', uid: 'u1' });
    expect(ownerOfPublicId('other/products/u1/p1/x')).toBeNull();
    expect(ownerOfPublicId('shopverse/products/u1/../u2/x')).toBeNull();
    expect(ownerOfPublicId('shopverse/nope/u1/p1/x')).toBeNull();
  });
});

describe('Cloudinary signing (server only)', () => {
  it('matches Cloudinary\'s documented example signature', () => {
    // From Cloudinary docs: sign "eager=w_400,h_300,c_pad|w_260,h_200,c_crop&public_id=sample_image&timestamp=1315060510" + secret "abcd".
    const sig = signParams({ eager: 'w_400,h_300,c_pad|w_260,h_200,c_crop', public_id: 'sample_image', timestamp: 1315060510 }, 'abcd');
    expect(sig).toBe('bfd09f95f331f558cbd1320e67aa8d488770583e');
  });
  it('signed upload contains the signature and api key but never the secret', () => {
    const c = { cloudName: 'demo', apiKey: 'KEY1', apiSecret: 'SECRET-VALUE' };
    const s = signUpload(c, { resourceType: 'image', publicId: 'shopverse/profiles/u1/x', allowedFormats: 'jpg,png' }, 1700000000);
    expect(s.uploadUrl).toBe('https://api.cloudinary.com/v1_1/demo/image/upload');
    expect(s.fields.api_key).toBe('KEY1');
    expect(JSON.stringify(s).includes('SECRET-VALUE')).toBe(false);
    expect(s.fields.signature).toBe(signParams({ allowed_formats: 'jpg,png', public_id: 'shopverse/profiles/u1/x', timestamp: 1700000000, overwrite: 'false' }, 'SECRET-VALUE'));
  });
  it('cloudinaryEnv needs all three variables', () => {
    expect(cloudinaryEnv({ CLOUDINARY_CLOUD_NAME: 'demo', CLOUDINARY_API_KEY: 'k' })).toBeNull();
    expect(cloudinaryEnv({ CLOUDINARY_CLOUD_NAME: 'demo', CLOUDINARY_API_KEY: 'k', CLOUDINARY_API_SECRET: 's' })?.cloudName).toBe('demo');
  });
});

/* ---- Firebase ID token verification against a locally generated key ---- */
const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = { ...(publicKey.export({ format: 'jwk' }) as object), kid: 'k1', alg: 'RS256', use: 'sig' } as JsonWebKey;
const b64 = (o: unknown) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
const PROJECT = 'proj-1';
const mkToken = (over: Record<string, unknown> = {}, kid = 'k1') => {
  const now = Math.floor(Date.now() / 1000);
  const h = b64({ alg: 'RS256', kid, typ: 'JWT' }); const p = b64({ aud: PROJECT, iss: `https://securetoken.google.com/${PROJECT}`, sub: 'u1', iat: now - 10, exp: now + 3600, email_verified: true, ...over });
  const sig = createSign('RSA-SHA256').update(`${h}.${p}`).sign(privateKey).toString('base64url');
  return `${h}.${p}.${sig}`;
};
const load = async () => ({ k1: jwk });
const ok = async (t: string) => { resetKeyCache(); try { await verifyIdToken(t, PROJECT, load); return 'ok'; } catch (e) { return (e as Error).message; } };

describe('verifyIdToken', () => {
  it('accepts a good token', async () => { expect(await ok(mkToken())).toBe('ok'); });
  it('rejects tampered, expired, wrong project, wrong issuer, unknown key, garbage', async () => {
    const t = mkToken(); const [h, , s] = t.split('.');
    expect(await ok(`${h}.${b64({ aud: PROJECT, iss: `https://securetoken.google.com/${PROJECT}`, sub: 'admin', exp: 9999999999 })}.${s}`)).toBe('unauthenticated');
    expect(await ok(mkToken({ exp: Math.floor(Date.now() / 1000) - 5 }))).toBe('unauthenticated');
    expect(await ok(mkToken({ aud: 'other' }))).toBe('unauthenticated');
    expect(await ok(mkToken({ iss: 'https://evil.example/' }))).toBe('unauthenticated');
    expect(await ok(mkToken({}, 'unknown-kid'))).toBe('unauthenticated');
    expect(await ok('not.a.token')).toBe('unauthenticated');
    expect(await ok('x')).toBe('unauthenticated');
  });
});

/* ---- the three endpoints, with every outside service faked ---- */
const docs: Record<string, Record<string, unknown>> = { 'roles/seller1': { role: 'seller' }, 'roles/adm': { role: 'admin' }, 'reviews/r1': { userId: 'u1' } };
const cloudCalls: { url: string; method: string }[] = []; let stored: { bytes: number; format: string } | null = { bytes: 1000, format: 'jpg' };
const fakeFetch = (async (url: string, init?: { method?: string }) => {
  cloudCalls.push({ url: String(url), method: init?.method ?? 'GET' });
  if (String(url).includes('/destroy')) return { ok: true, status: 200, json: async () => ({ result: 'ok' }) };
  if (!stored) return { ok: false, status: 404, json: async () => ({}) };
  return { ok: true, status: 200, json: async () => ({ ...stored, secure_url: 'https://res.cloudinary.com/demo/image/upload/v1/shopverse/profiles/u1/x.jpg' }) };
}) as unknown as typeof fetch;
const deps = (sub: string, claims: Record<string, unknown> = {}): Deps => ({
  projectId: PROJECT, cloudinary: { cloudName: 'demo', apiKey: 'KEY1', apiSecret: 'TOP-SECRET' }, fetchImpl: fakeFetch, now: () => 1700000000000, rand: () => 'r4nd',
  verify: async (t) => { if (t !== 'good') throw new Error('unauthenticated'); return { sub, email_verified: true, ...claims }; },
  getDoc: async (path) => docs[path] ?? null,
});
const run = async (fn: () => Promise<unknown>) => { try { return { ok: true as const, v: await fn() as Record<string, unknown> }; } catch (e) { return { ok: false as const, code: e instanceof MediaError ? e.code : 'other', msg: (e as Error).message }; } };

describe('POST /api/media/sign', () => {
  it('needs a valid Firebase token', async () => {
    expect((await run(() => handleSign(deps('u1'), null, { path: 'profiles/u1/a.jpg', contentType: 'image/jpeg', size: 10 }))) as { code: string }).toMatchObject({ code: 'unauthenticated' });
    expect((await run(() => handleSign(deps('u1'), 'Bearer forged', { path: 'profiles/u1/a.jpg', contentType: 'image/jpeg', size: 10 }))) as { code: string }).toMatchObject({ code: 'unauthenticated' });
  });
  it('signs an own upload and never returns the secret', async () => {
    const r = await run(() => handleSign(deps('u1'), 'Bearer good', { path: 'profiles/u1/a.jpg', contentType: 'image/jpeg', size: 10 }));
    expect(r.ok).toBe(true);
    if (r.ok) { expect(r.v.publicId).toBe('shopverse/profiles/u1/lx-r4nd'.replace('lx', (1700000000000).toString(36))); expect(JSON.stringify(r.v).includes('TOP-SECRET')).toBe(false); }
  });
  it('role comes from Firestore, not from the request', async () => {
    expect((await run(() => handleSign(deps('u1'), 'Bearer good', { path: 'products/u1/p1/a.jpg', contentType: 'image/jpeg', size: 10, role: 'admin' }))).ok).toBe(false);
    expect((await run(() => handleSign(deps('seller1'), 'Bearer good', { path: 'products/seller1/p1/a.jpg', contentType: 'image/jpeg', size: 10 }))).ok).toBe(true);
  });
  it('review photos only for the review author (read as the user)', async () => {
    expect((await run(() => handleSign(deps('u1'), 'Bearer good', { path: 'reviews/u1/r1/a.jpg', contentType: 'image/jpeg', size: 10 }))).ok).toBe(true);
    expect((await run(() => handleSign(deps('u9'), 'Bearer good', { path: 'reviews/u9/r1/a.jpg', contentType: 'image/jpeg', size: 10 }))).ok).toBe(false);
  });
  it('reports missing server configuration plainly', async () => {
    const r = await run(() => handleSign({ ...deps('u1'), cloudinary: null }, 'Bearer good', { path: 'profiles/u1/a.jpg', contentType: 'image/jpeg', size: 10 }));
    expect(r).toMatchObject({ ok: false, code: 'internal' });
  });
});

describe('POST /api/media/confirm and /delete', () => {
  it('confirm returns the optimised URL for a valid file and removes an oversized one', async () => {
    stored = { bytes: 1000, format: 'jpg' }; cloudCalls.length = 0;
    const good = await run(() => handleConfirm(deps('u1'), 'Bearer good', { publicId: 'shopverse/profiles/u1/lx-r4nd', resourceType: 'image' }));
    expect(good.ok && String(good.v.url).includes('/upload/q_auto,f_auto/')).toBe(true);
    expect(good.ok && good.v.path).toBe('cld:image/shopverse/profiles/u1/lx-r4nd');
    stored = { bytes: 6 * MB, format: 'jpg' };
    const big = await run(() => handleConfirm(deps('u1'), 'Bearer good', { publicId: 'shopverse/profiles/u1/lx-r4nd', resourceType: 'image' }));
    expect(big).toMatchObject({ ok: false, code: 'invalid-argument' });
    expect(cloudCalls.some((c) => c.url.includes('/destroy'))).toBe(true);
    stored = { bytes: 100, format: 'exe' };
    expect((await run(() => handleConfirm(deps('u1'), 'Bearer good', { publicId: 'shopverse/profiles/u1/lx-r4nd', resourceType: 'image' }))).ok).toBe(false);
  });
  it('nobody can confirm or delete another user\'s file; admins may delete', async () => {
    stored = { bytes: 100, format: 'jpg' };
    expect(await run(() => handleConfirm(deps('u2'), 'Bearer good', { publicId: 'shopverse/profiles/u1/x', resourceType: 'image' }))).toMatchObject({ ok: false, code: 'permission-denied' });
    expect(await run(() => handleDelete(deps('u2'), 'Bearer good', { publicId: 'shopverse/profiles/u1/x', resourceType: 'image' }))).toMatchObject({ ok: false, code: 'permission-denied' });
    expect((await run(() => handleDelete(deps('u1'), 'Bearer good', { publicId: 'shopverse/profiles/u1/x', resourceType: 'image' }))).ok).toBe(true);
    expect((await run(() => handleDelete(deps('adm'), 'Bearer good', { publicId: 'shopverse/profiles/u1/x', resourceType: 'image' }))).ok).toBe(true);
    expect(await run(() => handleDelete(deps('u1'), 'Bearer good', { publicId: 'somewhere/else/u1/x', resourceType: 'image' }))).toMatchObject({ ok: false, code: 'invalid-argument' });
  });
});
