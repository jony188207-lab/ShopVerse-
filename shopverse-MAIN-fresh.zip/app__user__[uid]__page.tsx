'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { Avatar } from '@/components/Avatar';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { followCounts, followUser, getPublicProfile, isFollowing, listFollowers, listFollowing, unfollowUser, type PersonRow, type PublicProfile } from '@/services/socialService';

type Tab = 'followers' | 'following';

function Profile() {
  const { uid } = useParams<{ uid: string }>(); const { user } = useAuth(); const router = useRouter(); const toast = useToast();
  const [p, setP] = useState<PublicProfile | null | undefined>(undefined); const [err, setErr] = useState('');
  const [counts, setCounts] = useState({ followers: 0, following: 0 }); const [following, setFollowing] = useState(false); const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<Tab | null>(null); const [rows, setRows] = useState<PersonRow[] | null>(null);
  const me = user?.uid ?? ''; const mine = me === uid;

  const refresh = useCallback(async () => { setCounts(await followCounts(uid)); if (me && !mine) setFollowing(await isFollowing(me, uid)); }, [uid, me, mine]);
  useEffect(() => { setErr(''); getPublicProfile(uid).then(setP).catch((e) => { setErr(friendlyError(e)); setP(null); }); refresh().catch(() => undefined); }, [uid, refresh]);
  const loadRows = useCallback((t: Tab) => { setRows(null); (t === 'followers' ? listFollowers(uid) : listFollowing(uid)).then(setRows).catch((e) => { toast(friendlyError(e), 'error'); setRows([]); }); }, [uid]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (tab) loadRows(tab); }, [tab, loadRows]);

  if (p === undefined) return <LoadingState />;
  if (err || !p) return <ErrorState title="Profile not available" message={err || 'This user does not exist.'} />;
  const toggle = async () => {
    setBusy(true);
    try { if (following) await unfollowUser(me, uid); else await followUser(me, uid); await refresh(); if (tab) loadRows(tab); }
    catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="mx-auto max-w-lg space-y-4 px-4">
      <Card className="space-y-3 text-center">
        <div className="flex justify-center"><Avatar name={p.name} src={p.photoURL} size={88} /></div>
        <div><h1 className="text-xl font-extrabold">{p.name}</h1>{p.username ? <p className="text-sm text-brand-purple">@{p.username}</p> : null}</div>
        {p.bio ? <p className="whitespace-pre-wrap text-sm">{p.bio}</p> : null}
        <div className="flex justify-center gap-6 text-sm">
          <button type="button" onClick={() => setTab('followers')} className="min-h-11 px-2"><strong className="block text-lg">{counts.followers}</strong>Followers</button>
          <button type="button" onClick={() => setTab('following')} className="min-h-11 px-2"><strong className="block text-lg">{counts.following}</strong>Following</button>
        </div>
        {mine ? <Link href="/profile/edit" className="font-semibold text-brand-purple underline">Edit your profile</Link> : (
          <div className="flex justify-center gap-2">
            <Button loading={busy} variant={following ? 'secondary' : 'primary'} onClick={toggle}>{following ? 'Unfollow' : 'Follow'}</Button>
            <Button variant="secondary" onClick={() => router.push(`/messages/new?user=${uid}`)}>Message</Button>
          </div>
        )}
      </Card>
      {tab ? (
        <section aria-label={tab} className="space-y-2">
          <h2 className="font-bold capitalize">{tab}</h2>
          {rows === null ? <LoadingState /> : !rows.length ? <EmptyState title="Nobody here yet" /> : (
            <ul className="space-y-2">{rows.map((r) => <li key={r.uid}><Link href={`/user/${r.uid}`}><Card className="flex items-center gap-3"><Avatar name={r.name} src={r.photoURL} /><div className="min-w-0"><p className="truncate font-semibold">{r.name}</p>{r.username ? <p className="text-sm text-brand-purple">@{r.username}</p> : null}</div></Card></Link></li>)}</ul>
          )}
        </section>
      ) : null}
    </div>
  );
}
export default function Page() { return <AuthGuard><Profile /></AuthGuard>; }
