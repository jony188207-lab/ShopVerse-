'use client';
import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { friendlyError } from '@/lib/firebase/errors';
import { ensureConversation, ensureDirectConversation } from '@/services/chatService';
import { getStore } from '@/services/storeService';

/** /messages/new?user=<uid> opens a private chat with another user.
 *  /messages/new?store=<storeId>[&product=<productId>][&order=<orderId>] -> opens/creates the conversation, then the thread with the reference pre-attached. */
function Inner() {
  const sp = useSearchParams(); const router = useRouter(); const { user } = useAuth();
  const [err, setErr] = useState(''); const storeId = sp.get('store'); const otherUid = sp.get('user');
  useEffect(() => {
    if (!user || (!storeId && !otherUid)) return;
    let cancelled = false;
    (async () => {
      try {
        if (otherUid) { const did = await ensureDirectConversation(user.uid, otherUid); if (!cancelled) router.replace(`/messages/${did}`); return; }
        if (!storeId) return;
        const store = await getStore(storeId);
        if (!store) throw new Error('This store is not available.');
        const id = await ensureConversation(user.uid, store);
        const q = new URLSearchParams(); if (sp.get('product')) q.set('product', sp.get('product')!); if (sp.get('order')) q.set('order', sp.get('order')!);
        if (!cancelled) router.replace(`/messages/${id}${q.size ? `?${q}` : ''}`);
      } catch (e) { if (!cancelled) setErr(e instanceof Error && !('code' in e) ? e.message : friendlyError(e)); }
    })();
    return () => { cancelled = true; };
  }, [user, storeId, otherUid, sp, router]);
  if (!storeId && !otherUid) return <EmptyState title="No one selected" />;
  return err ? <ErrorState title="Could not open the chat" message={err} /> : <LoadingState label="Opening chat…" />;
}
export default function Page() { return <Suspense fallback={<LoadingState />}><Inner /></Suspense>; }
