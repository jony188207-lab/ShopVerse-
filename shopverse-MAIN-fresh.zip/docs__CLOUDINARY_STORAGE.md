# Media storage with Cloudinary (login and data stay in Firebase)

| Service | Does | Does NOT |
|---|---|---|
| Firebase | Login/sign-up (Auth), all data (Firestore), security rules, the user's role | store media when Cloudinary is enabled |
| Cloudinary | Stores and serves images, avatars, store logos/banners, product images and videos, review photos, short videos and thumbnails | login, data, roles |
| Your Vercel site (`/api/media/*`) | Checks the Firebase login, role, ownership, file type and size, and only then **signs** a one-file upload. Holds the Cloudinary API secret. | store files |

Why not upload straight from the browser with an "unsigned preset"? Anyone could then upload anything, forever. Here the browser can upload only what the server signed for **one exact file name inside the user's own folder**, and the server re-checks the real size/format afterwards.

## How an upload works
1. Browser → `POST /api/media/sign` (header `Authorization: Bearer <Firebase ID token>`). The server verifies the token's signature, project and expiry, reads the user's role from Firestore **as that user** (so Firestore rules apply), validates path/type/size and returns signed fields.
2. Browser → Cloudinary directly (progress bar), with those fields.
3. Browser → `POST /api/media/confirm`. The server asks Cloudinary for the stored size and format; if it breaks the limit, the file is **deleted** and the user sees an error. Otherwise the final URL (`…/upload/q_auto,f_auto/…`, automatic compression and best format) is returned and saved in Firestore exactly where the old URL was.
4. Deleting a video later uses `POST /api/media/delete`: only the owner or an admin.

## What is stored where
| Media | Cloudinary folder | Who | Types | Max |
|---|---|---|---|---|
| Profile picture | `shopverse/profiles/<uid>/` | that user | JPG/PNG/WebP/GIF | 5 MB |
| Seller application logo/banner | `shopverse/applications/<uid>/` | that user, verified email | images | 8 MB |
| Store logo/banner | `shopverse/stores/<uid>/` | seller/admin | images | 8 MB |
| Product images | `shopverse/products/<uid>/<productId>/` | seller/admin | images | 10 MB |
| Product video | `shopverse/productVideos/<uid>/<productId>/` | seller/admin | MP4/WebM/MOV | 100 MB |
| Short video + thumbnail | `shopverse/videos/<uid>/<videoId>/` | seller, verified email | video, JPG/PNG/WebP | 100 MB |
| Review photos | `shopverse/reviews/<uid>/<reviewId>/` | the review's author, verified email | JPG/PNG/WebP | 5 MB |

Firestore keeps only the URL (and, for videos, a path like `cld:video/shopverse/videos/<uid>/<id>/<file>` used for deleting). Large files never go into database rows. These are the Cloudinary **free plan** limits (10 MB per image, 100 MB per video); check cloudinary.com/pricing for the current allowance and credits.

## 1. Create a Cloudinary account
1. Go to cloudinary.com → **Sign up for free** (no card needed). Choose "Developer" / any answer for the questionnaire.
2. Open the **Console**. The **Dashboard** shows **Cloud name**. **Settings → API Keys** (or "Product Environment Credentials") shows **API Key** and **API Secret**.
3. Copy them only into Vercel (next step). **Never** paste the API Secret into chat, GitHub, a `NEXT_PUBLIC_*` variable or the code.

## 2. Vercel environment variables (main app project, then redeploy)
| Name | Value | Visible to browser? |
|---|---|---|
| `CLOUDINARY_CLOUD_NAME` | your cloud name | no |
| `CLOUDINARY_API_KEY` | your API key | no |
| `CLOUDINARY_API_SECRET` | your API secret | **no, never** |
| `NEXT_PUBLIC_CLOUDINARY_ENABLED` | `true` | yes (just an on/off switch) |

Vercel → Project → Settings → Environment Variables → add each (Production + Preview) → Deployments → Redeploy. The Firebase project id is already in `NEXT_PUBLIC_FIREBASE_PROJECT_ID`.
Optional hardening in Cloudinary: Settings → Security → turn on "Restricted media types" you do not need, and set an alert on usage.

## 3. Test after deploying (about 10 minutes)
1. Sign in → Profile → Edit → choose a picture → Save. The picture appears; in Cloudinary → Media Library you see `shopverse/profiles/<uid>/…`.
2. As a seller: add a product with 2 images and a video (under 100 MB) → progress shows → product page plays it.
3. Leave a review with a photo (own delivered order) → photo shows.
4. Failure checks: try a 12 MB image (refused before upload); try a `.pdf` renamed to `.jpg` (Cloudinary/our check refuses); sign out in another tab and upload (asks you to sign in); as a customer (not seller) try adding a product video (refused).
5. Delete a short video from the seller area → the file disappears from Cloudinary.

## Security summary
- API secret only in server environment variables; the browser gets a signature, never the secret (a test checks this).
- Firebase token verified (RS256, Google keys, audience, issuer, expiry). Roles are read from Firestore as the caller, so nobody can claim a role in the request.
- Users can upload, confirm and delete only inside their own `<uid>` folder; admins may delete. Nobody can change roles, and Firebase Auth and the Firestore rules are untouched.
- Cloudinary `allowed_formats` is part of the signature, and the real size/format is re-checked after upload (oversize files are deleted).
- Honest limit: a user could skip step 3 (confirm) and leave an oversize file inside their own folder; it would never receive our URL rewrite, and Cloudinary's own plan limits still apply. There is no rate limiting beyond Vercel's defaults.
- Sellers vs customers: the role check is done at signing time from Firestore, so a customer cannot get a product upload signed.

## Rollback
Remove `NEXT_PUBLIC_CLOUDINARY_ENABLED` (or set it to anything but `true`) and redeploy: uploads go back to Firebase Storage immediately (that needs the Blaze plan). Files already uploaded to Cloudinary keep working because their full URLs are stored in Firestore; nothing is deleted by switching back.

## Migrating existing media (only with your approval)
- **Firebase Storage URLs** keep working; nothing was moved or deleted.
- **Supabase URLs** (only if you ever uploaded through the earlier Supabase version): they keep working as long as the Supabase project exists (the site still allows `*.supabase.co` images). To move them:
  1. List the URLs (Firestore Console: `products.images/video`, `profiles.photoURL`, `stores.logoUrl/bannerUrl`, `videos.videoUrl/thumbnailUrl`, `reviews.images`) into a file `urls.json` (a JSON array of `{ "url": "...", "folder": "shopverse/products/<uid>/<productId>" }`).
  2. On a computer with Node 18+, run `CLOUDINARY_CLOUD_NAME=… CLOUDINARY_API_KEY=… CLOUDINARY_API_SECRET=… node scripts/migrate-media-to-cloudinary.mjs urls.json` (add `--dry-run` first). It asks Cloudinary to fetch each file itself and writes `migration-map.json` (old URL → new URL). It does **not** touch Firestore or delete anything.
  3. Review the map, update the URL fields (by hand or with a script you approve), check the pages, and only then delete the Supabase files.

## Status
Server logic (planning, signing, token verification, the three endpoints) has 19 automated tests that pass against fakes of Firebase keys, Firestore and Cloudinary; the signing function reproduces Cloudinary's documented example signature. **Not run:** a real Cloudinary upload, a real Firebase token, a real browser or the Android app, `npm install`, type-check, lint and the production build.
