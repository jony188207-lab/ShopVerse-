// Copies existing media (for example from Supabase) into Cloudinary WITHOUT touching Firestore or deleting anything.
// Usage: CLOUDINARY_CLOUD_NAME=.. CLOUDINARY_API_KEY=.. CLOUDINARY_API_SECRET=.. node scripts/migrate-media-to-cloudinary.mjs urls.json [--dry-run]
// urls.json: [{ "url": "https://xyz.supabase.co/storage/v1/object/public/...", "folder": "shopverse/products/<uid>/<productId>" }]
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const [file, flag] = process.argv.slice(2);
const { CLOUDINARY_CLOUD_NAME: cloud, CLOUDINARY_API_KEY: key, CLOUDINARY_API_SECRET: secret } = process.env;
if (!file || !cloud || !key || !secret) { console.error('Usage: set CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET, then: node scripts/migrate-media-to-cloudinary.mjs urls.json [--dry-run]'); process.exit(1); }
const dry = flag === '--dry-run';
const items = JSON.parse(readFileSync(file, 'utf8'));
const sign = (p) => createHash('sha1').update(Object.keys(p).sort().map((k) => `${k}=${p[k]}`).join('&') + secret).digest('hex');
const map = {};
for (const [i, it] of items.entries()) {
  if (!/^https:\/\//.test(it.url) || !/^shopverse\/[A-Za-z0-9_\/-]+$/.test(it.folder ?? '')) { console.error(`#${i}: skipped (bad url or folder)`); continue; }
  const type = /\.(mp4|webm|mov)(\?|$)/i.test(it.url) ? 'video' : 'image';
  const publicId = `${it.folder}/migrated-${Date.now().toString(36)}-${i}`;
  if (dry) { console.log(`[dry-run] ${it.url} -> ${publicId} (${type})`); continue; }
  const params = { overwrite: 'false', public_id: publicId, timestamp: Math.floor(Date.now() / 1000) };
  const body = new URLSearchParams({ ...params, file: it.url, api_key: key, signature: sign(params) });
  const res = await fetch(`https://api.cloudinary.com/v1_1/${cloud}/${type}/upload`, { method: 'POST', body });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) { console.error(`#${i}: failed (${res.status}) ${j?.error?.message ?? ''}`); continue; }
  map[it.url] = j.secure_url; console.log(`#${i}: ok`);
}
if (!dry) { writeFileSync('migration-map.json', JSON.stringify(map, null, 2)); console.log(`Wrote migration-map.json (${Object.keys(map).length} files). Firestore was NOT changed.`); }
