import { defineConfig } from 'vitest/config';
import path from 'path';
export default defineConfig({
  resolve: { alias: { '@': path.resolve(__dirname, '.') } },
  test: { include: ['utils/**/*.test.ts', 'functions/src/**/*.test.ts', 'services/**/*.test.ts', 'lib/**/*.test.ts'] },
});
