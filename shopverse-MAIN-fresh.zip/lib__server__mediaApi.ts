import { MEDIA, MediaError, ownerOfPublicId, planMedia, SEG, MB } from './mediaPlan';
import { destroy, getUploaded, signUpload, type CloudinaryEnv } from './cloudinary';
import { verifyIdToken, type Claims } from './idToken';

/** Core of the three /api/media/* endpoints, with every outside dependency injected so it can be tested without network, Firebase or Cloudinary. */
export interface Deps {
  projectId: string;
  cloudinary: CloudinaryEnv | null;
  verify?: (token: string, projectId: string) => Promise<Claims>;
  /** Reads one Firestore document AS THE CALLER (their own ID token), so Firestore security rules decide what they may see. Returns fields or null. */
  getDoc: (path: string, idToken: string) => Promise<Record<string, unknown> | null>;
  fetchImpl?: typeof fetch;
  now?: () => number;
  rand?: () => string;
}
const STAFF = ['admin', 'super_admin'];
const randId = () => { const a = new Uint8Array(6); crypto.getRandomValues(a); return Array.from(a, (b) => b.toString(36).padStart(2, '0')).join('').slice(0, 10); };

async function authenticate(d: Deps, authHeader: string | null): Promise<{ claims: Claims; token: string }> {
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  if (!token) throw new MediaError('unauthenticated', 'Please sign in again.');
  try { return { claims: await (d.verify ?? verifyIdToken)(token, d.projectId), token }; } catch { throw new MediaError('unauthenticated', 'Please sign in again.'); }
}
const needCloudinary = (d: Deps): CloudinaryEnv => d.cloudinary ?? (() => { throw new MediaError('internal', 'Media uploads are not configured on the server (CLOUDINARY_* variables).'); })();
const roleOf = async (d: Deps, uid: string, token: string) => String((await d.getDoc(`roles/${uid}`, token))?.role ?? 'user');

export async function handleSign(d: Deps, authHeader: string | null, input: Record<string, unknown>) {
  const c = needCloudinary(d);
  const { claims, token } = await authenticate(d, authHeader);
  const uid = claims.sub;
  const kind = typeof input.path === 'string' ? input.path.split('/')[0] : '';
  const rule = Object.prototype.hasOwnProperty.call(MEDIA, kind) ? MEDIA[kind] : undefined;
  let role = 'user'; let reviewOwner = '';
  if (rule?.roles) role = await roleOf(d, uid, token);
  if (rule?.review) { const rid = String(input.path).split('/')[2] ?? ''; if (SEG.test(rid)) reviewOwner = String((await d.getDoc(`reviews/${rid}`, token))?.userId ?? ''); }
  const now = (d.now ?? Date.now)();
  const plan = planMedia({ uid, emailVerified: claims.email_verified === true, role, input, reviewOwner, rand: (d.rand ?? randId)(), stamp: now.toString(36) });
  return signUpload(c, plan, Math.floor(now / 1000));
}

/** Called by the browser right after the direct upload: checks the REAL stored size/format and removes the file if it breaks the rules. */
export async function handleConfirm(d: Deps, authHeader: string | null, input: Record<string, unknown>) {
  const c = needCloudinary(d);
  const { claims } = await authenticate(d, authHeader);
  const publicId = typeof input.publicId === 'string' ? input.publicId : '';
  const resourceType = input.resourceType === 'video' ? 'video' : 'image';
  const owner = ownerOfPublicId(publicId);
  if (!owner) throw new MediaError('invalid-argument', 'Unknown file.');
  if (owner.uid !== claims.sub) throw new MediaError('permission-denied', 'You can only confirm your own files.');
  const up = await getUploaded(c, resourceType, publicId, d.fetchImpl);
  if (!up) throw new MediaError('not-found', 'The upload was not found. Try again.');
  const rule = MEDIA[owner.kind];
  const okFormat = rule.formats.split(',').includes(up.format.toLowerCase());
  if (up.bytes > rule.max || !okFormat) {
    await destroy(c, resourceType, publicId, d.fetchImpl).catch(() => undefined);
    throw new MediaError('invalid-argument', up.bytes > rule.max ? `This file is larger than ${Math.round(rule.max / MB)} MB.` : 'This file type is not allowed here.');
  }
  // q_auto,f_auto: Cloudinary compresses and picks the best format for each viewer at delivery time.
  return { url: up.secure_url.replace('/upload/', '/upload/q_auto,f_auto/'), path: `cld:${resourceType}/${publicId}` };
}

export async function handleDelete(d: Deps, authHeader: string | null, input: Record<string, unknown>) {
  const c = needCloudinary(d);
  const { claims, token } = await authenticate(d, authHeader);
  const publicId = typeof input.publicId === 'string' ? input.publicId : '';
  const resourceType = input.resourceType === 'video' ? 'video' : 'image';
  const owner = ownerOfPublicId(publicId);
  if (!owner) throw new MediaError('invalid-argument', 'Unknown file.');
  if (owner.uid !== claims.sub && !STAFF.includes(await roleOf(d, claims.sub, token))) throw new MediaError('permission-denied', 'You can only delete your own files.');
  await destroy(c, resourceType, publicId, d.fetchImpl, Math.floor(((d.now ?? Date.now)()) / 1000));
  return { ok: true };
}
