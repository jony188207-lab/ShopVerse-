/** Firebase ID token verification with Web Crypto (RS256 against Google's public signing keys). No Admin SDK, no service account, no secret. */
const JWKS_URL = 'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com';
const te = new TextEncoder();
const td = new TextDecoder();
const unb64u = (s: string): Uint8Array => { const t = s.replace(/-/g, '+').replace(/_/g, '/'); const bin = atob(t + '='.repeat((4 - (t.length % 4)) % 4)); return Uint8Array.from(bin, (c) => c.charCodeAt(0)); };
const part = (p: string): Record<string, unknown> => JSON.parse(td.decode(unb64u(p)));

export interface Claims { sub: string; email_verified?: boolean; [k: string]: unknown }
export type KeyLoader = () => Promise<Record<string, JsonWebKey>>;

let cache: { at: number; keys: Map<string, CryptoKey> } = { at: 0, keys: new Map() };
export const resetKeyCache = () => { cache = { at: 0, keys: new Map() }; };
const defaultLoader: KeyLoader = async () => {
  const res = await fetch(JWKS_URL);
  if (!res.ok) throw new Error('Could not load Google signing keys.');
  const { keys = [] } = (await res.json()) as { keys?: (JsonWebKey & { kid: string })[] };
  return Object.fromEntries(keys.map((k) => [k.kid, k]));
};

/** Throws Error('unauthenticated') for any invalid token. */
export async function verifyIdToken(token: string, projectId: string, load: KeyLoader = defaultLoader, nowMs = Date.now()): Promise<Claims> {
  const bad = (): never => { throw new Error('unauthenticated'); };
  const parts = token.split('.');
  if (parts.length !== 3) return bad();
  let header: Record<string, unknown>; let payload: Record<string, unknown>;
  try { header = part(parts[0]); payload = part(parts[1]); } catch { return bad(); }
  if (header.alg !== 'RS256' || typeof header.kid !== 'string') return bad();
  if (!cache.keys.has(header.kid) || nowMs - cache.at > 3600_000) {
    const jwks = await load();
    const map = new Map<string, CryptoKey>();
    for (const [kid, jwk] of Object.entries(jwks)) map.set(kid, await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']));
    cache = { at: nowMs, keys: map };
  }
  const key = cache.keys.get(header.kid);
  if (!key) return bad();
  if (!(await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, unb64u(parts[2]), te.encode(`${parts[0]}.${parts[1]}`)))) return bad();
  const now = Math.floor(nowMs / 1000);
  if (payload.aud !== projectId || payload.iss !== `https://securetoken.google.com/${projectId}`) return bad();
  if (typeof payload.sub !== 'string' || !payload.sub || payload.sub.length > 128) return bad();
  if (typeof payload.exp !== 'number' || payload.exp <= now) return bad();
  if (typeof payload.iat === 'number' && payload.iat > now + 300) return bad();
  return payload as Claims;
}
