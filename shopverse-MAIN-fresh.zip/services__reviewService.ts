import { average, collection, count, doc, getAggregateFromServer, getCountFromServer, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, updateDoc, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { OrderItem, Product, Review } from '@/types';
import { mapReview } from './mappers';
import type { Page } from './productService';
import { uploadFile } from './uploadService';

export async function listReviews(productId: string, cursor: QueryDocumentSnapshot | null = null, pageSize = 10): Promise<Page<Review>> {
  const c = [where('productId', '==', productId), where('status', '==', 'published'), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(pageSize)];
  const s = await getDocs(query(collection(db(), 'reviews'), ...c));
  return { items: s.docs.map((d) => mapReview(d.id, d.data())), cursor: s.docs.at(-1) ?? null, hasMore: s.size === pageSize };
}
export async function getMyReview(orderItemId: string): Promise<Review | null> {
  try { const s = await getDoc(doc(db(), 'reviews', orderItemId)); return s.exists() ? mapReview(s.id, s.data()) : null; } catch { return null; }
}

/** Review id == orderItemId (one review per purchase). Rules require a delivered order item owned by the reviewer => verified purchase. */
export async function createReview(uid: string, userName: string, item: OrderItem, rating: number, text: string, files: File[]): Promise<void> {
  const ref = doc(db(), 'reviews', item.id);
  await setDoc(ref, {
    orderItemId: item.id, productId: item.productId, sellerId: item.sellerId, userId: uid, userName: userName.slice(0, 60) || 'Verified buyer',
    rating, text: text.trim().slice(0, 2000), images: [], status: 'published', verifiedPurchase: true, createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  if (files.length) {
    // Storage rules only accept review media after the review doc exists and belongs to the uploader.
    const urls = await Promise.all(files.slice(0, 4).map((f, i) => uploadFile(`reviews/${uid}/${item.id}/${Date.now()}-${i}-${f.name}`, f, { maxMB: 5, image: true })));
    await updateDoc(ref, { images: urls, updatedAt: serverTimestamp() });
  }
}

/** Report id is deterministic, so a second report by the same user is rejected by rules (reports can't be updated by users). */
export const reportReview = (uid: string, reviewId: string, reason: string) =>
  setDoc(doc(db(), 'reports', `${uid}_review_${reviewId}`), { reporterId: uid, targetType: 'review', targetId: reviewId, reason: reason.slice(0, 300), status: 'open', createdAt: serverTimestamp() });

/** Live rating summary computed from the published reviews themselves (works without the Cloud Function that maintains product.rating). */
export interface ReviewStats { count: number; average: number; distribution: Record<'1' | '2' | '3' | '4' | '5', number> }
export async function reviewStats(productId: string): Promise<ReviewStats> {
  const base = [where('productId', '==', productId), where('status', '==', 'published')] as const;
  const [agg, ...per] = await Promise.all([
    getAggregateFromServer(query(collection(db(), 'reviews'), ...base), { n: count(), avg: average('rating') }),
    ...[1, 2, 3, 4, 5].map((n) => getCountFromServer(query(collection(db(), 'reviews'), ...base, where('rating', '==', n)))),
  ]);
  const dist = { '1': per[0].data().count, '2': per[1].data().count, '3': per[2].data().count, '4': per[3].data().count, '5': per[4].data().count };
  return { count: agg.data().n, average: Math.round((agg.data().avg ?? 0) * 10) / 10, distribution: dist };
}

/** The signed-in user's own review of this product (verified or not), if any. Used to stop a second review. */
export async function getMyProductReview(uid: string, productId: string): Promise<Review | null> {
  const s = await getDocs(query(collection(db(), 'reviews'), where('userId', '==', uid), where('productId', '==', productId), limit(1)));
  return s.empty ? null : mapReview(s.docs[0].id, s.docs[0].data());
}

/** Open review (no order needed): id = uid_productId so a user can review a product only once. Always saved as NOT a verified purchase (rules enforce this). */
export async function createOpenReview(uid: string, userName: string, product: Pick<Product, 'id' | 'sellerId'>, rating: number, text: string): Promise<void> {
  if (!(rating >= 1 && rating <= 5)) throw new Error('Choose a star rating.');
  await setDoc(doc(db(), 'reviews', `${uid}_${product.id}`), {
    orderItemId: '', productId: product.id, sellerId: product.sellerId, userId: uid, userName: userName.trim().slice(0, 60) || 'ShopVerse user',
    rating, text: text.trim().slice(0, 2000), images: [], status: 'published', verifiedPurchase: false, createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
}
