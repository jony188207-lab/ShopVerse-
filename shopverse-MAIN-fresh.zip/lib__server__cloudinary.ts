import { createHash } from 'node:crypto';

/** Server-only Cloudinary helpers. The API secret is read from the environment HERE and nowhere else; it never reaches the browser. */
export interface CloudinaryEnv { cloudName: string; apiKey: string; apiSecret: string }
export function cloudinaryEnv(env: Record<string, string | undefined> = process.env): CloudinaryEnv | null {
  const cloudName = env.CLOUDINARY_CLOUD_NAME?.trim(); const apiKey = env.CLOUDINARY_API_KEY?.trim(); const apiSecret = env.CLOUDINARY_API_SECRET?.trim();
  return cloudName && apiKey && apiSecret && /^[a-z0-9_-]+$/i.test(cloudName) ? { cloudName, apiKey, apiSecret } : null;
}

/** Cloudinary signature: SHA-1 of "k=v&k=v" (keys sorted, file/api_key/resource_type/cloud_name excluded) + secret. */
export function signParams(params: Record<string, string | number>, secret: string): string {
  const str = Object.keys(params).filter((k) => params[k] !== '' && params[k] !== undefined).sort().map((k) => `${k}=${params[k]}`).join('&');
  return createHash('sha1').update(str + secret).digest('hex');
}

export interface SignedUpload { uploadUrl: string; fields: Record<string, string | number>; publicId: string; resourceType: 'image' | 'video' }
export function signUpload(c: CloudinaryEnv, plan: { resourceType: 'image' | 'video'; publicId: string; allowedFormats: string }, timestamp: number): SignedUpload {
  const signed = { allowed_formats: plan.allowedFormats, public_id: plan.publicId, timestamp, overwrite: 'false' };
  const signature = signParams(signed, c.apiSecret);
  return { uploadUrl: `https://api.cloudinary.com/v1_1/${c.cloudName}/${plan.resourceType}/upload`, fields: { ...signed, api_key: c.apiKey, signature }, publicId: plan.publicId, resourceType: plan.resourceType };
}

const basic = (c: CloudinaryEnv) => `Basic ${Buffer.from(`${c.apiKey}:${c.apiSecret}`).toString('base64')}`;
const encId = (id: string) => id.split('/').map(encodeURIComponent).join('/');

export interface Uploaded { bytes: number; format: string; secure_url: string }
/** Reads what Cloudinary actually stored (size + format) so the server can reject an oversized or wrong-type file after the direct upload. */
export async function getUploaded(c: CloudinaryEnv, resourceType: string, publicId: string, f: typeof fetch = fetch): Promise<Uploaded | null> {
  const res = await f(`https://api.cloudinary.com/v1_1/${c.cloudName}/resources/${resourceType}/upload/${encId(publicId)}`, { headers: { Authorization: basic(c) } });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`cloudinary lookup failed (${res.status})`);
  const j = (await res.json()) as Partial<Uploaded>;
  return { bytes: Number(j.bytes ?? 0), format: String(j.format ?? ''), secure_url: String(j.secure_url ?? '') };
}

/** Deletes one asset (signed request). Returns true when it existed. */
export async function destroy(c: CloudinaryEnv, resourceType: string, publicId: string, f: typeof fetch = fetch, timestamp = Math.floor(Date.now() / 1000)): Promise<boolean> {
  const params = { invalidate: 'true', public_id: publicId, timestamp };
  const body = new URLSearchParams({ ...Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)])), api_key: c.apiKey, signature: signParams(params, c.apiSecret) });
  const res = await f(`https://api.cloudinary.com/v1_1/${c.cloudName}/${resourceType}/destroy`, { method: 'POST', body });
  if (!res.ok) throw new Error(`cloudinary delete failed (${res.status})`);
  return ((await res.json()) as { result?: string }).result === 'ok';
}
