import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Conversation } from '@/types/chat';
import { getStoresMap } from './storeService';

const profileCache = new Map<string, { name: string; photo: string }>();
async function profileInfo(uid: string): Promise<{ name: string; photo: string }> {
  if (profileCache.has(uid)) return profileCache.get(uid)!;
  const d = (await getDoc(doc(db(), 'profiles', uid)).catch(() => null))?.data();   // profiles are public by design (name + avatar only)
  const v = { name: String(d?.displayName ?? 'Shopper'), photo: String(d?.photoURL ?? '') };
  profileCache.set(uid, v);
  return v;
}
async function profileName(uid: string): Promise<string> { return (await profileInfo(uid)).name; }
/** For each conversation: the OTHER side's display name + picture (store for buyers, profile for sellers and for user-to-user chats). */
export async function getPeerNames(me: string, list: Conversation[]): Promise<Map<string, { name: string; logo: string }>> {
  const buyerSide = list.filter((c) => c.kind !== 'dm' && c.buyerId === me);
  const stores = await getStoresMap(buyerSide.map((c) => c.storeId));
  const out = new Map<string, { name: string; logo: string }>();
  await Promise.all(list.map(async (c) => {
    if (c.kind === 'dm') { const p = await profileInfo(c.participants.find((u) => u !== me) ?? ''); out.set(c.id, { name: p.name, logo: p.photo }); }
    else if (c.buyerId === me) { const s = stores.get(c.storeId); out.set(c.id, { name: s?.name ?? 'Store', logo: s?.logoUrl ?? '' }); }
    else { const p = await profileInfo(c.buyerId); out.set(c.id, { name: p.name, logo: p.photo }); }
  }));
  return out;
}
export const nameOfUser = profileName;
