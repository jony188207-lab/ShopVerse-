import { auth } from '@/lib/firebase/config';

/**
 * Cloudinary for media (images, avatars, videos). Login and all data stay in Firebase.
 * Flow (the API secret never reaches the browser):
 *   1. POST /api/media/sign     -> our server checks the Firebase login, role, ownership, type and size, and returns a SIGNED upload for one exact file name.
 *   2. The browser uploads the file straight to Cloudinary (with progress).
 *   3. POST /api/media/confirm  -> our server asks Cloudinary for the real size/format, removes the file if it breaks the rules, and returns the final URL.
 * Enabled only when NEXT_PUBLIC_CLOUDINARY_ENABLED=true (a plain on/off switch, not a secret). Otherwise uploads use Firebase Storage exactly as before.
 * Stored paths look like "cld:<image|video>/<public_id>" so the owner can delete the file later.
 */
export const cloudinaryEnabled = (): boolean => process.env.NEXT_PUBLIC_CLOUDINARY_ENABLED === 'true';

async function api<T>(route: string, body: unknown): Promise<T> {
  const u = auth().currentUser;
  if (!u) throw new Error('Please sign in again.');
  let res: Response;
  try { res = await fetch(route, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${await u.getIdToken()}` }, body: JSON.stringify(body) }); }
  catch { throw new Error('Could not reach the upload service. Check your connection and try again.'); }
  const j = (await res.json().catch(() => ({}))) as { error?: { message?: string } } & T;
  if (!res.ok) throw new Error(j.error?.message || 'The upload service refused this request.');
  return j;
}

function post(url: string, fields: Record<string, string | number>, file: File, onProgress?: (pct: number) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.timeout = file.type.startsWith('video/') ? 10 * 60_000 : 2 * 60_000;
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress?.(Math.round((e.loaded / e.total) * 100)); };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve();
      let m = ''; try { m = (JSON.parse(xhr.responseText) as { error?: { message?: string } }).error?.message ?? ''; } catch { /* not JSON */ }
      reject(new Error(m ? `Upload failed: ${m}` : xhr.status === 413 ? 'This file is too large for the storage service.' : `Upload failed (${xhr.status}).`));
    };
    xhr.onerror = () => reject(new Error('The upload failed. Check your connection and try again.'));
    xhr.ontimeout = () => reject(new Error('The upload took too long. Try a smaller file or a better connection.'));
    const form = new FormData();
    for (const [k, v] of Object.entries(fields)) form.append(k, String(v));
    form.append('file', file);          // the file must be the last field
    xhr.send(form);
  });
}

/** `path` is the logical path the app already uses, e.g. profiles/<uid>/photo.webp or products/<uid>/<productId>/1.webp. Returns the public URL and a deletable path. */
export async function uploadViaCloudinary(path: string, file: File, onProgress?: (pct: number) => void): Promise<{ url: string; path: string }> {
  const s = await api<{ uploadUrl: string; fields: Record<string, string | number>; publicId: string; resourceType: 'image' | 'video' }>('/api/media/sign', { path, contentType: file.type, size: file.size });
  await post(s.uploadUrl, s.fields, file, onProgress);
  return api<{ url: string; path: string }>('/api/media/confirm', { publicId: s.publicId, resourceType: s.resourceType });
}

/** Deletes a file recorded as "cld:<type>/<public_id>" (owner or admin only; the server checks). Old "sb:" (Supabase) and Firebase paths are ignored here. */
export async function removeFromCloudinary(stored: string): Promise<void> {
  const m = /^cld:(image|video)\/(.+)$/.exec(stored);
  if (!m) return;
  await api('/api/media/delete', { resourceType: m[1], publicId: m[2] }).catch(() => undefined);
}
