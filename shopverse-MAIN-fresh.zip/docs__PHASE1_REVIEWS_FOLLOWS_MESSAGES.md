# Phase 1: reviews, followers/following, user-to-user messages (no Cloud Functions needed)

## Why they were broken
- **Reviews:** the rules only allowed a review for a *delivered order*. Orders are created by the `placeOrder` Cloud Function (Blaze plan), so on the free plan there was never a delivered order, hence no review. The product's star summary was also written by a Cloud Function.
- **Followers/following:** the follow lists were private by design (you could only read follows you made or that pointed at you), and the counters were never filled in without Cloud Functions. There was no public user profile page.
- **Messages:** chats existed only between a buyer and a store. The inbox preview and unread badge were maintained by a Cloud Function.

## What changed (which database does what)
| Feature | Where it lives | How it stays consistent |
|---|---|---|
| Reviews | Firestore `reviews/{id}` (unchanged collection). Verified purchases keep id = orderItemId. New "open" reviews use id = `uid_productId` (one per user per product) and are labelled "Not a verified purchase". | Star average and the 1-5 bars are computed live from the published reviews (aggregate queries), not from a stored counter. |
| Follows | Firestore `follows/{follower_target}` (unchanged collection). Now readable by signed-in users. | Counts come from count queries over the same documents, so they are always correct and update right after a follow/unfollow. The id makes duplicates impossible; rules refuse self-follows and unknown users. |
| Public profile | New page `/user/<uid>`: name, @username, picture, bio, counts, Follow/Unfollow, Message, public follower/following lists. Reads only `profiles` (public by design). Email, phone, addresses are never read. |  |
| User-to-user chat | Firestore `conversations/{smallerUid__largerUid}` with `kind: 'dm'`, messages in the usual `messages` sub-collection. Buyer-store chats are unchanged. | Only the two participants can read. The sender updates `lastMessage` and the receiver's `unread +1` in the same batch as the message (rules allow exactly that). |

## Security notes
- Review stars/text only for open reviews (no photos); never for your own product; product must be approved; email must be verified.
- Follow lists expose only two user ids and a date. This is a deliberate change from "private".
- If you ever deploy the Cloud Functions, `onMessageCreated` would ALSO bump unread/preview, so unread counts would double. Remove one of the two then.

## Still not working without Blaze
Order-driven notifications, new-message notifications/push and the product star field stored on the product document.

## Test status
Rules tests for all of this are written in `tests/firestore.rules.test.ts` ("PHASE 1") but need the Firebase emulator and were NOT run here. Build, lint and type-check were NOT run (npm registry blocked in this workspace).
