# Cloudflare R2 uploads (replaces Firebase Storage)

Firebase **Auth, Firestore, Cloud Functions and FCM are unchanged**. Only file storage moved: product images, profile pictures,
store logos/banners, seller-application images, review photos/videos, videos + thumbnails, category icons and home banners now go to Cloudflare R2.

## How an upload works (and why it is safe)
1. The browser asks `POST /api/upload/sign` with its **Firebase ID token** (`Authorization: Bearer …`), the object key, content type and size.
2. The server verifies the token (signature, issuer, audience, expiry), looks up the user's role / review ownership in Firestore **using the user's own token** (so Firestore rules still apply), and applies `lib/r2/policy.ts`
   (the rules that used to live in `storage.rules`: ownership, file type, size caps, verified email, admin-only banners/categories).
3. Only if allowed, it returns a **presigned PUT URL** valid for 5 minutes, locked to that exact key, content type and size. The browser uploads straight to R2 (with progress).
4. `POST /api/upload/delete` removes an object (owner, staff, or admin for banners/categories).

The R2 **Secret Access Key exists only in server environment variables**. It is never sent to the browser, never in `NEXT_PUBLIC_*`, never in git.

## Environment variables
| Variable | Where | Secret? | Meaning |
|---|---|---|---|
| `R2_ACCOUNT_ID` | server | no | Cloudflare account id (R2 → Overview) |
| `R2_ACCESS_KEY_ID` | server | **yes** | R2 API token Access Key ID |
| `R2_SECRET_ACCESS_KEY` | server | **YES** | R2 API token Secret Access Key |
| `R2_BUCKET` | server | no | Bucket name |
| `R2_PUBLIC_BASE_URL` | server (also read by `next.config.mjs`) | no | Public URL of the bucket, no trailing slash, e.g. `https://media.example.com` |
| `NEXT_PUBLIC_FIREBASE_*` | public | no | Existing Firebase web config (unchanged). `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` is **no longer used** |

Set them in Vercel → Project → Settings → Environment Variables (and `.env.local` for local dev). Redeploy after changing them.

## One-time Cloudflare setup
1. **R2 → Create bucket** (any name, e.g. `shopverse-media`).
2. **Public access**: bucket → Settings → *Custom Domains* (recommended, gets Cloudflare CDN caching) or enable the `r2.dev` URL (rate-limited, for testing). Put that URL in `R2_PUBLIC_BASE_URL`.
3. **API token**: R2 → *Manage R2 API Tokens* → Create → permission **Object Read & Write**, scoped to this one bucket. Copy the Access Key ID and Secret (shown once).
4. **CORS** (bucket → Settings → CORS policy). Replace the origin with your real site URL(s):
```json
[
  {
    "AllowedOrigins": ["https://your-domain.example", "http://localhost:3000"],
    "AllowedMethods": ["PUT", "GET", "HEAD"],
    "AllowedHeaders": ["Content-Type"],
    "ExposeHeaders": ["ETag"],
    "MaxAgeSeconds": 3600
  }
]
```
5. Install and deploy: `npm install` (adds `@aws-sdk/client-s3`, `@aws-sdk/s3-request-presigner`, `jose`), then deploy to Vercel (or any Node host; the API routes need the Node runtime, so a static export will not work).

## Notes and limits
* Object keys are unchanged (`products/{sellerId}/{productId}/…`, `videos/{uid}/{videoId}/…`, `reviews/{uid}/{reviewId}/…`, …), so existing `videoPath` fields keep working.
* Files already stored in Firebase Storage are **not migrated** by this change; their old URLs keep whatever Firestore stored, but `next/image` no longer allows Firebase Storage hosts. Re-upload or migrate them if you have any.
* Public R2 URLs are unguessable-by-key but not access-controlled: a hidden review photo or unpublished video stays reachable by anyone who already has its URL. Delete the object when content is removed if that matters.
* There is no per-user upload quota yet (same as before); add Cloudflare rate-limiting rules on `/api/upload/*` and a billing alert.
* If **App Check is enforced for Firestore**, the server's role lookup (REST, no App Check token) will be denied and everything falls back to the `user` role. Either keep Firestore App Check in unenforced/monitor mode, or move the lookup to the Admin SDK.
