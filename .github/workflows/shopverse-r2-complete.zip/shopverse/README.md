# ShopVerse — customer & seller app
Shop • Watch • Shop. Next.js 14 (App Router) · TypeScript · Tailwind · Firebase project **`shopverse21-831fc`** (Auth, Firestore, FCM, Cloud Functions) + **Cloudflare R2** for images and videos.

This repository is the **customer + seller app** and the shared Firebase backend code (rules, indexes, Cloud Functions). The **Admin App is a separate project** that uses the same Firebase project; it is not in this repository (see `docs/ADMIN_APP_CONTRACT.md`).

## Honest status (read first)
| | |
|---|---|
| Built and reviewed | Customer and seller screens, Firestore rules, R2 upload policy, indexes, Cloud Functions source, unit/rules tests. |
| **Never run against your live Firebase project** | Nothing here has been deployed or exercised end to end. |
| **Not executed by the author** | `npm install`, `npm run build`, `typecheck`, `lint`, `npm test`, `npm run test:rules` (the authoring environment had no access to the npm registry). Offline checks were run instead: `npm run validate:all` (config, rules structure, index coverage) and an import/export consistency scan. |
| Needs a paid Firebase plan (Blaze) | **Cloud Functions** (see next section). Uploads use Cloudflare R2, see `docs/R2_SETUP.md`. Nothing in this repo enables billing. |

## What works on the free Spark plan, and what does not
| Feature | Spark (free) | Why |
|---|---|---|
| Email/Password sign-up, login, logout, password reset, email verification | Yes | Firebase Auth is free. |
| Firestore reads/writes (browse, cart, wishlist, addresses, chat, follows…) | Yes, within the free daily quota | Going over a quota shuts Firestore off until it resets. |
| Firestore rules + indexes | Yes | Deploying them is free. |
| Push notifications (FCM) | Sending needs a Cloud Function, see below | The in-app notification feed is also written by functions. |
| **Checkout / place order, cancel, return, coupon preview** | **No** | Orders can only be created by the `placeOrder` Cloud Function (the rules forbid client-created orders on purpose). |
| **Seller approval, roles, store creation, commission, earnings, withdrawals** | **No** | Done by Cloud Functions (`reviewSellerApplication`, `releaseEarnings`, `requestWithdrawal`, …). Nothing on the client is trusted for money or roles. |
| **Rating / follower / like counters, notifications, scheduled jobs** | **No** | Maintained by Firestore triggers and Cloud Scheduler. |
| **Image and video uploads** (products, logos, banners, reviews, avatars, videos) | **Yes** | Stored in Cloudflare R2 through `/api/upload/*` (needs the `R2_*` variables, see `docs/R2_SETUP.md`). |

Free replacements (a free serverless backend, a free media host such as Cloudinary) are possible but **not implemented**: they need design work and your approval. Until then, the features marked "No" are unavailable on Spark. They are not faked or hidden.

## Environment variables
All variables are read in `lib/firebase/config.ts`, `lib/siteUrl.ts`, `app/api/assetlinks/route.ts`, `components/PwaRegister.tsx` and `scripts/generate-sw.mjs`. Copy `.env.example` to `.env.local` for local work and set the same names in Vercel.

| Variable | Required | Value |
|---|---|---|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | **Yes** | Firebase Console web app config (public by design). |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | **Yes** | Firebase Console web app config. |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | **Yes** | `shopverse21-831fc` |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | **Yes** | `shopverse21-831fc.firebaseapp.com` |
| `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET`, `R2_PUBLIC_BASE_URL` | **Yes for uploads** | Server-only Cloudflare R2 settings (the secret key must never be public). See `docs/R2_SETUP.md` |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | **Yes** | `413026494596` |
| `NEXT_PUBLIC_SITE_URL` | **Yes in production** | Your public URL, e.g. `https://your-app.vercel.app`, no trailing slash. Without it, sitemap and share links point to `http://localhost:3000`. |
| `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` | No | Console web app config (analytics is not initialised). |
| `NEXT_PUBLIC_FIREBASE_VAPID_KEY` | No | Console → Project settings → Cloud Messaging → Web Push certificates (public key). Push stays off without it. |
| `NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION` | No | Default `us-central1`. Must match `functions/src/common.ts`. |
| `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` | No | App Check reCAPTCHA v3 **site** key (public). |
| `ANDROID_PACKAGE_NAME`, `ANDROID_CERT_SHA256` | Only for the Android TWA app | Server-side; public values used by `/.well-known/assetlinks.json`. |

**Never** put a service-account JSON, Admin SDK private key or any server secret in these variables, in `NEXT_PUBLIC_*`, or in git. Nothing in this app needs one: Cloud Functions use Google's built-in credentials when deployed.

**The "Firebase is not configured" warning** appears whenever `API_KEY`, `PROJECT_ID` or `APP_ID` is missing **at build time**. `NEXT_PUBLIC_*` values are baked into the build, so after adding or changing them in Vercel you must **redeploy** (a new build), not just save.

## Vercel deployment (from an Android phone)
Use Chrome and switch on **Desktop site** (⋮ menu) for the Vercel and Firebase dashboards.
1. Put the project (the ZIP's contents, with `package.json` at the repository root) in a Git repository on GitHub/GitLab/Bitbucket. To my knowledge Vercel imports from Git; it does not take a ZIP in the dashboard.
2. vercel.com → **Add New… → Project** → import the repository. Framework: **Next.js** (auto-detected). Leave build/output settings at their defaults (`npm run build`).
3. Before the first deploy, open **Environment Variables** and add every **Required** variable above for **Production** (also tick **Preview** if you use previews). Paste values exactly, with no quotes or spaces.
4. Tap **Deploy**. If you added variables later: Project → **Deployments** → latest → ⋮ → **Redeploy**.
5. Copy your production domain, then:
   - set `NEXT_PUBLIC_SITE_URL` to it and redeploy;
   - Firebase Console → **Authentication → Settings → Authorized domains → Add domain** → add the domain (without `https://`).
6. Vercel's free **Hobby** plan is for non-commercial use. A real marketplace needs a plan that allows commercial use.

## Firebase Console setup (Spark-compatible parts)
Exact tap-by-tap steps for Firestore are in `docs/FIREBASE_SETUP.md`. Summary:
1. **Authentication → Sign-in method → Email/Password → Enable** (also recommended: *Settings → User actions → email enumeration protection*).
2. **Firestore Database → Create database** (Native/standard mode, production mode, pick a region: it cannot be changed later).
3. **Rules:** Firestore Database → **Rules** tab → select all → paste the whole of `firestore.rules` → **Publish**. Free. Roll back from the Rules history.
4. **Indexes:** `firestore.indexes.json` (58 composite indexes + 1 field override) cannot be pasted into the Console. Deploy it with the Firebase CLI (below). Free. Wait until every index shows **Enabled**.
5. **First super admin** (optional, only when you use the Admin App): sign up and verify, copy your **User UID** (Authentication → Users), then Firestore → Start collection `roles` → document ID = your UID → field `role` (string) = `super_admin`. This is the only way to create a role by hand; no client can write `roles`.

### Deploying rules and indexes with the CLI
```bash
npm install
npx firebase login
npm run deploy:free            # DRY RUN: prints exactly what it would do
npm run deploy:free -- --yes   # deploys ONLY firestore:rules + firestore:indexes to shopverse21-831fc
```
`scripts/deploy.mjs` refuses any other project, runs the validators first, and never deploys without `--yes`.

### Cloud Functions (require Blaze, not enabled by anything here)
Only if **you** decide to upgrade (Console → Upgrade; set a budget alert first):
2. `npm run install:functions`, then `npm run deploy:functions -- --yes` (Node 20, region `us-central1`).
3. Re-deploy rules/functions from this repository whenever either app changes them.

## Security model (what to trust)
* **Rules are the enforcement.** `AuthGuard` and hidden menus are UI only.
* **Roles** (`user`, `seller`, `moderator`, `admin`, `super_admin`) live in `roles/{uid}` and are written **only** by Cloud Functions or by you in the Console. Rules read them via `roleOf()`; callable functions re-check them server-side (`requireRole` in `functions/src/common.ts`).
* **Money and stock are server-only:** orders, order items, earnings, balances, withdrawals and notifications cannot be created or changed by any client. `placeOrder` recomputes price, stock, shipping, coupons and totals inside a Firestore transaction and is idempotent (`checkouts/{uid}_{checkoutId}`). It requires a verified email, an active (non-suspended) account, and refuses buying your own product. Only cash on delivery is supported; **no client payment confirmation is trusted**.
* **Private data:** users, addresses, carts, wishlists, orders and notification settings are readable only by their owner (and admins where listed in the rules). Sellers see only their own orders and finances.
* **Upload API** (`/api/upload/sign`) verifies the Firebase ID token, then checks ownership, role, content type (jpeg/png/webp/gif images, mp4/webm/quicktime video) and size before issuing a short-lived R2 upload URL; unknown paths are denied.
* Cloud Functions use Application Default Credentials: no key file exists anywhere in this project (`npm run validate:all` scans for private keys and the old project id).

## Tests
| Command | What it covers | Status in the authoring environment |
|---|---|---|
| `npm run validate:all` | Config consistency, rules structure audit, index coverage for 24 client queries | **Ran and passed** |
| Import/export scan (offline, one-off) | Every import resolves, named imports exist, Next.js page/layout/route export rules | **Ran and passed** (0 problems) |
| `npm test` | Unit tests: cart math, order pricing/coupon/stock logic, notification logic, redirects, auth service orchestration (`services/authService.test.ts`) | **Not run** (needs `npm install`) |
| `npm run test:rules` | Firestore rules on the local emulator (needs Java 11+): roles, private data, orders, money, reviews, usernames, uploads | **Not run** (needs `npm install`, Java, emulator download) |
| `npm run typecheck`, `npm run typecheck:functions`, `npm run lint`, `npm run build` | Type-check app (+ tests), type-check functions, lint, production build | **Not run** |

Not covered by any automated test: Cloud Functions against the emulator (checkout, seller approval, withdrawals, admin operations) and browser end-to-end flows. Test those manually using `SMOKE_TEST.md` after deploying.

## Manual actions you must do (Android phone)
1. Fill `NEXT_PUBLIC_*` variables in Vercel (above) and redeploy.
2. Firebase Console: enable Email/Password; create Firestore; publish `firestore.rules` (Rules tab); add your Vercel domain to Authorized domains.
3. Deploy `firestore.indexes.json` (needs the Firebase CLI on a computer or a free cloud shell: see `docs/FIREBASE_SETUP.md` §2).
4. Optional: create the first `super_admin` role document in the Console.
5. Decide whether to approve Blaze (needed for Functions); until then checkout, seller approval and withdrawals are unavailable. Uploads work once R2 is configured.
6. Run through `SMOKE_TEST.md` on your phone after the first deploy and report any error text.

## Layout
`app/` pages and API route · `components/` UI · `services/` Firestore/Auth/Storage/Functions access · `hooks/` · `lib/firebase/` init, errors · `config/`, `types/`, `utils/` · `functions/` Cloud Functions (own `package.json`) · `firestore.rules`, `lib/r2/` (upload policy), `app/api/upload/`, `firestore.indexes.json`, `firebase.json`, `.firebaserc` · `tests/` rules tests · `scripts/` validators and guarded deploy · `android/` TWA wrapper · `docs/`.
