// Guarded Firebase deploy for ShopVerse. Usage: node scripts/deploy.mjs <rules|indexes|functions|all> [--yes]
// Without --yes it only PRINTS what it would run (dry run). It refuses any project other than shopverse21-831fc,
// always passes --project explicitly (so a stale `firebase use` can never target another project), and runs the offline checks first.
import { spawnSync } from 'node:child_process';

const PROJECT = 'shopverse21-831fc';
const TARGETS = { rules: 'firestore:rules', indexes: 'firestore:indexes', functions: 'functions' };
// `free` = ONLY Firestore rules + indexes. These need no billing. It never touches Functions or any data.
const FREE_ONLY = 'firestore:rules,firestore:indexes';
const [what, ...flags] = process.argv.slice(2);
const yes = flags.includes('--yes');
if (!what || !(what === 'all' || what === 'free' || TARGETS[what])) { console.error(`Usage: node scripts/deploy.mjs <${[...Object.keys(TARGETS), 'free', 'all'].join('|')}> [--yes]`); process.exit(2); }
const proj = flags.find((f) => f.startsWith('--project='))?.split('=')[1];
if (proj && proj !== PROJECT) { console.error(`Refusing: this repository only deploys to ${PROJECT} (got ${proj}).`); process.exit(2); }

const only = what === 'all' ? Object.values(TARGETS).join(',') : what === 'free' ? FREE_ONLY : TARGETS[what];
const run = (cmd, args) => spawnSync(cmd, args, { stdio: 'inherit', shell: process.platform === 'win32' });

console.log(`Target project: ${PROJECT}\nDeploy: ${only}\n`);
for (const script of ['scripts/validate-firebase.mjs', 'scripts/rules-audit.mjs', 'scripts/check-indexes.mjs']) {
  if (run('node', [script]).status !== 0) { console.error(`\nAborted: ${script} failed. Nothing was deployed.`); process.exit(1); }
}
const cmd = ['firebase', 'deploy', '--only', only, '--project', PROJECT];
if (!yes) { console.log(`\nDRY RUN — would run: ${cmd.join(' ')}\nRe-run with --yes to deploy. (Cloud Functions and the default Storage bucket need the Blaze plan: that is a billing decision for you in the Console.)`); process.exit(0); }
process.exit(run(cmd[0], cmd.slice(1)).status ?? 1);
