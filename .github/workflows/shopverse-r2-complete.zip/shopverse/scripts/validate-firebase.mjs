// Offline consistency check: every Firebase setting points at the NEW project and nothing points at the old one.
// Usage: node scripts/validate-firebase.mjs   (also run by `npm run validate:all`). Makes NO network calls.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const PROJECT = 'shopverse21-831fc';
const OLD = [['jony', 'apk'].join(''), ['4797', '807860'].join('')];   // split so this file never matches its own search
let fail = 0, warn = 0;
const ok = (c, m, x = '') => { console.log(`${c ? '✔ PASS' : '✘ FAIL'} ${m}${!c && x ? ' — ' + x : ''}`); if (!c) fail++; };
const note = (m) => { console.log(`⚠ NOTE ${m}`); warn++; };
const env = (f) => existsSync(f) ? Object.fromEntries(readFileSync(f, 'utf8').split('\n').filter((l) => /^[A-Z0-9_]+=/.test(l)).map((l) => [l.split('=')[0], l.slice(l.indexOf('=') + 1).replace(/\s+#.*$/, '').trim()])) : null;

// 1. CLI project
const rc = existsSync('.firebaserc') ? JSON.parse(readFileSync('.firebaserc', 'utf8')) : null;
ok(rc?.projects?.default === PROJECT, `.firebaserc default project is ${PROJECT}`);
ok(rc && Object.values(rc.projects).every((p) => p === PROJECT), '.firebaserc has no other project/alias');

// 2. env files
const REQUIRED = ['NEXT_PUBLIC_FIREBASE_API_KEY', 'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN', 'NEXT_PUBLIC_FIREBASE_PROJECT_ID', 'NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID', 'NEXT_PUBLIC_FIREBASE_APP_ID'];
const ex = env('.env.example'); ok(!!ex, '.env.example exists');
if (ex) { ok(REQUIRED.every((k) => k in ex), '.env.example lists every required Firebase variable'); ok(ex.NEXT_PUBLIC_FIREBASE_PROJECT_ID === PROJECT, '.env.example project id is the new project'); ok(!/AIza[0-9A-Za-z_-]{30,}/.test(readFileSync('.env.example', 'utf8')), '.env.example contains no real API key'); }
const loc = env('.env.local');
if (!loc) note('.env.local not present (copy .env.example and fill it in). Production values live in your host dashboard.');
else {
  ok(REQUIRED.every((k) => loc[k]), '.env.local has every required Firebase variable filled in', REQUIRED.filter((k) => !loc[k]).join(', '));
  ok(loc.NEXT_PUBLIC_FIREBASE_PROJECT_ID === PROJECT, '.env.local project id');
  ok(loc.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN === `${PROJECT}.firebaseapp.com`, '.env.local auth domain');
  ok(/^\d+$/.test(loc.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID ?? '') && loc.NEXT_PUBLIC_FIREBASE_APP_ID?.split(':')[1] === loc.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID, '.env.local sender id matches app id');
  if (!loc.NEXT_PUBLIC_FIREBASE_VAPID_KEY) note('NEXT_PUBLIC_FIREBASE_VAPID_KEY is empty: push notifications stay disabled until you add the Web Push key.');
}
ok(/^\.env\.local$/m.test(readFileSync('.gitignore', 'utf8')), '.env.local is git-ignored');

// 3. firebase.json wiring
const fj = JSON.parse(readFileSync('firebase.json', 'utf8'));
ok(existsSync(fj.firestore.rules) && existsSync(fj.firestore.indexes), 'firebase.json rules/indexes files exist');
ok(existsSync(join(fj.functions.source, 'package.json')) && existsSync(join(fj.functions.source, 'src/index.ts')), 'functions source exists');
const idx = JSON.parse(readFileSync(fj.firestore.indexes, 'utf8')); ok(Array.isArray(idx.indexes) && idx.indexes.length > 0, `firestore.indexes.json is valid (${idx.indexes.length} composite indexes)`);
ok(fj.emulators?.firestore, 'firestore emulator configured (npm run test:rules)');

// 4. functions region == client region
const common = readFileSync('functions/src/common.ts', 'utf8'); const region = /region:\s*'([a-z0-9-]+)'/.exec(common)?.[1];
const clientRegion = loc?.NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION || ex?.NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION || 'us-central1';
ok(region === clientRegion, `functions region (${region}) matches NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION (${clientRegion})`);

// 5. client config reads ONLY env vars (no inlined project values) and the old project is gone everywhere
const cfg = readFileSync('lib/firebase/config.ts', 'utf8'); ok(REQUIRED.slice(0, 6).every((k) => cfg.includes(`process.env.${k}`)), 'lib/firebase/config.ts reads every value from NEXT_PUBLIC_FIREBASE_* env vars');
ok(!/AIza[0-9A-Za-z_-]{30,}/.test(cfg) && !cfg.includes(PROJECT), 'lib/firebase/config.ts has no hard-coded key or project id');
const hits = []; const walk = (d) => { for (const f of readdirSync(d)) { if (['node_modules', '.next', '.git', 'lib'].includes(f) && d !== 'lib' && f !== 'lib') continue; if (['node_modules', '.next', '.git'].includes(f)) continue; const p = join(d, f); const s = statSync(p); if (s.isDirectory()) { if (p === 'functions/lib') continue; walk(p); } else if (s.size < 3e6 && !/\.(png|jpg|jpeg|webp|ico|zip|woff2?)$/.test(f)) { const t = readFileSync(p, 'utf8'); if (OLD.some((o) => t.toLowerCase().includes(o))) hits.push(p); } } };
walk('.'); ok(!hits.length, 'no reference to the old Firebase project anywhere', hits.join(', '));
// 6. secrets
const secretRe = /-----BEGIN (RSA )?PRIVATE KEY-----|"private_key"\s*:|"type"\s*:\s*"service_account"/; const sec = [];
const walk2 = (d) => { for (const f of readdirSync(d)) { if (['node_modules', '.next', '.git'].includes(f)) continue; const p = join(d, f); const s = statSync(p); if (s.isDirectory()) walk2(p); else if (s.size < 2e6 && /\.(ts|tsx|js|mjs|json|md|env.*|txt)$/.test(f) && secretRe.test(readFileSync(p, 'utf8'))) sec.push(p); } };
walk2('.'); ok(!sec.length, 'no service-account / private key material in the project', sec.join(', '));
ok(!existsSync('google-services.json') && !existsSync('serviceAccountKey.json'), 'no google-services.json / service account file committed');

console.log(`\n${fail ? fail + ' FAILED' : 'Firebase configuration is consistent'}${warn ? `, ${warn} note(s)` : ''}. (Offline check — it proves the files agree, not that the live project is set up.)`);
process.exit(fail ? 1 : 0);
