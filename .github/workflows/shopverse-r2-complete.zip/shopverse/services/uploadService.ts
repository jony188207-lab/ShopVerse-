import { r2Upload } from './r2Client';

/** Client-side guard for fast feedback. The server (app/api/upload/sign + lib/r2/policy.ts) is the real enforcement. Returns the public R2 URL. */
export async function uploadFile(path: string, file: File, opts: { maxMB: number; image?: boolean; video?: boolean; onProgress?: (percent: number) => void }): Promise<string> {
  if (file.size > opts.maxMB * 1024 * 1024) throw new Error(`“${file.name}” is larger than ${opts.maxMB} MB.`);
  if (opts.image && !/^image\/(jpeg|png|webp|gif)$/.test(file.type)) throw new Error(`“${file.name}” must be a JPG, PNG, WebP or GIF image.`);
  if (opts.video && !/^video\/(mp4|webm|quicktime)$/.test(file.type)) throw new Error(`“${file.name}” must be an MP4, WebM or MOV video.`);
  return (await r2Upload(path, file, opts.onProgress)).url;
}
