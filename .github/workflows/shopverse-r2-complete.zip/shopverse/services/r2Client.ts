import { auth } from '@/lib/firebase/config';

/** Browser side of uploads: asks our server for a short-lived presigned URL (server verifies the Firebase ID token), then PUTs the file to R2. No secret ever reaches the browser. */
const safeKey = (path: string) => path.replace(/[^\w./-]+/g, '_');

async function idToken(): Promise<string> {
  const u = auth().currentUser;
  if (!u) throw new Error('Please sign in to upload.');
  return u.getIdToken();
}

export async function r2Upload(path: string, file: File, onProgress?: (percent: number) => void): Promise<{ url: string; key: string }> {
  const res = await fetch('/api/upload/sign', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${await idToken()}` },
    body: JSON.stringify({ key: safeKey(path), contentType: file.type, size: file.size }),
  });
  const data = (await res.json().catch(() => ({}))) as { uploadUrl?: string; url?: string; key?: string; error?: string };
  if (!res.ok || !data.uploadUrl || !data.url || !data.key) throw new Error(data.error || 'Upload was not allowed.');
  await new Promise<void>((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('PUT', data.uploadUrl as string);
    x.setRequestHeader('Content-Type', file.type);
    x.upload.onprogress = (e) => { if (e.lengthComputable) onProgress?.(Math.round((e.loaded / e.total) * 100)); };
    x.onload = () => (x.status >= 200 && x.status < 300 ? resolve() : reject(new Error('Upload failed. Please try again.')));
    x.onerror = () => reject(new Error('Network error during upload.'));
    x.send(file);
  });
  return { url: data.url, key: data.key };
}

export async function r2Remove(key: string): Promise<void> {
  try {
    await fetch('/api/upload/delete', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${await idToken()}` }, body: JSON.stringify({ key }) });
  } catch { /* best effort: the Firestore document is already gone */ }
}
