import { r2Remove, r2Upload } from '../r2Client';

/**
 * Storage/CDN abstraction for video + thumbnails. The rest of the app only talks to `videoProvider`.
 * Files live in Cloudflare R2; the Firestore document stores plain URLs (videoUrl / thumbnailUrl) and the object key (videoPath).
 */
export interface UploadOptions { kind: 'video' | 'image'; maxMB: number; onProgress?: (percent: number) => void }
export interface VideoStorageProvider {
  readonly name: string;
  upload(path: string, file: File, opts: UploadOptions): Promise<{ url: string; path: string }>;
  remove(path: string): Promise<void>;
}

const OK: Record<UploadOptions['kind'], RegExp> = { video: /^video\/(mp4|webm|quicktime)$/, image: /^image\/(jpeg|png|webp)$/ };

export const r2VideoProvider: VideoStorageProvider = {
  name: 'cloudflare-r2',
  async upload(path, file, opts) {
    if (file.size > opts.maxMB * 1024 * 1024) throw new Error(`“${file.name}” is larger than ${opts.maxMB} MB.`);
    if (!OK[opts.kind].test(file.type)) throw new Error(opts.kind === 'video' ? 'Use an MP4, WebM or MOV video.' : 'Use a JPG, PNG or WebP image.');
    const { url, key } = await r2Upload(path, file, opts.onProgress);
    return { url, path: key };
  },
  async remove(path) { await r2Remove(path); },
};

export const videoProvider: VideoStorageProvider = r2VideoProvider;
