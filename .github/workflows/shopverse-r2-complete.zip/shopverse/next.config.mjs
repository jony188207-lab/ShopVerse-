/** @type {import('next').NextConfig} */
const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=()' },
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin-allow-popups' },
];
// Public hostname of the Cloudflare R2 bucket (custom domain or r2.dev), derived from R2_PUBLIC_BASE_URL.
const r2Host = (() => { try { return new URL(process.env.R2_PUBLIC_BASE_URL || '').hostname; } catch { return null; } })();
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Lint runs as its own step (`npm run lint`); a style rule must never block a production deploy. Type errors still fail the build.
  eslint: { ignoreDuringBuilds: true },
  async rewrites() { return [{ source: '/.well-known/assetlinks.json', destination: '/api/assetlinks' }]; },
  async headers() { return [{ source: '/:path*', headers: securityHeaders }]; },
  images: { remotePatterns: r2Host ? [{ protocol: 'https', hostname: r2Host }] : [] },
};
export default nextConfig;
