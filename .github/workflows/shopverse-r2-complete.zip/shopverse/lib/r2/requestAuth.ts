import { readDocAsUser, verifyIdToken, type VerifiedUser } from '@/lib/auth/verifyIdToken';
import type { PolicyCtx, Role } from './policy';

export function bearerToken(req: Request): string | null {
  const h = req.headers.get('authorization') ?? '';
  return /^Bearer\s+\S+$/i.test(h) ? h.replace(/^Bearer\s+/i, '') : null;
}
const ROLES: Role[] = ['user', 'seller', 'moderator', 'admin', 'super_admin'];

export async function authenticate(req: Request): Promise<{ user: VerifiedUser; ctx: PolicyCtx } | null> {
  const token = bearerToken(req);
  if (!token) return null;
  let user: VerifiedUser;
  try { user = await verifyIdToken(token); } catch { return null; }
  let role: Promise<Role> | null = null;
  const ctx: PolicyCtx = {
    uid: user.uid,
    emailVerified: user.emailVerified,
    getRole: () => (role ??= readDocAsUser(`roles/${user.uid}`, token).then((d) => {
      const r = d?.role?.stringValue as Role | undefined;
      return r && ROLES.includes(r) ? r : 'user';
    }).catch(() => 'user' as Role)),
    reviewBelongsToUser: async (id) => {
      if (!/^[\w-]+$/.test(id)) return false;
      const d = await readDocAsUser(`reviews/${id}`, token).catch(() => null);
      return d?.userId?.stringValue === user.uid;
    },
  };
  return { user, ctx };
}
