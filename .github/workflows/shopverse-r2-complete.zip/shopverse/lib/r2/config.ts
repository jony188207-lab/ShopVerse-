import { S3Client } from '@aws-sdk/client-s3';

/** SERVER ONLY. Never import this file from a client component: it reads the R2 secret access key. */
export class R2NotConfiguredError extends Error {
  constructor(missing: string[]) {
    super(`Upload service is not configured. Missing environment variables: ${missing.join(', ')}`);
    this.name = 'R2NotConfiguredError';
  }
}

export interface R2Env { accountId: string; accessKeyId: string; secretAccessKey: string; bucket: string; publicBase: string }

export function r2Env(): R2Env {
  const e = process.env;
  const missing = ['R2_ACCOUNT_ID', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY', 'R2_BUCKET', 'R2_PUBLIC_BASE_URL'].filter((k) => !e[k]);
  if (missing.length) throw new R2NotConfiguredError(missing);
  return {
    accountId: e.R2_ACCOUNT_ID as string,
    accessKeyId: e.R2_ACCESS_KEY_ID as string,
    secretAccessKey: e.R2_SECRET_ACCESS_KEY as string,
    bucket: e.R2_BUCKET as string,
    publicBase: (e.R2_PUBLIC_BASE_URL as string).replace(/\/+$/, ''),
  };
}

export function r2Client(env: R2Env): S3Client {
  return new S3Client({
    region: 'auto',
    endpoint: `https://${env.accountId}.r2.cloudflarestorage.com`,
    credentials: { accessKeyId: env.accessKeyId, secretAccessKey: env.secretAccessKey },
  });
}
