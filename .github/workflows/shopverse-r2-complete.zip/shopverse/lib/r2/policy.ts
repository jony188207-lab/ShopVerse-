/**
 * Who may write which object key, and with what type/size. This is the exact rule set that used to live in storage.rules,
 * now enforced on the server BEFORE a presigned upload URL is issued. Pure logic (no I/O) so it can be unit tested.
 */
export type Role = 'user' | 'seller' | 'moderator' | 'admin' | 'super_admin';
export interface PolicyCtx {
  uid: string;
  emailVerified: boolean;
  getRole: () => Promise<Role>;
  reviewBelongsToUser: (reviewId: string) => Promise<boolean>;
}
export type Verdict = { ok: true } | { ok: false; status: number; error: string };

const MB = 1024 * 1024;
export const IMAGE_RE = /^image\/(jpeg|png|webp|gif)$/;
export const VIDEO_RE = /^video\/(mp4|webm|quicktime)$/;
const KEY_RE = /^[\w.-]+(\/[\w.-]+)*$/;

export function isSafeKey(key: string): boolean {
  return key.length <= 300 && KEY_RE.test(key) && !key.split('/').some((s) => s === '.' || s === '..');
}
const deny = (status: number, error: string): Verdict => ({ ok: false, status, error });
const ok: Verdict = { ok: true };
const ADMINS: Role[] = ['admin', 'super_admin'];
const STAFF: Role[] = ['moderator', 'admin', 'super_admin'];

export async function authorizeUpload(key: string, contentType: string, size: number, ctx: PolicyCtx): Promise<Verdict> {
  if (!isSafeKey(key)) return deny(400, 'Invalid file path.');
  if (!Number.isFinite(size) || size <= 0) return deny(400, 'Empty file.');
  const img = IMAGE_RE.test(contentType);
  const vid = VIDEO_RE.test(contentType);
  if (!img && !vid) return deny(400, 'Only JPG/PNG/WebP/GIF images and MP4/WebM/MOV videos are allowed.');
  const s = key.split('/');
  const me = (id: string | undefined) => id === ctx.uid;
  const under = (mb: number) => size < mb * MB;
  const tooBig = deny(413, 'File is too large.');
  const forbidden = deny(403, 'You are not allowed to upload here.');

  switch (s[0]) {
    case 'profiles':
      if (s.length !== 3 || !me(s[1])) return forbidden;
      return img && under(5) ? ok : img ? tooBig : forbidden;
    case 'applications':
      if (s.length !== 3 || !me(s[1]) || !ctx.emailVerified) return forbidden;
      return img && under(8) ? ok : img ? tooBig : forbidden;
    case 'stores': {
      if (s.length !== 3) return forbidden;
      const role = await ctx.getRole();
      if (!((role === 'seller' && me(s[1])) || ADMINS.includes(role))) return forbidden;
      return img && under(8) ? ok : img ? tooBig : forbidden;
    }
    case 'products': {
      if (s.length !== 4) return forbidden;
      const role = await ctx.getRole();
      if (!((role === 'seller' && me(s[1])) || ADMINS.includes(role))) return forbidden;
      return img && under(10) ? ok : img ? tooBig : forbidden;
    }
    case 'productVideos': {
      if (s.length !== 4) return forbidden;
      const role = await ctx.getRole();
      if (!((role === 'seller' && me(s[1])) || ADMINS.includes(role))) return forbidden;
      return vid && under(100) ? ok : vid ? tooBig : forbidden;
    }
    case 'videos': {
      if (s.length !== 4 || !me(s[1]) || !ctx.emailVerified) return forbidden;
      if ((await ctx.getRole()) !== 'seller') return forbidden;
      if (vid) return under(200) ? ok : tooBig;
      return under(5) ? ok : tooBig;
    }
    case 'reviews': {
      if (s.length !== 4 || !me(s[1]) || !ctx.emailVerified) return forbidden;
      if (!(await ctx.reviewBelongsToUser(s[2]))) return deny(403, 'Create the review before adding photos.');
      if (img) return under(5) ? ok : tooBig;
      return under(50) ? ok : tooBig;
    }
    case 'categories':
    case 'banners': {
      if (s.length !== 2 || !img) return forbidden;
      if (!ADMINS.includes(await ctx.getRole())) return forbidden;
      return under(s[0] === 'categories' ? 2 : 5) ? ok : tooBig;
    }
    default:
      return forbidden;
  }
}

/** Delete: the owner (uid segment), or staff; categories/banners are admin only. */
export async function authorizeDelete(key: string, ctx: Pick<PolicyCtx, 'uid' | 'getRole'>): Promise<Verdict> {
  if (!isSafeKey(key)) return deny(400, 'Invalid file path.');
  const s = key.split('/');
  const forbidden = deny(403, 'You are not allowed to delete this file.');
  if (s[0] === 'categories' || s[0] === 'banners') return ADMINS.includes(await ctx.getRole()) ? ok : forbidden;
  if (['profiles', 'stores', 'products', 'productVideos', 'videos', 'reviews', 'applications'].includes(s[0])) {
    if (s[1] === ctx.uid) return ok;
    return STAFF.includes(await ctx.getRole()) ? ok : forbidden;
  }
  return forbidden;
}
