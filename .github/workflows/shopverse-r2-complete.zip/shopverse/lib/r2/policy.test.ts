import { describe, expect, it } from 'vitest';
import { authorizeDelete, authorizeUpload, isSafeKey, type PolicyCtx, type Role } from './policy';

const ctx = (uid: string, role: Role, over: Partial<PolicyCtx> = {}): PolicyCtx => ({
  uid, emailVerified: true, getRole: async () => role, reviewBelongsToUser: async () => true, ...over,
});
const MB = 1024 * 1024;

describe('upload policy', () => {
  it('rejects unsafe keys', () => {
    expect(isSafeKey('products/u1/p1/a.png')).toBe(true);
    for (const k of ['../x.png', 'a/../b.png', '/abs.png', 'a//b.png', 'a b.png', '']) expect(isSafeKey(k)).toBe(false);
  });
  it('profile: only yourself, images only, <5MB', async () => {
    expect((await authorizeUpload('profiles/u1/a.png', 'image/png', 1 * MB, ctx('u1', 'user'))).ok).toBe(true);
    expect((await authorizeUpload('profiles/u2/a.png', 'image/png', 1 * MB, ctx('u1', 'user'))).ok).toBe(false);
    expect((await authorizeUpload('profiles/u1/a.png', 'video/mp4', 1 * MB, ctx('u1', 'user'))).ok).toBe(false);
    expect((await authorizeUpload('profiles/u1/a.png', 'image/png', 6 * MB, ctx('u1', 'user'))).ok).toBe(false);
  });
  it('product images: seller owns the path, buyers cannot, admin can', async () => {
    const k = 'products/s1/p1/a.webp';
    expect((await authorizeUpload(k, 'image/webp', MB, ctx('s1', 'seller'))).ok).toBe(true);
    expect((await authorizeUpload(k, 'image/webp', MB, ctx('s2', 'seller'))).ok).toBe(false);
    expect((await authorizeUpload(k, 'image/webp', MB, ctx('u1', 'user'))).ok).toBe(false);
    expect((await authorizeUpload(k, 'image/webp', MB, ctx('a1', 'admin'))).ok).toBe(true);
  });
  it('videos need a verified seller; reviews need an owned review doc', async () => {
    expect((await authorizeUpload('videos/s1/v1/video-a.mp4', 'video/mp4', 50 * MB, ctx('s1', 'seller'))).ok).toBe(true);
    expect((await authorizeUpload('videos/s1/v1/video-a.mp4', 'video/mp4', 50 * MB, ctx('s1', 'seller', { emailVerified: false }))).ok).toBe(false);
    expect((await authorizeUpload('videos/s1/v1/video-a.mp4', 'video/mp4', 50 * MB, ctx('s1', 'user'))).ok).toBe(false);
    expect((await authorizeUpload('reviews/u1/r1/a.png', 'image/png', MB, ctx('u1', 'user'))).ok).toBe(true);
    expect((await authorizeUpload('reviews/u1/r1/a.png', 'image/png', MB, ctx('u1', 'user', { reviewBelongsToUser: async () => false }))).ok).toBe(false);
  });
  it('banners/categories are admin only; unknown prefixes denied', async () => {
    expect((await authorizeUpload('banners/a.png', 'image/png', MB, ctx('a1', 'admin'))).ok).toBe(true);
    expect((await authorizeUpload('banners/a.png', 'image/png', MB, ctx('s1', 'seller'))).ok).toBe(false);
    expect((await authorizeUpload('evil/a.png', 'image/png', MB, ctx('a1', 'admin'))).ok).toBe(false);
  });
  it('delete: owner or staff only', async () => {
    expect((await authorizeDelete('videos/u1/v1/x.mp4', ctx('u1', 'seller'))).ok).toBe(true);
    expect((await authorizeDelete('videos/u1/v1/x.mp4', ctx('u2', 'user'))).ok).toBe(false);
    expect((await authorizeDelete('videos/u1/v1/x.mp4', ctx('m1', 'moderator'))).ok).toBe(true);
    expect((await authorizeDelete('banners/a.png', ctx('m1', 'moderator'))).ok).toBe(false);
  });
});
