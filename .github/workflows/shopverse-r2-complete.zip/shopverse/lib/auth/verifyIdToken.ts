import { createRemoteJWKSet, jwtVerify } from 'jose';

/** SERVER ONLY. Verifies a Firebase ID token (signature, issuer, audience, expiry) without needing a service-account key. */
const JWKS = createRemoteJWKSet(new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com'));

export interface VerifiedUser { uid: string; emailVerified: boolean }

export async function verifyIdToken(token: string): Promise<VerifiedUser> {
  const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
  if (!projectId) throw new Error('NEXT_PUBLIC_FIREBASE_PROJECT_ID is not set');
  const { payload } = await jwtVerify(token, JWKS, { issuer: `https://securetoken.google.com/${projectId}`, audience: projectId });
  if (!payload.sub) throw new Error('Token has no subject');
  return { uid: payload.sub, emailVerified: payload.email_verified === true };
}

/** Reads one Firestore document AS THE SIGNED-IN USER (their ID token), so Firestore security rules still decide what is visible. */
export async function readDocAsUser(path: string, idToken: string): Promise<Record<string, { stringValue?: string }> | null> {
  const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
  const res = await fetch(`https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/${path}`, {
    headers: { Authorization: `Bearer ${idToken}` }, cache: 'no-store',
  });
  if (res.status === 404 || res.status === 403) return null;
  if (!res.ok) throw new Error(`Firestore lookup failed (${res.status})`);
  const json = (await res.json()) as { fields?: Record<string, { stringValue?: string }> };
  return json.fields ?? {};
}
