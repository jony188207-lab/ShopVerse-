import { NextResponse } from 'next/server';
import { PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { R2NotConfiguredError, r2Client, r2Env } from '@/lib/r2/config';
import { authorizeUpload } from '@/lib/r2/policy';
import { authenticate } from '@/lib/r2/requestAuth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** POST { key, contentType, size } with `Authorization: Bearer <Firebase ID token>` → { uploadUrl, url, key }. */
export async function POST(req: Request) {
  try {
    const auth = await authenticate(req);
    if (!auth) return NextResponse.json({ error: 'Please sign in to upload.' }, { status: 401 });
    const body = (await req.json().catch(() => null)) as { key?: unknown; contentType?: unknown; size?: unknown } | null;
    if (!body || typeof body.key !== 'string' || typeof body.contentType !== 'string' || typeof body.size !== 'number') {
      return NextResponse.json({ error: 'Bad request.' }, { status: 400 });
    }
    const verdict = await authorizeUpload(body.key, body.contentType, body.size, auth.ctx);
    if (!verdict.ok) return NextResponse.json({ error: verdict.error }, { status: verdict.status });
    const env = r2Env();
    const uploadUrl = await getSignedUrl(
      r2Client(env),
      new PutObjectCommand({ Bucket: env.bucket, Key: body.key, ContentType: body.contentType, ContentLength: body.size }),
      { expiresIn: 300 },
    );
    return NextResponse.json({ uploadUrl, url: `${env.publicBase}/${body.key}`, key: body.key });
  } catch (e) {
    if (e instanceof R2NotConfiguredError) { console.error(e.message); return NextResponse.json({ error: 'Uploads are not configured on the server yet.' }, { status: 503 }); }
    console.error('upload sign failed', e);
    return NextResponse.json({ error: 'Upload is not available right now.' }, { status: 500 });
  }
}
