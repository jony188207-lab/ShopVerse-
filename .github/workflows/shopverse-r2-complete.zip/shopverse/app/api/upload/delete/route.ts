import { NextResponse } from 'next/server';
import { DeleteObjectCommand } from '@aws-sdk/client-s3';
import { R2NotConfiguredError, r2Client, r2Env } from '@/lib/r2/config';
import { authorizeDelete } from '@/lib/r2/policy';
import { authenticate } from '@/lib/r2/requestAuth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** POST { key } with `Authorization: Bearer <Firebase ID token>`. Owner, staff (or admin for banners/categories) only. */
export async function POST(req: Request) {
  try {
    const auth = await authenticate(req);
    if (!auth) return NextResponse.json({ error: 'Please sign in.' }, { status: 401 });
    const body = (await req.json().catch(() => null)) as { key?: unknown } | null;
    if (!body || typeof body.key !== 'string') return NextResponse.json({ error: 'Bad request.' }, { status: 400 });
    const verdict = await authorizeDelete(body.key, auth.ctx);
    if (!verdict.ok) return NextResponse.json({ error: verdict.error }, { status: verdict.status });
    const env = r2Env();
    await r2Client(env).send(new DeleteObjectCommand({ Bucket: env.bucket, Key: body.key }));
    return NextResponse.json({ ok: true });
  } catch (e) {
    if (e instanceof R2NotConfiguredError) return NextResponse.json({ error: 'Uploads are not configured on the server yet.' }, { status: 503 });
    console.error('upload delete failed', e);
    return NextResponse.json({ error: 'Could not delete the file.' }, { status: 500 });
  }
}
