import { formatMoney } from '@/utils/money';

/** Shared by the cart and checkout pages. Lives here (not in a page file) because Next.js pages may only export a default component. */
export function OrderSummary({ s }: { s: { subtotal: number; savings: number; shipping: number; total: number } }) {
  return (
    <dl className="space-y-1 text-sm">
      <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatMoney(s.subtotal)}</dd></div>
      {s.savings > 0 ? <div className="flex justify-between text-green-700 dark:text-green-400"><dt>You save (discounts included above)</dt><dd>{formatMoney(s.savings)}</dd></div> : null}
      <div className="flex justify-between"><dt>Shipping</dt><dd>{s.shipping > 0 ? formatMoney(s.shipping) : 'Free'}</dd></div>
      <div className="flex justify-between border-t border-navy-100 pt-2 text-base font-extrabold dark:border-navy-500"><dt>Total</dt><dd>{formatMoney(s.total)}</dd></div>
    </dl>
  );
}
