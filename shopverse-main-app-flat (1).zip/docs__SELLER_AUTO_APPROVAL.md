# Seller auto-approval (what exists, what changed in this round)

**Already in the project (unchanged):** a signed-in user with a VERIFIED email who submits /become-seller (or signs up as a seller) is approved immediately in one atomic
Firestore batch: application -> approved, roles/{uid} = seller, stores/{uid}, storePrivate/{uid}, storeSlugs/{slug}. Firestore rules check every document, so no Cloud
Function and no Blaze plan are needed. Store id = uid, so a user can never own two self-created stores. Staff, existing/suspended sellers and admin-reviewed
applications can never self-activate. The Admin Panel can still review/reject/suspend/reactivate (through the free Worker).

**Changed this round (2 small edits + 1 test line):**
- `cloudflare-worker/src/worker.js` and `customer-app/functions/src/seller.ts`: when an ADMIN approves an application they now also write `storeSlugs/{slug}`.
  Before, an admin-approved address was not claimed, so the rules could not stop a later self-activation from taking the same address.
- `cloudflare-worker/test/worker.test.mjs`: asserts the claim is written.

**You must publish firestore.rules** (the self-activation rules live there) and redeploy the Worker for the claim change. Without the new rules, activation shows a plain-language error.

**Limits:** email must be verified first (this is the safety gate; without it anyone could create sellers with fake emails). Stores approved by an admin BEFORE this change have no claim doc; the app's
address check still catches them in the browser, but the rules cannot. Rules tests (tests/firestore.rules.test.ts) need the Firebase emulator and were NOT run here.
