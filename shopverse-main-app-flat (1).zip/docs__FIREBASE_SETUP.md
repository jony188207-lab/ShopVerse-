# ShopVerse — Firebase setup (project `shopverse21-831fc`)

This repository uses **only** the Firebase project `shopverse21-831fc`. The old project must never be used; `npm run validate:firebase` fails if any reference to it appears.
The separate **Admin App** uses the same project and the same rules/functions deployed from *this* repository (see `ADMIN_APP_CONTRACT.md`).

## 1. What is in the repo
| Need | File | Notes |
|---|---|---|
| Client config | `lib/firebase/config.ts`, `.env.example` | Reads `NEXT_PUBLIC_FIREBASE_*` only. No keys in source. |
| Firestore rules | `firestore.rules` | Roles in `roles/{uid}` are server-written only. |
| Storage rules | `storage.rules` | Type + size + ownership on every write; unknown paths denied. |
| Indexes | `firestore.indexes.json` | 58 composite indexes + 1 field override (`fcmTokens.lastSeenAt`). |
| Cloud Functions | `functions/` (Node 22, v2, `us-central1`) | Callables, triggers and schedulers (list below). |
| Emulator tests | `tests/firestore.rules.test.ts`, `tests/storage.rules.test.ts` | Need the Firebase Emulator (`npm run test:rules`). |
| Checks | `scripts/preflight.mjs`, `validate-firebase.mjs`, `rules-audit.mjs`, `check-indexes.mjs` | Offline, no network. |
| Guarded deploy | `scripts/deploy.mjs` | Dry run by default; refuses other projects. |

## 2. Local setup
```bash
cp .env.example .env.local
# fill NEXT_PUBLIC_FIREBASE_API_KEY and NEXT_PUBLIC_FIREBASE_APP_ID
# Console > Project settings > General > Your apps > Web app "shopverse"  (values are public by design)
npm install
npm run install:functions
npm run dev
```
Optional: `NEXT_PUBLIC_FIREBASE_VAPID_KEY` (Console > Project settings > Cloud Messaging > Web Push certificates) enables push. Without it push stays off; everything else works.
**Never** put a service-account JSON or Admin SDK key in `.env*`, `NEXT_PUBLIC_*` variables, or git.

## 3. Checks (run in this order)
```bash
npm run validate:all     # offline: preflight + config consistency + rules audit + index coverage
npm run typecheck && npm run typecheck:functions
npm test                 # unit tests (utils/, functions/src/*.test.ts)
npm run test:rules       # Firestore + Storage rules against the local emulator (needs Java 11+)
npm run build
```
`validate:all` proves the files agree with each other. It does **not** prove the live project is configured. Only the emulator tests exercise the rules' behaviour, and only a deploy plus manual testing exercises the live project.

## 4. Firebase Console steps (once, by you)
1. **Authentication** → Sign-in method: Email/Password enabled (already done). Settings → *Authorized domains*: add your production domain(s) (`localhost` is present by default). Templates: optionally customise the verification and password-reset emails.
2. **Firestore** → create the database (Native mode), choose the location (cannot be changed later).
3. **Storage** → get started (creates the default bucket `shopverse21-831fc.firebasestorage.app`).
4. **Billing**: Cloud Functions (and schedulers) require the **Blaze** plan; new Storage buckets may as well. Enabling billing is your decision; nothing here changes billing.
5. After the first deploy of Storage rules: Storage rules read `roles/` and `reviews/` from Firestore (`firestore.get(...)`). If the Console reports a permission problem, grant the Storage service agent access when prompted.
6. **First super admin**: Firestore → create `roles/{your-auth-uid}` with `{ role: "super_admin" }` (the only way; no client can write roles). Use the account the Admin App signs in with.
7. Optional: **App Check** (reCAPTCHA v3). Set `NEXT_PUBLIC_RECAPTCHA_SITE_KEY`, verify it works, *then* enforce per product.
8. Optional: Web Push key (see §2).

## 5. Deploy (nothing runs automatically)
Each command is a **dry run** until you add `--yes`, and always targets `shopverse21-831fc`:
```bash
npm run deploy:rules   -- --yes
npm run deploy:indexes -- --yes      # indexes build in the background; wait for "Enabled" in the Console
npm run deploy:storage -- --yes
npm run deploy:functions -- --yes    # needs Blaze
```
Recommended order: **indexes → rules → storage → functions**, then deploy the web app (Vercel/Netlify/Firebase Hosting) with the same `NEXT_PUBLIC_*` variables in the host dashboard.
Re-deploy rules/functions from this repository whenever either app changes them; the Admin App must not carry its own copies.

## 6. Cloud Functions in this repo
- **Callable:** `placeOrder`, `previewCoupon`, `cancelOrder`, `requestReturn`, `requestWithdrawal`, `cancelWithdrawal` (customer/seller) · `reviewSellerApplication`, `setUserStatus`, `setUserRole`, `sendAnnouncement`, `reviewWithdrawal`, `reviewPromotion`, `confirmCodRemittance`, `migrateStoreFinance` (admin; role checked server-side).
- **Triggers:** orders, products, reviews, follows, videos (likes/saves/views/comments/moderation), messages, reports, withdrawals, coupons, seller applications, admin log, platform promotions.
- **Scheduled (Cloud Scheduler):** `releaseEarnings`, `syncPromotions`, `rankVideos` (hourly), `cleanupPushTokens`, `pruneOldNotifications` (daily).

## 7. First live test (after deploy)
1. Sign up as Customer → verify email → profile edit (username) → add to cart → COD order.
2. Sign up as Seller → application is `pending`, no Seller Center.
3. In the Admin App (or Console + callable): approve the application → seller gets `roles/{uid}` = seller and a store; Seller Center opens.
4. Seller creates a product → admin approves → customer sees it.
5. Confirm in the browser console that no "The query requires an index" or permission-denied errors appear in normal flows.

## 8. Rollback
Firestore rules/Storage rules: Console → Rules → *Rules history* → publish an earlier version. Functions: redeploy the previous commit. Indexes are additive and safe to leave.
