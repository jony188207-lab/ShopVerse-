import { ORDER_STATUS_LABEL, type Order } from '@/types';

/** Shared by the orders list and order detail pages. Lives here (not in a page file) because Next.js pages may only export a default component. */
export function StatusBadge({ status }: { status: Order['status'] }) {
  const tone = status === 'delivered' ? 'bg-green-100 text-green-800' : status === 'cancelled' || status === 'refunded' || status === 'returned' ? 'bg-red-100 text-red-800' : 'bg-brand-purple/15 text-brand-purple';
  return <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${tone}`}>{ORDER_STATUS_LABEL[status] ?? status}</span>;
}
