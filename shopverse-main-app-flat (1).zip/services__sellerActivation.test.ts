import { describe, expect, it } from 'vitest';
import { buildActivation } from './sellerActivation';

const app = { storeName: 'Ann Shop', slug: 'ann-shop', description: 'd', logoUrl: '', bannerUrl: '', city: 'Dhaka', country: 'Bangladesh', returnPolicy: '', shippingInfo: '', phone: '555555', email: 'a@a.co', address: '1 Road' };
const TS = Symbol('ts');

describe('buildActivation (seller auto-approval payload)', () => {
  const d = buildActivation('u1', app, TS);
  it('approves the application and links the store id to the uid', () => {
    expect(d.application.status).toBe('approved');
    expect(d.application.storeId).toBe('u1');
  });
  it('grants exactly the seller role, never a staff role', () => {
    expect(d.role.role).toBe('seller');
    expect(d.role.updatedBy).toBe('u1');
  });
  it('creates a store owned by the uid with zeroed counters and no commission', () => {
    expect(d.store.ownerId).toBe('u1');
    expect(d.store.applicationId).toBe('u1');
    expect(d.store.status).toBe('approved');
    expect(d.store.name).toBe('Ann Shop');
    expect(d.store.slug).toBe('ann-shop');
    expect([d.store.shippingFee, d.store.ratingAvg, d.store.ratingCount, d.store.ratingSum, d.store.followerCount, d.store.salesCount]).toEqual([0, 0, 0, 0, 0, 0]);
    expect('commissionRate' in d.store).toBe(false);
  });
  it('keeps contact details private and claims the slug for the uid', () => {
    expect('phone' in d.store).toBe(false);
    expect(d.storePrivate.phone).toBe('555555');
    expect(d.slugClaim.uid).toBe('u1');
    expect(Object.keys(d.slugClaim).sort()).toEqual(['createdAt', 'uid']);
  });
});
