// Best-effort STATIC check: finds Firestore queries in the client code and verifies that a composite index covers each one that needs it.
// Heuristic (it reads source text, it does not run queries): conditional constraints (`...(x ? [where(..)] : [])`) are treated as optional,
// so each query is checked in its fullest form AND without optional parts. The authoritative check is the emulator/live "index required" error.
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const idx = JSON.parse(readFileSync('firestore.indexes.json', 'utf8')).indexes;
const files = []; const walk = (d) => { for (const f of readdirSync(d)) { if (['node_modules', '.next', 'tests'].includes(f)) continue; const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else if (/\.(ts|tsx)$/.test(f)) files.push(p); } };
for (const d of ['services', 'hooks', 'app', 'components', 'lib']) walk(d);

function balanced(src, start) { let d = 0; for (let i = start; i < src.length; i++) { if (src[i] === '(') d++; else if (src[i] === ')') { d--; if (!d) return src.slice(start, i + 1); } } return ''; }
const splitTop = (s) => { const out = []; let d = 0, cur = ''; for (const ch of s) { if ('([{'.includes(ch)) d++; if (')]}'.includes(ch)) d--; if (ch === ',' && d === 0) { out.push(cur); cur = ''; } else cur += ch; } if (cur.trim()) out.push(cur); return out; };

function analyse(col, args, fnSrc) {
  // collect constraints from this call plus the local array constants it spreads (c = [where(..), ...])
  let text = args;
  for (const m of args.matchAll(/\.\.\.([a-zA-Z_]\w*)\b(?!\()/g)) { const d = new RegExp(`(?:const|let)\\s+${m[1]}\\s*=\\s*\\[([\\s\\S]*?)\\];`).exec(fnSrc); if (d) text += ',' + d[1]; }
  const eq = [], ineq = [], order = []; let optional = false;
  for (const m of text.matchAll(/(\.\.\.\([^)]*\?\s*\[)?\s*where\(\s*'([\w.]+)'\s*,\s*'([^']+)'/g)) {
    const [, opt, f, op] = m; if (opt) optional = true;
    (['==', 'in', 'array-contains'].includes(op) ? eq : ineq).push({ f, op, opt: !!opt });
  }
  for (const m of text.matchAll(/orderBy\(\s*'([\w.]+)'(?:\s*,\s*'(asc|desc)')?/g)) order.push({ f: m[1], dir: m[2] ?? 'asc' });
  return { eq, ineq, order, optional };
}
function needsIndex({ eq, ineq, order }) {
  const ineqFields = new Set(ineq.map((x) => x.f)); const orderOnly = order.filter((o) => !ineqFields.has(o.f) && !eq.some((e) => e.f === o.f && e.op === '=='));
  return (eq.length + ineq.length > 0 && orderOnly.length > 0) || ineqFields.size > 1 || (ineq.length && eq.length > 0 && false);
}
function covered(col, q) {
  const eqF = q.eq.filter((e) => e.op === '==' || e.op === 'in').map((e) => e.f); const ac = q.eq.filter((e) => e.op === 'array-contains').map((e) => e.f);
  const ineqF = [...new Set(q.ineq.map((x) => x.f))]; const ord = q.order.map((o) => o.f).filter((f) => !eqF.includes(f));
  const want = [...new Set([...eqF, ...ac])]; const tail = [...new Set([...ineqF, ...ord])];
  return idx.some((i) => i.collectionGroup === col && (() => {
    const f = i.fields.map((x) => x.fieldPath).filter((x) => x !== '__name__'); if (f.length < want.length + tail.length) return false;
    const head = f.slice(0, want.length); const rest = f.slice(want.length, want.length + tail.length);
    return want.every((w) => head.includes(w)) && tail.every((t, k) => rest[k] === t);
  })());
}
let problems = 0, checked = 0; const seen = new Set();
for (const f of files) {
  const src = readFileSync(f, 'utf8');
  for (const m of src.matchAll(/query\(\s*collection\(db\(\),\s*([^)]+?)\)\s*,/g)) {
    const col = m[1].trim().replace(/^'|'$/g, ''); if (!/^[A-Za-z]+$/.test(m[1].trim().replace(/'/g, ''))) continue;
    const call = balanced(src, m.index + 'query'.length); const args = call.slice(1, -1);
    const fnStart = src.lastIndexOf('\nexport', m.index); const fnSrc = src.slice(Math.max(0, fnStart), m.index + call.length + 200);
    const q = analyse(col, args, fnSrc);
    // Full form and (if any optional constraint) the minimal form.
    const variants = [q]; if (q.optional) variants.push({ ...q, eq: q.eq.filter((e) => !e.opt), ineq: q.ineq.filter((e) => !e.opt) });
    for (const v of variants) {
      if (!needsIndex(v)) continue; const key = `${col}|${v.eq.map((e) => e.f + e.op).join(',')}|${v.ineq.map((e) => e.f).join(',')}|${v.order.map((o) => o.f).join(',')}`; if (seen.has(key)) continue; seen.add(key); checked++;
      if (!covered(col, v)) { problems++; console.log(`✘ NO INDEX  ${col}  eq[${v.eq.map((e) => e.f).join(',')}] range[${v.ineq.map((e) => e.f).join(',')}] orderBy[${v.order.map((o) => o.f).join(',')}]  (${f})`); }
    }
  }
}
for (const i of idx) { if (!i.fields?.length || !i.collectionGroup) { problems++; console.log('✘ malformed index', JSON.stringify(i)); } }
const dup = new Set(); for (const i of idx) { const k = i.collectionGroup + '|' + i.queryScope + '|' + i.fields.map((x) => x.fieldPath + x.order).join(','); if (dup.has(k)) { problems++; console.log('✘ duplicate index', k); } dup.add(k); }
console.log(`${checked} distinct index-requiring queries checked against ${idx.length} indexes; ${problems} problem(s).`);
process.exit(problems ? 1 : 0);
