// Offline STATIC audit of firestore.rules / storage.rules (no emulator needed). It does NOT evaluate rules; it checks structural invariants
// that must always hold. The behavioural tests live in tests/firestore.rules.test.ts and need the Firebase Emulator (npm run test:rules).
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const fs = readFileSync('firestore.rules', 'utf8');
const st = readFileSync('storage.rules', 'utf8');
let fail = 0;
const ok = (c, m, extra = '') => { console.log(`${c ? '✔ PASS' : '✘ FAIL'} ${m}${!c && extra ? ' — ' + extra : ''}`); if (!c) fail++; };

// ---- split top-level collection blocks ----
function blocks(src) {
  const out = {}; const re = /^\s{4}match \/([A-Za-z]+)\/\{[^}]+\} \{/gm; let m; const starts = [];
  while ((m = re.exec(src))) starts.push({ name: m[1], at: m.index });
  starts.forEach((s, i) => { out[s.name] = src.slice(s.at, starts[i + 1]?.at ?? src.length); });
  return out;
}
const B = blocks(fs);
const rule = (name, op) => { const m = new RegExp(`allow ([a-z, ]*\\b${op}\\b[a-z, ]*):\\s*if ([^;]+);`).exec(B[name] ?? ''); return m ? m[2].trim() : null; };
const allRules = (name) => [...(B[name] ?? '').matchAll(/allow ([a-z, ]+):\s*if ([^;]+);/g)].map((x) => ({ ops: x[1].split(',').map((o) => o.trim()), cond: x[2].trim() }));

// 1. Money, notifications, orders: no client create/write.
for (const c of ['sellerEarnings', 'sellerBalances', 'withdrawals', 'orderItems', 'announcements']) ok(allRules(c).every((r) => !(r.ops.includes('write') || r.ops.includes('create') || r.ops.includes('update') || r.ops.includes('delete')) || r.cond === 'false'), `${c}: no client writes`);
ok(rule('orders', 'create') === 'false', 'orders: create is server-only'); ok(rule('orders', 'delete') === 'false', 'orders: delete denied');
ok(rule('notifications', 'create') === 'false', 'notifications: cannot be created by clients');
ok(rule('roles', 'update') === 'false' && rule('roles', 'delete') === 'false', 'roles: a role can never be updated or deleted by a client');
{ const c = rule('roles', 'create') ?? '';
  ok(/isMe\(uid\)/.test(c) && /role == 'seller'/.test(c) && /email_verified == true/.test(c) && /appUnreviewedBefore\(uid\)/.test(c) && /appApprovedFor\(uid\)/.test(c) && /storeExistsAfter\(uid\)/.test(c),
     'roles: the only client create is own uid, verified email, role == seller, same batch as an approved application + store'); }
ok(/allow create: if isMe\(uid\)[^;]*role == 'seller'/.test(B.roles) && !/'admin'|'super_admin'|'moderator'/.test((rule('roles', 'create') ?? '')), 'roles: self-created role can never be an admin/staff role');
ok(/match \/storeSlugs\//.test(fs) && rule('storeSlugs', 'update') === 'false', 'storeSlugs: claims are create-only');
ok(/storeFinance/.test(B.storeFinance ?? '') && !/allow create[^;]*isMe\(/.test(B.storeFinance ?? ''), 'storeFinance: a seller can never write their own commission');
ok(/noRoleDoc\(storeId\)/.test(rule('stores', 'create') ?? '') && /isMe\(storeId\)/.test(rule('stores', 'create') ?? ''), 'stores: self-create needs own uid as store id and no existing role (one store per user)');
// 2. Nothing world-WRITABLE.
for (const [n, body] of Object.entries(B)) { const bad = allRules(n).filter((r) => r.cond === 'true' && r.ops.some((o) => ['write', 'create', 'update', 'delete'].includes(o))); ok(!bad.length, `${n}: no unconditional write`); }
// 3. Public-read collections are an explicit allow-list.
const publicRead = Object.keys(B).filter((n) => allRules(n).some((r) => r.cond === 'true' && r.ops.some((o) => ['read', 'get', 'list'].includes(o)))).sort();
const EXPECTED_PUBLIC = ['categories', 'profiles', 'publicSettings', 'searchTerms', 'usernames'];
ok(JSON.stringify(publicRead) === JSON.stringify(EXPECTED_PUBLIC), 'world-readable collections are exactly the intended list', `got ${publicRead.join(', ')}`);
// 4. Seller application: pending only on create; role never client-written.
ok(/sellerApplications[\s\S]*?request\.resource\.data\.status == 'pending'/.test(B.sellerApplications), 'sellerApplications: create must be status=pending');
ok(!/allow [a-z, ]*(create|update|write)[a-z, ]*:\s*if[^;]*roles\//.test(fs) , 'no rule lets a client write under roles/ via another path');
// 5. Admin-only collections.
for (const c of ['adminLogs', 'platformSettings', 'platformPromotions', 'storeFinance']) ok(!allRules(c).some((r) => r.ops.includes('read') && r.cond === 'true'), `${c}: not publicly readable`);
ok(/isSuper\(\) && adOk/.test(B.adNetworkSettings), 'adNetworkSettings: only super admin may change ad code');
ok(/email_verified == true/.test(rule('sellerApplications', 'create') ?? '') || /activationFieldsOk/.test(B.sellerApplications) && /function activationFieldsOk[^}]*email_verified == true/.test(fs), 'sellerApplications: auto-approval requires a verified email');
// 6. The admin review function (and the Worker) keep email-verification for admin approvals (server side).
const seller = readFileSync('functions/src/seller.ts', 'utf8');
ok(/emailVerified/.test(seller) && /requireAdmin/.test(seller), 'reviewSellerApplication: admin-only and requires verified email');
// 7. Storage: every write rule has a content-type check AND a size cap; no unconditional write.
const sb = [...st.matchAll(/match (\/[^{]*\{[^}]*\}[^{]*)\{([\s\S]*?)\n    \}/g)];
for (const [, path, body] of sb) {
  const writes = [...body.matchAll(/allow ((?:create|update|write)[a-z, ]*):\s*if ([^;]+);/g)];
  for (const [, , cond] of writes) {
    const isDelete = false; void isDelete;
    ok(cond !== 'true', `storage ${path.trim()}: write is not unconditional`);
    const mediaWrite = !/isAdmin\(\) && isImage/.test(cond) || true;
    ok(/under\(\d+\)/.test(cond) && /(isImage|isVideo)\(\)/.test(cond), `storage ${path.trim()}: write checks type + size`, cond.slice(0, 90)); void mediaWrite;
    ok(/isMe\(|isAdmin\(\)/.test(cond), `storage ${path.trim()}: write checks ownership/admin`);
  }
}
// 8. No rule file accepts any path by wildcard.
ok(!/match \/\{allPaths=\*\*\}/.test(st) && !/match \/\{document=\*\*\}/.test(fs), 'no catch-all match (default deny)');
// 9. Collections the client code touches all have a rule.
const used = new Set(); const walk = (d) => { for (const f of readdirSync(d)) { if (['node_modules', '.next', 'functions', 'tests'].includes(f)) continue; const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else if (/\.(ts|tsx)$/.test(f)) for (const m of readFileSync(p, 'utf8').matchAll(/(?:collection|doc)\(db\(\), '([A-Za-z]+)'/g)) used.add(m[1]); } };
for (const d of ['app', 'components', 'services', 'hooks', 'lib']) walk(d);
const missing = [...used].filter((c) => !B[c]); ok(!missing.length, 'every collection used by the client has a rules block', missing.join(', '));
console.log(`\n${fail ? fail + ' FAILED' : 'all static checks passed'}. This is a structural audit only; behaviour requires the emulator tests.`);
process.exit(fail ? 1 : 0);
