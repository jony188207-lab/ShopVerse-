import type { SellerApplication } from '@/types/seller';

/** Pure builder for the auto-approval batch (kept free of Firebase imports so it is unit-testable). `ts` is the server timestamp sentinel. */
export function buildActivation<T>(uid: string, app: Pick<SellerApplication, 'storeName' | 'slug' | 'description' | 'logoUrl' | 'bannerUrl' | 'city' | 'country' | 'returnPolicy' | 'shippingInfo' | 'phone' | 'email' | 'address'>, ts: T) {
  return {
    application: { status: 'approved' as const, storeId: uid, updatedAt: ts },
    role: { role: 'seller' as const, updatedBy: uid, updatedAt: ts },
    store: {
      ownerId: uid, applicationId: uid, name: app.storeName, slug: app.slug, description: app.description ?? '', logoUrl: app.logoUrl ?? '', bannerUrl: app.bannerUrl ?? '',
      city: app.city, country: app.country, returnPolicy: app.returnPolicy ?? '', shippingInfo: app.shippingInfo ?? '', shippingFee: 0,
      status: 'approved' as const, ratingAvg: 0, ratingCount: 0, ratingSum: 0, followerCount: 0, salesCount: 0, createdAt: ts, updatedAt: ts,
    },
    storePrivate: { phone: app.phone, email: app.email, address: app.address, createdAt: ts, updatedAt: ts },
    slugClaim: { uid, createdAt: ts },
  };
}
