import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { doc, setDoc } from 'firebase/firestore';
import { ref, uploadBytes, deleteObject } from 'firebase/storage';
import { readFileSync } from 'fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';

// Needs BOTH emulators (storage rules read /roles and /reviews from Firestore): `firebase emulators:exec --only firestore,storage ...`
let env: RulesTestEnvironment;
beforeAll(async () => {
  env = await initializeTestEnvironment({ projectId: 'shopverse-storage-test', firestore: { rules: readFileSync('firestore.rules', 'utf8') }, storage: { rules: readFileSync('storage.rules', 'utf8') } });
});
afterAll(() => env.cleanup());
beforeEach(async () => {
  await env.clearFirestore(); await env.clearStorage();
  await env.withSecurityRulesDisabled(async (ctx) => {
    const d = ctx.firestore();
    await setDoc(doc(d, 'roles/sellerA'), { role: 'seller' }); await setDoc(doc(d, 'roles/sellerB'), { role: 'seller' }); await setDoc(doc(d, 'roles/adm'), { role: 'admin' });
    await setDoc(doc(d, 'reviews/r1'), { userId: 'u1', status: 'published' });
  });
});
const st = (uid: string, verified = true) => env.authenticatedContext(uid, { email_verified: verified }).storage();
const png = (kb = 1) => new Uint8Array(kb * 1024);
const img = { contentType: 'image/png' }; const vid = { contentType: 'video/mp4' };
const put = (s: ReturnType<typeof st>, path: string, bytes: Uint8Array, meta: { contentType: string }) => uploadBytes(ref(s, path), bytes, meta);

describe('storage ownership', () => {
  it('users write only their own profile image', async () => {
    await assertSucceeds(put(st('u1'), 'profiles/u1/a.png', png(), img));
    await assertFails(put(st('u2'), 'profiles/u1/a.png', png(), img));
    await assertFails(put(env.unauthenticatedContext().storage(), 'profiles/u1/b.png', png(), img));
  });
  it('seller A cannot write seller B\'s product media or store branding', async () => {
    await assertSucceeds(put(st('sellerA'), 'products/sellerA/p1/a.png', png(), img));
    await assertFails(put(st('sellerA'), 'products/sellerB/p1/a.png', png(), img));
    await assertFails(put(st('sellerA'), 'stores/sellerB/logo.png', png(), img));
    await assertFails(put(st('u1'), 'products/u1/p1/a.png', png(), img));   // customers are not sellers
  });
  it('seller A cannot delete seller B\'s files', async () => {
    await env.withSecurityRulesDisabled((ctx) => put(ctx.storage(), 'products/sellerB/p1/a.png', png(), img).then(() => undefined));
    await assertFails(deleteObject(ref(st('sellerA'), 'products/sellerB/p1/a.png')));
    await assertSucceeds(deleteObject(ref(st('sellerB'), 'products/sellerB/p1/a.png')));
  });
});
describe('storage types and sizes', () => {
  it('rejects non-media content types and oversized files', async () => {
    await assertFails(put(st('u1'), 'profiles/u1/x.html', png(), { contentType: 'text/html' }));
    await assertFails(put(st('u1'), 'profiles/u1/x.svg', png(), { contentType: 'image/svg+xml' }));
    await assertFails(put(st('u1'), 'profiles/u1/big.png', png(6 * 1024), img));            // > 5 MB
    await assertFails(put(st('sellerA'), 'products/sellerA/p1/v.mp4', png(), vid));          // video in the image-only path
    await assertFails(put(st('sellerA'), 'products/sellerA/p1/big.png', png(11 * 1024), img)); // > 10 MB
  });
});
describe('storage review media, videos, admin areas', () => {
  it('review media requires the reviewer\'s own review and a verified email', async () => {
    await assertSucceeds(put(st('u1'), 'reviews/u1/r1/a.png', png(), img));
    await assertFails(put(st('u1', false), 'reviews/u1/r1/a.png', png(), img));
    await assertFails(put(st('u2'), 'reviews/u2/r1/a.png', png(), img));      // review r1 belongs to u1
    await assertFails(put(st('u1'), 'reviews/u1/none/a.png', png(), img));    // no such review
  });
  it('only sellers (verified) upload videos, only to their own folder', async () => {
    await assertSucceeds(put(st('sellerA'), 'videos/sellerA/v1/a.mp4', png(), vid));
    await assertFails(put(st('sellerA', false), 'videos/sellerA/v1/b.mp4', png(), vid));
    await assertFails(put(st('sellerA'), 'videos/sellerB/v1/a.mp4', png(), vid));
    await assertFails(put(st('u1'), 'videos/u1/v1/a.mp4', png(), vid));
  });
  it('banners and categories are admin-only; unknown paths are denied', async () => {
    await assertSucceeds(put(st('adm'), 'banners/b.png', png(), img));
    await assertFails(put(st('sellerA'), 'banners/b.png', png(), img));
    await assertFails(put(st('adm'), 'categories/c.png', png(), vid));
    await assertFails(put(st('adm'), 'random/anything.png', png(), img));
  });
});
