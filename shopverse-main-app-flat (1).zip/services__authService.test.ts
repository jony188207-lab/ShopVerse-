import { beforeEach, describe, expect, it, vi } from 'vitest';

// Firebase and the sibling services are mocked: this tests OUR orchestration (order of steps, error handling), not Firebase itself.
const calls: string[] = [];
vi.mock('firebase/auth', () => ({
  createUserWithEmailAndPassword: vi.fn(),
  updateProfile: vi.fn(),
  sendEmailVerification: vi.fn(),
  signInWithEmailAndPassword: vi.fn(),
  signOut: vi.fn(),
  sendPasswordResetEmail: vi.fn(),
}));
vi.mock('@/lib/firebase/config', () => ({ auth: () => ({ currentUser: null }) }));
vi.mock('./pushService', () => ({ detachPush: vi.fn() }));
vi.mock('./userService', () => ({ ensureUserDocs: vi.fn() }));
vi.mock('./sellerService', () => ({ slugLooksFree: vi.fn(), submitApplication: vi.fn(), toStoreSlug: (s: string) => s }));

import * as fa from 'firebase/auth';
import { ensureUserDocs } from './userService';
import { login, requestPasswordReset, signUp } from './authService';

const user = { uid: 'u1', email: 'a@b.com', emailVerified: false };

beforeEach(() => {
  calls.length = 0;
  vi.clearAllMocks();
  vi.mocked(fa.createUserWithEmailAndPassword).mockResolvedValue({ user } as never);
  vi.mocked(fa.signInWithEmailAndPassword).mockResolvedValue({ user } as never);
  vi.mocked(fa.updateProfile).mockResolvedValue(undefined as never);
  vi.mocked(fa.sendEmailVerification).mockImplementation((async () => { calls.push('verify'); }) as never);
  vi.mocked(ensureUserDocs).mockImplementation((async () => { calls.push('docs'); }) as never);
});

describe('signUp', () => {
  it('trims the email, then sends the verification email BEFORE creating the Firestore docs', async () => {
    await signUp({ email: '  a@b.com ', password: 'password1', displayName: ' Ann ' });
    expect(fa.createUserWithEmailAndPassword).toHaveBeenCalledWith(expect.anything(), 'a@b.com', 'password1');
    expect(fa.updateProfile).toHaveBeenCalledWith(user, { displayName: 'Ann' });
    expect(calls).toEqual(['verify', 'docs']);
  });

  it('still sends the verification email when the Firestore step fails (and surfaces that failure)', async () => {
    vi.mocked(ensureUserDocs).mockRejectedValueOnce(new Error('permission-denied'));
    await expect(signUp({ email: 'a@b.com', password: 'password1', displayName: 'Ann' })).rejects.toThrow('permission-denied');
    expect(fa.sendEmailVerification).toHaveBeenCalledTimes(1);
  });

  it('does not touch Firestore or send email when account creation fails (e.g. email already in use)', async () => {
    vi.mocked(fa.createUserWithEmailAndPassword).mockRejectedValueOnce(Object.assign(new Error('x'), { code: 'auth/email-already-in-use' }));
    await expect(signUp({ email: 'a@b.com', password: 'password1', displayName: 'Ann' })).rejects.toMatchObject({ code: 'auth/email-already-in-use' });
    expect(fa.sendEmailVerification).not.toHaveBeenCalled();
    expect(ensureUserDocs).not.toHaveBeenCalled();
  });
});

describe('login', () => {
  it('signs in with the trimmed email and returns the user', async () => {
    await expect(login(' a@b.com ', 'pw')).resolves.toBe(user);
    expect(fa.signInWithEmailAndPassword).toHaveBeenCalledWith(expect.anything(), 'a@b.com', 'pw');
  });

  it('does not report a failed login when only the profile-repair step fails', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined);
    vi.mocked(ensureUserDocs).mockRejectedValueOnce(new Error('unavailable'));
    await expect(login('a@b.com', 'pw')).resolves.toBe(user);
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });

  it('propagates real authentication errors (wrong password) and does not repair docs', async () => {
    vi.mocked(fa.signInWithEmailAndPassword).mockRejectedValueOnce(Object.assign(new Error('x'), { code: 'auth/invalid-credential' }));
    await expect(login('a@b.com', 'bad')).rejects.toMatchObject({ code: 'auth/invalid-credential' });
    expect(ensureUserDocs).not.toHaveBeenCalled();
  });
});

describe('requestPasswordReset', () => {
  it('sends the reset email to the trimmed address', async () => {
    vi.mocked(fa.sendPasswordResetEmail).mockResolvedValue(undefined as never);
    await requestPasswordReset(' a@b.com ');
    expect(fa.sendPasswordResetEmail).toHaveBeenCalledWith(expect.anything(), 'a@b.com');
  });
});
