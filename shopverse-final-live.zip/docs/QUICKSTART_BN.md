# দ্রুত শুরু (Android ফোন, Bangla)

> Chrome-এ ⋮ মেনু থেকে **Desktop site** চালু করুন। কোনো কিছু ডেপ্লয় না করা পর্যন্ত সাইট Live নয়।

## ধাপ ১: GitHub-এ ফাইল তোলা (ফোল্ডার বাদ পড়ার সমস্যা এড়াতে)
1. GitHub-এ একটি **private** রিপোজিটরি বানান।
2. **Add file → Upload files** দিয়ে শুধু `shopverse-final-live.zip` আপলোড করুন → **Commit changes**।
3. **Add file → Create new file** → নামের ঘরে লিখুন `.github/workflows/unzip.yml` → `docs/github-unzip-workflow.yml` ফাইলের লেখা পেস্ট করুন → **Commit**।
4. **Actions** ট্যাব → **Unzip project** → **Run workflow**। সবুজ টিক এলে রিপোজিটরিতে `customer-app`, `admin-panel`, `cloudflare-worker` ফোল্ডার দেখা যাবে।

## ধাপ ২: Firebase (বিনামূল্যে)
`docs/FIREBASE_CONFIGURATION.md` অনুযায়ী: Email/Password চালু → Firestore তৈরি → `customer-app/firestore.rules` Publish → `roles/<আপনার UID>` ডকুমেন্টে `role` = `super_admin` (আন্ডারস্কোর দিয়ে)।

## ধাপ ৩: Vercel (দুটি আলাদা প্রজেক্ট)
- প্রজেক্ট ১: একই রিপোজিটরি → **Root Directory = `customer-app`**।
- প্রজেক্ট ২: একই রিপোজিটরি → **Root Directory = `admin-panel`**।
- দুটিতেই `NEXT_PUBLIC_FIREBASE_*` ভেরিয়েবল দিন (`.env.example` দেখুন) → Deploy।
- দুটি ডোমেইনই Firebase **Authentication → Authorized domains**-এ যোগ করুন।

## ধাপ ৪: ফ্রি Seller Approval (Cloudflare)
`cloudflare-worker/README.md` অনুযায়ী Worker বানান, `SERVICE_ACCOUNT_JSON` শুধু **Secret** হিসেবে বসান, তারপর Admin Vercel প্রজেক্টে `NEXT_PUBLIC_SELLER_API_URL` দিয়ে Redeploy করুন। Key ফাইল ফোন থেকে মুছে ফেলুন; কাউকে পাঠাবেন না।

## Admin Panel-এ কী করবেন
- **Banners**: ছবি (https লিংক), শিরোনাম, বিবরণ, প্রোডাক্ট (লিংক), অগ্রাধিকার, চালু/বন্ধ।
- **Adsterra settings** (শুধু Super Admin কোড বদলাতে পারে): Adsterra-র কোড পেস্ট → Save → "Show this ad" টিক দিন।
- **Sellers**: Pending আবেদন Approve/Reject (আবেদনকারীর ইমেইল ভেরিফাইড হতে হবে)।
