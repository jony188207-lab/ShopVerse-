# Firebase configuration (project `shopverse21-831fc`, free Spark plan)

Nothing here needs billing. Use Chrome with **Desktop site** on.

## 1. Authentication
Console → Build → **Authentication → Get started → Sign-in method → Email/Password → Enable → Save.**
Then **Settings → Authorized domains → Add domain** for **each** site: your customer-app domain and your admin-panel domain (host name only, no `https://`). Login fails on any domain not listed.

## 2. Web app keys (public by design)
Project settings (gear) → **General → Your apps → Web app** → copy `apiKey` and `appId` into Vercel as `NEXT_PUBLIC_FIREBASE_API_KEY` / `NEXT_PUBLIC_FIREBASE_APP_ID` for **both** Vercel projects. Project id, auth domain, sender id are in `.env.example`.

## 3. Firestore
Build → **Firestore Database → Create database** → production mode → choose a region (cannot be changed later).
**Rules:** Rules tab → select all → paste the whole of `customer-app/firestore.rules` → **Publish**. This is the only security layer for browser access; do not loosen it.
**Indexes:** `customer-app/firestore.indexes.json` (58 indexes) cannot be pasted in the Console. From a computer or a free GitHub Codespace: `cd customer-app && npm install && npx firebase login && npm run deploy:free` (dry run), then `npm run deploy:free -- --yes`. Wait until every index shows **Enabled**. Without them, admin lists and the storefront show "needs an index" errors.

## 4. Your first super admin (the document the panel reads)
Authentication → Users → copy your **User UID**. Firestore → **Start collection** `roles` → Document ID = **the UID** → field `role`, type string, value **`super_admin`** (underscore, lower case). Sign out and in again. Other spellings (`super-admin`, `Admin`) are refused by the panel, the rules and the functions.

## 5. Seller approval without Blaze
Follow `cloudflare-worker/README.md` (service account with two read/write roles, Worker secret, one Vercel variable). Do **not** use the Firebase Admin SDK key file; create the dedicated `shopverse-worker` account.

## 6. What still needs the paid Blaze plan
| Feature | Why |
|---|---|
| Checkout / place order, cancel, return | only the `placeOrder` Cloud Function may create orders (rules forbid clients) |
| User suspension and roles, withdrawals, COD confirmation, announcements | Cloud Functions |
| Counters, notifications, scheduled releases | Firestore triggers / Cloud Scheduler |
| Image/video uploads | Cloud Storage requires Blaze for a new project (banner and ad images are https links, so they do not) |

Seller approval, banners, Adsterra settings, categories and moderation work on Spark. Cloud Functions also need Node 22 (Node 20 is decommissioned for deploys on 2026-10-30).
