// Recreates the project's folders from "flat" files. Why: phone file pickers (and GitHub's web uploader on Android) upload loose files
// but silently skip folders. In the FLAT ZIP every file sits at the repository root with "/" written as "__"
// (e.g. app__login__page.tsx  ->  app/login/page.tsx). This script moves them back. It runs before every build/dev start.
// In the normal (folder) layout there are no such files, so it changes nothing.
import { existsSync, mkdirSync, readdirSync, renameSync } from 'node:fs';
import { dirname, join } from 'node:path';

const ROOTS = new Set(['app', 'components', 'config', 'docs', 'hooks', 'lib', 'public', 'scripts', 'types']);
let moved = 0;
for (const name of readdirSync('.')) {
  if (!name.includes('__')) continue;
  const parts = name.split('__');
  if (!ROOTS.has(parts[0])) continue;
  const target = join(...parts);
  mkdirSync(dirname(target), { recursive: true });
  renameSync(name, target); // overwrites an existing file of the same path
  moved++;
}
if (moved) console.log(`restore-structure: restored ${moved} files into folders.`);
if (!existsSync('app')) {
  console.error('ERROR: the "app" folder is missing and no flat "app__*" files were found. Upload ALL files from the ZIP, then redeploy.');
  process.exit(1);
}
