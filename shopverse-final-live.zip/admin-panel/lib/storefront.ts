// Optional link back to the customer app. Empty when NEXT_PUBLIC_STOREFRONT_URL is not set (the links are then simply not shown).
const BASE = (process.env.NEXT_PUBLIC_STOREFRONT_URL || '').replace(/\/+$/, '');
export const storefrontUrl = (path: string): string => (BASE ? `${BASE}${path}` : '');
