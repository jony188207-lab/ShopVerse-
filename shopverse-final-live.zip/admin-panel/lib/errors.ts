const CODES: Record<string, string> = {
  'auth/invalid-email': 'Enter a valid email address.',
  'auth/user-disabled': 'This account has been disabled.',
  'auth/user-not-found': 'Email or password is incorrect.',
  'auth/wrong-password': 'Email or password is incorrect.',
  'auth/invalid-credential': 'Email or password is incorrect.',
  'auth/too-many-requests': 'Too many attempts. Wait a few minutes and try again.',
  'auth/network-request-failed': 'Network problem. Check your connection and try again.',
  'permission-denied': 'Your role is not allowed to do that (Firestore security rules).',
  'failed-precondition': 'That query needs a Firestore index that is not deployed yet. Deploy firestore.indexes.json from the customer-app repository.',
  unavailable: 'Firestore is unreachable right now. Try again shortly.',
};

/**
 * Cloud Functions that are not deployed (they need the Firebase Blaze plan) fail in several ways depending on the browser/SDK
 * (404 not-found, a blocked cross-origin 404 that surfaces as internal/unavailable). We cannot tell those apart from a real outage,
 * so for those codes we say both things instead of guessing.
 */
const FUNCTIONS_UNREACHABLE = 'The Cloud Function did not respond. It is probably not deployed (Cloud Functions need the Firebase Blaze plan), or the network failed. Nothing was changed.';

/** The SDK reports an unreachable/undeployed function with a generic message equal to the code name ("internal", "not-found"...). Our own functions raise readable messages. */
const isGeneric = (m: string) => !m || /^(not[ _-]?found|internal|unavailable|unknown|deadline[ _-]?exceeded)$/i.test(m.trim());
const UNREACHABLE_CODES = ['not-found', 'internal', 'unavailable', 'deadline-exceeded', 'unknown'];

export function friendlyError(err: unknown): string {
  if (err instanceof Error && err.name === 'FirebaseNotConfiguredError') return err.message;
  const code = typeof err === 'object' && err && 'code' in err ? String((err as { code: unknown }).code) : '';
  const message = err instanceof Error ? err.message : '';
  if (code.startsWith('functions/')) {
    const c = code.slice('functions/'.length);
    if (UNREACHABLE_CODES.includes(c) && isGeneric(message)) return FUNCTIONS_UNREACHABLE;
    if (c === 'unauthenticated') return 'Your session expired. Sign in again.';
    return message || 'The request was refused.'; // permission-denied / failed-precondition / invalid-argument / not-found carry user-safe text from our functions
  }
  return CODES[code] ?? CODES[code.replace('firestore/', '')] ?? 'Something went wrong. Try again.';
}
