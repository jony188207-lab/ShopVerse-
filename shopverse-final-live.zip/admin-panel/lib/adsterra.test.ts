import { describe, expect, it } from 'vitest';
import { describeCode, hasInsecureScript, sizeFromCode, validateAd } from './adsterra';
import { normalizeApiUrl } from './apiUrl';

const SNIPPET = `<script type="text/javascript">atOptions = {'key' : 'abc123','format' : 'iframe','height' : 90,'width' : 728,'params' : {}};</script>
<script type="text/javascript" src="//www.example-ads.com/abc123/invoke.js"></script>`;
const ok = { networkName: 'Adsterra', adCode: SNIPPET, width: 728, height: 90, device: 'all' };

describe('sizeFromCode', () => {
  it('reads width and height from an Adsterra atOptions snippet', () => { expect(sizeFromCode(SNIPPET)).toEqual({ width: 728, height: 90 }); });
  it('returns undefined when the code has no size', () => { expect(sizeFromCode('<script src="//x/y.js"></script>')).toEqual({ width: undefined, height: undefined }); });
});
describe('validateAd (mirrors firestore.rules adOk)', () => {
  it('accepts a normal snippet', () => { expect(validateAd(ok)).toBe(''); });
  it('rejects empty, non-code and oversized code', () => {
    expect(/Paste/.test(validateAd({ ...ok, adCode: '   ' }))).toBe(true);
    expect(/does not look like ad code/.test(validateAd({ ...ok, adCode: 'hello world' }))).toBe(true);
    expect(/too long/.test(validateAd({ ...ok, adCode: `<script>${'a'.repeat(20000)}</script>` }))).toBe(true);
  });
  it('enforces size, device and name limits', () => {
    expect(/Width/.test(validateAd({ ...ok, width: 49 }))).toBe(true);
    expect(/Width/.test(validateAd({ ...ok, width: 1201 }))).toBe(true);
    expect(/Height/.test(validateAd({ ...ok, height: 29 }))).toBe(true);
    expect(/Height/.test(validateAd({ ...ok, height: 601 }))).toBe(true);
    expect(/Width/.test(validateAd({ ...ok, width: Number.NaN }))).toBe(true);
    expect(/device/.test(validateAd({ ...ok, device: 'tv' }))).toBe(true);
    expect(/Network name/.test(validateAd({ ...ok, networkName: '' }))).toBe(true);
    expect(/Network name/.test(validateAd({ ...ok, networkName: 'x'.repeat(61) }))).toBe(true);
  });
});
describe('helpers', () => {
  it('never returns the code when describing it', () => { expect(describeCode(SNIPPET)).not.toContain('script'); });
  it('flags plain-http scripts but accepts protocol-relative and https', () => {
    expect(hasInsecureScript('<script src="http://a.com/x.js"></script>')).toBe(true);
    expect(hasInsecureScript(SNIPPET)).toBe(false);
    expect(hasInsecureScript('<script src="https://a.com/x.js"></script>')).toBe(false);
  });
});
describe('normalizeApiUrl', () => {
  it('accepts https and localhost, strips trailing slashes', () => {
    expect(normalizeApiUrl('https://w.example.workers.dev/')).toBe('https://w.example.workers.dev');
    expect(normalizeApiUrl(' http://localhost:8787 ')).toBe('http://localhost:8787');
  });
  it('rejects empty, plain http, javascript: and junk', () => {
    for (const v of [undefined, '', 'http://evil.com', 'javascript:alert(1)', 'w.example.com', 'https://a b.com', 'https://a.com?x=1']) expect(normalizeApiUrl(v)).toBe('');
  });
});
