import { auth } from '@/lib/firebase/config';
import { normalizeApiUrl } from '@/lib/apiUrl';

/**
 * Optional free backend for seller decisions: the Cloudflare Worker in /cloudflare-worker. When NEXT_PUBLIC_SELLER_API_URL is set,
 * approve / reject / suspend / reactivate go there instead of the Cloud Function (which needs the Firebase Blaze plan).
 * The Worker verifies the Firebase ID token and the admin role itself; nothing secret is in the browser.
 */
// The literal process.env.NEXT_PUBLIC_* reference lets Next.js inline the value at build time.
export const sellerApiUrl = (): string => normalizeApiUrl(process.env.NEXT_PUBLIC_SELLER_API_URL);

export interface SellerReviewResult { ok: boolean; storeId: string; products: number }

export async function callSellerApi(base: string, payload: { applicationId: string; action: string; note: string }): Promise<SellerReviewResult> {
  const token = await auth().currentUser?.getIdToken();
  if (!token) throw new Error('Your session expired. Sign in again.');
  let res: Response;
  try {
    res = await fetch(`${base}/seller/review`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify(payload) });
  } catch {
    throw new Error('Could not reach the approval service. Check your connection and that this site is listed in ALLOWED_ORIGINS of the Cloudflare Worker.');
  }
  let json: { error?: { message?: string } } & Partial<SellerReviewResult> = {};
  try { json = await res.json(); } catch { /* not JSON */ }
  if (!res.ok) throw new Error(json.error?.message ?? `The approval service returned an error (${res.status}).`);
  return { ok: true, storeId: json.storeId ?? '', products: json.products ?? 0 };
}
