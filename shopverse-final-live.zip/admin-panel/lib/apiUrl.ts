/** Accepts only an https:// base URL (or http://localhost for local development); returns '' otherwise. Pure, so it is unit tested. */
export function normalizeApiUrl(raw: string | undefined): string {
  const v = (raw ?? '').trim().replace(/\/+$/, '');
  return /^https:\/\/[^\s/?#]+(\/[^\s?#]*)?$/.test(v) || /^http:\/\/localhost(:\d+)?$/.test(v) ? v : '';
}
