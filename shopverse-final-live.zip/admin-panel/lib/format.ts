export const str = (v: unknown, fallback = ''): string => (typeof v === 'string' ? v : fallback);
export const num = (v: unknown, fallback = 0): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
export const bool = (v: unknown): boolean => v === true;
export const strList = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []);

/** Firestore Timestamp | Date -> Date. Anything else -> null. */
export function toDate(v: unknown): Date | null {
  if (v instanceof Date) return v;
  if (v && typeof (v as { toDate?: unknown }).toDate === 'function') return (v as { toDate: () => Date }).toDate();
  return null;
}
export function fmtDate(v: unknown): string {
  const d = toDate(v);
  return d ? d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—';
}
export function fmtMoney(n: number, currency = 'USD'): string {
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(n); } catch { return `${n.toFixed(2)} ${currency}`; }
}
/** datetime-local input value <-> Date (local time). */
export function toInputValue(v: unknown): string {
  const d = toDate(v);
  if (!d) return '';
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
export function fromInputValue(s: string): Date | null {
  if (!s) return null;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}
/** Only same-site relative redirects after login. */
export function safeNextPath(next: string | null | undefined): string {
  if (!next || !next.startsWith('/') || next.startsWith('//') || next.includes('\\')) return '/';
  return next;
}
/** Category ids are slugs (rules: ^[a-z0-9]+(-[a-z0-9]+)*$). */
export const SLUG_RE = /^[a-z0-9]+(-[a-z0-9]+)*$/;
export const toSlug = (s: string): string => s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
