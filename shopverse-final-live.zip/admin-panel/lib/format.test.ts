import { describe, expect, it } from 'vitest';
import { SLUG_RE, fromInputValue, num, safeNextPath, str, toInputValue, toSlug } from './format';

describe('safeNextPath', () => {
  it('keeps same-site paths', () => { expect(safeNextPath('/orders/1')).toBe('/orders/1'); });
  it('rejects external, protocol-relative and backslash redirects', () => {
    expect(safeNextPath('https://evil.com')).toBe('/');
    expect(safeNextPath('//evil.com')).toBe('/');
    expect(safeNextPath('/\\evil.com')).toBe('/');
    expect(safeNextPath(null)).toBe('/');
    expect(safeNextPath('')).toBe('/');
  });
});
describe('toSlug / SLUG_RE', () => {
  it('turns names into valid slugs', () => {
    expect(toSlug('Mobile & Accessories')).toBe('mobile-and-accessories');
    expect(toSlug('  Home   & Living ')).toBe('home-and-living');
    expect(SLUG_RE.test(toSlug('Books & Stationery'))).toBe(true);
  });
  it('rejects bad slugs', () => {
    expect(SLUG_RE.test('Bad Slug')).toBe(false);
    expect(SLUG_RE.test('a--b')).toBe(false);
    expect(SLUG_RE.test('-a')).toBe(false);
  });
});
describe('safe readers', () => {
  it('str and num fall back on wrong types', () => {
    expect(str(3)).toBe('');
    expect(str('x')).toBe('x');
    expect(num('5')).toBe(0);
    expect(num(NaN)).toBe(0);
    expect(num(7)).toBe(7);
  });
});
describe('datetime-local helpers', () => {
  it('round-trips and handles empty/invalid input', () => {
    const d = fromInputValue('2026-03-04T05:06');
    expect(d).not.toBeNull();
    expect(toInputValue(d)).toBe('2026-03-04T05:06');
    expect(fromInputValue('')).toBeNull();
    expect(fromInputValue('nonsense')).toBeNull();
    expect(toInputValue(null)).toBe('');
  });
});
