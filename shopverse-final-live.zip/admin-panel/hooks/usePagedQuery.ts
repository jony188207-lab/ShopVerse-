'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { getDocs, limit, query, startAfter, type Query, type QueryDocumentSnapshot } from 'firebase/firestore';
import { friendlyError } from '@/lib/errors';

/**
 * Cursor-paged Firestore list. `key` identifies the query (tab, filter...): when it changes the list reloads from page 1.
 * `make` returns the BASE query (where + orderBy, no limit/cursor); `map` converts a document to a row.
 * Late responses from an older key are discarded, so quick tab switches cannot show the wrong list.
 */
export function usePagedQuery<T>(key: string, make: () => Query, map: (d: QueryDocumentSnapshot) => T, pageSize = 20) {
  const makeRef = useRef(make); makeRef.current = make;
  const mapRef = useRef(map); mapRef.current = map;
  const ticket = useRef(0);
  const [items, setItems] = useState<T[]>([]);
  const [cursor, setCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async (after: QueryDocumentSnapshot | null) => {
    const mine = ++ticket.current;
    setLoading(true); setError('');
    try {
      const base = makeRef.current();
      const snap = await getDocs(after ? query(base, startAfter(after), limit(pageSize)) : query(base, limit(pageSize)));
      if (mine !== ticket.current) return;
      const rows = snap.docs.map((d) => mapRef.current(d));
      setItems((prev) => (after ? [...prev, ...rows] : rows));
      setCursor(snap.docs.length ? snap.docs[snap.docs.length - 1] : after);
      setHasMore(snap.docs.length === pageSize);
    } catch (e) {
      if (mine !== ticket.current) return;
      setError(friendlyError(e));
    } finally {
      if (mine === ticket.current) setLoading(false);
    }
  }, [pageSize]);

  useEffect(() => { setItems([]); setCursor(null); void load(null); }, [key, load]);

  return {
    items, loading, error, hasMore,
    loadMore: () => load(cursor),
    reload: () => { setItems([]); setCursor(null); return load(null); },
  };
}
