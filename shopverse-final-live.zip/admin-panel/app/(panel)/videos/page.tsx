'use client';
import { useState } from 'react';
import { collection, orderBy, query, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { moderationFields, updateWithAudit } from '@/lib/audit';
import { fmtDate, str } from '@/lib/format';
import { storefrontUrl } from '@/lib/storefront';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { ReasonDialog } from '@/components/ReasonDialog';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Tabs } from '@/components/ui/Tabs';

type Tab = 'pending_review' | 'published' | 'rejected' | 'suspended';
const TABS: { id: Tab; label: string }[] = [{ id: 'pending_review', label: 'Pending review' }, { id: 'published', label: 'Published' }, { id: 'rejected', label: 'Rejected' }, { id: 'suspended', label: 'Suspended' }];
interface V { id: string; title: string; description: string; ownerId: string; storeId: string; thumbnailUrl: string; videoUrl: string; visibility: string; note: string; createdAt: unknown }
const mapV = (d: QueryDocumentSnapshot): V => {
  const x = d.data();
  return { id: d.id, title: str(x.title), description: str(x.description), ownerId: str(x.ownerId), storeId: str(x.storeId), thumbnailUrl: str(x.thumbnailUrl), videoUrl: str(x.videoUrl), visibility: str(x.visibility), note: str(x.moderationNote), createdAt: x.createdAt };
};
const isHttps = (u: string) => /^https:\/\//i.test(u);

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('pending_review');
  const [dialog, setDialog] = useState<{ v: V; status: 'rejected' | 'suspended' } | null>(null);
  const [busyId, setBusyId] = useState('');
  const list = usePagedQuery(tab, () => query(collection(db(), 'videos'), where('status', '==', tab), orderBy('createdAt', 'desc')), mapV);

  const moderate = async (v: V, status: 'published' | 'rejected' | 'suspended', note: string) => {
    if (!user) return;
    setBusyId(v.id);
    try {
      await updateWithAudit(user.uid, ['videos', v.id], moderationFields(user.uid, status, note), { action: `video.${status}`, targetType: 'video', targetId: v.id, note });
      toast(`“${v.title}” → ${status}.`, 'success');
      await list.reload();
    } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); throw e; } finally { setBusyId(''); }
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Videos</h1>
      <Tabs label="Video status" tabs={TABS} value={tab} onChange={setTab} />
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No videos in this state" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((v) => (
          <Card key={v.id} className="flex gap-3">
            {v.thumbnailUrl && isHttps(v.thumbnailUrl) ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={v.thumbnailUrl} alt="" loading="lazy" className="h-24 w-16 shrink-0 rounded-lg bg-navy-50 object-cover" /> : <div className="h-24 w-16 shrink-0 rounded-lg bg-navy-50 dark:bg-navy-900" />}
            <div className="min-w-0 flex-1 space-y-1">
              <div className="flex flex-wrap items-start justify-between gap-2"><p className="font-bold">{v.title}</p><Badge>{tab}</Badge></div>
              <p className="text-xs text-navy-500 dark:text-navy-100">{v.visibility} · {fmtDate(v.createdAt)}</p>
              <p className="break-all text-xs text-navy-500 dark:text-navy-100">owner {v.ownerId} · store {v.storeId}</p>
              {v.description ? <p className="line-clamp-3 text-sm">{v.description}</p> : null}
              {v.note ? <p className="text-sm"><span className="font-semibold">Note:</span> {v.note}</p> : null}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {tab !== 'published' ? <Button small loading={busyId === v.id} onClick={() => void moderate(v, 'published', '').catch(() => undefined)}>{tab === 'suspended' ? 'Restore' : 'Approve'}</Button> : null}
                {tab === 'pending_review' ? <Button small variant="danger" disabled={busyId === v.id} onClick={() => setDialog({ v, status: 'rejected' })}>Reject…</Button> : null}
                {tab === 'published' ? <Button small variant="danger" disabled={busyId === v.id} onClick={() => setDialog({ v, status: 'suspended' })}>Suspend…</Button> : null}
                {isHttps(v.videoUrl) ? <a className="text-xs text-brand-purple underline" href={v.videoUrl} target="_blank" rel="noopener noreferrer">Open video file</a> : null}
                {storefrontUrl(`/video/${v.id}`) && tab === 'published' ? <a className="text-xs text-brand-purple underline" href={storefrontUrl(`/video/${v.id}`)} target="_blank" rel="noopener noreferrer">View on storefront</a> : null}
              </div>
            </div>
          </Card>
        ))}
      </ListStates>
      {dialog ? <ReasonDialog title={`${dialog.status === 'rejected' ? 'Reject' : 'Suspend'} “${dialog.v.title}”`} confirmLabel={dialog.status === 'rejected' ? 'Reject' : 'Suspend'} danger
        onConfirm={(r) => moderate(dialog.v, dialog.status, r)} onClose={() => setDialog(null)} /> : null}
    </>
  );
}
export default function VideosPage() { return <Require level="staff"><Inner /></Require>; }
