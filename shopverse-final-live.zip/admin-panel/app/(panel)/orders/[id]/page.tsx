'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { collection, doc, getDoc, getDocs, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useToast } from '@/hooks/useToast';
import { confirmCodRemittance } from '@/lib/callables';
import { friendlyError } from '@/lib/errors';
import { fmtDate, fmtMoney, num, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { ErrorState, LoadingState, Notice } from '@/components/ui/States';

interface Item { id: string; title: string; variantLabel: string; quantity: number; unitPrice: number; lineTotal: number; productId: string }
interface Detail {
  id: string; orderNumber: string; status: string; paymentMethod: string; paymentStatus: string; storeName: string; buyerId: string; sellerId: string;
  subtotal: number; discount: number; shipping: number; total: number; currency: string; couponCode: string; codRemitted: boolean; createdAt: unknown;
  address: Record<string, string>; timeline: { status: string; at: unknown }[]; items: Item[];
}

function Inner() {
  const { id } = useParams<{ id: string }>();
  const toast = useToast();
  const [o, setO] = useState<Detail | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError('');
    try {
      const s = await getDoc(doc(db(), 'orders', id));
      if (!s.exists()) { setError('Order not found.'); return; }
      const x = s.data();
      const items = await getDocs(query(collection(db(), 'orderItems'), where('orderId', '==', id)));
      const a = (x.address ?? {}) as Record<string, unknown>;
      setO({
        id, orderNumber: str(x.orderNumber, id), status: str(x.status), paymentMethod: str(x.paymentMethod), paymentStatus: str(x.paymentStatus), storeName: str(x.storeName), buyerId: str(x.buyerId), sellerId: str(x.sellerId),
        subtotal: num(x.subtotal), discount: num(x.discount), shipping: num(x.shipping), total: num(x.total), currency: str(x.currency, 'USD'), couponCode: str(x.couponCode), codRemitted: x.codRemitted === true, createdAt: x.createdAt,
        address: Object.fromEntries(Object.entries(a).map(([k, v]) => [k, str(v)])),
        timeline: Array.isArray(x.timeline) ? (x.timeline as { status?: unknown; at?: unknown }[]).map((t) => ({ status: str(t.status), at: t.at })) : [],
        items: items.docs.map((d) => { const i = d.data(); return { id: d.id, title: str(i.title), variantLabel: str(i.variantLabel), quantity: num(i.quantity), unitPrice: num(i.unitPrice), lineTotal: num(i.lineTotal), productId: str(i.productId) }; }),
      });
    } catch (e) { setError(friendlyError(e)); }
  }, [id]);
  useEffect(() => { void load(); }, [load]);

  const confirmCash = async () => {
    if (!o || !window.confirm(`Confirm that the cash for ${o.orderNumber} reached the platform? The seller's earnings then start their hold period.`)) return;
    setBusy(true);
    try { await confirmCodRemittance(o.id); toast('Cash confirmed.', 'success'); await load(); } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); } finally { setBusy(false); }
  };

  if (error) return <ErrorState message={error} action={<Button onClick={() => void load()}>Try again</Button>} />;
  if (!o) return <LoadingState />;
  const addr = o.address;
  return (
    <>
      <p><Link href="/orders" className="text-sm text-brand-purple underline">← All orders</Link></p>
      <div className="flex flex-wrap items-center justify-between gap-2"><h1 className="text-2xl font-extrabold">{o.orderNumber}</h1><div className="flex gap-1"><Badge>{o.status}</Badge><Badge tone="gray">{`${o.paymentMethod} · ${o.paymentStatus}`}</Badge></div></div>
      <Card className="space-y-1 text-sm">
        <p><span className="font-semibold">Placed:</span> {fmtDate(o.createdAt)} · <span className="font-semibold">Store:</span> {o.storeName}</p>
        <p className="break-all"><span className="font-semibold">Buyer:</span> {o.buyerId} · <span className="font-semibold">Seller:</span> {o.sellerId}</p>
        <p><span className="font-semibold">Deliver to:</span> {[addr.fullName, addr.phone, addr.address, addr.area, addr.city, addr.postalCode, addr.country].filter(Boolean).join(', ')}</p>
        {addr.instructions ? <p><span className="font-semibold">Instructions:</span> {addr.instructions}</p> : null}
      </Card>
      <Card className="space-y-2">
        <h2 className="font-bold">Items</h2>
        <ul className="divide-y divide-navy-100 dark:divide-navy-500">{o.items.map((i) => (
          <li key={i.id} className="flex justify-between gap-2 py-2 text-sm"><span>{i.quantity} × {i.title}{i.variantLabel ? ` (${i.variantLabel})` : ''}</span><span>{fmtMoney(i.lineTotal, o.currency)}</span></li>
        ))}</ul>
        <dl className="space-y-1 border-t border-navy-100 pt-2 text-sm dark:border-navy-500">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{fmtMoney(o.subtotal, o.currency)}</dd></div>
          {o.discount > 0 ? <div className="flex justify-between"><dt>Discount{o.couponCode ? ` (${o.couponCode})` : ''}</dt><dd>−{fmtMoney(o.discount, o.currency)}</dd></div> : null}
          <div className="flex justify-between"><dt>Shipping</dt><dd>{fmtMoney(o.shipping, o.currency)}</dd></div>
          <div className="flex justify-between text-base font-extrabold"><dt>Total</dt><dd>{fmtMoney(o.total, o.currency)}</dd></div>
        </dl>
      </Card>
      <Card className="space-y-1"><h2 className="font-bold">Timeline</h2>
        {o.timeline.length ? <ol className="space-y-1 text-sm">{o.timeline.map((t, k) => <li key={k}><Badge>{t.status}</Badge> <span className="text-xs text-navy-500 dark:text-navy-100">{fmtDate(t.at)}</span></li>)}</ol> : <p className="text-sm">No timeline entries.</p>}
      </Card>
      {o.paymentMethod === 'cod' && o.status === 'delivered' ? (
        <Card className="space-y-2">
          <h2 className="font-bold">Cash on delivery</h2>
          {o.codRemitted ? <p className="text-sm">Cash confirmed. The seller&apos;s earnings follow the normal hold period.</p> : <>
            <p className="text-sm">The platform has not confirmed receiving the cash for this order. Seller earnings stay locked until you do.</p>
            <Notice tone="warn">Runs through the <code>confirmCodRemittance</code> Cloud Function (Blaze plan).</Notice>
            <Button loading={busy} onClick={() => void confirmCash()}>Confirm cash received</Button></>}
        </Card>
      ) : null}
      <Notice>Order status is changed by the seller (and the customer-app functions). This panel does not edit orders, so the audit trail and stock/earnings triggers stay consistent.</Notice>
    </>
  );
}
export default function OrderDetailPage() { return <Require level="admin"><Inner /></Require>; }
