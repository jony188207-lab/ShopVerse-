'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { collection, doc, getDocs, limit, orderBy, query, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/errors';
import { SLUG_RE, num, str, toSlug } from '@/lib/format';
import { DEFAULT_CATEGORIES } from '@/config/defaultCategories';
import { Require } from '@/components/Require';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field, Select } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState, Notice } from '@/components/ui/States';

interface C { id: string; name: string; order: number; active: boolean; imageUrl: string; parentId: string }
interface Draft { isNew: boolean; id: string; name: string; order: string; active: boolean; imageUrl: string; parentId: string }
const EMPTY: Draft = { isNew: true, id: '', name: '', order: '0', active: true, imageUrl: '', parentId: '' };

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState<C[] | null>(null);
  const [error, setError] = useState('');
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');

  const load = useCallback(async () => {
    setError('');
    try {
      const snap = await getDocs(query(collection(db(), 'categories'), orderBy('order'), limit(200)));
      setItems(snap.docs.map((d) => { const x = d.data(); return { id: d.id, name: str(x.name), order: num(x.order), active: x.active !== false, imageUrl: str(x.imageUrl), parentId: str(x.parentId) }; }));
    } catch (e) { setError(friendlyError(e)); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const log = (batch: ReturnType<typeof writeBatch>, action: string, id: string, note = '') => {
    if (user) batch.set(doc(collection(db(), 'adminLogs')), { adminId: user.uid, action, targetType: 'category', targetId: id, ...(note ? { note } : {}), createdAt: serverTimestamp() });
  };

  const importDefaults = async () => {
    if (!window.confirm('Copy the built-in categories into the database? The storefront will then use ONLY the categories listed here.')) return;
    setBusy(true);
    try {
      const batch = writeBatch(db());
      DEFAULT_CATEGORIES.forEach((c) => batch.set(doc(db(), 'categories', c.id), { name: c.name, order: c.order, active: true, imageUrl: '', parentId: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
      log(batch, 'category.import_defaults', '*', `${DEFAULT_CATEGORIES.length} categories`);
      await batch.commit();
      toast('Built-in categories imported.', 'success');
      await load();
    } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };

  const toggle = async (c: C) => {
    setBusy(true);
    try {
      const batch = writeBatch(db());
      batch.update(doc(db(), 'categories', c.id), { active: !c.active, updatedAt: serverTimestamp() });
      log(batch, c.active ? 'category.deactivate' : 'category.activate', c.id);
      await batch.commit();
      await load();
    } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft) return;
    const name = draft.name.trim();
    const order = Number(draft.order);
    const id = draft.isNew ? (draft.id.trim() || toSlug(name)) : draft.id;
    const imageUrl = draft.imageUrl.trim();
    if (name.length < 2 || name.length > 60) return setFormError('Name must be 2–60 characters.');
    if (!Number.isInteger(order) || order < 0 || order > 10000) return setFormError('Order must be a whole number from 0 to 10000.');
    if (draft.isNew && !SLUG_RE.test(id)) return setFormError('The id must be lowercase letters, numbers and single dashes (e.g. home-garden).');
    if (draft.isNew && items?.some((c) => c.id === id)) return setFormError('A category with this id already exists.');
    if (imageUrl && (!/^https:\/\//i.test(imageUrl) || imageUrl.length > 1000)) return setFormError('Image must be an https:// link (or empty).');
    setFormError(''); setBusy(true);
    try {
      const batch = writeBatch(db());
      if (draft.isNew) batch.set(doc(db(), 'categories', id), { name, order, active: draft.active, imageUrl, parentId: draft.parentId, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
      else batch.update(doc(db(), 'categories', id), { name, order, active: draft.active, imageUrl, parentId: draft.parentId, updatedAt: serverTimestamp() });
      log(batch, draft.isNew ? 'category.create' : 'category.update', id, name);
      await batch.commit();
      toast('Category saved.', 'success');
      setDraft(null);
      await load();
    } catch (err) { setFormError(friendlyError(err)); } finally { setBusy(false); }
  };

  if (error) return <ErrorState message={error} action={<Button onClick={() => void load()}>Try again</Button>} />;
  if (!items) return <LoadingState />;
  const tops = items.filter((c) => !c.parentId);
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-2"><h1 className="text-2xl font-extrabold">Categories</h1><Button onClick={() => { setFormError(''); setDraft(EMPTY); }}>New category</Button></div>
      <Notice tone="warn">The storefront uses its built-in list only while this list is empty. Once any category exists here, only these are shown, so import the built-in ones first. Categories are deactivated, not deleted, because existing products keep pointing at their id.</Notice>
      {draft ? (
        <Card><form onSubmit={save} className="space-y-3">
          <h2 className="font-bold">{draft.isNew ? 'New category' : `Edit ${draft.id}`}</h2>
          <Field label="Name" required minLength={2} maxLength={60} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
          {draft.isNew ? <Field label="Id (slug)" hint={`Leave empty to use “${toSlug(draft.name) || '…'}”. Cannot be changed later.`} value={draft.id} onChange={(e) => setDraft({ ...draft, id: e.target.value })} /> : null}
          <Field label="Sort order" type="number" min={0} max={10000} step={1} value={draft.order} onChange={(e) => setDraft({ ...draft, order: e.target.value })} />
          <Select label="Parent category (optional)" value={draft.parentId} onChange={(e) => setDraft({ ...draft, parentId: e.target.value })}>
            <option value="">None (top level)</option>
            {tops.filter((c) => c.id !== draft.id).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <Field label="Image link (optional, https)" type="url" value={draft.imageUrl} onChange={(e) => setDraft({ ...draft, imageUrl: e.target.value })} />
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={draft.active} onChange={(e) => setDraft({ ...draft, active: e.target.checked })} /> Active (visible in the storefront)</label>
          {formError ? <p role="alert" className="text-sm text-red-600">{formError}</p> : null}
          <div className="flex gap-2"><Button type="submit" loading={busy}>Save</Button><Button variant="ghost" onClick={() => setDraft(null)} disabled={busy}>Cancel</Button></div>
        </form></Card>
      ) : null}
      {items.length === 0 ? (
        <EmptyState title="No categories in the database" action={<Button loading={busy} onClick={() => void importDefaults()}>Import built-in categories</Button>}>The storefront is using its built-in list.</EmptyState>
      ) : items.map((c) => (
        <Card key={c.id} className="flex flex-wrap items-center justify-between gap-2">
          <div><p className="font-bold">{c.name}{c.parentId ? <span className="text-xs font-normal text-navy-500 dark:text-navy-100"> · under {items.find((p) => p.id === c.parentId)?.name ?? c.parentId}</span> : null}</p><p className="text-xs text-navy-500 dark:text-navy-100">{c.id} · order {c.order}</p></div>
          <div className="flex items-center gap-2"><Badge tone={c.active ? 'green' : 'gray'}>{c.active ? 'active' : 'inactive'}</Badge>
            <Button small variant="ghost" disabled={busy} onClick={() => { setFormError(''); setDraft({ isNew: false, id: c.id, name: c.name, order: String(c.order), active: c.active, imageUrl: c.imageUrl, parentId: c.parentId }); }}>Edit</Button>
            <Button small variant="ghost" disabled={busy} onClick={() => void toggle(c)}>{c.active ? 'Deactivate' : 'Activate'}</Button></div>
        </Card>
      ))}
    </>
  );
}
export default function CategoriesPage() { return <Require level="admin"><Inner /></Require>; }
