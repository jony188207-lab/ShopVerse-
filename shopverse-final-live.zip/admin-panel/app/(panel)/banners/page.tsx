'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { addDoc, collection, deleteDoc, doc, getDocs, limit, orderBy, query, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/errors';
import { fmtDate, fromInputValue, num, str, toDate, toInputValue } from '@/lib/format';
import { Require } from '@/components/Require';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState, Notice } from '@/components/ui/States';

interface B { id: string; title: string; subtitle: string; desktopImage: string; mobileImage: string; productId: string; ctaText: string; priority: number; active: boolean; startDate: Date | null; endDate: Date | null }
interface Draft { id: string; title: string; subtitle: string; desktopImage: string; mobileImage: string; productId: string; ctaText: string; priority: string; active: boolean; startDate: string; endDate: string }
const EMPTY: Draft = { id: '', title: '', subtitle: '', desktopImage: '', mobileImage: '', productId: '', ctaText: 'Shop now', priority: '0', active: true, startDate: '', endDate: '' };
const isHttps = (u: string) => /^https:\/\//i.test(u);

function stateOf(b: B, now = new Date()): { label: string; tone: 'green' | 'amber' | 'gray' } {
  if (!b.active) return { label: 'paused', tone: 'gray' };
  if (b.startDate && b.startDate > now) return { label: 'scheduled', tone: 'amber' };
  if (b.endDate && b.endDate < now) return { label: 'ended', tone: 'gray' };
  return { label: 'live', tone: 'green' };
}

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState<B[] | null>(null);
  const [error, setError] = useState('');
  const [draft, setDraft] = useState<Draft | null>(null);
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError('');
    try {
      const snap = await getDocs(query(collection(db(), 'productBanners'), orderBy('priority', 'desc'), limit(100)));
      setItems(snap.docs.map((d) => { const x = d.data(); return { id: d.id, title: str(x.title), subtitle: str(x.subtitle), desktopImage: str(x.desktopImage), mobileImage: str(x.mobileImage), productId: str(x.productId), ctaText: str(x.ctaText), priority: num(x.priority), active: x.active === true, startDate: toDate(x.startDate), endDate: toDate(x.endDate) }; }));
    } catch (e) { setError(friendlyError(e)); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const audit = (action: string, id: string, note = '') => user ? addDoc(collection(db(), 'adminLogs'), { adminId: user.uid, action, targetType: 'banner', targetId: id, ...(note ? { note } : {}), createdAt: serverTimestamp() }) : Promise.resolve();
  const patch = async (b: B, changes: Record<string, unknown>, action: string) => {
    setBusy(true);
    try { await updateDoc(doc(db(), 'productBanners', b.id), { ...changes, updatedAt: serverTimestamp() }); await audit(action, b.id); await load(); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  const remove = async (b: B) => {
    if (!window.confirm(`Delete the banner “${b.title}”?`)) return;
    setBusy(true);
    try { await deleteDoc(doc(db(), 'productBanners', b.id)); await audit('banner.delete', b.id, b.title); await load(); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft) return;
    const title = draft.title.trim(); const subtitle = draft.subtitle.trim(); const cta = draft.ctaText.trim();
    const desktop = draft.desktopImage.trim(); const mobile = draft.mobileImage.trim(); const pid = draft.productId.trim();
    const priority = Number(draft.priority);
    const start = fromInputValue(draft.startDate); const end = fromInputValue(draft.endDate);
    if (title.length < 2 || title.length > 100) return setFormError('Title must be 2–100 characters.');
    if (subtitle.length > 200) return setFormError('Subtitle can be at most 200 characters.');
    if (cta.length < 1 || cta.length > 30) return setFormError('Button text must be 1–30 characters.');
    if (!isHttps(desktop)) return setFormError('The desktop image must be an https:// link.');
    if (mobile && !isHttps(mobile)) return setFormError('The mobile image must be an https:// link (or empty).');
    if (!pid) return setFormError('Enter the product id the banner should open.');
    if (!Number.isInteger(priority)) return setFormError('Priority must be a whole number (higher shows first).');
    if (start && end && end <= start) return setFormError('The end must be after the start.');
    setFormError(''); setBusy(true);
    try {
      const data = { title, subtitle, desktopImage: desktop, mobileImage: mobile, productId: pid, ctaText: cta, priority, active: draft.active, startDate: start, endDate: end, updatedAt: serverTimestamp() };
      if (draft.id) { await updateDoc(doc(db(), 'productBanners', draft.id), data); await audit('banner.update', draft.id, title); }
      else { const ref = await addDoc(collection(db(), 'productBanners'), { ...data, createdAt: serverTimestamp() }); await audit('banner.create', ref.id, title); }
      toast('Banner saved.', 'success');
      setDraft(null); await load();
    } catch (err) { setFormError(friendlyError(err) + ' The product id must belong to an approved product.'); } finally { setBusy(false); }
  };

  if (error) return <ErrorState message={error} action={<Button onClick={() => void load()}>Try again</Button>} />;
  if (!items) return <LoadingState />;
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-2"><h1 className="text-2xl font-extrabold">Home banners</h1><Button onClick={() => { setFormError(''); setDraft(EMPTY); }}>New banner</Button></div>
      <Notice>Banners link to an <strong>approved product</strong> (the rules check this on create, edit and re-activation: use Activate… to re-check). Images are https links, so no file storage is needed: host them anywhere you control. The storefront also hides a banner whose product is out of stock.</Notice>
      {draft ? (
        <Card><form onSubmit={save} className="space-y-3">
          <h2 className="font-bold">{draft.id ? 'Edit banner' : 'New banner'}</h2>
          <Field label="Title" required maxLength={100} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
          <Field label="Subtitle (optional)" maxLength={200} value={draft.subtitle} onChange={(e) => setDraft({ ...draft, subtitle: e.target.value })} />
          <Field label="Desktop image (https link)" type="url" required value={draft.desktopImage} onChange={(e) => setDraft({ ...draft, desktopImage: e.target.value })} />
          <Field label="Mobile image (https link, optional)" type="url" value={draft.mobileImage} onChange={(e) => setDraft({ ...draft, mobileImage: e.target.value })} />
          <Field label="Product id" required hint="Copy the id from the Products page (approved products only)." value={draft.productId} onChange={(e) => setDraft({ ...draft, productId: e.target.value })} />
          <Field label="Button text" required maxLength={30} value={draft.ctaText} onChange={(e) => setDraft({ ...draft, ctaText: e.target.value })} />
          <Field label="Priority" type="number" step={1} hint="Higher numbers show first." value={draft.priority} onChange={(e) => setDraft({ ...draft, priority: e.target.value })} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Starts (optional)" type="datetime-local" value={draft.startDate} onChange={(e) => setDraft({ ...draft, startDate: e.target.value })} />
            <Field label="Ends (optional)" type="datetime-local" value={draft.endDate} onChange={(e) => setDraft({ ...draft, endDate: e.target.value })} />
          </div>
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={draft.active} onChange={(e) => setDraft({ ...draft, active: e.target.checked })} /> Active</label>
          {formError ? <p role="alert" className="text-sm text-red-600">{formError}</p> : null}
          <div className="flex gap-2"><Button type="submit" loading={busy}>Save</Button><Button variant="ghost" onClick={() => setDraft(null)} disabled={busy}>Cancel</Button></div>
        </form></Card>
      ) : null}
      {items.length === 0 ? <EmptyState title="No banners yet">Create one to show a carousel on the storefront home page.</EmptyState> : items.map((b) => {
        const st = stateOf(b);
        return (
          <Card key={b.id} className="space-y-2">
            <div className="flex gap-3">
              {isHttps(b.desktopImage) ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={b.desktopImage} alt="" loading="lazy" className="h-16 w-28 shrink-0 rounded-lg bg-navy-50 object-cover" /> : null}
              <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><p className="font-bold">{b.title}</p><Badge tone={st.tone}>{st.label}</Badge></div>
                <p className="text-xs text-navy-500 dark:text-navy-100">priority {b.priority} · {fmtDate(b.startDate)} → {fmtDate(b.endDate)}</p><p className="break-all text-xs text-navy-500 dark:text-navy-100">product {b.productId}</p></div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button small variant="ghost" disabled={busy} onClick={() => { setFormError(''); setDraft({ id: b.id, title: b.title, subtitle: b.subtitle, desktopImage: b.desktopImage, mobileImage: b.mobileImage, productId: b.productId, ctaText: b.ctaText, priority: String(b.priority), active: b.active, startDate: toInputValue(b.startDate), endDate: toInputValue(b.endDate) }); }}>Edit</Button>
              {b.active
                ? <Button small variant="ghost" disabled={busy} onClick={() => void patch(b, { active: false }, 'banner.pause')}>Pause</Button>
                : <Button small variant="ghost" disabled={busy} onClick={() => { setFormError(''); setDraft({ id: b.id, title: b.title, subtitle: b.subtitle, desktopImage: b.desktopImage, mobileImage: b.mobileImage, productId: b.productId, ctaText: b.ctaText, priority: String(b.priority), active: true, startDate: toInputValue(b.startDate), endDate: toInputValue(b.endDate) }); }}>Activate…</Button>}
              <Button small variant="ghost" disabled={busy} onClick={() => void patch(b, { priority: b.priority + 1 }, 'banner.priority')}>Priority +1</Button>
              <Button small variant="ghost" disabled={busy} onClick={() => void patch(b, { priority: b.priority - 1 }, 'banner.priority')}>−1</Button>
              <Button small variant="danger" disabled={busy} onClick={() => void remove(b)}>Delete</Button>
            </div>
          </Card>
        );
      })}
    </>
  );
}
export default function BannersPage() { return <Require level="admin"><Inner /></Require>; }
