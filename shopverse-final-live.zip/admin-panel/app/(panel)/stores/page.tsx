'use client';
import { useEffect, useState } from 'react';
import { collection, doc, getDoc, orderBy, query, serverTimestamp, writeBatch, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { fmtDate, num, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { Notice } from '@/components/ui/States';

interface S { id: string; name: string; slug: string; ownerId: string; status: string; city: string; country: string; createdAt: unknown }
const mapS = (d: QueryDocumentSnapshot): S => {
  const x = d.data();
  return { id: d.id, name: str(x.name), slug: str(x.slug), ownerId: str(x.ownerId), status: str(x.status), city: str(x.city), country: str(x.country), createdAt: x.createdAt };
};

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const list = usePagedQuery('stores', () => query(collection(db(), 'stores'), orderBy('createdAt', 'desc')), mapS);
  const [rates, setRates] = useState<Record<string, string>>({});   // commission text per store (loaded from storeFinance)
  const [saved, setSaved] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState('');

  // storeFinance is admin-only (the public store document never carries the commission).
  useEffect(() => {
    const missing = list.items.filter((s) => saved[s.id] === undefined);
    if (!missing.length) return;
    let alive = true;
    void Promise.all(missing.map(async (s) => {
      try { const f = await getDoc(doc(db(), 'storeFinance', s.id)); return [s.id, f.exists() ? String(num(f.data().commissionRate, 10)) : ''] as const; } catch { return [s.id, ''] as const; }
    })).then((pairs) => { if (!alive) return; const o = Object.fromEntries(pairs); setSaved((x) => ({ ...x, ...o })); setRates((x) => ({ ...o, ...x })); });
    return () => { alive = false; };
  }, [list.items, saved]);

  const save = async (s: S) => {
    if (!user) return;
    const n = Number(rates[s.id]);
    if (rates[s.id] === '' || !Number.isFinite(n) || n < 0 || n > 50) { toast('Commission must be a number from 0 to 50.', 'error'); return; }
    setBusyId(s.id);
    try {
      const batch = writeBatch(db());
      batch.set(doc(db(), 'storeFinance', s.id), { commissionRate: n, updatedAt: serverTimestamp() });
      batch.set(doc(collection(db(), 'adminLogs')), { adminId: user.uid, action: 'store.commission', targetType: 'store', targetId: s.id, note: `${saved[s.id] || 'default'} → ${n}%`, createdAt: serverTimestamp() });
      await batch.commit();
      setSaved((x) => ({ ...x, [s.id]: String(n) }));
      toast(`Commission for ${s.name} set to ${n}%. Applies to orders delivered from now on.`, 'success');
    } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); } finally { setBusyId(''); }
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Stores</h1>
      <Notice>Per-store commission (0–50%). A store without its own rate uses the platform default from Settings. Suspending or reactivating a store is done on the Sellers page.</Notice>
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No stores yet" emptyText="Stores are created when a seller application is approved." hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((s) => (
          <Card key={s.id} className="space-y-2">
            <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="font-bold">{s.name}</p><p className="text-xs text-navy-500 dark:text-navy-100">/{s.slug} · {[s.city, s.country].filter(Boolean).join(', ')} · {fmtDate(s.createdAt)}</p><p className="break-all text-xs text-navy-500 dark:text-navy-100">owner {s.ownerId}</p></div><Badge>{s.status}</Badge></div>
            <div className="flex items-end gap-2">
              <div className="w-40"><Field label="Commission %" type="number" inputMode="decimal" min={0} max={50} step="0.1" placeholder="default" value={rates[s.id] ?? ''} onChange={(e) => setRates((x) => ({ ...x, [s.id]: e.target.value }))} /></div>
              <Button small loading={busyId === s.id} disabled={saved[s.id] === undefined || rates[s.id] === saved[s.id]} onClick={() => void save(s)}>Save</Button>
            </div>
          </Card>
        ))}
      </ListStates>
    </>
  );
}
export default function StoresPage() { return <Require level="admin"><Inner /></Require>; }
