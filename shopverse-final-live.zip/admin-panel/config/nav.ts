import type { Level } from '@/lib/permissions';

export interface NavItem { href: string; label: string; level: Level }
/** Which role level sees each page (mirrors firestore.rules: staff = moderator+, admin = admin+, super = super_admin). */
export const NAV: NavItem[] = [
  { href: '/', label: 'Dashboard', level: 'staff' },
  { href: '/sellers', label: 'Sellers', level: 'admin' },
  { href: '/users', label: 'Users', level: 'admin' },
  { href: '/stores', label: 'Stores', level: 'admin' },
  { href: '/products', label: 'Products', level: 'staff' },
  { href: '/reviews', label: 'Reviews', level: 'staff' },
  { href: '/videos', label: 'Videos', level: 'staff' },
  { href: '/reports', label: 'Reports', level: 'staff' },
  { href: '/orders', label: 'Orders', level: 'admin' },
  { href: '/withdrawals', label: 'Withdrawals', level: 'admin' },
  { href: '/categories', label: 'Categories', level: 'admin' },
  { href: '/banners', label: 'Banners', level: 'admin' },
  { href: '/adsterra', label: 'Adsterra settings', level: 'admin' },
  { href: '/announcements', label: 'Announcements', level: 'admin' },
  { href: '/settings', label: 'Settings', level: 'super' },
  { href: '/logs', label: 'Audit log', level: 'admin' },
];

/** Features whose server side is a Cloud Function (needs the Firebase Blaze plan). Used only to label the UI honestly. */
const FUNCTION_FEATURES = ['Seller approval / suspension', 'User suspension and role changes', 'Withdrawal decisions', 'COD cash confirmation', 'Announcements'];
/** Seller decisions do not need Cloud Functions when the free Cloudflare Worker is configured (NEXT_PUBLIC_SELLER_API_URL). */
export const needsFunctions = (sellerApiConfigured: boolean): string[] => (sellerApiConfigured ? FUNCTION_FEATURES.slice(1) : FUNCTION_FEATURES);
