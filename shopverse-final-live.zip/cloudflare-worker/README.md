# ShopVerse seller-approval Worker (Cloudflare, free plan)

A free replacement for the Cloud Function `reviewSellerApplication`, which needs the Firebase Blaze plan. The Admin Panel calls this Worker
for **approve / reject / suspend / reactivate** when `NEXT_PUBLIC_SELLER_API_URL` is set. Firestore stays the only database: **D1 is not used**
(a second database would only create two sources of truth).

## How it keeps approvals safe
1. The browser sends its **Firebase ID token**. The Worker verifies the RS256 signature against Google's public keys, the audience (`shopverse21-831fc`), issuer and expiry. No secret is needed for this.
2. It reads `roles/{uid}` with its own service account and accepts **only `admin` or `super_admin`**. Everyone else gets 403 before any input is even looked at.
3. Only then does it write, inside a Firestore transaction, with the same checks as the Cloud Function: the application must be `pending`, the applicant's **email must be verified** (Identity Toolkit lookup), the account must still be a plain `user`, own no store, and the store slug must be free.
4. It writes the store, `storeFinance`, `storePrivate`, `roles/{uid} = seller`, the application, an `adminLogs` entry and an in-app notification. Push messages are not sent (the Worker has no FCM).
5. The service-account key exists **only** as the Worker secret `SERVICE_ACCOUNT_JSON`. It is not in the browser, the repository, `NEXT_PUBLIC_*` variables or logs (tests assert this).
6. The Firestore rules are not changed or weakened. The Worker acts as a trusted server, exactly like the Cloud Function did.

## Configuration
| Name | Type | Value |
|---|---|---|
| `FIREBASE_PROJECT_ID` | text | `shopverse21-831fc` |
| `ALLOWED_ORIGINS` | text | exact admin-panel origin(s), e.g. `https://my-admin.vercel.app` (comma separated) |
| `SERVICE_ACCOUNT_JSON` | **secret** | the whole JSON key file of a dedicated service account (see below) |

## Create the service account (least privilege)
Google Cloud Console → project `shopverse21-831fc` → **IAM & Admin → Service accounts → Create service account** (name `shopverse-worker`).
Grant only: **Cloud Datastore User** (`roles/datastore.user`, read/write Firestore) and **Firebase Authentication Viewer** (`roles/firebaseauth.viewer`, includes `firebaseauth.users.get`).
Then **Keys → Add key → Create new key → JSON**. Paste the file's whole text into the Worker secret, then **delete the downloaded file**. Do not use the broad "Firebase Admin SDK" account, and never paste the key into chat, Git or Vercel.
If key creation is blocked by an organisation policy, this approach cannot be used and the Blaze Cloud Function remains the only option.

## Deploy from an Android phone (dashboard, no tools)
1. dash.cloudflare.com → **Workers & Pages → Create → Create Worker** → name `shopverse-seller-approval` → **Deploy**.
2. **Edit code** → select all → paste the whole of `src/worker.js` → **Deploy**.
3. **Settings → Variables and Secrets → Add**: the two text variables above, then `SERVICE_ACCOUNT_JSON` as type **Secret**. **Deploy**.
4. Open the Worker URL (`https://shopverse-seller-approval.<you>.workers.dev`). You should see `{"ok":true,"service":"shopverse-seller-approval"}`.
5. In the admin panel's Vercel project set `NEXT_PUBLIC_SELLER_API_URL` to that URL (no trailing slash) and **redeploy**.

From a computer: `npm install`, `npx wrangler login`, edit `ALLOWED_ORIGINS` in `wrangler.toml`, `npx wrangler secret put SERVICE_ACCOUNT_JSON`, `npx wrangler deploy`.

## Free-plan limits (Cloudflare docs, checked 2026-10)
100,000 requests/day · 10 ms CPU per request (network waiting does not count) · 50 subrequests per request · 5 KB per variable (a key file is about 2.4 KB).
One approval uses about a dozen subrequests. Suspending a store uses 2 more per 400 products. If you ever see "Exceeded CPU" errors the free CPU limit is too small for the RSA signing; that would need a paid Workers plan, which is not assumed here.

## Tests
`npm test` runs 29 tests with Node's built-in runner against an in-memory **simulation** of Google's token endpoints, Identity Toolkit and the Firestore REST API (real RSA signing and verification).
It proves the logic (authentication, admin-only access, every approval rule, retry on conflict, CORS, secret handling). It does **not** prove compatibility with the live Firestore service: do the manual check in the root README after deploying.
