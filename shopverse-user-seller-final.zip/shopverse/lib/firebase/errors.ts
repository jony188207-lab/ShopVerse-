const AUTH_MESSAGES: Record<string, string> = {
  'auth/invalid-email': 'Enter a valid email address.',
  'auth/user-disabled': 'This account has been disabled. Contact support.',
  'auth/user-not-found': 'Email or password is incorrect.',
  'auth/wrong-password': 'Email or password is incorrect.',
  'auth/invalid-credential': 'Email or password is incorrect.',
  'auth/email-already-in-use': 'An account with this email already exists. Sign in instead.',
  'auth/weak-password': 'Use a password with at least 8 characters.',
  'auth/too-many-requests': 'Too many attempts. Wait a few minutes and try again.',
  'auth/network-request-failed': 'Network problem. Check your connection and try again.',
  'permission-denied': 'You do not have permission to do that.',
  unavailable: 'Service temporarily unavailable. Try again shortly.',
};

export function friendlyError(err: unknown): string {
  if (err instanceof Error && err.name === 'FirebaseNotConfiguredError') return err.message;
  const code = typeof err === 'object' && err && 'code' in err ? String((err as { code: unknown }).code) : '';
  if (code.startsWith('functions/') && code !== 'functions/internal' && err instanceof Error && err.message) return err.message;
  return AUTH_MESSAGES[code] ?? AUTH_MESSAGES[code.replace('firestore/', '')] ?? 'Something went wrong. Try again.';
}
