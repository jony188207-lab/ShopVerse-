import { getMessaging, isSupported, onMessage, type Messaging, type MessagePayload } from 'firebase/messaging';
import { getFirebaseApp } from './config';

/** FCM only works in supported browsers over HTTPS (or localhost). Returns null otherwise. */
export async function getMessagingIfSupported(): Promise<Messaging | null> {
  if (typeof window === 'undefined') return null;
  try {
    if (!(await isSupported())) return null;
    return getMessaging(getFirebaseApp());
  } catch {
    return null;
  }
}

export async function onForegroundMessage(cb: (p: MessagePayload) => void): Promise<() => void> {
  const m = await getMessagingIfSupported();
  return m ? onMessage(m, cb) : () => undefined;
}
