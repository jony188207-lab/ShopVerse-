import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import { ReCaptchaV3Provider, initializeAppCheck } from 'firebase/app-check';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getStorage, type FirebaseStorage } from 'firebase/storage';
import { getFunctions, type Functions } from 'firebase/functions';

// Literal process.env.NEXT_PUBLIC_* references are required so Next.js can inline them.
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID || undefined,   // optional (analytics is not initialised)
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId,
);

export class FirebaseNotConfiguredError extends Error {
  constructor() {
    super('Firebase is not configured. Copy .env.example to .env.local and fill in your Firebase web app values.');
    this.name = 'FirebaseNotConfiguredError';
  }
}

/** Lazy getters: importing this module never throws, so builds/tests work without credentials. */
let appCheckStarted = false;
export function getFirebaseApp(): FirebaseApp {
  if (!isFirebaseConfigured) throw new FirebaseNotConfiguredError();
  const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
  // Optional App Check (reCAPTCHA v3): set NEXT_PUBLIC_RECAPTCHA_SITE_KEY, then ENFORCE it per product in the Firebase console.
  const siteKey = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY;
  if (typeof window !== 'undefined' && siteKey && !appCheckStarted) {
    appCheckStarted = true;
    if (process.env.NODE_ENV !== 'production') (self as unknown as { FIREBASE_APPCHECK_DEBUG_TOKEN?: boolean }).FIREBASE_APPCHECK_DEBUG_TOKEN = true;
    initializeAppCheck(app, { provider: new ReCaptchaV3Provider(siteKey), isTokenAutoRefreshEnabled: true });
  }
  return app;
}
export const auth = (): Auth => getAuth(getFirebaseApp());
export const db = (): Firestore => getFirestore(getFirebaseApp());
export const storage = (): FirebaseStorage => getStorage(getFirebaseApp());
export const functions = (): Functions => getFunctions(getFirebaseApp(), process.env.NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION || 'us-central1');
