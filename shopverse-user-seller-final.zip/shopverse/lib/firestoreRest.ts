// Tiny server-side reader for PUBLIC documents (no credentials: the Security Rules decide what an anonymous caller may read).
// Used only for SEO metadata + sitemap, where the browser SDK is not available.
type V = { stringValue?: string; integerValue?: string; doubleValue?: number; booleanValue?: boolean; arrayValue?: { values?: V[] }; mapValue?: { fields?: Record<string, V> }; timestampValue?: string; nullValue?: null };
export type Doc = Record<string, unknown> & { id: string };

const pid = () => process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
const base = () => `https://firestore.googleapis.com/v1/projects/${pid()}/databases/(default)/documents`;
function val(v: V | undefined): unknown {
  if (!v) return undefined;
  if ('stringValue' in v) return v.stringValue; if ('integerValue' in v) return Number(v.integerValue); if ('doubleValue' in v) return v.doubleValue; if ('booleanValue' in v) return v.booleanValue;
  if ('timestampValue' in v) return v.timestampValue; if (v.arrayValue) return (v.arrayValue.values ?? []).map(val);
  if (v.mapValue) return Object.fromEntries(Object.entries(v.mapValue.fields ?? {}).map(([k, x]) => [k, val(x)]));
  return null;
}
const toDoc = (d: { name: string; fields?: Record<string, V> }): Doc => ({ id: d.name.split('/').pop()!, ...Object.fromEntries(Object.entries(d.fields ?? {}).map(([k, v]) => [k, val(v)])) });

/** Returns null on ANY failure (not found, rules denied, offline, project not configured) so pages still render. */
export async function getPublicDoc(path: string, revalidate = 300): Promise<Doc | null> {
  if (!pid()) return null;
  try { const r = await fetch(`${base()}/${path}`, { next: { revalidate } }); return r.ok ? toDoc(await r.json()) : null; } catch { return null; }
}
export async function runPublicQuery(collection: string, where: [string, string][], opts: { limit?: number; orderBy?: string; revalidate?: number } = {}): Promise<Doc[]> {
  if (!pid()) return [];
  const filters = where.map(([f, v]) => ({ fieldFilter: { field: { fieldPath: f }, op: 'EQUAL', value: { stringValue: v } } }));
  const body = { structuredQuery: { from: [{ collectionId: collection }], where: filters.length === 1 ? filters[0] : { compositeFilter: { op: 'AND', filters } }, ...(opts.orderBy ? { orderBy: [{ field: { fieldPath: opts.orderBy }, direction: 'DESCENDING' }] } : {}), limit: opts.limit ?? 100 } };
  try {
    const r = await fetch(`${base()}:runQuery`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), next: { revalidate: opts.revalidate ?? 3600 } });
    if (!r.ok) return [];
    return ((await r.json()) as { document?: { name: string; fields?: Record<string, V> } }[]).filter((x) => x.document).map((x) => toDoc(x.document!));
  } catch { return []; }
}
