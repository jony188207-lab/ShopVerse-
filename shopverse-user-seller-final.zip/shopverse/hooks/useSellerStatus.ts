'use client';
import { useCallback, useEffect, useState } from 'react';
import { useAuth } from './useAuth';
import { getMyApplication } from '@/services/sellerService';
import type { SellerApplication } from '@/types/seller';

export type SellerState = 'loading' | 'none' | 'pending' | 'approved' | 'rejected' | 'suspended';
const cache = new Map<string, { at: number; app: SellerApplication | null }>();

/** Approved is decided ONLY by the role (set by the Admin App through a Cloud Function), never by the application document alone. */
export function useSellerStatus(): { state: SellerState; application: SellerApplication | null } {
  const { user, role, loading } = useAuth();
  const [app, setApp] = useState<SellerApplication | null | undefined>(undefined);
  const load = useCallback(async (uid: string) => {
    const hit = cache.get(uid);
    if (hit && Date.now() - hit.at < 60_000) { setApp(hit.app); return; }
    try { const a = await getMyApplication(uid); cache.set(uid, { at: Date.now(), app: a }); setApp(a); } catch { setApp(null); }
  }, []);
  useEffect(() => { if (user) void load(user.uid); else setApp(undefined); }, [user, load]);
  if (loading || (user && app === undefined && role !== 'seller')) return { state: 'loading', application: null };
  if (role === 'seller') return { state: 'approved', application: app ?? null };
  if (!app) return { state: 'none', application: null };
  const s = app.status;
  return { state: s === 'approved' ? 'suspended' : s, application: app }; // approved application but no seller role => store was suspended/role removed
}
