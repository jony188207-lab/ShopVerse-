'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { auth, isFirebaseConfigured } from '@/lib/firebase/config';
import { fetchRole } from '@/services/userService';
import type { Role } from '@/types';

interface AuthState {
  user: User | null;
  role: Role;
  loading: boolean;
  configured: boolean;
  refresh: () => Promise<void>;
}
const Ctx = createContext<AuthState | null>(null);

/** Firebase Auth persists the session itself (IndexedDB); we only mirror it into React state. */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<Role>('user');
  const [loading, setLoading] = useState(isFirebaseConfigured);

  useEffect(() => {
    if (!isFirebaseConfigured) return;
    return onAuthStateChanged(auth(), async (u) => {
      setUser(u);
      try {
        setRole(u ? await fetchRole(u.uid) : 'user');
      } catch {
        setRole('user');
      }
      setLoading(false);
    });
  }, []);

  const refresh = useCallback(async () => {
    const u = isFirebaseConfigured ? auth().currentUser : null;
    if (!u) return;
    await u.reload();
    setUser(auth().currentUser);
    setRole(await fetchRole(u.uid).catch(() => 'user' as Role));
  }, []);

  const value = useMemo(() => ({ user, role, loading, configured: isFirebaseConfigured, refresh }), [user, role, loading, refresh]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside <AuthProvider>');
  return v;
}
