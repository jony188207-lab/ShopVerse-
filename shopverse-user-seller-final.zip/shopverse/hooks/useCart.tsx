'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from './useAuth';
import { useToast } from './useToast';
import { addToCart, CartError, clearCart, fetchCart, removeCartItem, setCartQuantity } from '@/services/cartService';
import { getProductsByIds } from '@/services/productService';
import { getStoresMap } from '@/services/storeService';
import { friendlyError } from '@/lib/firebase/errors';
import { resolveLine, summarize, type CartLineView, type CartSummary } from '@/utils/cartMath';
import type { CartItem, Product, Store } from '@/types';

interface C {
  lines: CartLineView[]; summary: CartSummary; stores: Map<string, Store>; count: number; loading: boolean; error: string;
  refresh: (force?: boolean) => Promise<void>;
  add: (p: Product, variantKey: string | undefined, qty: number) => Promise<boolean>;
  setQty: (id: string, qty: number) => Promise<void>; remove: (id: string) => Promise<void>; clear: () => Promise<void>;
}
const Ctx = createContext<C | null>(null);

/** Cart lives in Firestore (cartItems). Product/store docs are cached per session and re-read only on a forced refresh (cart/checkout pages). */
export function CartProvider({ children }: { children: ReactNode }) {
  const { user, configured } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const [items, setItems] = useState<CartItem[]>([]);
  const [products, setProducts] = useState<Map<string, Product | null>>(new Map());
  const [stores, setStores] = useState<Map<string, Store>>(new Map());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const cache = useRef({ products: new Map<string, Product | null>(), stores: new Map<string, Store>() });

  const refresh = useCallback(async (force = false) => {
    if (!configured || !user) { setItems([]); return; }
    setLoading(true); setError('');
    try {
      const its = await fetchCart(user.uid);
      if (force) cache.current.products.clear();
      const missingP = its.map((i) => i.productId).filter((id) => !cache.current.products.has(id));
      (await getProductsByIds(missingP)).forEach((p, id) => cache.current.products.set(id, p));
      const missingS = its.map((i) => i.storeId).filter((id) => !cache.current.stores.has(id));
      (await getStoresMap(missingS)).forEach((s, id) => cache.current.stores.set(id, s));
      setProducts(new Map(cache.current.products)); setStores(new Map(cache.current.stores)); setItems(its);
    } catch (e) { setError(friendlyError(e)); } finally { setLoading(false); }
  }, [user, configured]);

  useEffect(() => { if (!user) { setItems([]); cache.current.products.clear(); } else void refresh(); }, [user, refresh]);

  const lines = useMemo(() => items.map((i) => resolveLine(i, products.get(i.productId) ?? null)), [items, products]);
  const summary = useMemo(() => summarize(lines, stores), [lines, stores]);
  const count = useMemo(() => items.reduce((s, i) => s + i.quantity, 0), [items]);

  const add = useCallback(async (p: Product, variantKey: string | undefined, qty: number) => {
    if (!user) { router.push(`/login?next=${encodeURIComponent(window.location.pathname)}`); return false; }
    try { await addToCart(user.uid, p, variantKey, qty); cache.current.products.set(p.id, p); await refresh(); toast('Added to cart', 'success'); return true; }
    catch (e) { toast(e instanceof CartError ? e.message : friendlyError(e), 'error'); return false; }
  }, [user, refresh, router, toast]);

  const setQty = useCallback(async (id: string, qty: number) => {
    const line = lines.find((l) => l.item.id === id);
    if (!line) return;
    const q = Math.max(1, Math.min(qty, line.available || 1, 99));
    if (qty > q) toast(`Only ${line.available} available`, 'info');
    setItems((x) => x.map((i) => (i.id === id ? { ...i, quantity: q } : i)));
    try { await setCartQuantity(id, q); } catch (e) { toast(friendlyError(e), 'error'); void refresh(); }
  }, [lines, refresh, toast]);

  const remove = useCallback(async (id: string) => {
    setItems((x) => x.filter((i) => i.id !== id));
    try { await removeCartItem(id); } catch (e) { toast(friendlyError(e), 'error'); void refresh(); }
  }, [refresh, toast]);

  const clear = useCallback(async () => {
    const prev = items; setItems([]);
    try { await clearCart(prev); } catch (e) { toast(friendlyError(e), 'error'); void refresh(); }
  }, [items, refresh, toast]);

  const value = useMemo(() => ({ lines, summary, stores, count, loading, error, refresh, add, setQty, remove, clear }), [lines, summary, stores, count, loading, error, refresh, add, setQty, remove, clear]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useCart(): C { const v = useContext(Ctx); if (!v) throw new Error('useCart outside provider'); return v; }
