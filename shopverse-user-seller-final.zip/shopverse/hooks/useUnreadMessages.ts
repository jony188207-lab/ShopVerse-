'use client';
import { useEffect, useState } from 'react';
import { isFirebaseConfigured } from '@/lib/firebase/config';
import { watchConversations } from '@/services/chatService';
import { useAuth } from './useAuth';

/** Sum of my unread counters across my latest 30 conversations (single listener; none when signed out). */
export function useUnreadMessages(): number {
  const { user } = useAuth();
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!user || !isFirebaseConfigured) { setN(0); return; }
    return watchConversations(user.uid, (list) => setN(list.reduce((s, c) => s + (c.unread[user.uid] ?? 0), 0)), () => setN(0));
  }, [user]);
  return n;
}
