'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { friendlyError } from '@/lib/firebase/errors';
import type { Page } from '@/services/productService';

/** Cursor pagination with "load more". `deps` restart the list (filters). Fetcher errors surface as `error`, never as an empty list. */
export function usePaged<T>(fetcher: (cursor: QueryDocumentSnapshot | null) => Promise<Page<T>>, deps: unknown[]) {
  const [items, setItems] = useState<T[] | null>(null);
  const [more, setMore] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const cursor = useRef<QueryDocumentSnapshot | null>(null);
  const fn = useRef(fetcher); fn.current = fetcher;
  const run = useCallback(async (reset: boolean) => {
    setBusy(true); setError('');
    try {
      const p = await fn.current(reset ? null : cursor.current);
      cursor.current = p.cursor; setMore(p.hasMore);
      setItems((x) => (reset ? p.items : [...(x ?? []), ...p.items]));
    } catch (e) { setError(friendlyError(e)); setItems((x) => x ?? []); } finally { setBusy(false); }
  }, []);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { setItems(null); void run(true); }, deps);
  return { items, setItems, more, error, busy, loadMore: () => run(false), reload: () => run(true) };
}
