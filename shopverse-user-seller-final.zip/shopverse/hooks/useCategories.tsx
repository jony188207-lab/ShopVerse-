'use client';
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { DEFAULT_CATEGORIES, categoryById, setLiveCategories, subcategoriesOf, topCategories, type Category } from '@/config/categories';
import { isFirebaseConfigured } from '@/lib/firebase/config';
import { listCategories } from '@/services/categoryService';

interface Ctx { all: Category[]; categories: Category[]; loaded: boolean; byId: (id: string) => Category | undefined; childrenOf: (id: string) => Category[] }
const C = createContext<Ctx | null>(null);

/** One small read (<=200 docs) for the whole app. Falls back to the built-in defaults when the collection is empty or unreachable. */
export function CategoryProvider({ children }: { children: ReactNode }) {
  const [all, setAll] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [loaded, setLoaded] = useState(!isFirebaseConfigured);
  useEffect(() => {
    if (!isFirebaseConfigured) return;
    listCategories().then((l) => { if (l.length) { setLiveCategories(l); setAll(l); } }).catch(() => undefined).finally(() => setLoaded(true));
  }, []);
  const v = useMemo<Ctx>(() => ({ all, categories: topCategories(all), loaded, byId: (id) => all.find((c) => c.id === id) ?? categoryById(id), childrenOf: (id) => subcategoriesOf(id, all) }), [all, loaded]);
  return <C.Provider value={v}>{children}</C.Provider>;
}
export function useCategories(): Ctx {
  const v = useContext(C);
  if (!v) throw new Error('useCategories must be used inside <CategoryProvider>');
  return v;
}
