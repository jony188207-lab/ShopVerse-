'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from './useAuth';
import { useToast } from './useToast';
import { addWish, fetchWishlistIds, removeWish } from '@/services/wishlistService';
import { friendlyError } from '@/lib/firebase/errors';

interface W { ids: string[]; has: (id: string) => boolean; toggle: (id: string) => Promise<void>; remove: (id: string) => Promise<void>; loading: boolean }
const Ctx = createContext<W | null>(null);

export function WishlistProvider({ children }: { children: ReactNode }) {
  const { user, configured } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const [ids, setIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!configured || !user) { setIds([]); return; }
    let off = false;
    setLoading(true);
    fetchWishlistIds(user.uid).then((x) => !off && setIds(x)).catch(() => !off && setIds([])).finally(() => !off && setLoading(false));
    return () => { off = true; };
  }, [user, configured]);

  const remove = useCallback(async (id: string) => {
    if (!user) return;
    setIds((x) => x.filter((i) => i !== id));
    try { await removeWish(user.uid, id); } catch (e) { setIds((x) => [id, ...x]); toast(friendlyError(e), 'error'); }
  }, [user, toast]);

  const toggle = useCallback(async (id: string) => {
    if (!user) { router.push(`/login?next=${encodeURIComponent(window.location.pathname)}`); return; }
    if (ids.includes(id)) return remove(id);
    setIds((x) => [id, ...x]);
    try { await addWish(user.uid, id); toast('Saved to wishlist', 'success'); } catch (e) { setIds((x) => x.filter((i) => i !== id)); toast(friendlyError(e), 'error'); }
  }, [user, ids, remove, router, toast]);

  const value = useMemo(() => ({ ids, has: (id: string) => ids.includes(id), toggle, remove, loading }), [ids, toggle, remove, loading]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useWishlist(): W { const v = useContext(Ctx); if (!v) throw new Error('useWishlist outside provider'); return v; }
