export interface Schedulable {
  active: boolean;
  startDate?: Date | null;
  endDate?: Date | null;
}

/** Firestore Timestamp | Date | null -> Date | null (no firebase import so it stays unit-testable). */
export function toDate(v: unknown): Date | null {
  if (!v) return null;
  if (v instanceof Date) return v;
  if (typeof v === 'object' && v !== null && 'toDate' in v && typeof (v as { toDate: unknown }).toDate === 'function') {
    return (v as { toDate: () => Date }).toDate();
  }
  return null;
}

export function isLive(item: Schedulable, now: Date = new Date()): boolean {
  if (!item.active) return false;
  if (item.startDate && now < item.startDate) return false;
  if (item.endDate && now > item.endDate) return false;
  return true;
}

export function sortByPriorityDesc<T extends { priority: number }>(list: T[]): T[] {
  return [...list].sort((a, b) => b.priority - a.priority);
}

export function isSafeHttpsUrl(value: string): boolean {
  try {
    return new URL(value).protocol === 'https:';
  } catch {
    return false;
  }
}

/** Only allow same-site relative redirects after login. */
export function safeNextPath(next: string | null | undefined): string {
  if (!next || !next.startsWith('/') || next.startsWith('//') || next.includes('\\')) return '/';
  return next;
}
