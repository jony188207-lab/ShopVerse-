// Firestore has no full-text search. We store lowercase word-prefix tokens on each product (`searchKeywords`) and
// query with array-contains on ONE token; extra tokens are matched client-side. See README "Search limitations".
export const MAX_TOKEN = 15;
const STOP = new Set(['the', 'and', 'for', 'with', 'this', 'that', 'from', 'are', 'you', 'your']);

export function tokenizeQuery(q: string): string[] {
  const t = q.toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter((w) => w.length >= 2 && !STOP.has(w));
  return Array.from(new Set(t.map((w) => w.slice(0, MAX_TOKEN)))).slice(0, 5);
}

export function buildSearchKeywords(input: { title: string; brand?: string; categoryName?: string; description?: string }): string[] {
  const out = new Set<string>();
  // prefixes (min 2 chars) for title/brand/category words => partial matches like "wire" -> "wireless"
  for (const w of tokenizeQuery(`${input.title} ${input.brand ?? ''} ${input.categoryName ?? ''}`)) {
    for (let i = 2; i <= w.length; i++) out.add(w.slice(0, i));
  }
  // whole words only for the description (first 40 unique) to keep the array small
  for (const w of tokenizeQuery(input.description ?? '').slice(0, 40)) out.add(w);
  return Array.from(out).slice(0, 250);
}
