import type { Order } from '@/types';

export interface CustomerRow { buyerId: string; name: string; city: string; orders: number; spent: number; lastOrderAt: Date | null }

/**
 * Seller-visible customer list, derived ONLY from the seller's own orders (name + city + totals).
 * Phone/street address stay on the individual order (needed to deliver it); no email or profile data is ever read.
 * Cancelled orders don't count as spend.
 */
export function aggregateCustomers(orders: Order[]): CustomerRow[] {
  const by = new Map<string, CustomerRow>();
  for (const o of orders) {
    const r = by.get(o.buyerId) ?? { buyerId: o.buyerId, name: o.address.fullName, city: o.address.city, orders: 0, spent: 0, lastOrderAt: null };
    r.orders += 1;
    if (o.status !== 'cancelled' && o.status !== 'refunded') r.spent = Math.round((r.spent + o.total) * 100) / 100;
    if (o.createdAt && (!r.lastOrderAt || o.createdAt > r.lastOrderAt)) { r.lastOrderAt = o.createdAt; r.name = o.address.fullName; r.city = o.address.city; }
    by.set(o.buyerId, r);
  }
  return [...by.values()].sort((a, b) => b.spent - a.spent);
}
