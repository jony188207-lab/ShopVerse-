import { describe, expect, it } from 'vitest';
import { isLive, isSafeHttpsUrl, safeNextPath, sortByPriorityDesc, toDate } from './schedule';

const now = new Date('2026-06-15T12:00:00Z');
const d = (s: string) => new Date(s);

describe('isLive', () => {
  it('rejects inactive', () => expect(isLive({ active: false }, now)).toBe(false));
  it('accepts active with no schedule', () => expect(isLive({ active: true }, now)).toBe(true));
  it('rejects before start', () => expect(isLive({ active: true, startDate: d('2026-07-01') }, now)).toBe(false));
  it('rejects after end', () => expect(isLive({ active: true, endDate: d('2026-06-01') }, now)).toBe(false));
  it('accepts inside window', () =>
    expect(isLive({ active: true, startDate: d('2026-06-01'), endDate: d('2026-06-30') }, now)).toBe(true));
});

describe('helpers', () => {
  it('sorts by priority desc without mutating', () => {
    const src = [{ priority: 1 }, { priority: 5 }, { priority: 3 }];
    expect(sortByPriorityDesc(src).map((x) => x.priority)).toEqual([5, 3, 1]);
    expect(src[0].priority).toBe(1);
  });
  it('https only', () => {
    expect(isSafeHttpsUrl('https://ads.example.com/x')).toBe(true);
    expect(isSafeHttpsUrl('http://ads.example.com')).toBe(false);
    expect(isSafeHttpsUrl('javascript:alert(1)')).toBe(false);
  });
  it('safeNextPath blocks open redirects', () => {
    expect(safeNextPath('/orders')).toBe('/orders');
    expect(safeNextPath('//evil.com')).toBe('/');
    expect(safeNextPath('https://evil.com')).toBe('/');
    expect(safeNextPath(null)).toBe('/');
  });
  it('toDate handles Timestamp-likes', () => {
    expect(toDate({ toDate: () => now })).toEqual(now);
    expect(toDate(null)).toBeNull();
  });
});
