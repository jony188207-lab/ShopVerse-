import { describe, expect, it } from 'vitest';
import { aggregateCustomers } from './customers';
import type { Order } from '@/types';

const o = (buyerId: string, total: number, status: Order['status'], at: string): Order => ({
  id: buyerId + at, orderNumber: 'SV-1', groupId: 'g', buyerId, sellerId: 's', storeId: 'st', storeName: 'S', status, paymentMethod: 'cod', paymentStatus: 'unpaid', deliveryMethod: 'standard',
  subtotal: total, discount: 0, shipping: 0, total, currency: 'USD', itemCount: 1, timeline: [], deliveredAt: null, createdAt: new Date(at),
  address: { fullName: 'Name ' + buyerId, phone: '1', country: 'US', city: 'C' + buyerId, area: '', address: 'x', postalCode: '', instructions: '' },
});

describe('aggregateCustomers', () => {
  it('groups by buyer, ignores cancelled spend, sorts by spend', () => {
    const rows = aggregateCustomers([o('a', 10, 'delivered', '2026-01-01'), o('a', 5, 'cancelled', '2026-01-02'), o('b', 50, 'pending', '2026-01-03')]);
    expect(rows.map((r) => [r.buyerId, r.orders, r.spent])).toEqual([['b', 1, 50], ['a', 2, 10]]);
  });
  it('exposes only name and city, never phone/address', () => {
    expect(Object.keys(aggregateCustomers([o('a', 1, 'pending', '2026-01-01')])[0]).sort()).toEqual(['buyerId', 'city', 'lastOrderAt', 'name', 'orders', 'spent']);
  });
});
