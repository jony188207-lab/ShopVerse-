import { CURRENCY } from '@/config/site';
export const round2 = (n: number) => Math.round(n * 100) / 100;
export const formatMoney = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: CURRENCY }).format(n);
export const discountPercent = (price: number, original: number) => (original > price && original > 0 ? Math.round(((original - price) / original) * 100) : 0);
