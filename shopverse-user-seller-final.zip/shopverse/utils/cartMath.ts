import type { CartItem, Product, Store } from '@/types';
import { round2 } from './money';

export type LineProblem = 'missing' | 'unavailable' | 'variant_missing' | 'out_of_stock' | 'exceeds_stock';
export interface CartLineView { item: CartItem; product: Product | null; unitPrice: number; originalUnitPrice: number; available: number; problem?: LineProblem }
export interface SellerGroupView { sellerId: string; storeId: string; storeName: string; lines: CartLineView[]; subtotal: number; savings: number; shipping: number; total: number }
export interface CartSummary { groups: SellerGroupView[]; subtotal: number; savings: number; shipping: number; total: number; blocked: boolean }

/** Stock a buyer may still buy for this product/variant (0 when not purchasable). */
export function availableStock(p: Product, variantKey: string): number {
  if (p.status !== 'approved') return 0;
  if (p.variants.length) { const v = p.variants.find((x) => x.key === variantKey); return v ? Math.max(0, Math.min(v.stock, p.stock)) : 0; }
  return Math.max(0, p.stock);
}

export function resolveLine(item: CartItem, product: Product | null): CartLineView {
  if (!product) return { item, product, unitPrice: 0, originalUnitPrice: 0, available: 0, problem: 'missing' };
  const v = product.variants.find((x) => x.key === item.variantKey);
  if (product.variants.length && !v) return { item, product, unitPrice: product.price, originalUnitPrice: product.originalPrice, available: 0, problem: 'variant_missing' };
  const unitPrice = v?.price ?? product.price;
  const available = availableStock(product, item.variantKey);
  const base = { item, product, unitPrice, originalUnitPrice: Math.max(product.originalPrice, unitPrice), available };
  if (product.status !== 'approved') return { ...base, problem: 'unavailable' };
  if (available <= 0) return { ...base, problem: 'out_of_stock' };
  if (item.quantity > available) return { ...base, problem: 'exceeds_stock' };
  return base;
}

export function shippingFor(store: Store | undefined, subtotal: number): number {
  if (!store) return 0;
  if (store.freeShippingOver != null && subtotal >= store.freeShippingOver) return 0;
  return round2(store.shippingFee || 0);
}

export function summarize(lines: CartLineView[], stores: Map<string, Store>): CartSummary {
  const by = new Map<string, CartLineView[]>();
  for (const l of lines) by.set(l.item.sellerId, [...(by.get(l.item.sellerId) ?? []), l]);
  const groups: SellerGroupView[] = Array.from(by.entries()).map(([sellerId, ls]) => {
    const store = stores.get(ls[0].item.storeId);
    const subtotal = round2(ls.reduce((s, l) => s + l.unitPrice * l.item.quantity, 0));
    const savings = round2(ls.reduce((s, l) => s + (l.originalUnitPrice - l.unitPrice) * l.item.quantity, 0));
    const shipping = shippingFor(store, subtotal);
    return { sellerId, storeId: ls[0].item.storeId, storeName: store?.name ?? 'Store', lines: ls, subtotal, savings, shipping, total: round2(subtotal + shipping) };
  });
  const sum = (f: (g: SellerGroupView) => number) => round2(groups.reduce((s, g) => s + f(g), 0));
  return { groups, subtotal: sum((g) => g.subtotal), savings: sum((g) => g.savings), shipping: sum((g) => g.shipping), total: sum((g) => g.total), blocked: lines.length === 0 || lines.some((l) => !!l.problem) };
}
