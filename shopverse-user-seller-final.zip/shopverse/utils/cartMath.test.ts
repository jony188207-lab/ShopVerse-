import { describe, expect, it } from 'vitest';
import { availableStock, resolveLine, summarize } from './cartMath';
import { buildSearchKeywords, tokenizeQuery } from './keywords';
import type { CartItem, Product, Store } from '@/types';

const prod = (o: Partial<Product> = {}): Product => ({
  id: 'p1', sellerId: 's1', storeId: 'st1', title: 'Wireless Headphones', slug: 'x', description: 'Great sound', brand: 'Acme', categoryId: 'electronics',
  images: [], price: 50, originalPrice: 80, discount: 37, stock: 3, sku: 'A1', rating: 0, reviewCount: 0, ratingDistribution: { '1': 0, '2': 0, '3': 0, '4': 0, '5': 0 },
  salesCount: 0, status: 'approved', featured: false, variants: [], specs: [], flashSaleEndsAt: null, searchKeywords: [], createdAt: null, updatedAt: null, ...o,
});
const item = (o: Partial<CartItem> = {}): CartItem => ({ id: 'c1', userId: 'u', productId: 'p1', sellerId: 's1', storeId: 'st1', variantKey: 'default', variantLabel: '', quantity: 1, ...o });
const store: Store = { id: 'st1', ownerId: 's1', name: 'Acme', slug: 'acme', description: '', status: 'approved', ratingAvg: 0, ratingCount: 0, followerCount: 0, shippingFee: 5, freeShippingOver: 100 };

describe('cart math', () => {
  it('flags problems', () => {
    expect(resolveLine(item(), null).problem).toBe('missing');
    expect(resolveLine(item(), prod({ status: 'suspended' })).problem).toBe('unavailable');
    expect(resolveLine(item(), prod({ stock: 0 })).problem).toBe('out_of_stock');
    expect(resolveLine(item({ quantity: 4 }), prod()).problem).toBe('exceeds_stock');
    expect(resolveLine(item(), prod()).problem).toBeUndefined();
  });
  it('variant stock is capped by total stock', () => {
    expect(availableStock(prod({ stock: 2, variants: [{ key: 'a', label: 'A', stock: 9 }] }), 'a')).toBe(2);
  });
  it('summarizes per seller with shipping + savings', () => {
    const s = summarize([resolveLine(item({ quantity: 2 }), prod())], new Map([['st1', store]]));
    expect(s.subtotal).toBe(100); expect(s.savings).toBe(60); expect(s.shipping).toBe(0); expect(s.total).toBe(100); expect(s.blocked).toBe(false);
    const s2 = summarize([resolveLine(item(), prod())], new Map([['st1', store]]));
    expect(s2.shipping).toBe(5); expect(s2.total).toBe(55);
  });
  it('blocks empty or problematic carts', () => {
    expect(summarize([], new Map()).blocked).toBe(true);
    expect(summarize([resolveLine(item({ quantity: 9 }), prod())], new Map([['st1', store]])).blocked).toBe(true);
  });
});

describe('search keywords', () => {
  it('builds prefixes for title/brand and whole words for description', () => {
    const k = buildSearchKeywords({ title: 'Wireless Headphones', brand: 'Acme', description: 'Great sound quality' });
    expect(k).toContain('wi'); expect(k).toContain('wire'); expect(k).toContain('headphones'); expect(k).toContain('acme'); expect(k).toContain('sound');
    expect(k).not.toContain('soun');
  });
  it('tokenizes queries', () => {
    expect(tokenizeQuery('  The Wireless  Head-phones! ')).toEqual(['wireless', 'head', 'phones']);
    expect(tokenizeQuery('a')).toEqual([]);
  });
});
