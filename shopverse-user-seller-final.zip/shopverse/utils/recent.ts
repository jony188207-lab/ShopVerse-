// Recently viewed / recent searches are per-device UI conveniences (not important data), so localStorage is fine here.
const read = (k: string): string[] => { try { const v = JSON.parse(localStorage.getItem(k) ?? '[]'); return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []; } catch { return []; } };
const write = (k: string, v: string[]) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* blocked */ } };
const push = (k: string, item: string, max: number) => write(k, [item, ...read(k).filter((x) => x !== item)].slice(0, max));

export const getRecentlyViewed = () => read('sv-recent-products');
export const addRecentlyViewed = (id: string) => push('sv-recent-products', id, 12);
export const getRecentSearches = () => read('sv-recent-searches');
export const addRecentSearch = (q: string) => push('sv-recent-searches', q.trim(), 6);
export const clearRecentSearches = () => write('sv-recent-searches', []);
