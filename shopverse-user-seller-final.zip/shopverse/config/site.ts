export const SITE = { name: 'ShopVerse', tagline: 'Shop • Watch • Shop' } as const;
// Single-currency marketplace for now. Keep in sync with CURRENCY in functions/src/index.ts.
export const CURRENCY = 'USD';
// Enforced server-side in the requestReturn function; keep in sync with functions/src/index.ts.
export const RETURN_WINDOW_DAYS = 7;
export const MAX_CART_ITEMS = 50;
