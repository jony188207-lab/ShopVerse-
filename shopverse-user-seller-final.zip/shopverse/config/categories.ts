// Built-in DEFAULT taxonomy. Once an admin imports/creates categories in Firestore (/admin/categories), the live list replaces it.
// categoryId on a product == the category doc id (a slug). Nothing here is fake product data.
export interface Category { id: string; name: string; order?: number; active?: boolean; imageUrl?: string; parentId?: string }
const slug = (name: string) => name.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
export const DEFAULT_CATEGORIES: Category[] = [
  'Electronics', 'Mobile & Accessories', 'Computers', 'Fashion', 'Beauty', 'Home & Living', 'Food & Grocery', 'Sports & Outdoors',
  'Toys & Games', 'Automotive', 'Books & Stationery', 'Health', 'Pets', 'Tools', 'Other',
].map((name, i) => ({ id: slug(name), name, order: i * 10, active: true }));
/** @deprecated use useCategories(); kept so non-React code and old imports still see the defaults */
export const CATEGORIES = DEFAULT_CATEGORIES;

let live: Category[] = DEFAULT_CATEGORIES;
export const setLiveCategories = (l: Category[]) => { live = l.length ? l : DEFAULT_CATEGORIES; };
export const allCategories = (): Category[] => live;
/** Lookup includes inactive categories so existing products still resolve their name. */
export const categoryById = (id: string): Category | undefined => live.find((x) => x.id === id);
export const topCategories = (list: Category[] = live) => list.filter((c) => c.active !== false && !c.parentId).sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.name.localeCompare(b.name));
export const subcategoriesOf = (parentId: string, list: Category[] = live) => list.filter((c) => c.parentId === parentId && c.active !== false).sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
export const categorySlug = slug;
