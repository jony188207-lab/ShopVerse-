import { Home, ShoppingBag, Play, ShoppingCart, User, LayoutGrid, LayoutDashboard, Package, ClipboardList, type LucideIcon } from 'lucide-react';

export interface NavItem { href: string; label: string; icon: LucideIcon }

/** Customer bottom navigation. Search, notifications, wishlist, orders, categories and settings live in the header / account menu / profile. */
export const MOBILE_NAV: NavItem[] = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/shop', label: 'Shop', icon: ShoppingBag },
  { href: '/video', label: 'Video', icon: Play },
  { href: '/cart', label: 'Cart', icon: ShoppingCart },
  { href: '/profile', label: 'Profile', icon: User },
];

/** Seller bottom navigation (inside /seller). Everything else is reachable from /seller/menu. */
export const SELLER_NAV: NavItem[] = [
  { href: '/seller', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/seller/products', label: 'Products', icon: Package },
  { href: '/seller/orders', label: 'Orders', icon: ClipboardList },
  { href: '/seller/profile', label: 'Profile', icon: User },
];

export const DESKTOP_NAV: NavItem[] = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/shop', label: 'Shop', icon: ShoppingBag },
  { href: '/categories', label: 'Categories', icon: LayoutGrid },
  { href: '/video', label: 'Video', icon: Play },
];
