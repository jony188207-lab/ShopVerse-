# ShopVerse — Phases 1–3 (Foundation + Marketplace core + Seller system)
Shop • Watch • Shop. Next.js 14 · TypeScript · Tailwind · Firebase (Auth, Firestore, Storage, FCM, Cloud Functions).

**Verification status:** nothing here has been run against a real Firebase project, and `npm install` / typecheck / vitest / build were NOT executed by the author (package registry unreachable). Only `priceCart` (functions/src/orderLogic.ts) was smoke-executed with plain Node. Run everything below yourself.

## Commands
```bash
npm install
npm --prefix functions install
cp .env.example .env.local        # fill in Firebase web config
npm run typecheck
npm run typecheck:functions
npm test                          # unit tests: cart math, order pricing/stock logic, schedule/redirect helpers
npm run test:rules                # Firestore rules tests (needs Java + Firebase emulator)
npm run build
npm run dev
```

## Firebase Console / CLI actions (cannot be done from code)
1. Create a Firebase project, add a **Web app**, put its config in `.env.local`.
2. **Authentication → Email/Password**: enable. Add your domains to Authorized domains.
3. **Firestore** (production mode) and **Storage**: create.
4. **Upgrade to the Blaze plan** — Cloud Functions (checkout) cannot deploy on Spark.
5. **Cloud Messaging → Web Push certificates**: generate key → `NEXT_PUBLIC_FIREBASE_VAPID_KEY`.
6. Deploy everything: `npx firebase login && npx firebase use <project-id> && npx firebase deploy --only firestore:rules,firestore:indexes,storage,functions`.
   Indexes take a few minutes to build; queries fail with a "requires an index" error until they finish.
7. If you change the Functions region from `us-central1`, set `NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION` too.
8. **First super admin (console only):** sign up, verify email, copy your UID, create Firestore doc `roles/<uid>` = `{ role: "super_admin" }`.

## Getting real data in (no seed data ships with the app)
1. Sign in as super admin/admin → **/admin/stores** → create a store; `ownerId` = the UID of the account that will own it (sets `sellerId` on its products).
2. **/admin/products/new** → create products (images upload to Storage), then **Approve** them at /admin/products.
3. **/admin/banners** → pick an approved product, upload desktop + mobile images, set priority/schedule, activate.
4. Buy with a **different account** than the store owner (buying your own product is blocked server-side).
5. Fulfil at **/admin/orders** (Confirmed → Processing → Shipped → Delivered). Delivery unlocks reviews and returns.
Flash sale = set `flashSaleEndsAt` (timestamp) on a product in the console; a promotions UI is Phase 3. Featured = `featured: true` (console) until Phase 3.

## Architecture notes
- **Checkout is server-side** (`placeOrder` Cloud Function). Price, stock, shipping and totals are recomputed inside a Firestore transaction from documents the function reads itself; the client sends only `checkoutId`, `addressId`, `cod`. `checkouts/{uid}_{checkoutId}` is written in the same transaction, so retries/double-taps/reloads return the same orders. One order per seller (`orders.groupId` = checkout), `orderItems` per line.
- **Cancel/return** are callables (`cancelOrder`, `requestReturn`); buyers have no direct order write access in the rules. `onOrderStatusChange` appends the timeline, mirrors status to `orderItems`, restores stock on any cancellation (once, guarded by `stockRestored`), marks COD paid on delivery, and counts sales.
- **Reviews:** doc id = `orderItemId` (one per purchase); rules require the reviewer's order to be `delivered`. `onReviewWritten` maintains `rating`, `reviewCount`, `ratingSum`, `ratingDistribution`.
- **Search** = prefix keywords in `searchKeywords` + `array-contains` on the longest token, remaining tokens/category/price checked client-side. Not typo tolerant, not relevance-ranked. Swap in Algolia/Typesense/Meilisearch behind `searchProducts` when needed.
- Roles, ad code (super admin only, sandboxed iframe), banner→product integrity: see Phase 1 notes in `firestore.rules`.

## Known limitations
Transactional notifications are sent by Cloud Functions; push-delivery polish and broadcast push are Phase 7. No storage-rules tests. No integration tests of the Cloud Functions against the emulator (only the pure pricing/coupon logic is unit-tested). No App Check / rate limiting. Single currency (`USD` in `config/site.ts` and `functions/src/*.ts`). Recently viewed uses localStorage (product ids only) by design. Return stock is not auto-restocked. A coupon can be reused by the same buyer until its usage limit (no per-user limit). Suspending/reactivating a store handles products in chunks of 400 inside one function run (very large catalogs may need a re-run). Customers list is built from the seller's 50-per-page order history; it is not a stored CRM. Product views are not tracked, so analytics does not show them. Bank/payout details are stored as free text on the withdrawal (visible only to that seller and admins) — decide your own retention policy.

## Manual test checklist
AUTH: sign up → verify email → login/logout → reset password; /admin blocked for a normal user.
PRODUCT: draft/pending/rejected/suspended products are invisible when signed out; approved shows gallery, variants, specs, shipping/return, share; out-of-stock disables Add to cart/Buy now.
SEARCH: type 2+ letters → suggestions; recent searches appear; sort/price/category filters; "Load more"; empty and error states.
CATEGORY: /categories lists 15; /category/electronics shows only that category.
WISHLIST: heart toggles and survives reload/other device; move to cart; out-of-stock item can't be moved.
CART: add variant, +/- capped at stock, remove, clear; two stores → grouped with per-store shipping; survives logout/login.
ADDRESS: add/edit/delete/default at /profile/addresses; another user can't read it (rules test).
CHECKOUT/COD: cart → /checkout/address → review → Place order; the cart empties; reload/double-tap on the review page does NOT create a second order.
STOCK: stock 1, two accounts checkout simultaneously → exactly one succeeds; change a price in the console after review → order uses the DB price; cancel a pending order → stock returns.
ORDERS: multi-store cart → one order per store; timeline updates as admin moves status; cancel only while pending/confirmed; return within 7 days of delivery.
REVIEWS: form appears only for delivered items; second review of the same item impossible; rating average/distribution update within seconds; report review.
BANNERS: create with schedule/priority; inactive/expired/not-yet-started hidden; click opens /product/[id]; suspend the product → banner disappears.
SECURITY: `npm run test:rules`; try editing another user's cart/order from the browser console (must fail).

---
# Phase 3 — Seller system

**Verification status:** nothing in Phase 3 has been executed against Firebase, and `npm install`, typecheck, vitest, the rules tests and the build were NOT run (registry unreachable). Only the pure pricing + coupon logic (`functions/src/orderLogic.ts`) was smoke-run with plain Node. An offline `tsc` pass is meaningless without `node_modules` (thousands of missing-type errors), so treat typecheck as unknown until you run it.

## How a seller is created (no self-approval anywhere)
`/become-seller` writes `sellerApplications/{uid}` as `pending` (rules force `pending`, require verified email and a plain `user` role). **Only** the admin-only `reviewSellerApplication` Cloud Function can approve: in one transaction it checks the slug is unique, creates `stores/{id}` (public fields only), `storePrivate/{id}` (phone/email/address), sets `roles/{uid}` = `seller`, and marks the application approved; then it writes an audit log and notifies the applicant. Reject/suspend need a reason (shown to the applicant). Suspend sets the store to `suspended`, drops the role back to `user` and hides the store's products; reactivate reverses it. Admins cannot edit applications from the client at all.

## Money flow
Delivered order → `onOrderLifecycle` → `sellerEarnings/{orderItemId}` (gross, coupon share, commission from `stores.commissionRate` — default 10%, admin-only field — and seller amount), `pending` for 7 days (`EARNINGS_HOLD_DAYS`), then the hourly `releaseEarnings` job makes it `available`. Returned/refunded → earnings `reversed` (balance can go negative = seller owes the platform). `sellerBalances/{uid}` is written only by functions. Withdrawals: `requestWithdrawal` (balance-checked, idempotent, max 3 open, minimum 10) moves available→reserved; seller can `cancelWithdrawal` while pending; admin walks pending→approved→processing→completed (or rejected with reason) via `reviewWithdrawal`. Sellers have no client write access to any of it.

## Seller Center routes
`/seller` (overview), `/seller/products` (+`/new`, `/[id]/edit`), `/orders` (+`/[id]`), `/customers`, `/reviews`, `/earnings`, `/withdrawals`, `/coupons`, `/promotions`, `/analytics`, `/settings`. Admin: `/admin/sellers` (+`/[id]`), `/admin/withdrawals`, `/admin/promotions`, `/admin/logs`, `/admin/products` (reject/suspend now require a reason; suspended → "Restore"). Public: `/store/[slug]` (banner, followers, featured, products/reviews/about tabs, follow). Bell + `/notifications` for everyone.

## Isolation guarantees (see tests/firestore.rules.test.ts)
Orders are one document per seller, so a seller only ever sees `sellerId == uid` orders/items (queries include the filter; rules enforce it). Seller order moves follow a state machine in the rules (`sellerMove`): pending→confirmed→processing→shipped→out_for_delivery→delivered, cancel before shipping, return_requested→returned; refunds are admin-only. Sellers cannot write `featured`, `flashSaleEndsAt`, moderation fields, store `commissionRate/status/ownerId/slug/counters`, balances, earnings, withdrawals, notifications or audit logs. Coupons live at `coupons/{sellerId}_{CODE}` so a seller can only create in their own namespace; `usedCount` is function-written; discounts are applied inside `placeOrder` (never the browser), with a read-only `previewCoupon` for the checkout page. Promotions are *requests*; `reviewPromotion` (admin) validates again and is the only thing that sets `featured` / `flashSaleEndsAt`; an hourly job starts/ends them.

## Notifications (in-app + FCM push, written by Cloud Functions only)
Application approved/rejected/suspended/reactivated, product approved/rejected/suspended/restored, new order (seller), order status changes (buyer; cancel/return requests to seller), new review, withdrawal status, promotion status.

## Firebase Console / CLI steps for Phase 3
1. Deploy again: `npx firebase deploy --only firestore:rules,firestore:indexes,storage,functions` (new functions: `reviewSellerApplication`, `onProductModerated`, `requestWithdrawal`, `cancelWithdrawal`, `reviewWithdrawal`, `releaseEarnings`, `reviewPromotion`, `syncPromotions`, `previewCoupon`, `onOrderCreated`, `onOrderLifecycle`, `onReviewReceived`, plus the Phase 2 ones). Wait for the new indexes to finish building.
2. **Cloud Scheduler** must be enabled for the two hourly jobs (Blaze plan; the first deploy prompts to enable the API).
3. Make sure your own `roles/<uid>` doc is `super_admin` or `admin` (needed to approve sellers). Admin/moderator accounts cannot be converted to sellers — use a different account to test selling.
4. Optional: set a different default commission in `functions/src/common.ts` (`DEFAULT_COMMISSION_PERCENT`) before the first approval, or edit it per store at `/admin/sellers/[id]`.
5. Existing stores created earlier through `/admin/stores` keep working but have no `storePrivate` doc; their owners must create it once (console: `storePrivate/<storeId>` with `phone`, `email`, `address`, `createdAt`) before `/seller/settings` can save contact details. Stores created via application approval get it automatically.

## Manual security checklist (use two seller accounts A and B + one buyer)
- A cannot open B's `/seller/orders/<id>` (page says not found) and a console `getDoc` on B's order, earnings, balance, withdrawal, coupon, promotion or `storePrivate` is denied.
- A cannot edit B's product/store/coupon, cannot set their own `role`, cannot write `sellerBalances`, `withdrawals`, `sellerEarnings`, `notifications`, `adminLogs`.
- A cannot set `featured`, `flashSaleEndsAt`, `status: 'approved'` or `commissionRate` on their own docs.
- Submit an application; confirm no seller role until an admin approves; reject with a reason and see it on `/become-seller`; resubmit; approve; confirm `/seller` opens after re-login.
- Create a product → it is `pending_review` and invisible to buyers → approve in `/admin/products` → visible; edit it as the seller → hidden again until re-approved.
- Place an order with a coupon from A's store in a cart that also contains B's product → only A's order is discounted; B sees no coupon and cannot see A's order.
- Deliver the order (admin or seller) → earning appears `pending`; (to test release without waiting 7 days, edit `availableAt` in the console and run the scheduled function from the Cloud Scheduler console).
- Request a withdrawal larger than available → rejected; two rapid identical requests → one withdrawal; seller cannot complete their own.
- Suspend seller A → store 404s, products disappear from shop, role is `user`; reactivate → they return.

---
# Phase 4 — Admin panel (delivered together with Phase 5+6; its report had not been sent earlier)

**Routes:** `/admin` (live dashboard: counts + sum of delivered orders; cards a role cannot read show “—”), `/admin/users` (+`/[id]`), `/sellers`, `/stores`, `/products`, `/categories`, `/orders`, `/reviews`, `/videos`, `/reports`, `/withdrawals`, `/banners`, `/ads`, `/coupons`, `/promotions` (platform campaigns | seller requests), `/notifications`, `/settings`, `/logs`.

**Who can do what (enforced in rules / functions, not just hidden in the UI)**
- *Moderator*: moderate products, reviews, videos, comments and reports; write audit logs. Nothing else — no users, orders, addresses or chats.
- *Admin*: everything above + users (suspend/reactivate), sellers, orders, withdrawals, banners, coupons, categories, promotions, announcements, pause ads, read audit logs.
- *Super admin*: also ad code, settings, staff roles. Roles are written only by Cloud Functions (`reviewSellerApplication`, `setUserRole`) or the Console; **no client can write `/roles`**. User suspension (`setUserStatus`) disables the Firebase Auth account and revokes sessions.
- Trusted functions added: `setUserStatus`, `setUserRole`, `sendAnnouncement`, `onPlatformPromotionWritten` (+ hourly reconcile).
- Categories now live in Firestore (`categories`, admin-only writes); until you click “Import the 15 default categories” the app uses the built-in list. Subcategories use `parentId`; product `subcategoryId` is still free text.
- Platform coupons: `coupons/platform_{CODE}`, **platform-funded** (seller earnings are not reduced), applied only inside `placeOrder`; a store's own coupon with the same code is tried first.
- Platform promotions only set Featured / Flash-sale flags for a time window (products, a category, or one seller). They do **not** change prices — use coupons for discounts.
- Settings that are actually wired: default commission, earnings hold days, minimum withdrawal, max seller-promotion length, push on/off (admin-only doc); ads master switch and banner rotation seconds (public doc).
- Ad network: super admin pastes code / https URL; rendered in a sandboxed iframe; any admin can pause. Networks that forbid iframes/custom wrappers or require their tag on your own page will not serve in the sandbox — check your network's policy.
- Review media / video files: Storage rules limit direct reads to published content, but Firebase **download URLs carry a token and bypass rules**; hiding a review or suspending a video removes it from every page, not from someone who already has the file URL.

# Phase 5 — Video shopping

`/video` full-screen vertical feed (fixed overlay, snap scrolling). Tabs: **For You** (interleaves newest + trending, no ML), **Trending** (hourly `trendScore`: likes×3 + comments×4 + saves×5 + views×0.5, decayed by age, last 14 days), **Following** (newest from the first 30 creators you follow), **Products** (videos with linked products), **New**. `?v=<id>` deep-links to one video. Only the active slide and the next one hold a `<video>` element (neighbour = metadata only); every slide paints its thumbnail first; pages of 4–6 are fetched as you approach the end. Like / save / follow state for visible videos is loaded with one `in` query per 30 videos.

- **Data:** `videos` (field names follow the rules: `viewCount`=views, `likeCount`=likes, `commentCount`=commentsCount, `ownerId`=seller/creator), `videoLikes`, `videoSaves`, `videoViews`, `videoComments`, `follows`. Status: draft → pending_review → published | rejected | suspended. Visibility: public | private.
- **Upload** `/video/upload` (sellers only, verified email): MP4/WebM/MOV ≤200 MB and ≤3 min, optional thumbnail (a frame is captured if skipped), hashtags, category, visibility, up to 5 of **your own approved** products. Files → Storage `videos/{uid}/{videoId}/…`; metadata → Firestore. Always saved as draft or pending review. `/seller/videos` manages them (submit, resubmit, visibility, delete). After approval the seller cannot change content, only visibility.
- **Provider abstraction:** `services/video/provider.ts` (`VideoStorageProvider`); swapping hosts = another implementation + one export.
- **Counters** (`likeCount`, `saveCount`, `viewCount`, `commentCount`, `trendScore`) are written only by Cloud Functions. One view per signed-in user per video (doc id `videoId_uid`, no updates); anonymous views are not counted. Trigger retries can over-count by one; `trendScore` is recomputed hourly.
- **Shop Now** → `/product/<id>` (real ids; unavailable products show “No longer available / Out of stock”). Product pages show a “Watch this product” rail.
- **Comments** (paginated, own delete, report), **Share** (Web Share / copy link; share counts are not tracked), **Saved** page.
- **Moderation** `/admin/videos`: approve / reject / suspend / restore with reasons → audit log + seller notification.

# Phase 6 — Buyer ↔ seller chat

`/messages` (two-pane on desktop), `/messages/[id]`, `/messages/new?store=…[&product=…][&order=…]`. Header shows an unread badge. Realtime via `onSnapshot` (latest 40 messages, “load earlier”, 30 newest conversations).
- One conversation per buyer+store: id `{buyerId}_{storeId}`; **only the buyer can open it**; `sellerId` is derived from the store in the rules. Messages are a **subcollection** (`conversations/{id}/messages`) so rules check participants with one read.
- Clients write only the message. `onMessageCreated` (trusted) updates `lastMessage`, the receiver's `unread` counter and notifies the receiver once per unread burst (`new_message`, or `seller_response` when the seller replied).
- Receiver marks read (`readAt`) and zeroes only their own counter; nobody can edit/delete messages.
- Product reference (must be that seller's product) and order reference (must be this buyer's order with this seller) are validated by the rules, so multi-seller orders always route to the right seller (`/orders/[id]` → “Message {store}”).
- Block/unblock (you can only add/remove yourself; either side blocking stops sending both ways). Report conversation / message → `/admin/reports` with a text snapshot; admins can open the read-only thread at `/admin/conversations/[id]` (logged).
- Entry points: product page, store page, order detail, and from a video via the store link / Shop Now → product → Message seller.

## Firebase steps for Phases 4–6
1. `npx firebase deploy --only firestore:rules,firestore:indexes,storage,functions` and wait for indexes (about 20 new ones).
2. New functions: `setUserStatus`, `setUserRole`, `sendAnnouncement`, `onPlatformPromotionWritten`, `onVideoLikeWritten`, `onVideoSaveWritten`, `onVideoViewCreated`, `onVideoCommentWritten`, `onVideoModerated`, `rankVideos` (scheduled), `onMessageCreated`.
3. Optional: open `/admin/categories` and import the defaults; open `/admin/settings` (super admin) and save once so the settings documents exist.
4. Firebase Auth user disabling needs the Admin SDK default permissions (granted automatically to Cloud Functions' service account).

## Manual checklist — video
Upload as seller → appears as pending, invisible in feed → approve in `/admin/videos` → appears in New/For You → like/save/follow/comment (counts update within seconds, not instantly) → Shop Now opens the right product → suspend → disappears; seller sees the reason. Try as a normal user: `/video/upload` is blocked; in the console, writing `likeCount`, `status: 'published'`, or linking another seller's product is denied. Refresh/rewatch: view count rises once per account.

## Manual checklist — chat & security
Buyer opens chat from product (product chip attached) and from order (order chip). Seller replies; buyer gets a notification; unread badges clear when opened. Seller B cannot open `/messages/{A's conversation}` and a console read is denied; a user cannot send as someone else, reference another seller's product/order, edit or delete messages, or reset the other side's unread counter. Block → both sides blocked from sending; only the blocker can unblock. Report a message → appears in `/admin/reports` with evidence; opening the thread logs `conversation.view`.

## Known limitations (Phases 4–6)
- Nothing in Phases 4–6 has been run: no install, typecheck, vitest, rules tests, build, emulator or Firebase project. Offline `tsc` flags only missing-dependency noise plus the fixes already applied.
- “For You” is not personalised; Following uses at most 30 creators; Trending refreshes hourly and only covers videos from the last 14 days.
- No transcoding/HLS: videos play as uploaded files (large uploads on slow mobile networks will buffer). Thumbnails are not deleted with a video (only the video file is). Deleting a seller's videos on suspension is not automated.
- Anonymous viewers' views and share counts are not tracked.
- Chat is text only; no typing indicators; no push delivery beyond the existing FCM wiring (Phase 7). Counters can drift by one on trigger retries; opening a thread re-syncs the unread counter.
- Review/video files are protected by rules for direct access but remain reachable via tokenised URLs.
- Announcements go in-app only (cap 5,000 recipients each). Report triage for non-review/comment content uses the linked admin page.

---
# Phase 7 — Notifications + FCM

- **Model** (`notifications/{id}`): `userId`, `type`, `category`, `title`, `body`, `image`, `relatedId`, `relatedType`, `link` (the deep link / actionUrl), `read` (isRead), `createdAt`. Written **only** by Cloud Functions (`notify()`); clients can read their own, mark read, delete.
- **Preferences** (`notificationPrefs/{uid}`, `/notifications/preferences`): Orders, Messages, Reviews, Wishlist, Video, Followers, Promotions, plus Seller (sellers) and Admin (staff) switches and a master Push switch. A disabled category creates **no** notification; push-off keeps in-app. Account/safety types (store approval/rejection/suspension, role changes, important announcements, product/video suspension) are mandatory.
- **FCM:** one token doc per device (`users/{uid}/fcmTokens/{token}`), registered from a click (permission handling + denied/unsupported messages), refreshed on every app start while signed in, removed on logout / “turn off” / device list, dead tokens pruned on send and daily (60 days unseen). Pushes are **data-only** (the service worker shows one notification; click opens a same-site path). Foreground pushes show a toast. Private credentials never reach the browser; only the public web config + VAPID public key do.
- **Center** `/notifications`: newest first, cursor pagination, All/Unread, exact unread count, mark one/all read, delete one / clear read, icons by entity, deep links via `safeHref`.
- **Events (all trusted triggers):** buyer — order placed, confirmed, processing, shipped, out for delivery, delivered, cancelled, return requested/approved/rejected, refund, seller reply (chat), review response, wishlist price drop (≥5%) / back in stock, new follower, video like/comment, promotions (admin announcements). Seller — application decisions, suspension/reactivation, new order, order cancelled, return request, product approved/rejected/suspended/restored/out of stock, new review, customer message, withdrawal status, promotion status, coupon exhausted, video decisions. Admin/moderator — new seller application (+resubmission), product pending review, report (chats: admins only), withdrawal request, return escalation, security-relevant admin actions (to super admins).
- **Deep links use the real routes:** `/orders/[id]`, `/seller/orders/[id]`, `/product/[id]`, `/store/[slug]`, `/video?v=[id]`, `/messages/[id]`, `/seller/withdrawals`, `/seller/products/[id]/edit`, `/admin/...`. (The task text's `/video/[id]` and `/chat/[id]` do not exist in this app.)
- **New functions:** `onSellerApplicationCreated`, `onSellerApplicationResubmitted`, `onProductChanged`, `onReportCreated`, `onWithdrawalRequested`, `onAdminLogCreated`, `onReviewResponded`, `onCouponUpdated`, `cleanupPushTokens`, `pruneOldNotifications` (90 days), `migrateStoreFinance`; changed: `notify`, `onOrderCreated`, `onOrderLifecycle`, `onFollowWritten`, `sendAnnouncement` (promotion vs important), video like/comment triggers.

## Firebase steps for Phase 7/8
1. Deploy rules, indexes, storage and functions (`npx firebase deploy --only firestore:rules,firestore:indexes,storage,functions`). The new indexes include `notifications (userId, read, createdAt)` and a collection-group override on `fcmTokens.lastSeenAt`.
2. Set `NEXT_PUBLIC_FIREBASE_VAPID_KEY` (Cloud Messaging → Web Push certificates). FCM web push needs HTTPS (localhost is fine).
3. Set `NEXT_PUBLIC_SITE_URL` (canonical links, sitemap, Open Graph).
4. Super admin: open `/admin/settings` and run **“Move legacy commission fields”** once (calls `migrateStoreFinance`).
5. Optional hardening: create a reCAPTCHA v3 key, set `NEXT_PUBLIC_RECAPTCHA_SITE_KEY`, register the app in App Check, then enforce per product; set a Billing budget alert.
6. Enable the stricter password policy and email-enumeration protection in Authentication settings.

## Phase 8
See **AUDIT.md** for the full audit, what was fixed, and every unresolved item with file, problem, impact and exact next action.

---
# Phase 9 — deployment, PWA and Android handoff
Start with **DEPLOYMENT.md** (Firebase setup, env vars, rules/indexes/functions deploy, Vercel, PWA, Android TWA, FCM, admin/seller setup, first production test), then **SMOKE_TEST.md** (buyer, seller, video, chat and admin journeys) and **AUDIT.md** (what was fixed and what is still open). Run `npm run preflight` any time for the offline packaging/config checks.

---
## Customer + Seller app (Admin Panel is a separate project)
This repository is the **customer and seller** application. It contains **no admin UI**; the Admin App is a separate project on the **same Firebase project**.
See [`docs/ADMIN_APP_CONTRACT.md`](docs/ADMIN_APP_CONTRACT.md) for the roles, callable functions and collections it uses.

- Signup: **Customer** or **Seller** (`/signup`, `/signup?as=seller`). Seller signup creates a normal account plus a `sellerApplications/{uid}` document with status `pending`. No role is granted until the Admin App approves (email must be verified).
- Customer bottom nav: Home · Shop · Video · Cart · Profile. Seller bottom nav (inside `/seller`): Dashboard · Products · Orders · Profile; other tools are on `/seller/menu`.
- Profile: `/profile` (+ `/profile/edit`, `/reviews`, `/following`, `/followers`, `/settings`, `/addresses`). Usernames are unique via `usernames/{name}` claim documents enforced by Firestore rules.
- Video: `/video` is a full-screen (100dvh) feed with a Back button.
- After pulling this change, redeploy rules and functions: `firebase deploy --only firestore:rules,functions`.
