import { defineConfig } from 'vitest/config';
export default defineConfig({ test: { include: ['tests/**/*.rules.test.ts'], testTimeout: 30000, fileParallelism: false } });
