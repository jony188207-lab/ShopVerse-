# ShopVerse — production smoke test (manual)

**Status: NOT RUN.** These are the journeys to execute on the deployed site with three accounts: **buyer**, **seller** (separate account), **admin** (super admin). Tick each step; any failure is a launch blocker. The author could not execute any of them (no Firebase project or browser in the authoring environment).

## A. Visitor → buyer → COD order → review
- [ ] Home loads: banner carousel (if an active banner exists), categories, rails with real products or proper empty states.
- [ ] Search “…” shows suggestions (≥2 letters), results, filters, load-more; empty search shows the empty state.
- [ ] Open a product as a visitor: gallery, price, stock, variants, share. “Add to cart” works without signing in? (it asks to sign in.)
- [ ] Sign up → verification email arrives → `/verify-email` “I’ve verified” → profile shows *Email verified*. Login/logout work; reset-password email arrives.
- [ ] Add to cart (cap at stock), wishlist toggle, `/cart` totals + per-store shipping.
- [ ] `/checkout/address` add address → review → coupon (optional) → **Place order** once; reload and double-tap do not create a second order; cart empties.
- [ ] `/orders` shows the order(s) (one per store); detail shows timeline; “Message seller” opens chat.
- [ ] After the seller/admin marks it delivered: Review form appears, review posts, rating updates; second review impossible; “Return” is offered only inside the window.

## B. Seller journey
- [ ] `/become-seller` submit (logo/banner upload) → status Pending; no seller role yet.
- [ ] Admin `/admin/sellers/<uid>` → Approve → seller receives a notification; `/seller` opens after re-login.
- [ ] Seller creates a product (images, variants) → Submit for review → invisible to buyers.
- [ ] Admin/moderator approves → product visible in shop/search; seller notified.
- [ ] Buyer orders it → seller sees *New order* (notification + `/seller/orders`) and **only their own** orders; advances status Confirmed → … → Delivered.
- [ ] `/seller/earnings` shows the earning as *Awaiting cash confirmation*; admin clicks **Confirm cash received** on `/admin/orders`; after the hold period (or by editing `availableAt` in the console and running `releaseEarnings`) it becomes Available.
- [ ] `/seller/withdrawals`: request > balance is refused; valid request → admin Approve → Processing → Completed; seller notified at each step; seller cannot change status.

## C. Video journey
- [ ] Seller `/video/upload` (MP4, thumbnail optional, link own products) → Submit → `/seller/videos` shows *Pending review*; not in feed.
- [ ] Admin `/admin/videos` → Approve → seller notified → appears in New/For You (and in Trending after the hourly job).
- [ ] As buyer: autoplay on scroll, mute/unmute, like, save (also in `/video/saved`), follow (appears in Following), comment (count updates), share link `/video/<id>` opens on that video.
- [ ] Product card → **Shop Now** → `/product/<id>` → **Message seller**.
- [ ] Admin suspends the video → disappears everywhere; seller sees the reason.

## D. Chat + notifications
- [ ] Buyer opens a store → **Message seller** → send; seller sees unread badge, opens, replies; buyer sees *Seen* and the unread badge clears.
- [ ] Product and order chips are attached from product/order pages. Block → neither side can send; only the blocker unblocks. Report message → appears in `/admin/reports` with evidence; admin opens `/admin/conversations/<id>` (logged).
- [ ] Push: enable on a device → receive a push for a new message with the app in background; click opens `/messages/<id>`; foreground shows a toast. `/notifications`: unread count, mark read/all, delete, load more; preferences switch off a category and no new ones arrive.

## E. Admin journey
- [ ] `/admin` dashboard shows real counts (0 is fine on an empty site). Users: search, open, suspend (user is signed out and cannot sign in), reactivate.
- [ ] Sellers, Products (reject/suspend need a reason), Orders (status moves + cash confirmation), Reviews (hide/restore), Videos, Reports (triage, hide content), Withdrawals.
- [ ] Banners: create with desktop + mobile image, pick a real product, schedule, priority, reorder → banner shows on Home only inside its window; click opens `/product/<id>`; suspend the product → banner disappears.
- [ ] Ads: super admin adds ad code/URL, activates → ad appears at the bottom of storefront pages and **never** over the bottom nav, checkout, chat input or buttons; pause/disable in Settings hides it.
- [ ] `/admin/logs` lists the actions above.

## F. Security spot checks (browser console / second account)
- [ ] Seller B cannot open or read Seller A’s order, earnings, withdrawals, conversations, coupons.
- [ ] A normal user cannot write `/roles`, cannot open `/admin`, cannot read another user’s cart/orders/notifications.
- [ ] Suspended user: cannot sign in; if already signed in, cannot send messages / post comments / place orders.

## G. PWA / Android
- [ ] Lighthouse PWA audit on production URL; Chrome shows the Install button; installed app opens standalone with the ShopVerse icon; offline navigation shows `/offline`.
- [ ] After wiring Digital Asset Links, the Android TWA opens without a URL bar; deep links from a browser open the app.

## H. Viewports
Check 360, 375, 390, 412, 430 px and 1280, 1440, 1920 px: no horizontal scroll, bottom nav never covered by the ad, chat input visible with the keyboard open, notch/home-bar safe areas respected, tables scroll inside their container.
