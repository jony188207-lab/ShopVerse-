import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { deleteDoc, doc, getDoc, serverTimestamp, setDoc, updateDoc, writeBatch } from 'firebase/firestore';
import { readFileSync } from 'fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';

let env: RulesTestEnvironment;
beforeAll(async () => {
  env = await initializeTestEnvironment({ projectId: 'shopverse-rules-test', firestore: { rules: readFileSync('firestore.rules', 'utf8') } });
});
afterAll(() => env.cleanup());
beforeEach(() => env.clearFirestore());

const as = (uid: string) => env.authenticatedContext(uid, { email_verified: true }).firestore();
const anon = () => env.unauthenticatedContext().firestore();
const seed = (fn: (db: any) => Promise<void>) => env.withSecurityRulesDisabled((ctx) => fn(ctx.firestore()));
const roles = () => seed(async (d) => {
  await setDoc(doc(d, 'roles/sup'), { role: 'super_admin' });
  await setDoc(doc(d, 'roles/adm'), { role: 'admin' });
  await setDoc(doc(d, 'roles/sellerA'), { role: 'seller' });
  await setDoc(doc(d, 'roles/sellerB'), { role: 'seller' });
});
const product = { sellerId: 'sellerA', storeId: 'st1', status: 'approved', title: 'Widget', categoryId: 'electronics', images: [] as string[], price: 10, stock: 5 };

describe('roles', () => {
  it('user cannot grant self a role', async () => { await roles(); await assertFails(setDoc(doc(as('u1'), 'roles/u1'), { role: 'admin' })); });
  it('admin can approve seller but not create admins', async () => {
    await roles();
    await assertSucceeds(setDoc(doc(as('adm'), 'roles/u2'), { role: 'seller' }));
    await assertFails(setDoc(doc(as('adm'), 'roles/u3'), { role: 'admin' }));
    await assertSucceeds(setDoc(doc(as('sup'), 'roles/u3'), { role: 'admin' }));
  });
});

describe('private data', () => {
  it('users cannot read each other', async () => {
    await seed((d) => setDoc(doc(d, 'users/u1'), { email: 'a@a.com' }));
    await assertSucceeds(getDoc(doc(as('u1'), 'users/u1')));
    await assertFails(getDoc(doc(as('u2'), 'users/u1')));
  });
  it('cart is owner-only', async () => {
    await assertSucceeds(setDoc(doc(as('u1'), 'cartItems/c1'), { userId: 'u1', productId: 'p', quantity: 2 }));
    await assertFails(setDoc(doc(as('u2'), 'cartItems/c2'), { userId: 'u1', productId: 'p', quantity: 1 }));
    await assertFails(getDoc(doc(as('u2'), 'cartItems/c1')));
  });
});

describe('sellers/products', () => {
  it('seller B cannot edit seller A product; A can', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'products/p1'), product));
    await assertFails(updateDoc(doc(as('sellerB'), 'products/p1'), { price: 1, status: 'pending_review' }));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'products/p1'), { price: 12, status: 'pending_review' }));
  });
  it('seller cannot self-approve or spoof ratings', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'products/p1'), product));
    await assertFails(updateDoc(doc(as('sellerA'), 'products/p1'), { status: 'approved', reviewCount: 99 }));
  });
});

describe('orders & reviews', () => {
  const order = { buyerId: 'buyer', sellerId: 'sellerA', status: 'pending', total: 20 };
  it('client cannot create orders', async () => { await assertFails(setDoc(doc(as('buyer'), 'orders/o1'), order)); });
  it('buyer has no direct write access to orders (cancel/return go through Cloud Functions)', async () => {
    await seed((d) => setDoc(doc(d, 'orders/o1'), order));
    await assertFails(updateDoc(doc(as('buyer'), 'orders/o1'), { total: 1 }));
    await assertFails(updateDoc(doc(as('buyer'), 'orders/o1'), { status: 'cancelled' }));
    await assertFails(updateDoc(doc(as('buyer'), 'orders/o1'), { status: 'delivered' }));
  });
  it('orders are private to buyer + own seller', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'orders/o1'), order));
    await assertSucceeds(getDoc(doc(as('buyer'), 'orders/o1')));
    await assertSucceeds(getDoc(doc(as('sellerA'), 'orders/o1')));
    await assertFails(getDoc(doc(as('sellerB'), 'orders/o1')));
    await assertFails(getDoc(doc(as('other'), 'orders/o1')));
  });
  it('seller can advance own order but not another seller\'s', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'orders/o1'), order));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'orders/o1'), { status: 'confirmed' }));
    await assertFails(updateDoc(doc(as('sellerB'), 'orders/o1'), { status: 'confirmed' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'orders/o1'), { total: 1 }));
  });
  it('checkout markers are server-only', async () => { await assertFails(getDoc(doc(as('buyer'), 'checkouts/buyer_x'))); });
  it('review requires delivered purchase', async () => {
    const review = { orderItemId: 'oi1', productId: 'p1', sellerId: 'sellerA', userId: 'buyer', rating: 5, text: 'good', status: 'published', verifiedPurchase: true };
    await seed(async (d) => {
      await setDoc(doc(d, 'orders/o1'), { buyerId: 'buyer', sellerId: 'sellerA', status: 'shipped' });
      await setDoc(doc(d, 'orderItems/oi1'), { orderId: 'o1', buyerId: 'buyer', sellerId: 'sellerA', productId: 'p1' });
    });
    await assertFails(setDoc(doc(as('buyer'), 'reviews/oi1'), review));
    await seed((d) => updateDoc(doc(d, 'orders/o1'), { status: 'delivered' }));
    await assertSucceeds(setDoc(doc(as('buyer'), 'reviews/oi1'), review));
    await assertFails(setDoc(doc(as('other'), 'reviews/oi1'), { ...review, userId: 'other' }));
  });
});

describe('catalog visibility, cart, wishlist, stores', () => {
  it('public reads only approved products; owner sees own drafts', async () => {
    await roles();
    await seed(async (d) => { await setDoc(doc(d, 'products/live'), product); await setDoc(doc(d, 'products/draft'), { ...product, status: 'draft' }); });
    await assertSucceeds(getDoc(doc(anon(), 'products/live')));
    await assertFails(getDoc(doc(anon(), 'products/draft')));
    await assertSucceeds(getDoc(doc(as('sellerA'), 'products/draft')));
    await assertFails(getDoc(doc(as('sellerB'), 'products/draft')));
  });
  it('cart doc id must be uid_productId_variantKey and quantity 1..99', async () => {
    const line = { userId: 'u1', productId: 'p1', sellerId: 'sellerA', storeId: 'st1', variantKey: 'default', variantLabel: '', quantity: 2, createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(as('u1'), 'cartItems/u1_p1_default'), line));
    await assertFails(setDoc(doc(as('u1'), 'cartItems/random'), line));
    await assertFails(setDoc(doc(as('u1'), 'cartItems/u1_p1_default'), { ...line, quantity: 500 }));
    await assertFails(setDoc(doc(as('u1'), 'cartItems/u1_p1_default'), { ...line, price: 0.01 }));
    await assertFails(getDoc(doc(as('u2'), 'cartItems/u1_p1_default')));
  });
  it('wishlist and addresses are owner-only', async () => {
    await assertSucceeds(setDoc(doc(as('u1'), 'wishlists/u1_p1'), { userId: 'u1', productId: 'p1', createdAt: serverTimestamp() }));
    await assertFails(getDoc(doc(as('u2'), 'wishlists/u1_p1')));
    const addr = { userId: 'u1', fullName: 'Ann Lee', phone: '5551234', country: 'US', city: 'X', area: '', address: '1 Main St', postalCode: '', instructions: '', isDefault: true, createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(as('u1'), 'addresses/a1'), addr));
    await assertFails(getDoc(doc(as('u2'), 'addresses/a1')));
    await assertFails(setDoc(doc(as('u2'), 'addresses/a2'), addr));
  });
  it('seller cannot write store counters (followerCount/salesCount)', async () => {
    await roles();
    await seed((d) => setDoc(doc(d, 'stores/st1'), { ownerId: 'sellerA', status: 'approved', name: 'S', slug: 's', followerCount: 0, salesCount: 0 }));
    await assertFails(updateDoc(doc(as('sellerA'), 'stores/st1'), { followerCount: 9999 }));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'stores/st1'), { name: 'New name' }));
  });
});

describe('banners & ads', () => {
  it('banner must reference an existing product; public sees only active', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'products/p1'), product));
    const b = { title: 't', productId: 'p1', active: true, priority: 1 };
    await assertSucceeds(setDoc(doc(as('adm'), 'productBanners/b1'), b));
    await assertFails(setDoc(doc(as('adm'), 'productBanners/b2'), { ...b, productId: 'missing' }));
    await seed((d) => setDoc(doc(d, 'products/hidden'), { ...product, status: 'suspended' }));
    await assertFails(setDoc(doc(as('adm'), 'productBanners/b4'), { ...b, productId: 'hidden' }));
    await assertFails(setDoc(doc(as('u1'), 'productBanners/b3'), b));
    await seed((d) => setDoc(doc(d, 'productBanners/off'), { ...b, active: false }));
    await assertSucceeds(getDoc(doc(anon(), 'productBanners/b1')));
    await assertFails(getDoc(doc(anon(), 'productBanners/off')));
  });
  it('only super admin writes ad code', async () => {
    await roles();
    const ad = { networkName: 'x', adCode: '<b>x</b>', placement: 'bottom', active: true };
    await assertFails(setDoc(doc(as('adm'), 'adNetworkSettings/a1'), ad));
    await assertSucceeds(setDoc(doc(as('sup'), 'adNetworkSettings/a1'), ad));
    await assertSucceeds(getDoc(doc(anon(), 'adNetworkSettings/a1')));
  });
});

describe('social, money, audit', () => {
  it('cannot like as someone else', async () => {
    await seed((d) => setDoc(doc(d, 'videos/v1'), { ownerId: 'x', status: 'published', visibility: 'public' }));
    await assertSucceeds(setDoc(doc(as('u1'), 'videoLikes/v1_u1'), { userId: 'u1', videoId: 'v1' }));
    await assertFails(setDoc(doc(as('u1'), 'videoLikes/v1_u2'), { userId: 'u2', videoId: 'v1' }));
  });
  it('earnings are read-only, withdrawals owner-scoped', async () => {
    await roles();
    await seed((d) => setDoc(doc(d, 'sellerEarnings/e1'), { sellerId: 'sellerA', amount: 5 }));
    await assertSucceeds(getDoc(doc(as('sellerA'), 'sellerEarnings/e1')));
    await assertFails(getDoc(doc(as('sellerB'), 'sellerEarnings/e1')));
    await assertFails(updateDoc(doc(as('sellerA'), 'sellerEarnings/e1'), { amount: 500 }));
    await assertFails(setDoc(doc(as('sellerB'), 'withdrawals/w1'), { sellerId: 'sellerA', status: 'pending', amount: 5 }));
  });
  it('admin logs are append-only', async () => {
    await roles();
    await assertSucceeds(setDoc(doc(as('adm'), 'adminLogs/l1'), { adminId: 'adm', action: 'x', createdAt: serverTimestamp() }));
    await assertFails(deleteDoc(doc(as('adm'), 'adminLogs/l1')));
    await assertFails(getDoc(doc(as('u1'), 'adminLogs/l1')));
  });
});

// ---------------- Phase 3: seller system ----------------
const adminDb = () => as('adm');
const app = (uid: string, over: Record<string, unknown> = {}) => ({
  userId: uid, storeName: 'My Shop', slug: 'my-shop', description: '', phone: '5551234', email: 'a@b.co', country: 'US', city: 'X', address: '1 Main St',
  returnPolicy: '', shippingInfo: '', logoUrl: '', bannerUrl: '', status: 'pending', createdAt: serverTimestamp(), updatedAt: serverTimestamp(), ...over,
});

describe('seller applications & roles', () => {
  it('a user can apply, but only as pending, and cannot approve themselves', async () => {
    await assertSucceeds(setDoc(doc(as('u1'), 'sellerApplications/u1'), app('u1')));
    await assertFails(setDoc(doc(as('u2'), 'sellerApplications/u2'), app('u2', { status: 'approved' })));
    await assertFails(updateDoc(doc(as('u1'), 'sellerApplications/u1'), { status: 'approved' }));
    await assertFails(setDoc(doc(as('u1'), 'roles/u1'), { role: 'seller' }));
  });
  it('cannot apply for someone else, with a bad slug, or while unverified', async () => {
    await assertFails(setDoc(doc(as('u1'), 'sellerApplications/u2'), app('u2')));
    await assertFails(setDoc(doc(as('u3'), 'sellerApplications/u3'), app('u3', { slug: 'Bad Slug!' })));
    // Seller signup applies right after account creation (email not verified yet): allowed, because an application grants nothing.
    await assertSucceeds(setDoc(doc(env.authenticatedContext('u4', { email_verified: false }).firestore(), 'sellerApplications/u4'), app('u4', { ownerName: 'Owner Four' })));
  });
  it('applications are private; admin can read; admin cannot edit directly (function-only)', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'sellerApplications/u1'), app('u1')));
    await assertSucceeds(getDoc(doc(as('u1'), 'sellerApplications/u1')));
    await assertFails(getDoc(doc(as('u2'), 'sellerApplications/u1')));
    await assertSucceeds(getDoc(doc(as('adm'), 'sellerApplications/u1')));
    await assertFails(updateDoc(doc(as('adm'), 'sellerApplications/u1'), { status: 'approved' }));
  });
  it('rejected applicants may resubmit (pending), approved/suspended may not edit', async () => {
    await seed(async (d) => { await setDoc(doc(d, 'sellerApplications/r1'), app('r1', { status: 'rejected', reviewNote: 'fix' })); await setDoc(doc(d, 'sellerApplications/s1'), app('s1', { status: 'suspended' })); });
    await assertSucceeds(updateDoc(doc(as('r1'), 'sellerApplications/r1'), { status: 'pending', storeName: 'Better Name' }));
    await assertFails(updateDoc(doc(as('s1'), 'sellerApplications/s1'), { status: 'pending' }));
  });
  it('an existing seller or staff cannot apply', async () => {
    await roles();
    await assertFails(setDoc(doc(as('sellerA'), 'sellerApplications/sellerA'), app('sellerA')));
    await assertFails(setDoc(doc(as('adm'), 'sellerApplications/adm'), app('adm')));
  });
});

describe('usernames', () => {
  it('claims a username atomically with the profile', async () => {
    await seed((d) => setDoc(doc(d, 'profiles/u1'), { displayName: 'A', photoURL: null, bio: '', followerCount: 0, followingCount: 0 }));
    const db = as('u1'); const b = writeBatch(db);
    b.set(doc(db, 'usernames/alice_1'), { uid: 'u1', createdAt: serverTimestamp() });
    b.update(doc(db, 'profiles/u1'), { username: 'alice_1', updatedAt: serverTimestamp() });
    await assertSucceeds(b.commit());
  });
  it('rejects a profile username without a matching claim, or claimed by someone else', async () => {
    await seed((d) => setDoc(doc(d, 'profiles/u1'), { displayName: 'A', photoURL: null, bio: '', followerCount: 0, followingCount: 0 }));
    await assertFails(updateDoc(doc(as('u1'), 'profiles/u1'), { username: 'nobody_yet' }));
    await seed((d) => setDoc(doc(d, 'usernames/taken'), { uid: 'u2' }));
    await assertFails(updateDoc(doc(as('u1'), 'profiles/u1'), { username: 'taken' }));
    await assertFails(setDoc(doc(as('u1'), 'usernames/taken'), { uid: 'u1', createdAt: serverTimestamp() })); // cannot overwrite
  });
  it('only the owner can release a username', async () => {
    await seed((d) => setDoc(doc(d, 'usernames/mine'), { uid: 'u1' }));
    await assertFails(deleteDoc(doc(as('u2'), 'usernames/mine')));
    await assertSucceeds(deleteDoc(doc(as('u1'), 'usernames/mine')));
  });
});

describe('seller isolation', () => {
  it('seller cannot self-promote products or touch moderation fields', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'products/p1'), { ...product, storeId: 'st1' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'products/p1'), { featured: true, status: 'pending_review' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'products/p1'), { flashSaleEndsAt: new Date(Date.now() + 1e9), status: 'pending_review' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'products/p1'), { moderationNote: 'ok', status: 'pending_review' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'products/p1'), { status: 'approved' }));
  });
  it('seller B cannot read A\'s balance, earnings, withdrawals, store-private data', async () => {
    await roles();
    await seed(async (d) => {
      await setDoc(doc(d, 'sellerBalances/sellerA'), { available: 50 }); await setDoc(doc(d, 'withdrawals/w1'), { sellerId: 'sellerA', amount: 5, status: 'pending' });
      await setDoc(doc(d, 'stores/st1'), { ownerId: 'sellerA', status: 'approved', name: 'A', slug: 'a', shippingFee: 0 }); await setDoc(doc(d, 'storePrivate/st1'), { phone: '555', email: 'a@a.co', address: 'x' });
    });
    for (const p of ['sellerBalances/sellerA', 'withdrawals/w1', 'storePrivate/st1']) { await assertSucceeds(getDoc(doc(as('sellerA'), p))); await assertFails(getDoc(doc(as('sellerB'), p))); await assertFails(getDoc(doc(anon(), p))); }
  });
  it('nobody can write money state from the client', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'withdrawals/w1'), { sellerId: 'sellerA', amount: 5, status: 'pending' }));
    await assertFails(setDoc(doc(as('sellerA'), 'sellerBalances/sellerA'), { available: 1e6 }));
    await assertFails(setDoc(doc(as('sellerA'), 'withdrawals/w2'), { sellerId: 'sellerA', amount: 5, status: 'pending' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'withdrawals/w1'), { status: 'completed' }));
    await assertFails(updateDoc(doc(as('sup'), 'withdrawals/w1'), { status: 'completed' }));
  });
  it('store private contact: seller edits own only; commission/status untouchable', async () => {
    await roles();
    await seed(async (d) => { await setDoc(doc(d, 'stores/st1'), { ownerId: 'sellerA', status: 'approved', name: 'A', slug: 'a', shippingFee: 0, commissionRate: 10 }); await setDoc(doc(d, 'storePrivate/st1'), { phone: '55555', email: 'a@a.co', address: 'xyz', createdAt: new Date() }); });
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'storePrivate/st1'), { phone: '66666' }));
    await assertFails(updateDoc(doc(as('sellerB'), 'storePrivate/st1'), { phone: '66666' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'stores/st1'), { commissionRate: 0 }));
    await assertFails(updateDoc(doc(as('sellerA'), 'stores/st1'), { status: 'suspended' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'stores/st1'), { ownerId: 'sellerB' }));
  });
  it('order status machine: valid moves only, own orders only', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'orders/o1'), { buyerId: 'buyer', sellerId: 'sellerA', status: 'pending', total: 20 }));
    await assertFails(updateDoc(doc(as('sellerA'), 'orders/o1'), { status: 'delivered' }));   // skipping steps
    await assertFails(updateDoc(doc(as('sellerA'), 'orders/o1'), { status: 'refunded' }));    // admin-only
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'orders/o1'), { status: 'confirmed', trackingNumber: 'T1' }));
    await assertFails(updateDoc(doc(as('sellerB'), 'orders/o1'), { status: 'processing' }));
  });
});

describe('coupons, promotions, notifications, audit', () => {
  const coupon = (over: Record<string, unknown> = {}) => ({ sellerId: 'sellerA', code: 'SAVE10', discountType: 'percent', discountValue: 10, minOrder: 0, maxDiscount: 0, usageLimit: 0, usedCount: 0, active: true, ...over });
  it('seller creates coupons only in own namespace and cannot fake usedCount', async () => {
    await roles();
    await assertSucceeds(setDoc(doc(as('sellerA'), 'coupons/sellerA_SAVE10'), coupon()));
    await assertFails(setDoc(doc(as('sellerA'), 'coupons/sellerB_SAVE10'), coupon({ sellerId: 'sellerB' })));
    await assertFails(setDoc(doc(as('sellerA'), 'coupons/sellerA_BIG'), coupon({ code: 'BIG', discountValue: 500 })));
    await assertFails(setDoc(doc(as('sellerA'), 'coupons/sellerA_USED'), coupon({ code: 'USED', usedCount: 5 })));
    await assertFails(updateDoc(doc(as('sellerB'), 'coupons/sellerA_SAVE10'), { active: false }));
    await assertFails(getDoc(doc(as('sellerB'), 'coupons/sellerA_SAVE10')));
  });
  it('promotion requests: own approved products only, pending only, no self-approval', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'products/p1'), { ...product, storeId: 'st1' }));
    const now = Date.now(); const promo = { sellerId: 'sellerA', storeId: 'st1', productId: 'p1', type: 'featured', startsAt: new Date(now + 1000), endsAt: new Date(now + 3 * 86400000), note: '', status: 'pending', createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(as('sellerA'), 'promotions/pr1'), promo));
    await assertFails(setDoc(doc(as('sellerB'), 'promotions/pr2'), { ...promo, sellerId: 'sellerB' }));   // not their product
    await assertFails(setDoc(doc(as('sellerA'), 'promotions/pr3'), { ...promo, status: 'approved' }));
    await assertFails(updateDoc(doc(as('sellerA'), 'promotions/pr1'), { status: 'approved' }));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'promotions/pr1'), { status: 'cancelled' }));
    await assertFails(getDoc(doc(as('sellerB'), 'promotions/pr1')));
  });
  it('notifications cannot be forged; owner may only mark read', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'notifications/n1'), { userId: 'u1', title: 't', read: false }));
    await assertFails(setDoc(doc(as('u1'), 'notifications/n2'), { userId: 'u1', title: 'x', read: false }));
    await assertFails(setDoc(doc(as('adm'), 'notifications/n3'), { userId: 'u1', title: 'x', read: false }));
    await assertSucceeds(updateDoc(doc(as('u1'), 'notifications/n1'), { read: true }));
    await assertFails(updateDoc(doc(as('u1'), 'notifications/n1'), { title: 'hacked' }));
    await assertFails(getDoc(doc(as('u2'), 'notifications/n1')));
  });
  it('moderators can moderate products and log it; sellers cannot touch logs', async () => {
    await seed(async (d) => { await setDoc(doc(d, 'roles/mod'), { role: 'moderator' }); await setDoc(doc(d, 'roles/sellerA'), { role: 'seller' }); await setDoc(doc(d, 'products/p1'), { ...product, status: 'pending_review' }); });
    await assertSucceeds(updateDoc(doc(as('mod'), 'products/p1'), { status: 'approved', moderationNote: '', moderatedBy: 'mod', moderatedAt: new Date(), updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('mod'), 'products/p1'), { status: 'out_of_stock' }));
    await assertSucceeds(setDoc(doc(as('mod'), 'adminLogs/l1'), { adminId: 'mod', action: 'product.approved', createdAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as('sellerA'), 'adminLogs/l2'), { adminId: 'sellerA', action: 'x', createdAt: serverTimestamp() }));
    await assertFails(getDoc(doc(as('mod'), 'adminLogs/l1')));
  });
});

// ---------------- Phase 4: admin panel ----------------
describe('admin: roles, users, categories, reports, ads, promotions, settings', () => {
  const asRole = async (uid: string, role: string) => { await seed((d) => setDoc(doc(d, `roles/${uid}`), { role })); return as(uid); };
  it('roles cannot be written by ANY client (functions/console only); moderators cannot read users/orders', async () => {
    await roles(); const mod = await asRole('mod', 'moderator');
    await assertFails(setDoc(doc(as('sup'), 'roles/x'), { role: 'admin' }));
    await assertFails(updateDoc(doc(as('sup'), 'roles/adm'), { role: 'user' }));
    await seed(async (d) => { await setDoc(doc(d, 'users/u1'), { email: 'a@a.co', status: 'active' }); await setDoc(doc(d, 'orders/o1'), { buyerId: 'u1', sellerId: 'sellerA', status: 'pending' }); });
    await assertSucceeds(getDoc(doc(as('adm'), 'users/u1'))); await assertFails(getDoc(doc(mod, 'users/u1'))); await assertFails(getDoc(doc(mod, 'orders/o1')));
  });
  it('user status is function-only: neither the user nor an admin can edit it from the client', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'users/u1'), { email: 'a@a.co', status: 'active', displayName: 'A' }));
    await assertFails(updateDoc(doc(as('u1'), 'users/u1'), { status: 'active', suspendReason: '' }));
    await assertFails(updateDoc(doc(as('adm'), 'users/u1'), { status: 'suspended' }));
    await assertSucceeds(updateDoc(doc(as('u1'), 'users/u1'), { displayName: 'New' }));
  });
  it('categories: public read, admin-only validated writes', async () => {
    await roles(); const c = { name: 'Toys', order: 10, active: true, imageUrl: '', parentId: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(as('adm'), 'categories/toys'), c));
    await assertFails(setDoc(doc(as('sellerA'), 'categories/hack'), c));
    await assertFails(setDoc(doc(as('adm'), 'categories/Bad Id'), c));
    await assertFails(setDoc(doc(as('adm'), 'categories/x'), { ...c, order: 'first' }));
    await assertSucceeds(getDoc(doc(anon(), 'categories/toys')));
  });
  it('reports: one per user per target, staff-only triage with limited fields', async () => {
    await roles(); const mod = await asRole('mod', 'moderator');
    const r = { reporterId: 'u1', targetType: 'review', targetId: 'rv1', reason: 'spam', status: 'open', createdAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(as('u1'), 'reports/u1_review_rv1'), r));
    await assertFails(setDoc(doc(as('u1'), 'reports/anything'), r));
    await assertFails(setDoc(doc(as('u1'), 'reports/u1_nope_rv1'), { ...r, targetType: 'nope' }));
    await assertFails(setDoc(doc(as('u1'), 'reports/u1_conversation_c1'), { ...r, targetType: 'conversation', targetId: 'c1', status: 'resolved' }));
    await assertFails(getDoc(doc(as('u1'), 'reports/u1_review_rv1')));
    await assertSucceeds(updateDoc(doc(mod, 'reports/u1_review_rv1'), { status: 'under_review', internalNote: 'checking', updatedAt: new Date() }));
    await assertFails(updateDoc(doc(mod, 'reports/u1_review_rv1'), { reason: 'rewritten' }));
  });
  it('reviews: moderators hide with who/why; sellers cannot hide or edit text', async () => {
    await seed(async (d) => { await setDoc(doc(d, 'roles/mod'), { role: 'moderator' }); await setDoc(doc(d, 'roles/sellerA'), { role: 'seller' }); await setDoc(doc(d, 'reviews/rv1'), { userId: 'u1', sellerId: 'sellerA', productId: 'p1', rating: 5, text: 'x', status: 'published' }); });
    await assertSucceeds(updateDoc(doc(as('mod'), 'reviews/rv1'), { status: 'hidden', moderationNote: 'abuse', moderatedBy: 'mod', moderatedAt: new Date(), updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('sellerA'), 'reviews/rv1'), { status: 'hidden', updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('sellerA'), 'reviews/rv1'), { text: 'edited', updatedAt: new Date() }));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'reviews/rv1'), { sellerResponse: 'thanks', sellerResponseAt: new Date(), updatedAt: new Date() }));
  });
  it('ad network: only a super admin writes code; any admin can pause; code is validated', async () => {
    await roles();
    const ad = { networkName: 'Net', adCode: '<b>ad</b>', adUrl: '', placement: 'bottom', device: 'all', width: 320, height: 50, active: true, createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await assertFails(setDoc(doc(as('adm'), 'adNetworkSettings/a1'), ad));
    await assertSucceeds(setDoc(doc(as('sup'), 'adNetworkSettings/a1'), ad));
    await assertFails(setDoc(doc(as('sup'), 'adNetworkSettings/a2'), { ...ad, adCode: '', adUrl: 'http://insecure.example' }));
    await assertFails(setDoc(doc(as('sup'), 'adNetworkSettings/a3'), { ...ad, width: 99999 }));
    await assertSucceeds(updateDoc(doc(as('adm'), 'adNetworkSettings/a1'), { active: false, updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('adm'), 'adNetworkSettings/a1'), { adCode: '<script>evil()</script>', updatedAt: new Date() }));
    await assertFails(getDoc(doc(anon(), 'adNetworkSettings/a1')));   // paused => not public
  });
  it('platform promotions: admin-only, applied flag is server-owned, separate from seller requests', async () => {
    await roles();
    const now = Date.now(); const p = { title: 'Summer', type: 'featured', targetType: 'category', productIds: [], categoryId: 'toys', storeOwnerId: '', startsAt: new Date(now + 1000), endsAt: new Date(now + 5 * 86400000), active: true, applied: false, appliedProductIds: [], createdBy: 'adm', createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(as('adm'), 'platformPromotions/pp1'), p));
    await assertFails(setDoc(doc(as('sellerA'), 'platformPromotions/pp2'), { ...p, createdBy: 'sellerA' }));
    await assertFails(setDoc(doc(as('adm'), 'platformPromotions/pp3'), { ...p, applied: true }));
    await assertFails(updateDoc(doc(as('adm'), 'platformPromotions/pp1'), { applied: true }));
    await assertFails(setDoc(doc(as('adm'), 'platformPromotions/pp4'), { ...p, endsAt: new Date(now + 200 * 86400000) }));
    await assertFails(getDoc(doc(as('sellerA'), 'platformPromotions/pp1')));
  });
  it('settings: super admin writes, admins read sensitive, storefront reads only public', async () => {
    await roles();
    const s = { commissionDefaultPercent: 12, earningsHoldDays: 7, minWithdrawal: 10, promotionMaxDays: 14, pushEnabled: true, updatedAt: serverTimestamp(), updatedBy: 'sup' };
    await assertSucceeds(setDoc(doc(as('sup'), 'platformSettings/main'), s));
    await assertFails(setDoc(doc(as('adm'), 'platformSettings/main'), s));
    await assertFails(setDoc(doc(as('sup'), 'platformSettings/main'), { ...s, commissionDefaultPercent: 90 }));
    await assertSucceeds(getDoc(doc(as('adm'), 'platformSettings/main'))); await assertFails(getDoc(doc(anon(), 'platformSettings/main'))); await assertFails(getDoc(doc(as('sellerA'), 'platformSettings/main')));
    await assertSucceeds(setDoc(doc(as('sup'), 'publicSettings/main'), { adsEnabled: true, bannerRotateSeconds: 6, updatedAt: serverTimestamp(), updatedBy: 'sup' }));
    await assertSucceeds(getDoc(doc(anon(), 'publicSettings/main')));
    await assertFails(setDoc(doc(as('sup'), 'announcements/x'), { title: 'client write' }));
  });
  it('banners: must reference an approved product; reorder/pause still work after the product is suspended', async () => {
    await roles(); await seed(async (d) => { await setDoc(doc(d, 'products/p1'), { ...product, status: 'approved' }); await setDoc(doc(d, 'products/p2'), { ...product, status: 'suspended' }); });
    const b = { title: 'Big sale', subtitle: '', desktopImage: 'https://x/d.jpg', mobileImage: 'https://x/m.jpg', productId: 'p1', ctaText: 'Shop now', priority: 10, active: true, createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(as('adm'), 'productBanners/b1'), b));
    await assertFails(setDoc(doc(as('adm'), 'productBanners/b2'), { ...b, productId: 'p2' }));
    await assertFails(setDoc(doc(as('adm'), 'productBanners/b3'), { ...b, extra: 'field' }));
    await seed((d) => setDoc(doc(d, 'productBanners/b4'), { ...b, productId: 'p2' }));
    await assertSucceeds(updateDoc(doc(as('adm'), 'productBanners/b4'), { priority: 5, updatedAt: new Date() }));
    await assertSucceeds(updateDoc(doc(as('adm'), 'productBanners/b4'), { active: false, updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('adm'), 'productBanners/b4'), { active: true, updatedAt: new Date() }));
  });
});

// ---------------- Phase 5+6: video + chat ----------------
describe('video', () => {
  const vid = (over: Record<string, unknown> = {}) => ({ ownerId: 'sellerA', storeId: 'st1', title: 'My video', description: '', videoUrl: 'https://x/v.mp4', thumbnailUrl: '', productIds: ['p1'], hasProducts: true, hashtags: ['a'], category: '', visibility: 'public', status: 'pending_review', likeCount: 0, commentCount: 0, viewCount: 0, saveCount: 0, shareCount: 0, trendScore: 0, createdAt: serverTimestamp(), updatedAt: serverTimestamp(), ...over });
  const world = () => seed(async (d) => {
    await setDoc(doc(d, 'roles/sellerA'), { role: 'seller' }); await setDoc(doc(d, 'roles/sellerB'), { role: 'seller' }); await setDoc(doc(d, 'roles/mod'), { role: 'moderator' });
    await setDoc(doc(d, 'stores/st1'), { ownerId: 'sellerA', status: 'approved', name: 'A', slug: 'a', shippingFee: 0 }); await setDoc(doc(d, 'stores/st2'), { ownerId: 'sellerB', status: 'approved', name: 'B', slug: 'b', shippingFee: 0 });
    await setDoc(doc(d, 'products/p1'), { ...product, sellerId: 'sellerA', storeId: 'st1' }); await setDoc(doc(d, 'products/p2'), { ...product, sellerId: 'sellerB', storeId: 'st2' });
  });
  it('only sellers upload; only their own products can be linked; cannot self-publish or fake counters', async () => {
    await world();
    await assertSucceeds(setDoc(doc(as('sellerA'), 'videos/v1'), vid()));
    await assertFails(setDoc(doc(as('u1'), 'videos/v2'), vid({ ownerId: 'u1' })));                       // not a seller
    await assertFails(setDoc(doc(as('sellerA'), 'videos/v3'), vid({ productIds: ['p2'] })));            // B's product
    await assertFails(setDoc(doc(as('sellerA'), 'videos/v4'), vid({ storeId: 'st2' })));                // B's store
    await assertFails(setDoc(doc(as('sellerA'), 'videos/v5'), vid({ status: 'published' })));
    await assertFails(setDoc(doc(as('sellerA'), 'videos/v6'), vid({ viewCount: 1000 })));
    await assertFails(setDoc(doc(as('sellerA'), 'videos/v7'), vid({ productIds: ['p1', 'p1', 'p1', 'p1', 'p1', 'p1'] })));
  });
  it('visibility: public only when published+public; owner/staff see the rest', async () => {
    await world();
    await seed(async (d) => { await setDoc(doc(d, 'videos/pub'), vid({ status: 'published' })); await setDoc(doc(d, 'videos/pend'), vid()); await setDoc(doc(d, 'videos/priv'), vid({ status: 'published', visibility: 'private' })); });
    await assertSucceeds(getDoc(doc(anon(), 'videos/pub'))); await assertFails(getDoc(doc(anon(), 'videos/pend'))); await assertFails(getDoc(doc(anon(), 'videos/priv')));
    await assertSucceeds(getDoc(doc(as('sellerA'), 'videos/pend'))); await assertFails(getDoc(doc(as('sellerB'), 'videos/pend'))); await assertSucceeds(getDoc(doc(as('mod'), 'videos/pend')));
  });
  it('after approval the seller cannot change content or status, only visibility; moderators decide', async () => {
    await world(); await seed((d) => setDoc(doc(d, 'videos/pub'), vid({ status: 'published' })));
    await assertFails(updateDoc(doc(as('sellerA'), 'videos/pub'), { title: 'swapped', updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('sellerA'), 'videos/pub'), { status: 'published', productIds: ['p1'], viewCount: 99 }));
    await assertFails(updateDoc(doc(as('sellerA'), 'videos/pub'), { status: 'suspended', updatedAt: new Date() }));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'videos/pub'), { visibility: 'private', updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('sellerB'), 'videos/pub'), { visibility: 'private', updatedAt: new Date() }));
    await assertSucceeds(updateDoc(doc(as('mod'), 'videos/pub'), { status: 'suspended', moderationNote: 'policy', moderatedBy: 'mod', moderatedAt: new Date(), updatedAt: new Date() }));
  });
  it('rejected videos can be edited and resubmitted by the owner only', async () => {
    await world(); await seed((d) => setDoc(doc(d, 'videos/rej'), vid({ status: 'rejected', moderationNote: 'blurry' })));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'videos/rej'), { title: 'Better', status: 'pending_review', updatedAt: new Date() }));
    await assertFails(updateDoc(doc(as('sellerA'), 'videos/rej'), { status: 'published' }));
  });
  it('likes / saves / views are own-only, one per user, and only for published videos', async () => {
    await world(); await seed(async (d) => { await setDoc(doc(d, 'videos/pub'), vid({ status: 'published' })); await setDoc(doc(d, 'videos/pend'), vid()); });
    await assertSucceeds(setDoc(doc(as('u1'), 'videoLikes/pub_u1'), { userId: 'u1', videoId: 'pub' }));
    await assertFails(setDoc(doc(as('u1'), 'videoLikes/pub_u2'), { userId: 'u2', videoId: 'pub' }));
    await assertFails(setDoc(doc(as('u1'), 'videoLikes/pend_u1'), { userId: 'u1', videoId: 'pend' }));
    await assertSucceeds(setDoc(doc(as('u1'), 'videoViews/pub_u1'), { userId: 'u1', videoId: 'pub' }));
    await assertFails(setDoc(doc(as('u1'), 'videoViews/pub_u1'), { userId: 'u1', videoId: 'pub', again: true }));   // no second count
    await assertFails(updateDoc(doc(as('u1'), 'videos/pub'), { likeCount: 5 }));
  });
  it('comments: verified users, own delete, hidden ones are not public', async () => {
    await world(); await seed((d) => setDoc(doc(d, 'videos/pub'), vid({ status: 'published' })));
    await assertSucceeds(setDoc(doc(as('u1'), 'videoComments/c1'), { userId: 'u1', userName: 'U', videoId: 'pub', text: 'nice', status: 'visible', createdAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as('u1'), 'videoComments/c2'), { userId: 'u2', userName: 'U', videoId: 'pub', text: 'x', status: 'visible', createdAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as('u1'), 'videoComments/c3'), { userId: 'u1', userName: 'U', videoId: 'pub', text: 'x'.repeat(600), status: 'visible', createdAt: serverTimestamp() }));
    await assertSucceeds(updateDoc(doc(as('mod'), 'videoComments/c1'), { status: 'hidden', updatedAt: new Date() }));
    await assertFails(getDoc(doc(anon(), 'videoComments/c1')));
    await assertFails(deleteDoc(doc(as('u2'), 'videoComments/c1')));
  });
});

describe('chat', () => {
  const world = () => seed(async (d) => {
    await setDoc(doc(d, 'roles/sellerA'), { role: 'seller' }); await setDoc(doc(d, 'roles/sellerB'), { role: 'seller' }); await setDoc(doc(d, 'roles/adm'), { role: 'admin' }); await setDoc(doc(d, 'roles/mod'), { role: 'moderator' });
    await setDoc(doc(d, 'stores/st1'), { ownerId: 'sellerA', status: 'approved', name: 'A', slug: 'a', shippingFee: 0 }); await setDoc(doc(d, 'stores/st2'), { ownerId: 'sellerB', status: 'approved', name: 'B', slug: 'b', shippingFee: 0 });
    await setDoc(doc(d, 'products/pA'), { ...product, sellerId: 'sellerA', storeId: 'st1' }); await setDoc(doc(d, 'products/pB'), { ...product, sellerId: 'sellerB', storeId: 'st2' });
    await setDoc(doc(d, 'orders/oA'), { buyerId: 'buyer', sellerId: 'sellerA', status: 'pending' }); await setDoc(doc(d, 'orders/oB'), { buyerId: 'buyer', sellerId: 'sellerB', status: 'pending' });
    await setDoc(doc(d, 'conversations/buyer_st1'), { buyerId: 'buyer', sellerId: 'sellerA', storeId: 'st1', participants: ['buyer', 'sellerA'], unread: { buyer: 0, sellerA: 3 }, blockedBy: [] });
  });
  const conv = (over: Record<string, unknown> = {}) => ({ buyerId: 'buyer', sellerId: 'sellerA', storeId: 'st1', participants: ['buyer', 'sellerA'], unread: { buyer: 0, sellerA: 0 }, blockedBy: [], createdAt: serverTimestamp(), updatedAt: serverTimestamp(), ...over });
  const msg = (from: string, to: string, over: Record<string, unknown> = {}) => ({ senderId: from, receiverId: to, conversationId: 'buyer_st1', text: 'hi', createdAt: serverTimestamp(), readAt: null, ...over });
  it('only the buyer can open a conversation, with the store owner as the other side', async () => {
    await world();
    await assertSucceeds(setDoc(doc(as('buyer'), 'conversations/buyer_st2'), conv({ storeId: 'st2', sellerId: 'sellerB', participants: ['buyer', 'sellerB'], unread: { buyer: 0, sellerB: 0 } })));
    await assertFails(setDoc(doc(as('sellerA'), 'conversations/other_st1'), conv({ buyerId: 'other', participants: ['other', 'sellerA'], unread: { other: 0, sellerA: 0 } })));  // seller starting a chat for someone else
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1'), conv({ sellerId: 'sellerB', participants: ['buyer', 'sellerB'], unread: { buyer: 0, sellerB: 0 } })));   // wrong seller for store
    await assertFails(setDoc(doc(as('buyer'), 'conversations/random-id'), conv()));
    await assertFails(setDoc(doc(as('sellerA'), 'conversations/sellerA_st1'), conv({ buyerId: 'sellerA', participants: ['sellerA', 'sellerA'], unread: { sellerA: 0 } })));
  });
  it('conversations and messages are visible only to the two participants (and admins)', async () => {
    await world(); await seed((d) => setDoc(doc(d, 'conversations/buyer_st1/messages/m1'), msg('buyer', 'sellerA', { readAt: null })));
    for (const p of ['conversations/buyer_st1', 'conversations/buyer_st1/messages/m1']) {
      await assertSucceeds(getDoc(doc(as('buyer'), p))); await assertSucceeds(getDoc(doc(as('sellerA'), p))); await assertSucceeds(getDoc(doc(as('adm'), p)));
      await assertFails(getDoc(doc(as('sellerB'), p))); await assertFails(getDoc(doc(as('other'), p))); await assertFails(getDoc(doc(as('mod'), p))); await assertFails(getDoc(doc(anon(), p)));
    }
  });
  it('sending: must be a participant, as yourself, to the other side, with valid references', async () => {
    await world();
    await assertSucceeds(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/a'), msg('buyer', 'sellerA', { productId: 'pA', orderId: 'oA' })));
    await assertSucceeds(setDoc(doc(as('sellerA'), 'conversations/buyer_st1/messages/b'), msg('sellerA', 'buyer')));
    await assertFails(setDoc(doc(as('sellerB'), 'conversations/buyer_st1/messages/c'), msg('sellerB', 'buyer')));                       // outsider
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/d'), msg('sellerA', 'buyer')));                         // spoofed sender
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/e'), msg('buyer', 'sellerB')));                         // wrong receiver
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/f'), msg('buyer', 'sellerA', { productId: 'pB' })));    // other seller's product
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/g'), msg('buyer', 'sellerA', { orderId: 'oB' })));      // other seller's order
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/h'), msg('buyer', 'sellerA', { text: '' })));
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/i'), msg('buyer', 'sellerA', { createdAt: new Date('2020-01-01') })));
  });
  it('read receipts: only the receiver can mark read; nobody can edit text or delete', async () => {
    await world(); await seed((d) => setDoc(doc(d, 'conversations/buyer_st1/messages/m1'), msg('buyer', 'sellerA')));
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'conversations/buyer_st1/messages/m1'), { readAt: serverTimestamp() }));
    await seed((d) => setDoc(doc(d, 'conversations/buyer_st1/messages/m2'), msg('buyer', 'sellerA')));
    await assertFails(updateDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/m2'), { readAt: serverTimestamp() }));
    await assertFails(updateDoc(doc(as('sellerA'), 'conversations/buyer_st1/messages/m2'), { text: 'rewritten' }));
    await assertFails(updateDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/m2'), { text: 'rewritten' }));
    await assertFails(deleteDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/m2')));
  });
  it('unread counters: you can zero only your own; blocking stops messages both ways', async () => {
    await world();
    await assertSucceeds(updateDoc(doc(as('sellerA'), 'conversations/buyer_st1'), { 'unread.sellerA': 0 }));
    await assertFails(updateDoc(doc(as('buyer'), 'conversations/buyer_st1'), { 'unread.sellerA': 0 }));       // not yours
    await assertFails(updateDoc(doc(as('buyer'), 'conversations/buyer_st1'), { 'unread.buyer': 5 }));         // cannot inflate
    await assertFails(updateDoc(doc(as('buyer'), 'conversations/buyer_st1'), { lastMessage: 'forged' }));
    await assertSucceeds(updateDoc(doc(as('buyer'), 'conversations/buyer_st1'), { blockedBy: ['buyer'] }));
    await assertFails(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/x'), msg('buyer', 'sellerA')));
    await assertFails(setDoc(doc(as('sellerA'), 'conversations/buyer_st1/messages/y'), msg('sellerA', 'buyer')));
    await assertFails(updateDoc(doc(as('sellerA'), 'conversations/buyer_st1'), { blockedBy: [] }));            // seller cannot lift the buyer's block
    await assertSucceeds(updateDoc(doc(as('buyer'), 'conversations/buyer_st1'), { blockedBy: [] }));
    await assertSucceeds(setDoc(doc(as('buyer'), 'conversations/buyer_st1/messages/z'), msg('buyer', 'sellerA')));
  });
});

// ---------------- Phase 7 + 8: notifications, FCM tokens, preferences, privacy hardening ----------------
describe('notifications / FCM / preferences', () => {
  const tok = { token: 'tok-1', platform: 'desktop-web', userAgent: 'UA', createdAt: serverTimestamp(), lastSeenAt: serverTimestamp() };
  it('FCM tokens: owner-only, one doc per device, validated shape (id must equal the token)', async () => {
    await assertSucceeds(setDoc(doc(as('u1'), 'users/u1/fcmTokens/tok-1'), tok));
    await assertSucceeds(setDoc(doc(as('u1'), 'users/u1/fcmTokens/tok-2'), { ...tok, token: 'tok-2' }));       // second device
    await assertFails(setDoc(doc(as('u1'), 'users/u1/fcmTokens/tok-3'), { ...tok, token: 'other' }));            // id != token
    await assertFails(setDoc(doc(as('u1'), 'users/u1/fcmTokens/tok-4'), { ...tok, token: 'tok-4', isAdmin: true })); // unknown field
    await assertFails(setDoc(doc(as('u2'), 'users/u1/fcmTokens/tok-5'), { ...tok, token: 'tok-5' }));            // someone else's device list
    await assertFails(getDoc(doc(as('u2'), 'users/u1/fcmTokens/tok-1')));
    await assertSucceeds(deleteDoc(doc(as('u1'), 'users/u1/fcmTokens/tok-2')));
  });
  it('preferences: own doc only, booleans only, known keys only', async () => {
    await assertSucceeds(setDoc(doc(as('u1'), 'notificationPrefs/u1'), { orders: true, wishlist: false, push: false, updatedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as('u1'), 'notificationPrefs/u1'), { orders: 'no', updatedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as('u1'), 'notificationPrefs/u1'), { admin: true, hacker: true, updatedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as('u2'), 'notificationPrefs/u1'), { orders: false, updatedAt: serverTimestamp() }));
    await assertFails(getDoc(doc(as('u2'), 'notificationPrefs/u1')));
  });
  it('notifications: nobody (not even admins) can create; owner reads/marks read/deletes; others cannot read', async () => {
    await roles(); await seed(async (d) => { await setDoc(doc(d, 'notifications/n1'), { userId: 'u1', title: 't', body: 'b', read: false, type: 'x' }); await setDoc(doc(d, 'notifications/n2'), { userId: 'u2', title: 't', read: false }); });
    await assertFails(setDoc(doc(as('sup'), 'notifications/forged'), { userId: 'u1', title: 'You won', read: false }));
    await assertFails(setDoc(doc(as('u1'), 'notifications/forged2'), { userId: 'u1', title: 'self', read: false }));
    await assertSucceeds(getDoc(doc(as('u1'), 'notifications/n1'))); await assertFails(getDoc(doc(as('u1'), 'notifications/n2'))); await assertFails(getDoc(doc(as('adm'), 'notifications/n1')));
    await assertSucceeds(updateDoc(doc(as('u1'), 'notifications/n1'), { read: true, readAt: serverTimestamp() }));
    await assertFails(updateDoc(doc(as('u1'), 'notifications/n1'), { link: '/admin' }));
    await assertFails(deleteDoc(doc(as('u2'), 'notifications/n1'))); await assertSucceeds(deleteDoc(doc(as('u1'), 'notifications/n1')));
  });
  it('a seller only ever sees notifications addressed to them', async () => {
    await roles(); await seed(async (d) => { await setDoc(doc(d, 'notifications/a'), { userId: 'sellerA', title: 'order', read: false }); await setDoc(doc(d, 'notifications/b'), { userId: 'sellerB', title: 'order', read: false }); });
    await assertSucceeds(getDoc(doc(as('sellerA'), 'notifications/a'))); await assertFails(getDoc(doc(as('sellerA'), 'notifications/b')));
  });
});

describe('privacy hardening (audit fixes)', () => {
  it('the social graph is private: you see follows you made or that point at you', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'follows/u1_sellerA'), { followerId: 'u1', followingId: 'sellerA' }));
    await assertSucceeds(getDoc(doc(as('u1'), 'follows/u1_sellerA'))); await assertSucceeds(getDoc(doc(as('sellerA'), 'follows/u1_sellerA')));
    await assertFails(getDoc(doc(as('u2'), 'follows/u1_sellerA'))); await assertSucceeds(getDoc(doc(as('adm'), 'follows/u1_sellerA')));
  });
  it('commission lives in admin-only storeFinance: public cannot read, seller reads own, nobody but admins writes', async () => {
    await roles(); await seed(async (d) => { await setDoc(doc(d, 'stores/st1'), { ownerId: 'sellerA', status: 'approved', name: 'A', slug: 'a', shippingFee: 0 }); await setDoc(doc(d, 'storeFinance/st1'), { commissionRate: 12 }); });
    await assertFails(getDoc(doc(anon(), 'storeFinance/st1'))); await assertFails(getDoc(doc(as('sellerB'), 'storeFinance/st1')));
    await assertSucceeds(getDoc(doc(as('sellerA'), 'storeFinance/st1'))); await assertSucceeds(getDoc(doc(as('adm'), 'storeFinance/st1')));
    await assertFails(setDoc(doc(as('sellerA'), 'storeFinance/st1'), { commissionRate: 0, updatedAt: serverTimestamp() }));
    await assertSucceeds(setDoc(doc(as('adm'), 'storeFinance/st1'), { commissionRate: 15, updatedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as('adm'), 'storeFinance/st1'), { commissionRate: 99, updatedAt: serverTimestamp() }));
  });
  it('a seller cannot rewrite their own earnings, balance or withdrawals even as a "seller" (money is function-only)', async () => {
    await roles();
    await assertFails(setDoc(doc(as('sellerA'), 'sellerEarnings/x'), { sellerId: 'sellerA', sellerAmount: 1e6, status: 'available' }));
    await assertFails(setDoc(doc(as('sellerA'), 'sellerBalances/sellerA'), { available: 1e6 }));
    await assertFails(setDoc(doc(as('sellerA'), 'withdrawals/w'), { sellerId: 'sellerA', amount: 1e6, status: 'completed' }));
  });
});

// ---------------- Phase 9: suspension + COD remittance ----------------
describe('suspension & COD (final audit fixes)', () => {
  it('a suspended account is refused on verified()-gated writes immediately, others are unaffected', async () => {
    await seed(async (d) => { await setDoc(doc(d, 'users/bad'), { email: 'b@b.co', status: 'suspended' }); await setDoc(doc(d, 'users/ok'), { email: 'o@o.co', status: 'active' });
      await setDoc(doc(d, 'stores/st1'), { ownerId: 'sellerX', status: 'approved', name: 'S', slug: 's', shippingFee: 0 }); });
    const conv = (b: string) => ({ buyerId: b, sellerId: 'sellerX', storeId: 'st1', participants: [b, 'sellerX'], unread: { [b]: 0, sellerX: 0 }, blockedBy: [], createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
    await assertFails(setDoc(doc(as('bad'), 'conversations/bad_st1'), conv('bad')));
    await assertSucceeds(setDoc(doc(as('ok'), 'conversations/ok_st1'), conv('ok')));
    await assertSucceeds(setDoc(doc(as('newuser'), 'conversations/newuser_st1'), conv('newuser')));   // no users doc yet: not treated as suspended
  });
  it('sellers cannot touch the COD remittance flag', async () => {
    await roles(); await seed((d) => setDoc(doc(d, 'orders/o1'), { buyerId: 'buyer', sellerId: 'sellerA', status: 'delivered', paymentMethod: 'cod', total: 10 }));
    await assertFails(updateDoc(doc(as('sellerA'), 'orders/o1'), { codRemitted: true }));
    await assertFails(updateDoc(doc(as('buyer'), 'orders/o1'), { codRemitted: true }));
  });
});
