# Android (Trusted Web Activity)

ShopVerse ships as a **PWA first**; the Android app is a thin Trusted Web Activity (TWA) around the production site.
No Android source is stored here — Bubblewrap generates it from `twa-manifest.json`, so there is nothing to keep in sync and no extra permissions.
See **DEPLOYMENT.md → Android packaging** for the exact steps (package id `com.aistudio.shopverse.mktplc`).
Keystores, passwords and `google-services.json` must never be committed.
