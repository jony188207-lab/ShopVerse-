import { redirect } from 'next/navigation';
// Spec-compatible alias: /chat/<conversationId> -> the real thread route.
export default function ChatAlias({ params }: { params: { id: string } }) { redirect(`/messages/${encodeURIComponent(params.id)}`); }
