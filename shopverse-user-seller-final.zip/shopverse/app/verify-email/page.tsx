'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/hooks/useAuth';
import { refreshVerification, resendVerification } from '@/services/authService';
import { friendlyError } from '@/lib/firebase/errors';

function VerifyInner() {
  const { user, refresh } = useAuth();
  const router = useRouter();
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const wrap = (fn: () => Promise<void>) => async () => {
    setBusy(true); setMsg('');
    try { await fn(); } catch (e) { setMsg(friendlyError(e)); } finally { setBusy(false); }
  };
  return (
    <div className="mx-auto max-w-sm space-y-4 px-4 py-8">
      <h1 className="text-2xl font-extrabold">Verify your email</h1>
      <p>We sent a confirmation link to <strong>{user?.email}</strong>. Open it, then come back and continue.</p>
      <Button className="w-full" loading={busy} onClick={wrap(async () => {
        if (await refreshVerification()) { await refresh(); router.replace('/profile'); } else setMsg('Not verified yet. Open the link in your email first.');
      })}>I&apos;ve verified — continue</Button>
      <Button variant="ghost" className="w-full" disabled={busy} onClick={wrap(async () => { await resendVerification(); setMsg('Verification email sent.'); })}>Resend email</Button>
      {msg ? <p role="status" className="text-sm">{msg}</p> : null}
    </div>
  );
}
export default function VerifyEmailPage() { return <AuthGuard><VerifyInner /></AuthGuard>; }
