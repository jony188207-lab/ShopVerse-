'use client';
import Link from 'next/link';
import { TopBannerCarousel } from '@/components/TopBannerCarousel';
import { SearchBar } from '@/components/SearchBar';
import { useCategories } from '@/hooks/useCategories';
import { getFeatured, getFlashSale, getNewArrivals, getPopular } from '@/services/productService';
import { LazyMount, ProductRail, Section, EmptyRail } from '@/components/home/Rail';
import { StoresRail } from '@/components/home/StoresRail';
import { RecentRails } from '@/components/home/RecentRails';

export default function HomePage() {
  const { categories } = useCategories();
  return (
    <div className="space-y-6">
      <div className="px-4 md:hidden"><SearchBar /></div>
      <TopBannerCarousel />
      <Section title="Categories">
        <ul className="flex gap-2 overflow-x-auto pb-2 md:flex-wrap">
          {categories.map((c) => (
            <li key={c.id} className="shrink-0"><Link href={`/category/${c.id}`} className="block rounded-full border border-navy-100 px-4 py-2 text-sm font-medium hover:border-brand-purple dark:border-navy-500">{c.name}</Link></li>
          ))}
        </ul>
      </Section>
      <ProductRail title="Flash sale" href="/shop" fetcher={() => getFlashSale(12)} empty="No flash sales are running right now." />
      <LazyMount eager><ProductRail title="Featured products" href="/shop" fetcher={() => getFeatured(12)} empty="No featured products yet." /></LazyMount>
      <LazyMount><ProductRail title="Popular products" href="/shop?sort=popular" fetcher={() => getPopular(12)} empty="Best sellers appear here after the first orders." /></LazyMount>
      <LazyMount><ProductRail title="New arrivals" href="/shop" fetcher={() => getNewArrivals(12)} empty="No products have been published yet." /></LazyMount>
      <LazyMount><RecentRails /></LazyMount>
      <LazyMount>
        <Section title="Product videos"><EmptyRail text="Shoppable videos arrive in the video phase." /></Section>
      </LazyMount>
      <LazyMount><StoresRail /></LazyMount>
    </div>
  );
}
