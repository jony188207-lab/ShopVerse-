'use client';
import { Suspense, useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { ApplicationAfterSignupError, signUp, signUpSeller } from '@/services/authService';
import { toStoreSlug } from '@/services/sellerService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';
import { textareaCls } from '@/components/seller/ui';

type Kind = 'customer' | 'seller';
const EMPTY = { name: '', email: '', password: '', confirm: '', storeName: '', slug: '', phone: '', country: '', city: '', address: '', description: '', returnPolicy: '', shippingInfo: '' };

function SignupForm() {
  const router = useRouter();
  const [kind, setKind] = useState<Kind>(useSearchParams().get('as') === 'seller' ? 'seller' : 'customer');
  const [f, setF] = useState(EMPTY);
  const [slugTouched, setSlugTouched] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof EMPTY) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setF((x) => ({ ...x, [k]: e.target.value, ...(k === 'storeName' && !slugTouched ? { slug: toStoreSlug(e.target.value) } : {}) }));
  const seller = kind === 'seller';

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return; // no duplicate submissions
    setError('');
    if (f.password.length < 8) return setError('Use a password with at least 8 characters.');
    if (f.password !== f.confirm) return setError('Passwords do not match.');
    setBusy(true);
    try {
      if (seller) {
        await signUpSeller({ email: f.email, password: f.password, app: { ownerName: f.name.trim(), storeName: f.storeName, slug: f.slug, phone: f.phone, email: f.email, country: f.country, city: f.city, address: f.address, description: f.description, returnPolicy: f.returnPolicy, shippingInfo: f.shippingInfo } });
      } else await signUp({ email: f.email, password: f.password, displayName: f.name });
      router.replace('/verify-email');
    } catch (err) {
      if (err instanceof ApplicationAfterSignupError) { router.replace('/become-seller'); return; }
      setError(err instanceof Error && !('code' in err) ? err.message : friendlyError(err));
    } finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="mx-auto max-w-lg space-y-4 px-4 py-8 animate-fade-up motion-reduce:animate-none" aria-busy={busy}>
      <h1 className="text-2xl font-extrabold">Create your account</h1>
      <div role="tablist" aria-label="Account type" className="grid grid-cols-2 gap-1 rounded-xl bg-navy-50 p-1 dark:bg-navy-700">
        {(['customer', 'seller'] as const).map((k) => (
          <button key={k} type="button" role="tab" aria-selected={kind === k} onClick={() => setKind(k)}
            className={`min-h-11 rounded-lg text-sm font-semibold ${kind === k ? 'bg-white text-navy-900 shadow dark:bg-navy-900 dark:text-white' : 'text-navy-500 dark:text-navy-100'}`}>
            {k === 'customer' ? 'Sign up as Customer' : 'Sign up as Seller'}
          </button>
        ))}
      </div>
      {seller ? <p className="rounded-xl bg-navy-50 p-3 text-sm dark:bg-navy-700">Your seller application starts as <strong>Pending</strong>. You can shop right away; Seller Center opens after ShopVerse approves your store and you have verified your email.</p> : null}

      <Field label={seller ? 'Owner name' : 'Name'} autoComplete="name" required minLength={2} maxLength={60} value={f.name} onChange={set('name')} />
      <Field label="Email" type="email" autoComplete="email" required value={f.email} onChange={set('email')} />
      <Field label="Password" type="password" autoComplete="new-password" required minLength={8} value={f.password} onChange={set('password')} />
      <Field label="Confirm password" type="password" autoComplete="new-password" required value={f.confirm} onChange={set('confirm')} />

      {seller ? (
        <fieldset className="space-y-3 border-t border-navy-100 pt-4 dark:border-navy-500">
          <legend className="text-lg font-bold">Your store</legend>
          <Field label="Store name" required minLength={2} maxLength={80} value={f.storeName} onChange={set('storeName')} />
          <Field label="Store slug (shopverse.com/store/…)" required minLength={3} maxLength={40} pattern="[a-z0-9]+(-[a-z0-9]+)*" value={f.slug} onChange={(e) => { setSlugTouched(true); setF({ ...f, slug: toStoreSlug(e.target.value) }); }} />
          <Field label="Phone" type="tel" autoComplete="tel" required minLength={5} maxLength={25} value={f.phone} onChange={set('phone')} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Country" required minLength={2} maxLength={60} value={f.country} onChange={set('country')} />
            <Field label="City" required maxLength={80} value={f.city} onChange={set('city')} />
          </div>
          <Field label="Address" autoComplete="street-address" required minLength={3} maxLength={300} value={f.address} onChange={set('address')} />
          <div><label htmlFor="sd" className="text-sm font-medium">Store description</label><textarea id="sd" rows={3} maxLength={2000} value={f.description} onChange={set('description')} className={textareaCls} /></div>
          <div><label htmlFor="rp" className="text-sm font-medium">Return policy</label><textarea id="rp" rows={2} maxLength={2000} value={f.returnPolicy} onChange={set('returnPolicy')} className={textareaCls} /></div>
          <div><label htmlFor="si" className="text-sm font-medium">Shipping information</label><textarea id="si" rows={2} maxLength={2000} value={f.shippingInfo} onChange={set('shippingInfo')} className={textareaCls} /></div>
        </fieldset>
      ) : null}

      {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
      <Button type="submit" loading={busy} className="w-full">{seller ? 'Create account & apply' : 'Create account'}</Button>
      <p className="text-sm">Already have an account? <Link className="font-semibold text-brand-purple underline" href="/login">Sign in</Link></p>
    </form>
  );
}
export default function SignupPage() { return <Suspense fallback={null}><SignupForm /></Suspense>; }
