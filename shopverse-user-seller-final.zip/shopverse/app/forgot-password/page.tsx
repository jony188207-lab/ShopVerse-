'use client';
import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { requestPasswordReset } from '@/services/authService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(''); setBusy(true);
    try { await requestPasswordReset(email); } catch (err) {
      // Don't reveal whether an account exists; only surface non-enumeration errors.
      const msg = friendlyError(err);
      if (!/incorrect|exists/i.test(msg)) { setError(msg); setBusy(false); return; }
    }
    setSent(true); setBusy(false);
  };
  return (
    <div className="mx-auto max-w-sm animate-fade-up space-y-4 px-4 py-8 motion-reduce:animate-none">
      <h1 className="text-2xl font-extrabold">Reset your password</h1>
      {sent ? (
        <p role="status">If an account exists for {email}, a reset link is on its way. The link opens Firebase&apos;s secure page where you choose a new password.</p>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <Field label="Email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
          <Button type="submit" loading={busy} className="w-full">Send reset link</Button>
        </form>
      )}
      <p className="text-sm"><Link className="text-brand-purple underline" href="/login">Back to sign in</Link></p>
    </div>
  );
}
