'use client';
import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { login } from '@/services/authService';
import { friendlyError } from '@/lib/firebase/errors';
import { safeNextPath } from '@/utils/schedule';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      await login(email, password);
      router.replace(safeNextPath(new URLSearchParams(window.location.search).get('next')));
    } catch (err) { setError(friendlyError(err)); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="mx-auto max-w-sm space-y-4 px-4 py-8 animate-fade-up motion-reduce:animate-none" aria-busy={busy}>
      <h1 className="text-2xl font-extrabold">Sign in</h1>
      <Field label="Email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
      <Field label="Password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
      <Button type="submit" loading={busy} className="w-full">Sign in</Button>
      <p className="text-sm"><Link className="text-brand-purple underline" href="/forgot-password">Forgot password?</Link></p>
      <p className="text-sm">New to ShopVerse? <Link className="font-semibold text-brand-purple underline" href="/signup">Create an account</Link></p>
    </form>
  );
}
