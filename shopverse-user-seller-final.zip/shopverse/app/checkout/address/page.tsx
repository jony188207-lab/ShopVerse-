'use client';
import { useRouter } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { AddressManager } from '@/components/AddressManager';

export default function CheckoutAddressPage() {
  const router = useRouter();
  return (
    <AuthGuard requireVerified>
      <div className="mx-auto max-w-lg space-y-4 px-4">
        <p className="text-sm font-semibold text-brand-purple">Step 1 of 4 · Address</p>
        <h1 className="text-2xl font-extrabold">Where should we deliver?</h1>
        <AddressManager onSelect={(a) => router.push(`/checkout?address=${encodeURIComponent(a.id)}`)} />
      </div>
    </AuthGuard>
  );
}
