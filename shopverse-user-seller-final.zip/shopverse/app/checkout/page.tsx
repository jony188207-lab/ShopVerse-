'use client';
import { Suspense, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter, useSearchParams } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/hooks/useToast';
import { listAddresses } from '@/services/addressService';
import { placeOrder, previewCoupon, type CouponPreview } from '@/services/orderService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { ErrorState, LoadingState } from '@/components/ui/States';
import { OrderSummary } from '../cart/page';
import { formatMoney } from '@/utils/money';
import type { Address } from '@/types';

type Step = 'delivery' | 'payment' | 'review';
const STEPS: { id: Step; label: string }[] = [{ id: 'delivery', label: 'Delivery' }, { id: 'payment', label: 'Payment' }, { id: 'review', label: 'Review' }];

/** One id per checkout attempt, kept in sessionStorage: retries/double-taps/reloads replay the SAME server-side order instead of creating another. */
function checkoutId(): string {
  try {
    const k = 'sv-checkout-id'; const ex = sessionStorage.getItem(k);
    if (ex) return ex;
    const id = crypto.randomUUID().replace(/-/g, ''); sessionStorage.setItem(k, id); return id;
  } catch { return crypto.randomUUID().replace(/-/g, ''); }
}
const clearCheckoutId = () => { try { sessionStorage.removeItem('sv-checkout-id'); } catch { /* ignore */ } };

function Inner() {
  const params = useSearchParams(); const router = useRouter(); const toast = useToast();
  const { user } = useAuth();
  const { lines, summary, loading, refresh } = useCart();
  const [address, setAddress] = useState<Address | null | undefined>(undefined);
  const [step, setStep] = useState<Step>('delivery');
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState('');
  const [codeInput, setCodeInput] = useState('');
  const [coupon, setCoupon] = useState<CouponPreview | null>(null);
  const [couponBusy, setCouponBusy] = useState(false);
  const inFlight = useRef(false);
  const addressId = params.get('address');

  useEffect(() => { void refresh(true); }, [refresh]);
  useEffect(() => {
    if (!user || !addressId) { setAddress(null); return; }
    listAddresses(user.uid).then((l) => setAddress(l.find((a) => a.id === addressId) ?? null)).catch(() => setAddress(null));
  }, [user, addressId]);

  if (address === undefined || (loading && !lines.length)) return <LoadingState />;
  if (!address) return <ErrorState title="Choose a delivery address" action={<Link href="/checkout/address" className="font-semibold text-brand-purple underline">Select address</Link>} />;
  if (!lines.length) return <ErrorState title="Your cart is empty" action={<Link href="/shop" className="font-semibold text-brand-purple underline">Keep shopping</Link>} />;

  const place = async () => {
    if (inFlight.current) return; // blocks double taps before state updates
    inFlight.current = true; setPlacing(true); setError('');
    try {
      const r = await placeOrder({ checkoutId: checkoutId(), addressId: address.id, ...(coupon ? { couponCode: coupon.code } : {}) });
      clearCheckoutId(); await refresh(true);
      toast('Order placed', 'success');
      router.replace(r.orderIds.length === 1 ? `/orders/${r.orderIds[0]}` : '/orders');
    } catch (e) { setError(friendlyError(e)); void refresh(true); } finally { inFlight.current = false; setPlacing(false); }
  };
  const applyCode = async () => {
    setCouponBusy(true); setError('');
    try { setCoupon(await previewCoupon(codeInput)); } catch (e) { setCoupon(null); setError(friendlyError(e)); } finally { setCouponBusy(false); }
  };
  const idx = STEPS.findIndex((s) => s.id === step);
  return (
    <div className="mx-auto grid max-w-5xl gap-6 px-4 lg:grid-cols-[1fr,22rem]">
      <div className="space-y-4">
        <p className="text-sm font-semibold text-brand-purple">Step {idx + 2} of 4 · {STEPS[idx].label}</p>
        <ol className="flex gap-2 text-sm" aria-label="Checkout progress">
          {STEPS.map((s, i) => <li key={s.id} aria-current={s.id === step ? 'step' : undefined} className={`rounded-full px-3 py-1 font-semibold ${i <= idx ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'bg-navy-50 dark:bg-navy-700'}`}>{s.label}</li>)}
        </ol>
        <Card className="text-sm"><div className="flex justify-between gap-2"><div><p className="font-semibold">Deliver to {address.fullName}</p><p>{address.address}, {address.city}, {address.country}</p><p>{address.phone}</p></div><Link href="/checkout/address" className="shrink-0 text-brand-purple underline">Change</Link></div></Card>

        {step === 'delivery' ? (
          <Card className="space-y-3"><h1 className="text-lg font-bold">Delivery method</h1>
            <label className="flex items-start gap-3 rounded-xl border border-brand-orange p-3"><input type="radio" checked readOnly className="mt-1 h-5 w-5" /><span className="text-sm"><strong>Standard delivery</strong><br />Shipping is set by each seller: {summary.groups.map((g) => `${g.storeName} ${g.shipping > 0 ? formatMoney(g.shipping) : 'free'}`).join(' · ')}</span></label>
            <Button onClick={() => setStep('payment')}>Continue to payment</Button></Card>
        ) : null}
        {step === 'payment' ? (
          <Card className="space-y-3"><h1 className="text-lg font-bold">Payment</h1>
            <label className="flex items-start gap-3 rounded-xl border border-brand-orange p-3"><input type="radio" checked readOnly className="mt-1 h-5 w-5" /><span className="text-sm"><strong>Cash on delivery</strong><br />Pay the courier when your order arrives. Online payments are not available yet.</span></label>
            <div className="flex gap-2"><Button variant="ghost" onClick={() => setStep('delivery')}>Back</Button><Button onClick={() => setStep('review')}>Review order</Button></div></Card>
        ) : null}
        {step === 'review' ? (
          <Card className="space-y-4"><h1 className="text-lg font-bold">Review your order</h1>
            {summary.groups.map((g) => (
              <div key={g.sellerId} className="space-y-2"><p className="text-sm font-bold">{g.storeName}</p>
                <ul className="space-y-2">{g.lines.map((l) => (
                  <li key={l.item.id} className="flex gap-3 text-sm"><span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-navy-50 dark:bg-navy-900">{l.product?.images[0] ? <Image src={l.product.images[0]} alt="" fill sizes="56px" className="object-cover" /> : null}</span>
                    <span className="min-w-0 flex-1"><span className="line-clamp-1 font-medium">{l.product?.title}</span>{l.item.variantLabel ? <span className="block text-xs">{l.item.variantLabel}</span> : null}<span className="text-xs">Qty {l.item.quantity}</span></span>
                    <span className="font-semibold">{formatMoney(l.unitPrice * l.item.quantity)}</span></li>))}</ul></div>
            ))}
            <div className="space-y-2">
              <label htmlFor="coupon" className="text-sm font-medium">Coupon code (optional)</label>
              <div className="flex gap-2">
                <input id="coupon" value={codeInput} onChange={(e) => { setCodeInput(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '')); setCoupon(null); }} maxLength={20} disabled={placing}
                  className="min-h-11 flex-1 rounded-xl border border-navy-100 bg-white px-3 text-base text-navy-900 dark:border-navy-500 dark:bg-navy-900 dark:text-white" />
                <Button variant="secondary" onClick={applyCode} loading={couponBusy} disabled={placing || codeInput.length < 3}>Apply</Button>
              </div>
              {coupon ? <p role="status" className="text-sm text-green-700 dark:text-green-400">{coupon.code} applied: −{formatMoney(coupon.discount)} ({coupon.stores.map((s) => s.storeName).join(', ')})</p> : null}
            </div>
            <p className="text-sm">Payment: <strong>Cash on delivery</strong> · Delivery: <strong>Standard</strong></p>
            {summary.blocked ? <p role="alert" className="text-sm text-red-600">Some items changed. <Link href="/cart" className="underline">Review your cart</Link> before placing the order.</p> : null}
            {error ? <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700 dark:bg-red-950 dark:text-red-200">{error} <Link href="/cart" className="font-semibold underline">Open cart</Link></p> : null}
            <div className="flex gap-2"><Button variant="ghost" onClick={() => setStep('payment')} disabled={placing}>Back</Button><Button onClick={place} loading={placing} disabled={summary.blocked}>Place order · {formatMoney(Math.max(0, summary.total - (coupon?.discount ?? 0)))}</Button></div>
          </Card>
        ) : null}
      </div>
      <aside className="h-fit space-y-3 rounded-card border border-navy-100 p-4 dark:border-navy-500 lg:sticky lg:top-24"><h2 className="text-lg font-bold">Order summary</h2><OrderSummary s={summary} /></aside>
    </div>
  );
}
export default function CheckoutPage() { return <AuthGuard requireVerified><Suspense fallback={<LoadingState />}><Inner /></Suspense></AuthGuard>; }
