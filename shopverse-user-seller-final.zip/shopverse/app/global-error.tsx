'use client';
export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en"><body style={{ fontFamily: 'system-ui, sans-serif', padding: '4rem 1rem', textAlign: 'center' }}>
      <h1>ShopVerse hit a problem</h1><p>Please reload the page.</p><button onClick={reset} style={{ minHeight: 44, padding: '0 20px' }}>Reload</button>
    </body></html>
  );
}
