import Link from 'next/link';
export const metadata = { title: 'Page not found', robots: { index: false } };
export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-20 text-center">
      <h1 className="text-2xl font-extrabold">Page not found</h1>
      <p className="text-sm text-navy-500 dark:text-navy-100">The page you are looking for does not exist or was moved.</p>
      <Link href="/shop" className="inline-flex min-h-11 items-center rounded-xl bg-brand-orange px-5 text-sm font-semibold text-white">Browse the shop</Link>
    </div>
  );
}
