import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

/**
 * Digital Asset Links for the Android Trusted Web Activity, served at /.well-known/assetlinks.json (see rewrites in next.config.mjs).
 * Fingerprints are PUBLIC certificate hashes, supplied by env so nothing is committed:
 *   ANDROID_PACKAGE_NAME   default com.aistudio.shopverse.mktplc
 *   ANDROID_CERT_SHA256    comma-separated SHA-256 fingerprints (Play App Signing key AND your upload key)
 * Without fingerprints it returns [] (valid JSON, no association) rather than a fake value.
 */
export function GET() {
  const pkg = process.env.ANDROID_PACKAGE_NAME || 'com.aistudio.shopverse.mktplc';
  const prints = (process.env.ANDROID_CERT_SHA256 || '').split(',').map((s) => s.trim().toUpperCase()).filter((s) => /^([0-9A-F]{2}:){31}[0-9A-F]{2}$/.test(s));
  const body = prints.length ? [{ relation: ['delegate_permission/common.handle_all_urls'], target: { namespace: 'android_app', package_name: pkg, sha256_cert_fingerprints: prints } }] : [];
  return NextResponse.json(body, { headers: { 'Cache-Control': 'public, max-age=3600' } });
}
