'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useParams, useRouter } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { ReviewForm } from '@/components/ReviewForm';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/hooks/useToast';
import { cancelOrder, getOrder, getOrderItems, requestReturn } from '@/services/orderService';
import { getProduct } from '@/services/productService';
import { addToCart } from '@/services/cartService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { formatMoney } from '@/utils/money';
import { RETURN_WINDOW_DAYS } from '@/config/site';
import { ORDER_STATUS_LABEL, type Order, type OrderItem } from '@/types';
import { StatusBadge } from '../page';

const NOTE: Partial<Record<Order['status'], string>> = {
  return_requested: 'Your return request was sent to the seller. We will update this page when it is reviewed.',
  returned: 'The return was received. A refund will be shown here once it is processed.',
  refunded: 'This order was refunded.',
  cancelled: 'This order was cancelled.',
};

function Inner() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { refresh } = useCart();
  const toast = useToast();
  const router = useRouter();
  const [order, setOrder] = useState<Order | null | undefined>(undefined);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [busy, setBusy] = useState('');
  const [returning, setReturning] = useState(false);
  const [reason, setReason] = useState('');

  const load = useCallback(async () => {
    if (!user) return;
    const o = await getOrder(id, user.uid);
    setOrder(o);
    if (o) setItems(await getOrderItems(o.id, user.uid));
  }, [id, user]);
  useEffect(() => { void load(); }, [load]);

  if (order === undefined) return <LoadingState />;
  if (!order) return <EmptyState title="Order not found">It may belong to another account.</EmptyState>;

  const returnOpen = order.status === 'delivered' && Date.now() - (order.deliveredAt ?? order.createdAt ?? new Date(0)).getTime() <= RETURN_WINDOW_DAYS * 86_400_000;
  const run = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try { await fn(); toast(ok, 'success'); await new Promise((r) => setTimeout(r, 1200)); await load(); /* status timeline is written by a trigger */ }
    catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(''); }
  };
  const buyAgain = async () => {
    if (!user) return;
    setBusy('again'); let added = 0; let skipped = 0;
    for (const it of items) {
      const p = await getProduct(it.productId);
      const vk = it.variantKey === 'default' ? undefined : it.variantKey;
      try { if (p && p.status === 'approved') { await addToCart(user.uid, p, vk, it.quantity); added++; } else skipped++; } catch { skipped++; }
    }
    await refresh(true); setBusy('');
    toast(added ? `Added ${added} item${added > 1 ? 's' : ''} to your cart${skipped ? ` (${skipped} unavailable)` : ''}` : 'These items are no longer available', added ? 'success' : 'error');
    if (added) router.push('/cart');
  };
  const a = order.address;
  return (
    <div className="mx-auto max-w-2xl space-y-4 px-4">
      <div className="flex items-start justify-between gap-2"><div><h1 className="text-2xl font-extrabold">{order.orderNumber}</h1><p className="text-sm text-navy-500 dark:text-navy-100">Placed {order.createdAt?.toLocaleString()} · {order.storeName}</p></div><StatusBadge status={order.status} /></div>
      {NOTE[order.status] ? <p role="status" className="rounded-xl bg-navy-50 p-3 text-sm dark:bg-navy-700">{NOTE[order.status]}</p> : null}

      <Card className="space-y-3"><h2 className="font-bold">Items</h2>
        <ul className="space-y-4">{items.map((it) => (
          <li key={it.id} className="space-y-2"><div className="flex gap-3"><Link href={`/product/${it.productId}`} className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-navy-50 dark:bg-navy-900">{it.image ? <Image src={it.image} alt="" fill sizes="64px" className="object-cover" /> : null}</Link>
            <div className="min-w-0 flex-1 text-sm"><p className="line-clamp-2 font-medium">{it.title}</p>{it.variantLabel ? <p className="text-xs">{it.variantLabel}</p> : null}<p>{it.quantity} × {formatMoney(it.unitPrice)}</p></div><p className="text-sm font-bold">{formatMoney(it.lineTotal)}</p></div>
            {it.status === 'delivered' ? <ReviewForm item={it} /> : null}</li>))}</ul></Card>

      <Card className="text-sm"><dl className="space-y-1">
        <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatMoney(order.subtotal)}</dd></div>
        {order.couponDiscount ? <div className="flex justify-between text-green-700 dark:text-green-400"><dt>Coupon {order.couponCode}</dt><dd>−{formatMoney(order.couponDiscount)}</dd></div> : null}
        <div className="flex justify-between"><dt>Shipping</dt><dd>{order.shipping > 0 ? formatMoney(order.shipping) : 'Free'}</dd></div>
        <div className="flex justify-between border-t border-navy-100 pt-2 text-base font-extrabold dark:border-navy-500"><dt>Total</dt><dd>{formatMoney(order.total)}</dd></div>
        <div className="flex justify-between"><dt>Payment</dt><dd>Cash on delivery ({order.paymentStatus})</dd></div></dl></Card>

      <Card className="text-sm"><h2 className="mb-1 font-bold">Delivery address</h2><p>{a.fullName} · {a.phone}</p><p>{a.address}{a.area ? `, ${a.area}` : ''}, {a.city} {a.postalCode}, {a.country}</p>{a.instructions ? <p>Note: {a.instructions}</p> : null}</Card>

      <Card><h2 className="mb-2 font-bold">Order timeline</h2>
        <ol className="space-y-2 border-l-2 border-navy-100 pl-4 dark:border-navy-500">{order.timeline.map((t, i) => (
          <li key={i} className="relative text-sm"><span className={`absolute -left-[1.4rem] top-1.5 h-2.5 w-2.5 rounded-full ${i === order.timeline.length - 1 ? 'bg-brand-orange' : 'bg-navy-500'}`} /><strong>{ORDER_STATUS_LABEL[t.status] ?? t.status}</strong><span className="block text-xs text-navy-500 dark:text-navy-100">{t.at?.toLocaleString()}</span></li>))}</ol></Card>

      <div className="flex flex-wrap gap-2">
        {['pending', 'confirmed'].includes(order.status) ? <Button variant="danger" loading={busy === 'cancel'} onClick={() => { if (window.confirm('Cancel this order?')) void run('cancel', () => cancelOrder(order.id, 'Cancelled by buyer'), 'Order cancelled'); }}>Cancel order</Button> : null}
        {returnOpen && !returning ? <Button variant="secondary" onClick={() => setReturning(true)}>Request return</Button> : null}
        <Button variant="ghost" className="border border-navy-100 dark:border-navy-500" loading={busy === 'again'} onClick={buyAgain}>Buy again</Button>
        <Link href={`/messages/new?store=${order.storeId}&order=${order.id}`} className="inline-flex min-h-11 items-center rounded-xl border border-navy-100 px-4 text-sm font-semibold dark:border-navy-500">Message {order.storeName || 'seller'}</Link>
      </div>
      {returning ? (
        <Card className="space-y-2"><label htmlFor="rr" className="text-sm font-medium">Why are you returning this order?</label>
          <textarea id="rr" rows={3} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} className="w-full rounded-xl border border-navy-100 bg-white p-3 text-base text-navy-900 dark:border-navy-500 dark:bg-navy-900 dark:text-white" />
          <div className="flex gap-2"><Button loading={busy === 'return'} disabled={reason.trim().length < 5} onClick={() => run('return', () => requestReturn(order.id, reason), 'Return requested').then(() => setReturning(false))}>Send request</Button><Button variant="ghost" onClick={() => setReturning(false)}>Cancel</Button></div></Card>
      ) : null}
    </div>
  );
}
export default function OrderPage() { return <AuthGuard><Inner /></AuthGuard>; }
