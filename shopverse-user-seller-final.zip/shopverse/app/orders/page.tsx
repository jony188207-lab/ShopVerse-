'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { AuthGuard } from '@/components/AuthGuard';
import { useAuth } from '@/hooks/useAuth';
import { listOrders } from '@/services/orderService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { formatMoney } from '@/utils/money';
import { ORDER_STATUS_LABEL, type Order } from '@/types';

export function StatusBadge({ status }: { status: Order['status'] }) {
  const tone = status === 'delivered' ? 'bg-green-100 text-green-800' : status === 'cancelled' || status === 'refunded' || status === 'returned' ? 'bg-red-100 text-red-800' : 'bg-brand-purple/15 text-brand-purple';
  return <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${tone}`}>{ORDER_STATUS_LABEL[status] ?? status}</span>;
}

function Inner() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [cursor, setCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [more, setMore] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const load = useCallback(async (cur: QueryDocumentSnapshot | null) => {
    if (!user) return;
    setBusy(true); setError('');
    try { const p = await listOrders(user.uid, cur); setOrders((x) => (cur ? [...(x ?? []), ...p.items] : p.items)); setCursor(p.cursor); setMore(p.hasMore); }
    catch (e) { setError(friendlyError(e)); } finally { setBusy(false); }
  }, [user]);
  useEffect(() => { void load(null); }, [load]);

  if (error && !orders) return <ErrorState message={error} action={<Button onClick={() => load(null)}>Try again</Button>} />;
  if (!orders) return <LoadingState />;
  if (!orders.length) return <EmptyState title="No orders yet" action={<Link href="/shop" className="font-semibold text-brand-purple underline">Start shopping</Link>}>Your orders will appear here after checkout.</EmptyState>;
  return (
    <div className="mx-auto max-w-2xl space-y-3 px-4">
      <h1 className="text-2xl font-extrabold">Orders</h1>
      {orders.map((o) => (
        <Link key={o.id} href={`/orders/${o.id}`} className="block"><Card className="space-y-1 hover:border-brand-purple">
          <div className="flex items-center justify-between"><p className="font-bold">{o.orderNumber}</p><StatusBadge status={o.status} /></div>
          <p className="text-sm">{o.storeName} · {o.itemCount} item{o.itemCount > 1 ? 's' : ''}</p>
          <p className="text-sm text-navy-500 dark:text-navy-100">{o.createdAt?.toLocaleDateString()} · <strong>{formatMoney(o.total)}</strong> · Cash on delivery</p>
        </Card></Link>
      ))}
      {more ? <Button variant="secondary" loading={busy} onClick={() => load(cursor)}>Load more</Button> : null}
    </div>
  );
}
export default function OrdersPage() { return <AuthGuard><Inner /></AuthGuard>; }
