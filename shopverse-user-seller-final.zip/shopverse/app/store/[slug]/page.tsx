'use client';
import { Suspense, useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePaged } from '@/hooks/usePaged';
import { friendlyError } from '@/lib/firebase/errors';
import { follow, getStoreBySlug, isFollowing, listStoreReviews, unfollow } from '@/services/storeService';
import { listProducts } from '@/services/productService';
import { ProductGrid } from '@/components/ProductGrid';
import { ShopView } from '@/components/ShopView';
import { StarRating } from '@/components/StarRating';
import { Pill, fmtDate } from '@/components/seller/ui';
import { ReportButton } from '@/components/ReportButton';
import { Button } from '@/components/ui/Button';
import { EmptyState, LoadingState } from '@/components/ui/States';
import type { Store } from '@/types';

type Tab = 'products' | 'reviews' | 'about';

function Reviews({ ownerId }: { ownerId: string }) {
  const { items, more, busy, loadMore, error } = usePaged((c) => listStoreReviews(ownerId, c), [ownerId]);
  if (error) return <EmptyState title="Could not load reviews">{error}</EmptyState>;
  if (items === null) return <LoadingState />;
  if (!items.length) return <EmptyState title="No reviews yet">Verified buyers can review products after delivery.</EmptyState>;
  return (
    <div className="space-y-3 px-4">
      <ul className="space-y-3">{items.map((r) => (
        <li key={r.id} className="space-y-1 rounded-card border border-navy-100 p-3 dark:border-navy-500">
          <div className="flex flex-wrap items-center gap-2"><StarRating value={r.rating} />{r.verifiedPurchase ? <Pill status="approved" label="Verified purchase" /> : null}<span className="text-xs">{r.userName} · {fmtDate(r.createdAt)}</span></div>
          {r.text ? <p className="text-sm">{r.text}</p> : null}
          {r.sellerResponse ? <p className="rounded-lg bg-navy-50 p-2 text-sm dark:bg-navy-700"><strong>Seller response:</strong> {r.sellerResponse}</p> : null}
        </li>))}
      </ul>
      {more ? <Button variant="secondary" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}

export default function StorePage() {
  const { slug } = useParams<{ slug: string }>();
  const { user } = useAuth(); const toast = useToast(); const router = useRouter();
  const [store, setStore] = useState<Store | null | undefined>(undefined);
  const [hasFeatured, setHasFeatured] = useState(false);
  const [tab, setTab] = useState<Tab>('products');
  const [following, setFollowing] = useState<boolean | null>(null); const [busy, setBusy] = useState(false);
  useEffect(() => { getStoreBySlug(slug).then(setStore).catch(() => setStore(null)); }, [slug]);
  useEffect(() => { if (store) listProducts({ storeId: store.id, featured: true }, null, 1).then((p) => setHasFeatured(p.items.length > 0)).catch(() => setHasFeatured(false)); }, [store]);
  const own = !!store && user?.uid === store.ownerId;
  useEffect(() => { if (store && user && !own) isFollowing(user.uid, store.ownerId).then(setFollowing).catch(() => setFollowing(false)); else setFollowing(false); }, [store, user, own]);
  if (store === undefined) return <LoadingState />;
  if (!store) return <EmptyState title="Store not found">This store does not exist or is not open right now.</EmptyState>;
  const toggle = async () => {
    if (!user) return router.push(`/login?next=${encodeURIComponent(`/store/${slug}`)}`);
    setBusy(true);
    try { if (following) await unfollow(user.uid, store.ownerId); else await follow(user.uid, store.ownerId); setFollowing(!following); toast(following ? 'Unfollowed' : 'Following store', 'success'); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <div className="relative h-32 w-full overflow-hidden bg-gradient-to-r from-navy-700 to-brand-purple md:h-48 md:rounded-card">{store.bannerUrl ? <Image src={store.bannerUrl} alt="" fill priority sizes="100vw" className="object-cover" /> : null}</div>
      <header className="flex flex-wrap items-center gap-3 px-4">
        <div className="relative -mt-10 h-20 w-20 shrink-0 overflow-hidden rounded-full border-4 border-white bg-navy-100 dark:border-navy-900 dark:bg-navy-700">{store.logoUrl ? <Image src={store.logoUrl} alt="" fill sizes="80px" className="object-cover" /> : null}</div>
        <div className="min-w-0 flex-1"><h1 className="text-2xl font-extrabold">{store.name}</h1><StarRating value={store.ratingAvg} count={store.ratingCount} /><p className="text-sm text-navy-500 dark:text-navy-100">{store.followerCount} followers{store.city ? ` · ${store.city}${store.country ? `, ${store.country}` : ''}` : ''}</p></div>
        <div className="flex gap-2">
          {!own ? <Button variant="secondary" loading={busy} disabled={following === null} onClick={toggle}>{following ? 'Following' : 'Follow'}</Button> : null}
          {!own ? <Link href={user ? `/messages/new?store=${store.id}` : `/login?next=${encodeURIComponent(`/messages/new?store=${store.id}`)}`} className="inline-flex min-h-11 items-center rounded-xl border border-navy-100 px-4 text-sm font-semibold dark:border-navy-500">Message seller</Link> : null}
          {!own ? <ReportButton targetType="store" targetId={store.id} label="Report store" /> : null}
        </div>
      </header>
      {hasFeatured ? <section className="space-y-2 px-4"><h2 className="text-lg font-bold">Featured</h2><ProductGrid resetKey={store.id} fetchPage={(c) => listProducts({ storeId: store.id, featured: true }, c, 8)} emptyTitle="No featured products" /></section> : null}
      <div role="tablist" className="flex gap-1 px-4">{(['products', 'reviews', 'about'] as Tab[]).map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`rounded-lg px-4 py-2 text-sm font-semibold capitalize ${tab === t ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'hover:bg-navy-50 dark:hover:bg-navy-700'}`}>{t}</button>)}</div>
      {tab === 'products' ? <Suspense fallback={<LoadingState />}><ShopView storeId={store.id} /></Suspense> : null}
      {tab === 'reviews' ? <Reviews ownerId={store.ownerId} /> : null}
      {tab === 'about' ? (
        <div className="space-y-3 px-4 text-sm">
          {store.description ? <p>{store.description}</p> : null}
          <section><h2 className="font-semibold">Shipping</h2><p>{store.shippingInfo || 'Standard shipping.'} Fee per order: {store.shippingFee ? store.shippingFee.toFixed(2) : 'free'}{store.freeShippingOver ? ` (free over ${store.freeShippingOver.toFixed(2)})` : ''}.</p></section>
          <section><h2 className="font-semibold">Return policy</h2><p>{store.returnPolicy || 'See the product page.'}</p></section>
        </div>
      ) : null}
    </div>
  );
}
