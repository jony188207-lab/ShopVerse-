import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import { runPublicQuery } from '@/lib/firestoreRest';
import { SITE_URL } from '@/lib/siteUrl';

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const [s] = await runPublicQuery('stores', [['status', 'approved'], ['slug', params.slug]], { limit: 1, revalidate: 600 });
  if (!s) return { title: 'Store', robots: { index: false } };
  const desc = String(s.description ?? '').replace(/\s+/g, ' ').slice(0, 160) || `Shop ${s.name} on ShopVerse.`;
  return { title: String(s.name), description: desc, alternates: { canonical: `/store/${params.slug}` }, openGraph: { title: String(s.name), description: desc, url: `${SITE_URL}/store/${params.slug}`, ...(s.logoUrl ? { images: [{ url: String(s.logoUrl) }] } : {}) } };
}
export default function StoreLayout({ children }: { children: ReactNode }) { return children; }
