'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useCategories } from '@/hooks/useCategories';

export default function CategoriesPage() {
  const { categories, childrenOf } = useCategories();
  return (
    <div className="space-y-4 px-4">
      <h1 className="text-2xl font-extrabold">Categories</h1>
      <ul className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
        {categories.map((c) => (
          <li key={c.id} className="space-y-1">
            <Link href={`/category/${c.id}`} className="relative flex min-h-24 items-end overflow-hidden rounded-card border border-navy-100 p-4 text-base font-bold hover:border-brand-purple dark:border-navy-500">
              {c.imageUrl ? <Image src={c.imageUrl} alt="" fill sizes="(max-width: 768px) 50vw, 20vw" className="object-cover opacity-40" /> : null}
              <span className="relative">{c.name}</span>
            </Link>
            {childrenOf(c.id).length ? <p className="text-xs text-navy-500 dark:text-navy-100">{childrenOf(c.id).map((s) => s.name).join(' · ')}</p> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}
