'use client';
import { Suspense } from 'react';
import { useParams } from 'next/navigation';
import { ShopView } from '@/components/ShopView';
import { LoadingState, ErrorState } from '@/components/ui/States';
import { useCategories } from '@/hooks/useCategories';

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const { byId, loaded } = useCategories();
  if (!loaded && !byId(slug)) return <LoadingState />;
  if (!byId(slug)) return <ErrorState title="Category not found" message="Pick one from the categories page." />;
  return <Suspense fallback={<LoadingState />}><ShopView fixedCategory={slug} /></Suspense>;
}
