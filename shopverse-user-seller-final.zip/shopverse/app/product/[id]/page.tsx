import type { Metadata } from 'next';
import { ProductDetail } from '@/components/ProductDetail';
import { getPublicDoc } from '@/lib/firestoreRest';
import { SITE_URL } from '@/lib/siteUrl';

type Props = { params: { id: string } };
const clip = (s: unknown, n: number) => String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, n);

// Server-rendered metadata from the PUBLIC product doc (rules only expose approved / out-of-stock products, so private ones yield the generic title).
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getPublicDoc(`products/${encodeURIComponent(params.id)}`);
  if (!p || (p.status !== 'approved' && p.status !== 'out_of_stock')) return { title: 'Product', robots: { index: false } };
  const title = clip(p.title, 70); const desc = clip(p.description, 160) || `Buy ${title} on ShopVerse.`;
  const img = Array.isArray(p.images) ? (p.images[0] as string | undefined) : undefined;
  return { title, description: desc, alternates: { canonical: `/product/${params.id}` }, openGraph: { type: 'website', title, description: desc, url: `${SITE_URL}/product/${params.id}`, ...(img ? { images: [{ url: img }] } : {}) }, twitter: { card: img ? 'summary_large_image' : 'summary', title, description: desc } };
}

export default async function ProductPage({ params }: Props) {
  const p = await getPublicDoc(`products/${encodeURIComponent(params.id)}`);
  const ok = p && (p.status === 'approved' || p.status === 'out_of_stock');
  const ld = ok ? {
    '@context': 'https://schema.org', '@type': 'Product', name: clip(p.title, 150), description: clip(p.description, 500), sku: p.sku || undefined, brand: p.brand ? { '@type': 'Brand', name: p.brand } : undefined,
    image: Array.isArray(p.images) ? p.images.slice(0, 4) : undefined,
    offers: { '@type': 'Offer', price: Number(p.price), priceCurrency: 'USD', availability: p.status === 'approved' && Number(p.stock) > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock', url: `${SITE_URL}/product/${params.id}` },
    ...(Number(p.reviewCount) > 0 ? { aggregateRating: { '@type': 'AggregateRating', ratingValue: Number(p.rating), reviewCount: Number(p.reviewCount) } } : {}),
  } : null;
  return (
    <>
      {ld ? <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, '\\u003c') }} /> : null}
      <ProductDetail id={params.id} />
    </>
  );
}
