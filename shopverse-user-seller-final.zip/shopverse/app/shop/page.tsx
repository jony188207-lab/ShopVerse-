import { Suspense } from 'react';
import { ShopView } from '@/components/ShopView';
import { LoadingState } from '@/components/ui/States';
export const metadata = { title: 'Shop' };
export default function ShopPage() { return <Suspense fallback={<LoadingState />}><ShopView /></Suspense>; }
