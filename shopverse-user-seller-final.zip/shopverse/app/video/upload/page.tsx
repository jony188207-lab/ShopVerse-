'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState, type FormEvent } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { SellerProvider, useSeller } from '@/components/seller/SellerProvider';
import { PageHead, selectCls, textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';
import { useCategories } from '@/hooks/useCategories';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { listMyProducts } from '@/services/sellerService';
import { createVideo, type VideoUploadInput } from '@/services/videoService';
import type { Product } from '@/types';

function Form() {
  const { uid, store } = useSeller(); const toast = useToast(); const router = useRouter(); const { categories } = useCategories();
  const [f, setF] = useState<VideoUploadInput>({ title: '', description: '', hashtags: '', category: '', visibility: 'public', productIds: [] });
  const [video, setVideo] = useState<File | null>(null); const [thumb, setThumb] = useState<File | null>(null); const [products, setProducts] = useState<Product[]>([]);
  const [busy, setBusy] = useState(false); const [pct, setPct] = useState(0);
  useEffect(() => { listMyProducts(uid, 'approved', null, 100).then((p) => setProducts(p.items)).catch((e) => toast(friendlyError(e), 'error')); }, [uid]);
  const toggle = (id: string) => setF((x) => ({ ...x, productIds: x.productIds.includes(id) ? x.productIds.filter((p) => p !== id) : x.productIds.length >= 5 ? x.productIds : [...x.productIds, id] }));
  const go = async (submit: boolean) => {
    if (!video) return toast('Choose a video file', 'error');
    setBusy(true); setPct(0);
    try { await createVideo(uid, store.id, f, video, thumb, submit, setPct); toast(submit ? 'Submitted for review' : 'Draft saved', 'success'); router.push('/seller/videos'); }
    catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  const onSubmit = (e: FormEvent) => { e.preventDefault(); void go(true); };
  return (
    <div className="mx-auto max-w-2xl space-y-3 px-4">
      <PageHead title="Upload a video"><Link href="/seller/videos" className="text-sm font-semibold text-brand-purple underline">My videos</Link></PageHead>
      <p className="text-sm">Vertical videos up to 3 minutes (MP4, WebM or MOV, max 200 MB). Videos are reviewed before they appear in the feed.</p>
      <form onSubmit={onSubmit} className="grid gap-3 md:grid-cols-2">
        <div className="md:col-span-2"><label htmlFor="vf" className="text-sm font-medium">Video file</label><input id="vf" type="file" required accept="video/mp4,video/webm,video/quicktime" onChange={(e) => setVideo(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
        <div className="md:col-span-2"><label htmlFor="tf" className="text-sm font-medium">Thumbnail (optional — we grab a frame if you skip it)</label><input id="tf" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setThumb(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
        <div className="md:col-span-2"><Field label="Title" required minLength={2} maxLength={100} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
        <div className="md:col-span-2"><label htmlFor="vd" className="text-sm font-medium">Description</label><textarea id="vd" rows={3} maxLength={1000} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} className={textareaCls} /></div>
        <Field label="Hashtags (space or comma separated, max 10)" value={f.hashtags} onChange={(e) => setF({ ...f, hashtags: e.target.value })} />
        <label className="text-sm font-medium">Category<select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} className={`mt-1 w-full ${selectCls}`}><option value="">None</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
        <label className="text-sm font-medium">Visibility<select value={f.visibility} onChange={(e) => setF({ ...f, visibility: e.target.value as 'public' | 'private' })} className={`mt-1 w-full ${selectCls}`}><option value="public">Public (once approved)</option><option value="private">Private (only you)</option></select></label>
        <fieldset className="md:col-span-2"><legend className="text-sm font-medium">Link your approved products (up to 5) — they appear as Shop Now cards</legend>
          {!products.length ? <p className="text-sm">You have no approved products yet.</p> : <ul className="mt-1 max-h-48 divide-y divide-navy-100 overflow-y-auto rounded-xl border border-navy-100 dark:divide-navy-500 dark:border-navy-500">{products.map((p) => (
            <li key={p.id}><label className="flex min-h-11 items-center gap-2 px-3 text-sm"><input type="checkbox" className="h-5 w-5" checked={f.productIds.includes(p.id)} onChange={() => toggle(p.id)} /><span className="truncate">{p.title}</span></label></li>))}</ul>}
        </fieldset>
        {busy ? <div className="md:col-span-2" role="status"><div className="h-2 overflow-hidden rounded-full bg-navy-100"><div className="h-full bg-brand-orange transition-all" style={{ width: `${pct}%` }} /></div><p className="mt-1 text-xs">Uploading… {pct}% — keep this tab open</p></div> : null}
        <div className="flex flex-wrap gap-2 md:col-span-2"><Button type="submit" loading={busy}>Submit for review</Button><Button type="button" variant="ghost" disabled={busy} onClick={() => go(false)}>Save as draft</Button></div>
      </form>
    </div>
  );
}
export default function Page() { return <AuthGuard roles={['seller']} requireVerified><SellerProvider><Form /></SellerProvider></AuthGuard>; }
