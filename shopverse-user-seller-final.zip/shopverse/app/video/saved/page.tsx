'use client';
import Link from 'next/link';
import { AuthGuard } from '@/components/AuthGuard';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { usePaged } from '@/hooks/usePaged';
import { listSavedVideos } from '@/services/videoService';

function Inner() {
  const { user } = useAuth();
  const { items, more, error, busy, loadMore } = usePaged((c) => listSavedVideos(user!.uid, c), [user?.uid]);
  return (
    <div className="space-y-3 px-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">Saved videos</h1><Link href="/video" className="text-sm font-semibold text-brand-purple underline">Back to feed</Link></div>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No saved videos">Tap the bookmark on a video to keep it here.</EmptyState> : (
        <ul className="grid grid-cols-2 gap-3 md:grid-cols-4">{items.map((v) => (
          <li key={v.id}><Link href={`/video?v=${v.id}`} className="block space-y-1">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {v.thumbnailUrl ? <img src={v.thumbnailUrl} alt="" loading="lazy" className="aspect-[9/16] w-full rounded-card object-cover" /> : <div className="aspect-[9/16] w-full rounded-card bg-navy-100" />}
            <p className="line-clamp-2 text-sm font-semibold">{v.title}</p></Link></li>))}</ul>
      )}
      {more ? <Button variant="secondary" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
export default function Page() { return <AuthGuard><Inner /></AuthGuard>; }
