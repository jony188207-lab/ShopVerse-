import type { Metadata } from 'next';
import { Suspense } from 'react';
import { VideoFeed } from '@/components/video/VideoFeed';
import { LoadingState } from '@/components/ui/States';
import { getPublicDoc } from '@/lib/firestoreRest';
import { SITE_URL } from '@/lib/siteUrl';

type Props = { params: { id: string } };
// Shareable canonical URL for one video: the feed opens on it, and link previews use the (public) video doc.
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const v = await getPublicDoc(`videos/${encodeURIComponent(params.id)}`);
  if (!v || v.status !== 'published' || v.visibility !== 'public') return { title: 'Video', robots: { index: false } };
  const title = String(v.title ?? 'Video').slice(0, 70); const desc = String(v.description ?? '').replace(/\s+/g, ' ').slice(0, 160) || `Watch ${title} on ShopVerse.`;
  const img = typeof v.thumbnailUrl === 'string' && v.thumbnailUrl ? v.thumbnailUrl : undefined;
  return { title, description: desc, alternates: { canonical: `/video/${params.id}` }, openGraph: { type: 'video.other', title, description: desc, url: `${SITE_URL}/video/${params.id}`, ...(img ? { images: [{ url: img }] } : {}) }, twitter: { card: img ? 'summary_large_image' : 'summary', title, description: desc } };
}
export default function VideoById({ params }: Props) { return <Suspense fallback={<LoadingState />}><VideoFeed initialId={params.id} /></Suspense>; }
