import { Suspense } from 'react';
import { VideoFeed } from '@/components/video/VideoFeed';
import { LoadingState } from '@/components/ui/States';
export const metadata = { title: 'Video' };
export default function Page() { return <Suspense fallback={<LoadingState />}><VideoFeed /></Suspense>; }
