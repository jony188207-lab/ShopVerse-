import type { MetadataRoute } from 'next';
import { SITE_URL } from '@/lib/siteUrl';
export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/seller', '/cart', '/checkout', '/orders', '/profile', '/messages', '/notifications', '/login', '/signup', '/forgot-password', '/verify-email', '/become-seller', '/wishlist', '/video/upload', '/video/saved', '/api', '/offline'] }], sitemap: `${SITE_URL}/sitemap.xml` };
}
