'use client';
import Link from 'next/link';
import { useEffect } from 'react';

/** Route-level error boundary: a crash in one page shows a friendly retry, never a blank screen or a stack trace. */
export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error('route error', error.digest ?? '', error); }, [error]);
  return (
    <div role="alert" className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-20 text-center">
      <h1 className="text-2xl font-extrabold">Something went wrong</h1>
      <p className="text-sm text-navy-500 dark:text-navy-100">This page hit an unexpected problem. Your data is safe. Try again, or head back home.</p>
      <div className="flex gap-2"><button onClick={reset} className="min-h-11 rounded-xl bg-brand-orange px-5 text-sm font-semibold text-white">Try again</button><Link href="/" className="inline-flex min-h-11 items-center rounded-xl border border-navy-100 px-5 text-sm font-semibold dark:border-navy-500">Home</Link></div>
    </div>
  );
}
