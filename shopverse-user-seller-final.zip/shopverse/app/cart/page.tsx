'use client';
import Link from 'next/link';
import Image from 'next/image';
import { useEffect } from 'react';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { AuthGuard } from '@/components/AuthGuard';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { formatMoney } from '@/utils/money';
import type { LineProblem } from '@/utils/cartMath';

const PROBLEM: Record<LineProblem, string> = {
  missing: 'This item is no longer available.', unavailable: 'This item is no longer for sale.', variant_missing: 'This option is no longer offered.',
  out_of_stock: 'Out of stock.', exceeds_stock: 'Not enough stock for this quantity.',
};

export function OrderSummary({ s }: { s: { subtotal: number; savings: number; shipping: number; total: number } }) {
  return (
    <dl className="space-y-1 text-sm">
      <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatMoney(s.subtotal)}</dd></div>
      {s.savings > 0 ? <div className="flex justify-between text-green-700 dark:text-green-400"><dt>You save (discounts included above)</dt><dd>{formatMoney(s.savings)}</dd></div> : null}
      <div className="flex justify-between"><dt>Shipping</dt><dd>{s.shipping > 0 ? formatMoney(s.shipping) : 'Free'}</dd></div>
      <div className="flex justify-between border-t border-navy-100 pt-2 text-base font-extrabold dark:border-navy-500"><dt>Total</dt><dd>{formatMoney(s.total)}</dd></div>
    </dl>
  );
}

function CartInner() {
  const { lines, summary, loading, error, refresh, setQty, remove, clear } = useCart();
  useEffect(() => { void refresh(true); /* fresh stock/prices whenever the cart is opened */ }, [refresh]);

  if (error) return <ErrorState message={error} action={<Button onClick={() => refresh(true)}>Try again</Button>} />;
  if (loading && !lines.length) return <LoadingState />;
  if (!lines.length) return <EmptyState title="Your cart is empty" action={<Link href="/shop" className="font-semibold text-brand-purple underline">Start shopping</Link>}>Products you add will be saved to your account.</EmptyState>;
  return (
    <div className="grid gap-6 px-4 lg:grid-cols-[1fr,22rem]">
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">Cart</h1>
          <button onClick={() => { if (window.confirm('Remove everything from your cart?')) void clear(); }} className="min-h-11 text-sm underline">Clear cart</button></div>
        {summary.groups.map((g) => (
          <Card key={g.sellerId} className="space-y-3">
            <h2 className="font-bold">{g.storeName}</h2>
            <ul className="space-y-4">
              {g.lines.map((l) => (
                <li key={l.item.id} className="flex gap-3">
                  <Link href={`/product/${l.item.productId}`} className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-navy-50 dark:bg-navy-900">{l.product?.images[0] ? <Image src={l.product.images[0]} alt="" fill sizes="80px" className="object-cover" /> : null}</Link>
                  <div className="min-w-0 flex-1 space-y-1">
                    <p className="line-clamp-2 text-sm font-medium">{l.product?.title ?? 'Unavailable item'}</p>
                    {l.item.variantLabel ? <p className="text-xs text-navy-500 dark:text-navy-100">{l.item.variantLabel}</p> : null}
                    {l.problem ? <p role="alert" className="text-xs font-semibold text-red-600">{PROBLEM[l.problem]}{l.problem === 'exceeds_stock' ? ` Only ${l.available} left.` : ''}</p> : <p className="text-sm font-bold">{formatMoney(l.unitPrice)}</p>}
                    <div className="flex items-center gap-1">
                      <button aria-label="Decrease quantity" disabled={l.item.quantity <= 1} onClick={() => setQty(l.item.id, l.item.quantity - 1)} className="grid h-11 w-11 place-items-center rounded-lg border border-navy-100 disabled:opacity-40 dark:border-navy-500"><Minus className="h-4 w-4" /></button>
                      <span className="w-8 text-center text-sm font-semibold" aria-live="polite">{l.item.quantity}</span>
                      <button aria-label="Increase quantity" disabled={!l.product || l.item.quantity >= l.available} onClick={() => setQty(l.item.id, l.item.quantity + 1)} className="grid h-11 w-11 place-items-center rounded-lg border border-navy-100 disabled:opacity-40 dark:border-navy-500"><Plus className="h-4 w-4" /></button>
                      <button aria-label="Remove item" onClick={() => remove(l.item.id)} className="ml-auto grid h-11 w-11 place-items-center rounded-lg text-red-600"><Trash2 className="h-5 w-5" /></button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <p className="text-right text-sm">Shipping {g.shipping > 0 ? formatMoney(g.shipping) : 'free'} · Seller total <strong>{formatMoney(g.total)}</strong></p>
          </Card>
        ))}
      </div>
      <aside className="h-fit space-y-3 rounded-card border border-navy-100 p-4 dark:border-navy-500 lg:sticky lg:top-24">
        <h2 className="text-lg font-bold">Order summary</h2>
        <OrderSummary s={summary} />
        {summary.blocked ? <p role="alert" className="text-sm text-red-600">Fix the items marked above before checking out.</p> : null}
        {summary.blocked ? <Button disabled className="w-full">Checkout</Button> : <Link href="/checkout/address" className="inline-flex min-h-11 w-full items-center justify-center rounded-xl bg-brand-orange text-sm font-semibold text-white">Checkout</Link>}
        <p className="text-xs text-navy-500 dark:text-navy-100">Prices and stock are confirmed again when you place the order.</p>
      </aside>
    </div>
  );
}
export default function CartPage() { return <AuthGuard><CartInner /></AuthGuard>; }
