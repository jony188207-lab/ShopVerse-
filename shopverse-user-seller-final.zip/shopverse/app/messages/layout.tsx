'use client';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { useEffect, useState, type ReactNode } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { friendlyError } from '@/lib/firebase/errors';
import { watchConversations } from '@/services/chatService';
import { getPeerNames } from '@/services/peerService';
import type { Conversation } from '@/types/chat';

function List({ hideOnMobile }: { hideOnMobile: boolean }) {
  const { user } = useAuth(); const path = usePathname();
  const [list, setList] = useState<Conversation[] | null>(null); const [err, setErr] = useState('');
  const [names, setNames] = useState<Map<string, { name: string; logo: string }>>(new Map());
  useEffect(() => user ? watchConversations(user.uid, setList, (e) => { setErr(friendlyError(e)); setList([]); }) : undefined, [user]);
  useEffect(() => { if (user && list?.length) getPeerNames(user.uid, list).then(setNames).catch(() => undefined); }, [user, list]);
  return (
    <aside className={`${hideOnMobile ? 'hidden md:block' : ''} md:w-80 md:shrink-0 md:border-r md:border-navy-100 md:dark:border-navy-500`}>
      <h1 className="px-4 pb-2 text-2xl font-extrabold">Messages</h1>
      {err ? <ErrorState message={err} /> : list === null ? <LoadingState /> : !list.length ? <EmptyState title="No conversations yet">Message a seller from a product, store or order page.</EmptyState> : (
        <ul className="divide-y divide-navy-100 dark:divide-navy-500">
          {list.map((c) => {
            const n = c.unread[user!.uid] ?? 0; const peer = names.get(c.id);
            return (
              <li key={c.id}><Link href={`/messages/${c.id}`} aria-current={path === `/messages/${c.id}` ? 'page' : undefined} className={`flex items-center gap-3 px-4 py-3 hover:bg-navy-50 dark:hover:bg-navy-700 ${path === `/messages/${c.id}` ? 'bg-navy-50 dark:bg-navy-700' : ''}`}>
                <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-700">{peer?.logo ? <Image src={peer.logo} alt="" fill sizes="44px" className="object-cover" /> : null}</div>
                <div className="min-w-0 flex-1"><p className={`truncate text-sm ${n ? 'font-extrabold' : 'font-semibold'}`}>{peer?.name ?? '…'}</p><p className={`truncate text-xs ${n ? 'font-semibold' : 'text-navy-500 dark:text-navy-100'}`}>{c.lastMessage || 'No messages yet'}</p></div>
                <div className="flex flex-col items-end gap-1 text-[11px]">{c.lastMessageAt ? <span>{c.lastMessageAt.toLocaleDateString()}</span> : null}{n ? <span className="grid h-5 min-w-5 place-items-center rounded-full bg-brand-orange px-1 font-bold text-white">{n}</span> : null}</div>
              </Link></li>
            );
          })}
        </ul>
      )}
    </aside>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const inThread = path !== '/messages';
  return (
    <div className="flex min-h-[70vh] flex-col md:flex-row">
      <List hideOnMobile={inThread} />
      <section className={`${inThread ? '' : 'hidden md:block'} min-w-0 flex-1`}>{children}</section>
    </div>
  );
}
export default function MessagesLayout({ children }: { children: ReactNode }) { return <AuthGuard><Shell>{children}</Shell></AuthGuard>; }
