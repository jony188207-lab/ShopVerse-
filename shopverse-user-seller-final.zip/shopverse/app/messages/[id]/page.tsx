'use client';
import Link from 'next/link';
import { Suspense, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { ArrowLeft } from 'lucide-react';
import { MessageBubble } from '@/components/chat/MessageBubble';
import { ReportButton } from '@/components/ReportButton';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { evidenceText, loadEarlier, markRead, sendMessage, setBlocked, watchConversation, watchMessages, type MessageRef } from '@/services/chatService';
import { getPeerNames } from '@/services/peerService';
import { getProduct } from '@/services/productService';
import type { ChatMessage, Conversation } from '@/types/chat';

function Thread() {
  const { id } = useParams<{ id: string }>(); const sp = useSearchParams(); const { user } = useAuth(); const toast = useToast();
  const [conv, setConv] = useState<Conversation | null | undefined>(undefined); const [err, setErr] = useState('');
  const [msgs, setMsgs] = useState<ChatMessage[]>([]); const [oldest, setOldest] = useState<QueryDocumentSnapshot | null>(null); const [more, setMore] = useState(false);
  const [peer, setPeer] = useState({ name: '…', logo: '' }); const [text, setText] = useState(''); const [sending, setSending] = useState(false);
  const [ref, setRef] = useState<MessageRef>({ productId: sp.get('product') ?? undefined, orderId: sp.get('order') ?? undefined }); const [refLabel, setRefLabel] = useState('');
  const bottom = useRef<HTMLDivElement | null>(null); const stick = useRef(true);
  const uid = user!.uid;

  useEffect(() => watchConversation(id, setConv, (e) => { setErr(friendlyError(e)); setConv(null); }), [id]);
  useEffect(() => watchMessages(id, (m, o) => { setMsgs((cur) => { const older = cur.filter((x) => m.length && x.createdAt && m[0].createdAt && x.createdAt < m[0].createdAt); return [...older, ...m]; }); setOldest((cur) => cur ?? o); setMore(m.length >= 40); }, (e) => setErr(friendlyError(e))), [id]);
  useEffect(() => { if (conv) getPeerNames(uid, [conv]).then((m) => setPeer(m.get(conv.id) ?? { name: 'Chat', logo: '' })).catch(() => undefined); }, [conv?.id, uid]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (ref.productId) getProduct(ref.productId).then((p) => setRefLabel(p ? `About: ${p.title}` : 'About a product')).catch(() => undefined); else setRefLabel(ref.orderId ? 'About your order' : ''); }, [ref.productId, ref.orderId]);

  // Mark received messages as read while this thread is open.
  const unreadIds = useMemo(() => msgs.filter((m) => m.receiverId === uid && !m.readAt && !m.pending).map((m) => m.id), [msgs, uid]);
  useEffect(() => { if (conv && (unreadIds.length || (conv.unread[uid] ?? 0) > 0) && document.visibilityState === 'visible') markRead(conv, uid, unreadIds).catch(() => undefined); }, [conv, unreadIds, uid]);
  useEffect(() => { if (stick.current) bottom.current?.scrollIntoView({ block: 'end' }); }, [msgs.length]);

  if (conv === undefined) return <LoadingState />;
  if (err || !conv) return <ErrorState title="Conversation not available" message={err || 'It does not exist or you are not part of it.'} action={<Link href="/messages" className="font-semibold text-brand-purple underline">Back to messages</Link>} />;
  const blockedByMe = conv.blockedBy.includes(uid); const blocked = conv.blockedBy.length > 0;
  const send = async (e: FormEvent) => {
    e.preventDefault(); setSending(true);
    try { await sendMessage(conv, uid, text, ref); setText(''); setRef({}); stick.current = true; } catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setSending(false); }
  };
  const earlier = async () => { if (!oldest) return; try { const r = await loadEarlier(id, oldest); setMsgs((c) => [...r.items, ...c]); setOldest(r.oldest); setMore(r.more); stick.current = false; } catch (x) { toast(friendlyError(x), 'error'); } };
  const lastSeenMine = [...msgs].reverse().find((m) => m.senderId === uid && m.readAt)?.id;
  return (
    <div className="flex h-[calc(100dvh-13rem)] min-h-96 flex-col md:h-[calc(100dvh-9rem)]">
      <header className="flex items-center gap-2 border-b border-navy-100 px-3 py-2 dark:border-navy-500">
        <Link href="/messages" aria-label="Back to conversations" className="grid h-11 w-11 place-items-center md:hidden"><ArrowLeft className="h-5 w-5" /></Link>
        <div className="min-w-0 flex-1"><p className="truncate font-bold">{peer.name}</p>{conv.buyerId === uid ? null : <p className="text-xs">Buyer</p>}</div>
        <ReportButton targetType="conversation" targetId={conv.id} label="Report" evidence={() => evidenceText(msgs, (u) => (u === uid ? 'Reporter' : peer.name))} />
        <Button variant="ghost" onClick={() => setBlocked(conv.id, uid, !blockedByMe).then(() => toast(blockedByMe ? 'Unblocked' : 'Blocked — neither of you can send messages', 'success')).catch((x) => toast(friendlyError(x), 'error'))}>{blockedByMe ? 'Unblock' : 'Block'}</Button>
      </header>
      <div className="flex-1 overflow-y-auto px-3 py-3" onScroll={(e) => { const t = e.currentTarget; stick.current = t.scrollHeight - t.scrollTop - t.clientHeight < 80; }}>
        {more ? <div className="mb-2 text-center"><Button variant="ghost" onClick={earlier}>Load earlier messages</Button></div> : null}
        {!msgs.length ? <EmptyState title="Say hello">Ask about a product, shipping or an order. Replies appear here instantly.</EmptyState> : <ul className="space-y-2">{msgs.map((m) => <MessageBubble key={m.id} m={m} mine={m.senderId === uid} cid={conv.id} seen={m.id === lastSeenMine || (!!m.readAt)} />)}</ul>}
        <div ref={bottom} />
      </div>
      {blocked ? <p role="status" className="border-t border-navy-100 p-3 text-center text-sm dark:border-navy-500">{blockedByMe ? 'You blocked this chat. Unblock to send messages.' : 'This person is not accepting messages.'}</p>
        : !user?.emailVerified ? <p className="border-t border-navy-100 p-3 text-center text-sm dark:border-navy-500"><Link className="underline" href="/verify-email">Verify your email</Link> to send messages.</p>
        : (
          <form onSubmit={send} className="border-t border-navy-100 p-2 dark:border-navy-500">
            {refLabel ? <p className="mb-1 flex items-center justify-between rounded-lg bg-navy-50 px-2 py-1 text-xs dark:bg-navy-700"><span className="truncate">{refLabel}</span><button type="button" onClick={() => setRef({})} aria-label="Remove reference" className="min-h-8 px-2">✕</button></p> : null}
            <div className="flex gap-2"><textarea value={text} onChange={(e) => setText(e.target.value)} rows={1} maxLength={2000} placeholder="Write a message…" aria-label="Message" onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); e.currentTarget.form?.requestSubmit(); } }}
              className="min-h-11 min-w-0 flex-1 resize-none rounded-xl border border-navy-100 bg-white px-3 py-2 text-base text-navy-900 dark:border-navy-500 dark:bg-navy-900 dark:text-white" />
              <Button type="submit" loading={sending} disabled={!text.trim()}>Send</Button></div>
          </form>
        )}
    </div>
  );
}
export default function Page() { return <Suspense fallback={<LoadingState />}><Thread /></Suspense>; }
