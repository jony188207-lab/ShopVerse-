import { EmptyState } from '@/components/ui/States';
export const metadata = { title: 'Messages' };
export default function Page() { return <div className="hidden md:block"><EmptyState title="Select a conversation">Pick a chat on the left, or message a seller from a product, store or order page.</EmptyState></div>; }
