'use client';
import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { friendlyError } from '@/lib/firebase/errors';
import { ensureConversation } from '@/services/chatService';
import { getStore } from '@/services/storeService';

/** /messages/new?store=<storeId>[&product=<productId>][&order=<orderId>] -> opens/creates the conversation, then the thread with the reference pre-attached. */
function Inner() {
  const sp = useSearchParams(); const router = useRouter(); const { user } = useAuth();
  const [err, setErr] = useState(''); const storeId = sp.get('store');
  useEffect(() => {
    if (!user || !storeId) return;
    let cancelled = false;
    (async () => {
      try {
        const store = await getStore(storeId);
        if (!store) throw new Error('This store is not available.');
        const id = await ensureConversation(user.uid, store);
        const q = new URLSearchParams(); if (sp.get('product')) q.set('product', sp.get('product')!); if (sp.get('order')) q.set('order', sp.get('order')!);
        if (!cancelled) router.replace(`/messages/${id}${q.size ? `?${q}` : ''}`);
      } catch (e) { if (!cancelled) setErr(e instanceof Error && !('code' in e) ? e.message : friendlyError(e)); }
    })();
    return () => { cancelled = true; };
  }, [user, storeId, sp, router]);
  if (!storeId) return <EmptyState title="No store selected" />;
  return err ? <ErrorState title="Could not open the chat" message={err} /> : <LoadingState label="Opening chat…" />;
}
export default function Page() { return <Suspense fallback={<LoadingState />}><Inner /></Suspense>; }
