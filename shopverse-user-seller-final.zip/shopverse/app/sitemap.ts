import type { MetadataRoute } from 'next';
import { DEFAULT_CATEGORIES } from '@/config/categories';
import { runPublicQuery } from '@/lib/firestoreRest';
import { SITE_URL } from '@/lib/siteUrl';

export const revalidate = 3600;
/** Static pages + up to 1,000 approved products + 500 approved stores (public docs only). Larger catalogs need a sitemap index (see AUDIT.md). */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [products, stores, cats] = await Promise.all([runPublicQuery('products', [['status', 'approved']], { limit: 1000, orderBy: 'createdAt' }), runPublicQuery('stores', [['status', 'approved']], { limit: 500 }), runPublicQuery('categories', [], { limit: 200 }).catch(() => [])]);
  const catIds = cats.length ? cats.filter((c) => c.active !== false && !c.parentId).map((c) => c.id) : DEFAULT_CATEGORIES.map((c) => c.id);
  return [
    { url: SITE_URL, changeFrequency: 'daily', priority: 1 }, { url: `${SITE_URL}/shop`, changeFrequency: 'daily', priority: 0.9 }, { url: `${SITE_URL}/categories` }, { url: `${SITE_URL}/video` },
    ...catIds.map((id) => ({ url: `${SITE_URL}/category/${id}`, changeFrequency: 'daily' as const, priority: 0.7 })),
    ...products.map((p) => ({ url: `${SITE_URL}/product/${p.id}`, lastModified: typeof p.updatedAt === 'string' ? p.updatedAt : undefined, changeFrequency: 'weekly' as const, priority: 0.8 })),
    ...stores.map((s) => ({ url: `${SITE_URL}/store/${String(s.slug)}`, changeFrequency: 'weekly' as const, priority: 0.6 })),
  ];
}
