'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { AuthGuard } from '@/components/AuthGuard';
import { useWishlist } from '@/hooks/useWishlist';
import { useCart } from '@/hooks/useCart';
import { getProductsByIds } from '@/services/productService';
import { availableStock } from '@/utils/cartMath';
import { Price } from '@/components/Price';
import { Button } from '@/components/ui/Button';
import { EmptyState, LoadingState } from '@/components/ui/States';
import type { Product } from '@/types';

const STEP = 24;

function Inner() {
  const { ids, remove, loading } = useWishlist();
  const { add } = useCart();
  const [shown, setShown] = useState(STEP);
  const [products, setProducts] = useState<Map<string, Product | null>>(new Map());
  const [busy, setBusy] = useState('');
  const slice = ids.slice(0, shown).join(',');

  useEffect(() => {
    const need = slice.split(',').filter((id) => id && !products.has(id));
    if (!need.length) return;
    getProductsByIds(need).then((m) => setProducts((x) => new Map([...x, ...m])));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slice]);

  if (loading && !ids.length) return <LoadingState />;
  if (!ids.length) return <EmptyState title="Your wishlist is empty" action={<Link href="/shop" className="font-semibold text-brand-purple underline">Browse products</Link>}>Tap the heart on any product to save it here.</EmptyState>;
  const move = async (p: Product) => {
    setBusy(p.id);
    if (await add(p, p.variants.length === 1 ? p.variants[0].key : undefined, 1)) await remove(p.id);
    setBusy('');
  };
  return (
    <div className="space-y-4 px-4">
      <h1 className="text-2xl font-extrabold">Wishlist</h1>
      <ul className="grid gap-3 md:grid-cols-2">
        {ids.slice(0, shown).map((id) => {
          const p = products.get(id);
          if (p === undefined) return <li key={id}><LoadingState label="" /></li>;
          const sellable = !!p && p.status === 'approved' && availableStock(p, p.variants[0]?.key ?? 'default') > 0 || (!!p && p.status === 'approved' && p.variants.some((v) => v.stock > 0));
          return (
            <li key={id} className="flex gap-3 rounded-card border border-navy-100 p-3 dark:border-navy-500">
              <Link href={p ? `/product/${id}` : '#'} className="relative h-24 w-24 shrink-0 overflow-hidden rounded-lg bg-navy-50 dark:bg-navy-900">{p?.images[0] ? <Image src={p.images[0]} alt="" fill sizes="96px" className="object-cover" /> : null}</Link>
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <p className="line-clamp-2 text-sm font-medium">{p?.title ?? 'This product is no longer available'}</p>
                {p ? <Price price={p.price} original={p.originalPrice} /> : null}
                {p && !sellable ? <p className="text-xs font-semibold text-red-600">{p.status === 'approved' ? 'Out of stock' : 'Unavailable'}</p> : null}
                <div className="mt-auto flex flex-wrap gap-2">
                  {p && sellable ? (p.variants.length > 1 ? <Link href={`/product/${id}`} className="inline-flex min-h-11 items-center rounded-xl bg-brand-orange px-4 text-sm font-semibold text-white">Choose options</Link>
                    : <Button loading={busy === id} onClick={() => move(p)}>Move to cart</Button>) : null}
                  <Button variant="ghost" onClick={() => remove(id)}>Remove</Button>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
      {ids.length > shown ? <Button variant="secondary" onClick={() => setShown(shown + STEP)}>Show more</Button> : null}
    </div>
  );
}
export default function WishlistPage() { return <AuthGuard><Inner /></AuthGuard>; }
