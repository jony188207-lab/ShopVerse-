import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/Providers';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { Footer } from '@/components/Footer';
import { SITE_URL } from '@/lib/siteUrl';
import { PwaRegister } from '@/components/PwaRegister';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: 'ShopVerse — Shop • Watch • Shop', template: '%s | ShopVerse' },
  description: 'Shop from independent sellers and watch product videos on ShopVerse.',
  applicationName: 'ShopVerse', alternates: { canonical: '/' },
  openGraph: { type: 'website', siteName: 'ShopVerse', title: 'ShopVerse — Shop • Watch • Shop', description: 'Shop from independent sellers and watch product videos.' },
  twitter: { card: 'summary' }, icons: { icon: [{ url: '/favicon-32.png', sizes: '32x32', type: 'image/png' }, { url: '/icon-192.png', sizes: '192x192', type: 'image/png' }], apple: '/apple-touch-icon.png' },
  appleWebApp: { capable: true, title: 'ShopVerse', statusBarStyle: 'black-translucent' }, formatDetection: { telephone: false },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover', themeColor: '#0B1B36', interactiveWidget: 'resizes-content' };

// Applies the saved theme before first paint (prevents a light flash in dark mode).
const themeScript = `try{var t=localStorage.getItem('sv-theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable} suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body className="flex min-h-screen flex-col font-sans">
        <Providers>
          <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-[60] focus:rounded-lg focus:bg-white focus:px-3 focus:py-2 focus:text-navy-900">Skip to content</a>
          <Header />
          <main id="main" className="mx-auto w-full max-w-7xl flex-1 py-4">{children}</main>
          <Footer />
          <PwaRegister />
          <BottomNav />
        </Providers>
      </body>
    </html>
  );
}
