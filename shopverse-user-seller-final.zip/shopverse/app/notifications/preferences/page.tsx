'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { DEFAULT_PREFS, getPrefs, savePrefs, type Prefs } from '@/services/notificationPrefsService';
import { disablePush, enablePush, listDevices, removeDevice, type Device } from '@/services/pushService';
import { PREF_LABELS } from '@/types/seller';

const PUSH_MSG = { enabled: 'Push is on for this device.', denied: 'Notifications are blocked in your browser. Allow them in the site settings, then try again.', unsupported: 'This browser does not support push notifications.', 'missing-vapid': 'Push is not configured on this site yet.' } as const;

function Inner() {
  const { user, role } = useAuth(); const toast = useToast();
  const [prefs, setPrefs] = useState<Prefs | null>(null); const [devices, setDevices] = useState<Device[] | null>(null); const [busy, setBusy] = useState(false);
  const [perm, setPerm] = useState<string>(typeof Notification === 'undefined' ? 'unsupported' : Notification.permission);
  const loadDevices = useCallback(() => listDevices(user!.uid).then(setDevices).catch(() => setDevices([])), [user]);
  useEffect(() => { getPrefs(user!.uid).then(setPrefs).catch(() => setPrefs(DEFAULT_PREFS)); void loadDevices(); }, [user, loadDevices]);
  if (!prefs) return <LoadingState />;
  const isStaff = ['moderator', 'admin', 'super_admin'].includes(role);
  const rows = PREF_LABELS.filter((p) => !p.role || (p.role === 'seller' && role === 'seller') || (p.role === 'staff' && isStaff));
  const set = async (key: string, on: boolean) => {
    const next = { ...prefs, [key]: on }; setPrefs(next);
    try { await savePrefs(user!.uid, next); } catch (e) { setPrefs(prefs); toast(friendlyError(e), 'error'); }
  };
  const turnOn = async () => { setBusy(true); try { const r = await enablePush(user!.uid); setPerm(typeof Notification === 'undefined' ? 'unsupported' : Notification.permission); toast(PUSH_MSG[r], r === 'enabled' ? 'success' : 'error'); if (r === 'enabled') await set('push', true); await loadDevices(); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); } };
  const turnOff = async () => { setBusy(true); try { await disablePush(user!.uid); await loadDevices(); toast('Push turned off for this device', 'success'); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); } };
  return (
    <div className="mx-auto max-w-xl space-y-4 px-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">Notification settings</h1><Link href="/notifications" className="text-sm font-semibold text-brand-purple underline">Back</Link></div>
      <Card className="space-y-3">
        <h2 className="font-semibold">Push notifications</h2>
        <label className="flex items-start gap-3 text-sm"><input type="checkbox" className="mt-1 h-5 w-5" checked={prefs.push !== false} onChange={(e) => set('push', e.target.checked)} /><span><strong>Allow push</strong><br /><span className="text-navy-500 dark:text-navy-100">Master switch for every device. In-app notifications keep working.</span></span></label>
        <p className="text-sm">This device: <strong>{perm === 'granted' ? 'allowed' : perm === 'denied' ? 'blocked in browser' : perm === 'unsupported' ? 'not supported' : 'not enabled yet'}</strong></p>
        <div className="flex flex-wrap gap-2"><Button onClick={turnOn} loading={busy} disabled={perm === 'unsupported'}>{perm === 'granted' ? 'Re-register this device' : 'Enable push on this device'}</Button>{perm === 'granted' ? <Button variant="ghost" onClick={turnOff} disabled={busy}>Turn off on this device</Button> : null}</div>
      </Card>
      <Card className="space-y-1">
        <h2 className="mb-1 font-semibold">What to notify me about</h2>
        <ul className="divide-y divide-navy-100 dark:divide-navy-500">{rows.map((p) => (
          <li key={p.key}><label className="flex items-start gap-3 py-3 text-sm"><input type="checkbox" className="mt-1 h-5 w-5" checked={prefs[p.key] !== false} onChange={(e) => set(p.key, e.target.checked)} /><span><strong>{p.label}</strong><br /><span className="text-navy-500 dark:text-navy-100">{p.hint}</span></span></label></li>))}</ul>
        <p className="pt-2 text-xs text-navy-500 dark:text-navy-100">Account and safety messages (store approval or suspension, role changes, important announcements) are always delivered.</p>
      </Card>
      <Card className="space-y-2">
        <h2 className="font-semibold">Your devices</h2>
        {devices === null ? <LoadingState /> : !devices.length ? <p className="text-sm">No devices registered.</p> : (
          <ul className="divide-y divide-navy-100 dark:divide-navy-500">{devices.map((d) => (
            <li key={d.token} className="flex items-center gap-2 py-2 text-sm"><div className="min-w-0 flex-1"><p className="font-medium">{d.platform || 'device'}{d.current ? ' (this device)' : ''}</p><p className="truncate text-xs">{d.userAgent} · last active {fmtDate(d.lastSeenAt)}</p></div>
              <Button variant="ghost" onClick={async () => { try { await removeDevice(user!.uid, d.token); await loadDevices(); } catch (e) { toast(friendlyError(e), 'error'); } }}>Remove</Button></li>))}</ul>
        )}
      </Card>
    </div>
  );
}
export default function Page() { return <AuthGuard><Inner /></AuthGuard>; }
