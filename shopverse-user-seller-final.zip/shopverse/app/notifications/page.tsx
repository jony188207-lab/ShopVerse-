'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Bell, MessageSquare, Package, Play, ShieldAlert, Star, Store, Tag, Trash2, UserPlus, Wallet } from 'lucide-react';
import { AuthGuard } from '@/components/AuthGuard';
import { fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { deleteAllRead, deleteNotification, listNotifications, markAllReadForUser, markRead, safeHref, unreadTotal } from '@/services/notificationService';
import type { AppNotification } from '@/types/seller';

const ICON: Record<string, typeof Bell> = { order: Package, product: Tag, conversation: MessageSquare, video: Play, store: Store, withdrawal: Wallet, seller: Store };
function iconFor(n: AppNotification) {
  if (n.category === 'admin') return ShieldAlert; if (n.category === 'reviews') return Star; if (n.category === 'followers') return UserPlus;
  return ICON[n.relatedType] ?? Bell;
}

function Inner() {
  const { user } = useAuth(); const toast = useToast();
  const [unreadOnly, setUnreadOnly] = useState(false); const [total, setTotal] = useState<number | null>(null);
  const { items, setItems, more, error, busy, loadMore, reload } = usePaged((c) => listNotifications(user!.uid, unreadOnly, c), [user?.uid, unreadOnly]);
  useEffect(() => { unreadTotal(user!.uid).then(setTotal).catch(() => setTotal(null)); }, [user, items]);
  const run = async (fn: () => Promise<unknown>, ok?: string) => { try { await fn(); if (ok) toast(ok, 'success'); } catch (e) { toast(friendlyError(e), 'error'); } };
  const open = (n: AppNotification) => { if (!n.read) { void markRead(n.id).catch(() => undefined); setItems((x) => x?.map((i) => (i.id === n.id ? { ...i, read: true } : i)) ?? null); } };
  return (
    <div className="mx-auto max-w-xl space-y-3 px-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-extrabold">Notifications{total ? <span className="ml-2 rounded-full bg-brand-orange px-2 py-0.5 align-middle text-xs font-bold text-white">{total}</span> : null}</h1>
        <Link href="/notifications/preferences" className="text-sm font-semibold text-brand-purple underline">Settings</Link>
      </div>
      <div className="flex flex-wrap gap-1">
        <Button variant={unreadOnly ? 'ghost' : 'secondary'} onClick={() => setUnreadOnly(false)}>All</Button>
        <Button variant={unreadOnly ? 'secondary' : 'ghost'} onClick={() => setUnreadOnly(true)}>Unread</Button>
        <Button variant="ghost" disabled={!total} onClick={() => run(async () => { await markAllReadForUser(user!.uid); setItems((x) => x?.map((i) => ({ ...i, read: true })) ?? null); setTotal(0); }, 'All marked as read')}>Mark all read</Button>
        <Button variant="ghost" onClick={() => window.confirm('Delete all read notifications?') && run(async () => { await deleteAllRead(user!.uid); await reload(); }, 'Cleared')}>Clear read</Button>
      </div>
      {error ? <ErrorState message={error} action={<Button onClick={() => reload()}>Try again</Button>} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title={unreadOnly ? 'You are all caught up' : 'Nothing yet'}>Order updates, messages, reviews and seller news show up here.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((n) => {
            const Icon = iconFor(n);
            return (
              <li key={n.id} className={`flex items-start gap-1 ${n.read ? '' : 'bg-navy-50 dark:bg-navy-700'}`}>
                <Link href={safeHref(n.link || '/notifications')} onClick={() => open(n)} className="flex min-w-0 flex-1 items-start gap-3 p-3">
                  <span className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full ${n.read ? 'bg-navy-100 dark:bg-navy-500' : 'bg-brand-orange text-white'}`}><Icon className="h-4 w-4" aria-hidden /></span>
                  <span className="min-w-0 flex-1"><span className={`block text-sm ${n.read ? 'font-medium' : 'font-bold'}`}>{n.title}</span><span className="block text-sm">{n.body}</span><span className="block text-xs text-navy-500 dark:text-navy-100">{fmtDate(n.createdAt)}{n.createdAt ? ` · ${n.createdAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : ''}</span></span>
                </Link>
                <button aria-label="Delete notification" className="grid h-11 w-11 shrink-0 place-items-center text-navy-500 hover:text-red-600" onClick={() => run(async () => { await deleteNotification(n.id); setItems((x) => x?.filter((i) => i.id !== n.id) ?? null); })}><Trash2 className="h-4 w-4" aria-hidden /></button>
              </li>
            );
          })}
        </ul>
      )}
      {more ? <Button variant="secondary" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
export default function Page() { return <AuthGuard><Inner /></AuthGuard>; }
