'use client';
import Link from 'next/link';
import { BarChart3, DollarSign, Film, MessageSquare, Plus, Settings, Star, Tag, Megaphone, Users, Wallet, type LucideIcon } from 'lucide-react';
import { PageHead } from '@/components/seller/ui';

const ITEMS: { href: string; label: string; icon: LucideIcon }[] = [
  { href: '/seller/products/new', label: 'Add product', icon: Plus }, { href: '/seller/customers', label: 'Customers', icon: Users }, { href: '/seller/reviews', label: 'Reviews', icon: Star },
  { href: '/seller/earnings', label: 'Earnings', icon: DollarSign }, { href: '/seller/withdrawals', label: 'Withdrawals', icon: Wallet }, { href: '/seller/coupons', label: 'Coupons', icon: Tag },
  { href: '/seller/promotions', label: 'Promotions', icon: Megaphone }, { href: '/seller/analytics', label: 'Analytics', icon: BarChart3 }, { href: '/seller/videos', label: 'Videos', icon: Film },
  { href: '/messages', label: 'Messages', icon: MessageSquare }, { href: '/seller/settings', label: 'Store settings', icon: Settings },
];
export default function SellerMenu() {
  return (
    <div className="space-y-3">
      <PageHead title="Seller menu" />
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {ITEMS.map(({ href, label, icon: Icon }) => (
          <li key={href}><Link href={href} className="flex min-h-20 flex-col items-center justify-center gap-1 rounded-card border border-navy-100 bg-white p-3 text-center text-sm font-medium hover:border-brand-purple dark:border-navy-500 dark:bg-navy-700"><Icon className="h-5 w-5 text-brand-purple" aria-hidden />{label}</Link></li>
        ))}
      </ul>
    </div>
  );
}
