'use client';
import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, fmtDate, textareaCls } from '@/components/seller/ui';
import { StarRating } from '@/components/StarRating';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { reportReview } from '@/services/reviewService';
import { listSellerReviews, respondToReview } from '@/services/sellerService';

export default function Page() {
  const { uid } = useSeller(); const { user } = useAuth(); const toast = useToast();
  const { items, setItems, more, error, busy, loadMore } = usePaged((c) => listSellerReviews(uid, c), [uid]);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const reply = async (id: string) => {
    try { await respondToReview(id, draft[id] ?? ''); setItems((x) => x?.map((r) => (r.id === id ? { ...r, sellerResponse: (draft[id] ?? '').trim() } : r)) ?? null); toast('Response posted', 'success'); }
    catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : friendlyError(e), 'error'); }
  };
  const report = async (id: string) => {
    const reason = window.prompt('Why is this review inappropriate?'); if (!reason || !user) return;
    try { await reportReview(user.uid, id, reason); toast('Reported to moderators', 'success'); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  return (
    <div>
      <PageHead title="Reviews" />
      <p className="mb-3 text-sm">You can respond to and report reviews, but not edit or delete them.</p>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No reviews yet">Verified buyers can review products after delivery.</EmptyState> : (
        <ul className="space-y-3">
          {items.map((r) => (
            <li key={r.id} className="space-y-2 rounded-card border border-navy-100 p-3 dark:border-navy-500">
              <div className="flex flex-wrap items-center gap-2"><StarRating value={r.rating} />{r.verifiedPurchase ? <Pill status="approved" label="Verified purchase" /> : null}{r.status !== 'published' ? <Pill status="suspended" label={r.status} /> : null}<span className="text-xs">{r.userName} · {fmtDate(r.createdAt)}</span></div>
              {r.text ? <p className="text-sm">{r.text}</p> : null}
              {r.sellerResponse ? <p className="rounded-lg bg-navy-50 p-2 text-sm dark:bg-navy-700"><strong>Your response:</strong> {r.sellerResponse}</p> : (
                <div className="space-y-2"><textarea rows={2} maxLength={1000} placeholder="Write a public response…" value={draft[r.id] ?? ''} onChange={(e) => setDraft({ ...draft, [r.id]: e.target.value })} className={textareaCls} /><Button variant="secondary" onClick={() => reply(r.id)}>Respond</Button></div>
              )}
              <Button variant="ghost" onClick={() => report(r.id)}>Report review</Button>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
