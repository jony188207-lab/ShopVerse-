'use client';
import { useMemo } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { listSellerOrders } from '@/services/sellerService';
import { aggregateCustomers } from '@/utils/customers';
import { formatMoney } from '@/utils/money';

export default function Page() {
  const { uid } = useSeller();
  const { items, more, error, busy, loadMore } = usePaged((c) => listSellerOrders(uid, '', c, 50), [uid]);
  const rows = useMemo(() => aggregateCustomers(items ?? []), [items]);
  return (
    <div>
      <PageHead title="Customers" />
      <p className="mb-3 text-sm">Built from your own orders only: name, city and totals. Delivery phone and address are on each order.</p>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !rows.length ? <EmptyState title="No customers yet">Customers appear after their first order.</EmptyState> : (
        <div className="overflow-x-auto rounded-card border border-navy-100 dark:border-navy-500">
          <table className="w-full min-w-[480px] text-left text-sm"><thead className="bg-navy-50 dark:bg-navy-700"><tr><th className="p-2">Customer</th><th className="p-2">City</th><th className="p-2">Orders</th><th className="p-2">Spent</th><th className="p-2">Last order</th></tr></thead>
            <tbody>{rows.map((r) => <tr key={r.buyerId} className="border-t border-navy-100 dark:border-navy-500"><td className="p-2 font-medium">{r.name}</td><td className="p-2">{r.city}</td><td className="p-2">{r.orders}</td><td className="p-2">{formatMoney(r.spent)}</td><td className="p-2">{fmtDate(r.lastOrderAt)}</td></tr>)}</tbody></table>
        </div>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load older orders</Button> : null}
    </div>
  );
}
