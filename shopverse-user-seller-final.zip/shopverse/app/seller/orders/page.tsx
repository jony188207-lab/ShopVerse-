'use client';
import Link from 'next/link';
import { useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { listSellerOrders } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import { ORDER_STATUS_LABEL, type OrderStatus } from '@/types';

export default function Page() {
  const { uid } = useSeller();
  const [status, setStatus] = useState<OrderStatus | ''>('');
  const { items, more, error, busy, loadMore } = usePaged((c) => listSellerOrders(uid, status, c), [uid, status]);
  return (
    <div>
      <PageHead title="Orders" />
      <label className="mb-3 block text-sm font-medium">Status <select value={status} onChange={(e) => setStatus(e.target.value as OrderStatus | '')} className={selectCls}><option value="">All</option>{(Object.keys(ORDER_STATUS_LABEL) as OrderStatus[]).map((s) => <option key={s} value={s}>{ORDER_STATUS_LABEL[s]}</option>)}</select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No orders">Orders for your products appear here.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((o) => (
            <li key={o.id}><Link href={`/seller/orders/${o.id}`} className="flex flex-wrap items-center gap-2 p-3 hover:bg-navy-50 dark:hover:bg-navy-700">
              <div className="min-w-0 flex-1"><p className="font-semibold">{o.orderNumber}</p><p className="text-xs">{fmtDate(o.createdAt)} · {o.itemCount} item(s) · {o.address.fullName}, {o.address.city}</p></div>
              <span className="font-semibold">{formatMoney(o.total)}</span><Pill status={o.status} label={ORDER_STATUS_LABEL[o.status]} />
            </Link></li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
