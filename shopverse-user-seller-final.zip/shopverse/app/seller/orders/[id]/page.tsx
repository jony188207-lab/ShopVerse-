'use client';
import Image from 'next/image';
import { useParams } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { SELLER_NEXT, getSellerOrder, getSellerOrderItems, setSellerOrderStatus } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import { ORDER_STATUS_LABEL, type Order, type OrderItem, type OrderStatus } from '@/types';

export default function Page() {
  const { id } = useParams<{ id: string }>(); const { uid } = useSeller(); const toast = useToast();
  const [o, setO] = useState<Order | null | undefined>(undefined);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [tracking, setTracking] = useState(''); const [carrier, setCarrier] = useState(''); const [busy, setBusy] = useState(false);
  const load = useCallback(async () => { try { const ord = await getSellerOrder(id, uid); setO(ord); if (ord) setItems(await getSellerOrderItems(id, uid)); } catch { setO(null); } }, [id, uid]);
  useEffect(() => { void load(); }, [load]);
  if (o === undefined) return <LoadingState />;
  if (!o) return <EmptyState title="Order not found">It does not exist or belongs to another seller.</EmptyState>;
  const move = async (n: OrderStatus) => {
    if (n === 'cancelled' && !window.confirm('Cancel this order? The buyer is notified and stock goes back on sale.')) return;
    if (n === 'shipped' && !tracking.trim() && !window.confirm('Ship without a tracking number?')) return;
    setBusy(true);
    try { await setSellerOrderStatus(o, n, tracking, carrier); toast(`Marked ${ORDER_STATUS_LABEL[n]}`, 'success'); await load(); } catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <PageHead title={`Order ${o.orderNumber}`}><Pill status={o.status} label={ORDER_STATUS_LABEL[o.status]} /></PageHead>
      <Card className="space-y-1 text-sm"><p>{fmtDate(o.createdAt)} · Cash on delivery ({o.paymentStatus})</p>
        <p className="font-semibold">Ship to</p><p>{o.address.fullName} · {o.address.phone}</p><p>{o.address.address}{o.address.area ? `, ${o.address.area}` : ''}, {o.address.city}, {o.address.country} {o.address.postalCode}</p>
        {o.address.instructions ? <p>Note: {o.address.instructions}</p> : null}
        {o.trackingNumber ? <p>Tracking: {o.carrier} {o.trackingNumber}</p> : null}</Card>
      <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
        {items.map((i) => (
          <li key={i.id} className="flex items-center gap-3 p-3">
            <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-navy-100">{i.image ? <Image src={i.image} alt="" fill sizes="56px" className="object-cover" /> : null}</div>
            <div className="min-w-0 flex-1"><p className="truncate font-semibold">{i.title}</p><p className="text-xs">{i.variantLabel ? `${i.variantLabel} · ` : ''}{i.sku ? `SKU ${i.sku} · ` : ''}{formatMoney(i.unitPrice)} × {i.quantity}</p></div>
            <span className="font-semibold">{formatMoney(i.lineTotal)}</span>
          </li>
        ))}
      </ul>
      <Card className="space-y-1 text-sm"><p className="flex justify-between"><span>Subtotal</span>{formatMoney(o.subtotal)}</p>{o.couponDiscount ? <p className="flex justify-between"><span>Coupon {o.couponCode}</span>−{formatMoney(o.couponDiscount)}</p> : null}
        <p className="flex justify-between"><span>Shipping</span>{formatMoney(o.shipping)}</p><p className="flex justify-between font-bold"><span>Order total</span>{formatMoney(o.total)}</p>
        <p className="pt-1 text-xs text-navy-500 dark:text-navy-100">Commission and your net amount are calculated by the platform when the order is delivered (see Earnings).</p></Card>
      {SELLER_NEXT[o.status].length ? (
        <Card className="space-y-3">
          <h2 className="font-semibold">Update status</h2>
          {SELLER_NEXT[o.status].includes('shipped') ? <div className="grid gap-2 sm:grid-cols-2"><Field label="Carrier (optional)" value={carrier} maxLength={60} onChange={(e) => setCarrier(e.target.value)} /><Field label="Tracking number (optional)" value={tracking} maxLength={80} onChange={(e) => setTracking(e.target.value)} /></div> : null}
          <div className="flex flex-wrap gap-2">{SELLER_NEXT[o.status].map((n) => <Button key={n} variant={n === 'cancelled' ? 'danger' : 'primary'} loading={busy} onClick={() => move(n)}>{n === 'returned' ? 'Mark as returned' : ORDER_STATUS_LABEL[n]}</Button>)}</div>
          {o.status === 'return_requested' ? <p className="text-sm">The buyer requested a return. Mark it returned once you receive the goods; the admin then issues the refund.</p> : null}
        </Card>
      ) : null}
      <ol className="space-y-1 text-sm">{o.timeline.map((t, i) => <li key={i}>{fmtDate(t.at)} — {ORDER_STATUS_LABEL[t.status] ?? t.status}</li>)}</ol>
    </div>
  );
}
