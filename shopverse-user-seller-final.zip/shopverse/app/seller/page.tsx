'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, Stat, fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { ErrorState, LoadingState } from '@/components/ui/States';
import { friendlyError } from '@/lib/firebase/errors';
import { getSellerStats, listSellerOrders, type SellerStats } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import { ORDER_STATUS_LABEL, type Order } from '@/types';

/** Every number comes from Firestore: counts, sellerBalances (maintained by Cloud Functions) and the store document. Nothing is hardcoded. */
export default function Dashboard() {
  const { uid, store } = useSeller();
  const [s, setS] = useState<SellerStats | null>(null); const [recent, setRecent] = useState<Order[] | null>(null); const [err, setErr] = useState('');
  const load = useCallback(() => {
    setErr(''); setS(null);
    getSellerStats(uid).then(setS).catch((e) => setErr(friendlyError(e)));
    listSellerOrders(uid, '', null, 5).then((p) => setRecent(p.items)).catch(() => setRecent([]));
  }, [uid]);
  useEffect(() => { load(); }, [load]);
  if (err) return <ErrorState message={err} action={<Button onClick={load}>Try again</Button>} />;
  if (!s) return <LoadingState />;
  const b = s.balance;
  return (
    <div className="space-y-4">
      <PageHead title="Dashboard"><Link href="/seller/products/new" className="inline-flex min-h-11 items-center rounded-xl bg-brand-orange px-4 text-sm font-semibold text-white">Add product</Link></PageHead>
      <p className="text-sm">{store.name}</p>
      <section aria-label="Sales and orders" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total sales" value={formatMoney(b.grossSales)} hint="delivered orders, before commission" />
        <Stat label="Total orders" value={s.orders} />
        <Stat label="Pending orders" value={s.pendingOrders} hint="waiting for you to confirm" />
        <Stat label="Completed orders" value={s.delivered} hint={`${s.cancelled} cancelled`} />
      </section>
      <section aria-label="Store" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total products" value={s.products} hint={`${s.approvedProducts} live`} />
        <Stat label="Store rating" value={store.ratingCount ? `${store.ratingAvg.toFixed(1)} ★` : '—'} hint={store.ratingCount ? `${store.ratingCount} review${store.ratingCount === 1 ? '' : 's'}` : 'no reviews yet'} />
        <Stat label="Followers" value={store.followerCount} />
        <Stat label="Store visits" value="—" hint="visit tracking is not available yet" />
      </section>
      <section aria-label="Money" className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Stat label="Total earnings" value={formatMoney(b.netTotal)} hint="after commission" />
        <Stat label="Pending earnings" value={formatMoney(b.pending)} hint="released after the hold period" />
        <Stat label="Withdrawable balance" value={formatMoney(b.available)} hint={<Link href="/seller/withdrawals" className="font-semibold text-brand-purple underline">Withdraw</Link>} />
      </section>
      {!s.products ? <p className="rounded-card border border-dashed border-navy-100 p-4 text-sm dark:border-navy-500">You have no products yet. Add your first product; it goes live after review.</p> : null}
      <Card className="space-y-2">
        <div className="flex items-center justify-between"><h2 className="font-semibold">Recent orders</h2><Link href="/seller/orders" className="text-sm font-semibold text-brand-purple underline">All orders</Link></div>
        {recent === null ? <p className="text-sm">Loading…</p> : !recent.length ? <p className="text-sm">No orders yet.</p> : (
          <ul className="divide-y divide-navy-100 dark:divide-navy-500">{recent.map((o) => (
            <li key={o.id}><Link href={`/seller/orders/${o.id}`} className="flex flex-wrap items-center gap-2 py-2 text-sm hover:underline"><span className="min-w-0 flex-1"><strong>{o.orderNumber}</strong> · {fmtDate(o.createdAt)} · {o.itemCount} item(s)</span><span className="font-semibold">{formatMoney(o.total)}</span><Pill status={o.status} label={ORDER_STATUS_LABEL[o.status]} /></Link></li>))}</ul>
        )}
      </Card>
    </div>
  );
}
