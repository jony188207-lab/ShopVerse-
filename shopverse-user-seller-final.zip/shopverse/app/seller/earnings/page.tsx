'use client';
import { useEffect, useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, Stat, fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { friendlyError } from '@/lib/firebase/errors';
import { getBalance, listEarnings } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import type { Balance } from '@/types/seller';

export default function Page() {
  const { uid } = useSeller();
  const [b, setB] = useState<Balance | null>(null); const [err, setErr] = useState('');
  useEffect(() => { getBalance(uid).then(setB).catch((e) => setErr(friendlyError(e))); }, [uid]);
  const { items, more, error, busy, loadMore } = usePaged((c) => listEarnings(uid, c), [uid]);
  if (err || error) return <ErrorState message={err || error} />;
  return (
    <div className="space-y-4">
      <PageHead title="Earnings" />
      {b ? <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Available" value={formatMoney(b.available)} hint="ready to withdraw" /><Stat label="Pending" value={formatMoney(b.pending)} hint="held until the return window ends" />
        <Stat label="In withdrawals" value={formatMoney(b.reserved)} /><Stat label="Paid out" value={formatMoney(b.paidOut)} /></div> : <LoadingState />}
      <p className="text-sm">Earnings are created by the platform when an order is delivered. For cash on delivery they become withdrawable only after the platform confirms the cash was received, plus the hold period. Commission is set by the platform and cannot be edited.</p>
      {items === null ? <LoadingState /> : !items.length ? <EmptyState title="No earnings yet">They appear once an order is delivered.</EmptyState> : (
        <div className="overflow-x-auto rounded-card border border-navy-100 dark:border-navy-500">
          <table className="w-full min-w-[640px] text-left text-sm"><thead className="bg-navy-50 dark:bg-navy-700"><tr><th className="p-2">Item</th><th className="p-2">Gross</th><th className="p-2">Coupon</th><th className="p-2">Commission</th><th className="p-2">You earn</th><th className="p-2">Status</th><th className="p-2">Available</th></tr></thead>
            <tbody>{items.map((e) => <tr key={e.id} className="border-t border-navy-100 dark:border-navy-500"><td className="max-w-[14rem] truncate p-2">{e.title} × {e.quantity}</td><td className="p-2">{formatMoney(e.gross)}</td><td className="p-2">{e.couponShare ? `−${formatMoney(e.couponShare)}` : '—'}</td><td className="p-2">{formatMoney(e.commission)} ({e.commissionRate}%)</td><td className="p-2 font-semibold">{formatMoney(e.sellerAmount)}</td><td className="p-2"><Pill status={e.status} />{e.status === 'pending' && !e.remitted ? <span className="mt-1 block text-[11px]">Awaiting cash confirmation</span> : null}</td><td className="p-2">{e.remitted ? fmtDate(e.availableAt) : '—'}</td></tr>)}</tbody></table>
        </div>
      )}
      {more ? <Button variant="secondary" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
