'use client';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, Stat, fmtDate, selectCls, textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { cancelWithdrawal, getBalance, listWithdrawals, requestWithdrawal } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import { PAYOUT_METHODS, WITHDRAWAL_LABEL, type Balance } from '@/types/seller';

export default function Page() {
  const { uid } = useSeller(); const toast = useToast();
  const [b, setB] = useState<Balance | null>(null);
  const [amount, setAmount] = useState(''); const [method, setMethod] = useState<string>('bank_transfer'); const [details, setDetails] = useState(''); const [busy, setBusy] = useState(false);
  const reqId = useRef(crypto.randomUUID()); // same id on retry/double-tap => the server returns the same withdrawal
  const { items, more, error, busy: more2, loadMore, reload } = usePaged((c) => listWithdrawals(uid, c), [uid]);
  const refresh = () => getBalance(uid).then(setB).catch((e) => toast(friendlyError(e), 'error'));
  useEffect(() => { void refresh(); }, [uid]); // eslint-disable-line react-hooks/exhaustive-deps
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await requestWithdrawal({ requestId: reqId.current, amount: Number(amount), method, details }); reqId.current = crypto.randomUUID(); setAmount(''); toast('Withdrawal requested', 'success'); await Promise.all([refresh(), reload()]); }
    catch (err) { toast(friendlyError(err), 'error'); } finally { setBusy(false); }
  };
  const cancel = async (id: string) => { try { await cancelWithdrawal(id); toast('Cancelled; the amount is back in your balance', 'success'); await Promise.all([refresh(), reload()]); } catch (e) { toast(friendlyError(e), 'error'); } };
  if (error) return <ErrorState message={error} />;
  return (
    <div className="space-y-4">
      <PageHead title="Withdrawals" />
      {b ? <div className="grid grid-cols-3 gap-3"><Stat label="Available" value={formatMoney(b.available)} /><Stat label="Pending withdrawals" value={formatMoney(b.reserved)} /><Stat label="Paid out" value={formatMoney(b.paidOut)} /></div> : <LoadingState />}
      <Card>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
          <Field label="Amount" type="number" min={0.01} step="0.01" required value={amount} onChange={(e) => setAmount(e.target.value)} />
          <label className="text-sm font-medium">Payout method<select value={method} onChange={(e) => setMethod(e.target.value)} className={`mt-1 w-full ${selectCls}`}>{PAYOUT_METHODS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}</select></label>
          <div className="md:col-span-2"><label htmlFor="pd" className="text-sm font-medium">Payout details (account, phone or pickup info)</label><textarea id="pd" rows={2} required minLength={5} maxLength={500} value={details} onChange={(e) => setDetails(e.target.value)} className={textareaCls} /><p className="text-xs">Only you and platform admins can see this.</p></div>
          <div className="md:col-span-2"><Button type="submit" loading={busy}>Request withdrawal</Button></div>
        </form>
      </Card>
      {items === null ? <LoadingState /> : !items.length ? <EmptyState title="No withdrawals yet" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((w) => (
            <li key={w.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1"><p className="font-semibold">{formatMoney(w.amount)}</p><p className="text-xs">{fmtDate(w.createdAt)} · {PAYOUT_METHODS.find((m) => m.id === w.method)?.label ?? w.method}{w.note ? ` · ${w.note}` : ''}</p></div>
              <Pill status={w.status} label={WITHDRAWAL_LABEL[w.status]} />
              {w.status === 'pending' ? <Button variant="ghost" onClick={() => cancel(w.id)}>Cancel</Button> : null}
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" loading={more2} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
