'use client';
import Link from 'next/link';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { deleteVideo, listMyVideos, resubmitVideo, setVideoVisibility } from '@/services/videoService';
import { VIDEO_STATUS_LABEL, type Video } from '@/types/video';

export default function Page() {
  const { uid } = useSeller(); const toast = useToast();
  const { items, setItems, more, error, busy, loadMore } = usePaged((c) => listMyVideos(uid, c), [uid]);
  const patch = (id: string, p: Partial<Video>) => setItems((l) => l?.map((v) => (v.id === id ? { ...v, ...p } : v)) ?? null);
  const run = async (fn: () => Promise<unknown>, after: () => void) => { try { await fn(); after(); } catch (e) { toast(friendlyError(e), 'error'); } };
  return (
    <div>
      <PageHead title="Videos"><Link href="/video/upload" className="rounded-xl bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white">Upload video</Link></PageHead>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No videos yet">Upload a short product video; it goes live after review.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((v) => (
            <li key={v.id} className="flex flex-wrap items-center gap-3 p-3 text-sm">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              {v.thumbnailUrl ? <img src={v.thumbnailUrl} alt="" loading="lazy" className="h-20 w-12 shrink-0 rounded-lg object-cover" /> : <div className="h-20 w-12 shrink-0 rounded-lg bg-navy-100" />}
              <div className="min-w-0 flex-1"><p className="truncate font-semibold">{v.title}</p><p className="text-xs">{fmtDate(v.createdAt)} · {v.views} views · {v.likes} likes · {v.commentsCount} comments · {v.visibility}</p>
                {(v.status === 'rejected' || v.status === 'suspended') && v.moderationNote ? <p className="text-xs text-red-700">{v.moderationNote}</p> : null}</div>
              <Pill status={v.status === 'pending_review' ? 'pending' : v.status === 'published' ? 'approved' : v.status} label={VIDEO_STATUS_LABEL[v.status]} />
              <div className="flex flex-wrap gap-1">
                {v.status === 'published' ? <Link href={`/video?v=${v.id}`} className="rounded-xl px-3 py-2 font-semibold text-brand-purple">Watch</Link> : null}
                {v.status === 'published' ? <Button variant="ghost" onClick={() => run(() => setVideoVisibility(v.id, v.visibility === 'public' ? 'private' : 'public'), () => patch(v.id, { visibility: v.visibility === 'public' ? 'private' : 'public' }))}>{v.visibility === 'public' ? 'Make private' : 'Make public'}</Button> : null}
                {v.status === 'draft' || v.status === 'rejected' ? <Button variant="ghost" onClick={() => run(() => resubmitVideo(v.id), () => patch(v.id, { status: 'pending_review' }))}>{v.status === 'draft' ? 'Submit for review' : 'Resubmit'}</Button> : null}
                <Button variant="ghost" onClick={() => window.confirm(`Delete “${v.title}”?`) && run(() => deleteVideo(v), () => setItems((l) => l?.filter((x) => x.id !== v.id) ?? null))}>Delete</Button>
              </div>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
