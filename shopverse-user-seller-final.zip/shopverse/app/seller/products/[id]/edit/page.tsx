'use client';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead } from '@/components/seller/ui';
import { SellerProductForm } from '@/components/seller/SellerProductForm';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { getMyProduct } from '@/services/sellerService';
import type { Product } from '@/types';

export default function Page() {
  const { id } = useParams<{ id: string }>(); const { uid } = useSeller();
  const [p, setP] = useState<Product | null | undefined>(undefined);
  useEffect(() => { getMyProduct(id, uid).then(setP).catch(() => setP(null)); }, [id, uid]);
  if (p === undefined) return <LoadingState />;
  if (!p) return <EmptyState title="Product not found">It does not exist or is not yours.</EmptyState>;
  return <><PageHead title="Edit product" /><SellerProductForm existing={p} /></>;
}
