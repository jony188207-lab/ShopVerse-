'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { deleteMyProduct, listMyProducts, updateStockOnly } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import { PRODUCT_STATUS_LABEL, type Product } from '@/types';

export default function Page() {
  const { uid } = useSeller(); const toast = useToast();
  const [status, setStatus] = useState('');
  const { items, setItems, more, error, busy, loadMore, reload } = usePaged((c) => listMyProducts(uid, status, c), [uid, status]);
  const stock = async (p: Product) => {
    const v = window.prompt(`New stock for “${p.title}”`, String(p.stock)); if (v === null) return;
    const n = Math.floor(Number(v)); if (!(n >= 0)) return toast('Enter a number, 0 or more', 'error');
    try { await updateStockOnly(p, n, p.variants); toast('Stock updated', 'success'); void reload(); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  const del = async (p: Product) => {
    if (!window.confirm(`Delete “${p.title}”? This cannot be undone.`)) return;
    try { await deleteMyProduct(p.id); setItems((x) => x?.filter((i) => i.id !== p.id) ?? null); toast('Deleted', 'success'); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  return (
    <div>
      <PageHead title="Products"><Link href="/seller/products/new" className="rounded-xl bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white">Add product</Link></PageHead>
      <label className="mb-3 block text-sm font-medium">Status <select value={status} onChange={(e) => setStatus(e.target.value)} className={selectCls}><option value="">All</option>{Object.entries(PRODUCT_STATUS_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No products">Nothing here yet.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center gap-3 p-3">
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-navy-100 dark:bg-navy-700">{p.images[0] ? <Image src={p.images[0]} alt="" fill sizes="56px" className="object-cover" /> : null}</div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{p.title}</p>
                <p className="text-xs">{formatMoney(p.price)} · stock {p.stock} · {p.salesCount} sold</p>
                {p.status === 'rejected' || p.status === 'suspended' ? <p className="text-xs text-red-700">{p.moderationNote || 'See the edit page'}</p> : null}
              </div>
              <Pill status={p.status} label={PRODUCT_STATUS_LABEL[p.status]} />
              <div className="flex flex-wrap gap-1">
                <Link href={`/seller/products/${p.id}/edit`} className="rounded-xl px-3 py-2 text-sm font-semibold text-brand-purple">Edit</Link>
                {p.status === 'approved' || p.status === 'out_of_stock' ? <Button variant="ghost" onClick={() => stock(p)}>Update stock</Button> : null}
                <Button variant="ghost" onClick={() => del(p)}>Delete</Button>
              </div>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
