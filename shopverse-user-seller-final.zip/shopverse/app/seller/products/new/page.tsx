'use client';
import { PageHead } from '@/components/seller/ui';
import { SellerProductForm } from '@/components/seller/SellerProductForm';
export default function Page() { return <><PageHead title="Add product" /><p className="mb-3 text-sm">New products are reviewed by our team before they appear in the shop.</p><SellerProductForm existing={null} /></>; }
