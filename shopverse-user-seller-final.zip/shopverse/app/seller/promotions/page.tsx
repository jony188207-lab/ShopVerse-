'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { cancelPromotion, listMyProducts, listPromotions, submitPromotion } from '@/services/sellerService';
import type { Product } from '@/types';
import type { Promotion } from '@/types/seller';

export default function Page() {
  const { uid, store } = useSeller(); const toast = useToast();
  const [list, setList] = useState<Promotion[] | null>(null); const [products, setProducts] = useState<Product[]>([]); const [err, setErr] = useState('');
  const [f, setF] = useState({ productId: '', type: 'featured' as 'featured' | 'flash_sale', startsAt: '', endsAt: '', note: '' }); const [busy, setBusy] = useState(false);
  const load = useCallback(() => listPromotions(uid).then(setList).catch((e) => { setErr(friendlyError(e)); setList([]); }), [uid]);
  useEffect(() => { void load(); listMyProducts(uid, 'approved', null, 100).then((p) => setProducts(p.items)).catch((e) => toast(friendlyError(e), 'error')); }, [load, uid]);
  const title = (id: string) => products.find((p) => p.id === id)?.title ?? id;
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await submitPromotion(uid, store.id, f); toast('Request sent for admin review', 'success'); setF({ ...f, productId: '', note: '' }); await load(); }
    catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <PageHead title="Promotions" />
      <p className="text-sm">Ask to feature an approved product on the Home page or in the flash sale rail. An admin reviews every request; nothing goes live automatically. Flash sales need a product that already shows a discount. Max 14 days.</p>
      <Card>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
          <label className="text-sm font-medium">Product<select required value={f.productId} onChange={(e) => setF({ ...f, productId: e.target.value })} className={`mt-1 w-full ${selectCls}`}><option value="">Choose an approved product…</option>{products.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}</select></label>
          <label className="text-sm font-medium">Type<select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value as 'featured' | 'flash_sale' })} className={`mt-1 w-full ${selectCls}`}><option value="featured">Featured on Home</option><option value="flash_sale">Flash sale</option></select></label>
          <Field label="Starts" type="datetime-local" required value={f.startsAt} onChange={(e) => setF({ ...f, startsAt: e.target.value })} />
          <Field label="Ends" type="datetime-local" required value={f.endsAt} onChange={(e) => setF({ ...f, endsAt: e.target.value })} />
          <div className="md:col-span-2"><Field label="Note to the reviewer (optional)" maxLength={500} value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></div>
          <div className="md:col-span-2"><Button type="submit" loading={busy}>Submit request</Button></div>
        </form>
      </Card>
      {err ? <ErrorState message={err} /> : list === null ? <LoadingState /> : !list.length ? <EmptyState title="No promotion requests" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {list.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1"><p className="truncate font-semibold">{title(p.productId)}</p><p className="text-xs">{p.type === 'featured' ? 'Featured' : 'Flash sale'} · {fmtDate(p.startsAt)} → {fmtDate(p.endsAt)}{p.note ? ` · ${p.note}` : ''}</p></div>
              <Pill status={p.status} />
              {p.status === 'pending' ? <Button variant="ghost" onClick={async () => { try { await cancelPromotion(p.id); await load(); } catch (e) { toast(friendlyError(e), 'error'); } }}>Withdraw</Button> : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
