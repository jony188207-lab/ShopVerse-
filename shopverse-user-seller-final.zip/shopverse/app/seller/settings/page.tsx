'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';
import { LoadingState } from '@/components/ui/States';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { getMyStore, getMyStorePrivate, saveStoreSettings, type StoreSettings } from '@/services/sellerService';

export default function Page() {
  const { store, setStore } = useSeller(); const toast = useToast();
  const [f, setF] = useState<StoreSettings | null>(null); const [logo, setLogo] = useState<File | null>(null); const [banner, setBanner] = useState<File | null>(null); const [busy, setBusy] = useState(false);
  useEffect(() => {
    getMyStorePrivate(store.id).then((p) => setF({ name: store.name, description: store.description, city: store.city ?? '', country: store.country ?? '', shippingFee: store.shippingFee, freeShippingOver: store.freeShippingOver ?? null, returnPolicy: store.returnPolicy ?? '', shippingInfo: store.shippingInfo ?? '', ...p })).catch(() => toast('Could not load your contact details', 'error'));
  }, [store, toast]);
  if (!f) return <LoadingState />;
  const set = <K extends keyof StoreSettings>(k: K, v: StoreSettings[K]) => setF((x) => (x ? { ...x, [k]: v } : x));
  const t = (k: keyof StoreSettings) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => set(k, e.target.value as never);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await saveStoreSettings(store, f, logo, banner); const fresh = await getMyStore(store.ownerId); if (fresh) setStore(fresh); setLogo(null); setBanner(null); toast('Store settings saved', 'success'); }
    catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
      <div className="md:col-span-2"><PageHead title="Store settings" /><p className="text-sm">Store address (slug): <strong>/store/{store.slug}</strong> — it cannot be changed. Commission is set by the platform.</p></div>
      <Field label="Store name" required minLength={2} maxLength={80} value={f.name} onChange={t('name')} />
      <Field label="City (public)" value={f.city} onChange={t('city')} />
      <Field label="Country (public)" value={f.country} onChange={t('country')} />
      <Field label="Shipping fee per order" type="number" min={0} step="0.01" value={f.shippingFee} onChange={(e) => set('shippingFee', Number(e.target.value))} />
      <Field label="Free shipping over (optional)" type="number" min={0} step="0.01" value={f.freeShippingOver ?? ''} onChange={(e) => set('freeShippingOver', e.target.value === '' ? null : Number(e.target.value))} />
      <div className="md:col-span-2"><label htmlFor="sd" className="text-sm font-medium">Description</label><textarea id="sd" rows={4} maxLength={2000} value={f.description} onChange={t('description')} className={textareaCls} /></div>
      <div><label htmlFor="sr" className="text-sm font-medium">Return policy</label><textarea id="sr" rows={3} maxLength={2000} value={f.returnPolicy} onChange={t('returnPolicy')} className={textareaCls} /></div>
      <div><label htmlFor="ss" className="text-sm font-medium">Shipping information</label><textarea id="ss" rows={3} maxLength={2000} value={f.shippingInfo} onChange={t('shippingInfo')} className={textareaCls} /></div>
      <fieldset className="grid gap-3 rounded-card border border-navy-100 p-3 dark:border-navy-500 md:col-span-2 md:grid-cols-3"><legend className="px-1 text-sm font-semibold">Private contact details (not shown publicly)</legend>
        <Field label="Phone" required minLength={5} maxLength={25} value={f.phone} onChange={t('phone')} /><Field label="Email" type="email" required value={f.email} onChange={t('email')} /><Field label="Address" required minLength={3} maxLength={300} value={f.address} onChange={t('address')} /></fieldset>
      <div><label htmlFor="lg" className="text-sm font-medium">Logo (replace)</label><input id="lg" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setLogo(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
      <div><label htmlFor="bn" className="text-sm font-medium">Banner (replace)</label><input id="bn" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setBanner(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
      <div className="md:col-span-2"><Button type="submit" loading={busy}>Save settings</Button></div>
    </form>
  );
}
