'use client';
import { useEffect, useMemo, useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Stat } from '@/components/seller/ui';
import { Card } from '@/components/ui/Card';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { friendlyError } from '@/lib/firebase/errors';
import { getSellerStats, listEarnings, type SellerStats } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import type { Earning } from '@/types/seller';

export default function Page() {
  const { uid } = useSeller();
  const [s, setS] = useState<SellerStats | null>(null); const [earn, setEarn] = useState<Earning[]>([]); const [err, setErr] = useState('');
  useEffect(() => { getSellerStats(uid).then(setS).catch((e) => setErr(friendlyError(e))); listEarnings(uid, null, 100).then((p) => setEarn(p.items)).catch(() => undefined); }, [uid]);
  const days = useMemo(() => {
    const m = new Map<string, number>();
    earn.filter((e) => e.status !== 'reversed' && e.createdAt).forEach((e) => { const k = e.createdAt!.toISOString().slice(0, 10); m.set(k, (m.get(k) ?? 0) + e.gross); });
    return [...m.entries()].sort().slice(-14);
  }, [earn]);
  if (err) return <ErrorState message={err} />;
  if (!s) return <LoadingState />;
  const max = Math.max(1, ...days.map(([, v]) => v));
  const b = s.balance;
  return (
    <div className="space-y-4">
      <PageHead title="Analytics" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Products" value={s.products} hint={`${s.approvedProducts} approved`} /><Stat label="Orders" value={s.orders} hint={`${s.delivered} delivered · ${s.cancelled} cancelled`} />
        <Stat label="Units sold" value={b.unitsSold} hint="delivered orders" /><Stat label="Gross sales" value={formatMoney(b.grossSales)} />
        <Stat label="Platform commission" value={formatMoney(b.commissionTotal)} /><Stat label="Net earnings" value={formatMoney(b.netTotal)} />
        <Stat label="Pending earnings" value={formatMoney(b.pending)} /><Stat label="Completed orders" value={s.delivered} />
      </div>
      <Card className="space-y-2">
        <h2 className="font-semibold">Gross sales by day (latest delivered items)</h2>
        {!days.length ? <EmptyState title="No sales data yet">The chart fills in after your first delivered order.</EmptyState> : (
          <div className="flex h-40 items-end gap-1" role="img" aria-label="Gross sales by day">
            {days.map(([d, v]) => <div key={d} className="flex flex-1 flex-col items-center justify-end gap-1"><div className="w-full rounded-t bg-brand-purple" style={{ height: `${Math.max(4, (v / max) * 100)}%` }} title={`${d}: ${formatMoney(v)}`} /><span className="text-[10px]">{d.slice(5)}</span></div>)}
          </div>
        )}
      </Card>
      <p className="text-sm text-navy-500 dark:text-navy-100">Product views are not tracked yet, so they are not shown.</p>
    </div>
  );
}
