'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useSeller } from '@/components/seller/SellerProvider';
import { Avatar } from '@/components/Avatar';
import { PageHead, Pill } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { useAuth } from '@/hooks/useAuth';
import { logout } from '@/services/authService';

export default function SellerProfile() {
  const { store } = useSeller(); const { user } = useAuth(); const router = useRouter();
  const link = 'block min-h-11 py-2 font-semibold text-brand-purple underline';
  return (
    <div className="space-y-4">
      <PageHead title="Seller profile" />
      <Card className="flex items-center gap-4">
        <Avatar name={store.name} src={store.logoUrl || undefined} size={72} />
        <div className="min-w-0 space-y-1"><h2 className="truncate text-lg font-bold">{store.name}</h2><p className="text-sm">/store/{store.slug}</p><Pill status={store.status} label={store.status === 'approved' ? 'Approved seller' : store.status} />
          <p className="text-sm">{store.ratingCount ? `${store.ratingAvg.toFixed(1)} ★ (${store.ratingCount})` : 'No reviews yet'} · {store.followerCount} followers</p></div>
      </Card>
      <Card className="space-y-1">
        <Link href="/seller/settings" className={link}>Store settings</Link><Link href={`/store/${store.slug}`} className={link}>View public store</Link>
        <Link href="/seller/menu" className={link}>All seller tools</Link><Link href="/profile" className={link}>Switch to my customer profile</Link>
        <p className="pt-1 text-xs">Signed in as {user?.email}</p>
      </Card>
      <Button variant="ghost" className="w-full" onClick={async () => { await logout(); router.replace('/'); }}>Log out</Button>
    </div>
  );
}
