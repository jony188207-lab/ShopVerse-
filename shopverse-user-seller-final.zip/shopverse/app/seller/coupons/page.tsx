'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { deleteCoupon, listCoupons, saveCoupon, setCouponActive, type CouponForm } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';
import type { Coupon } from '@/types/seller';

const EMPTY: CouponForm = { code: '', discountType: 'percent', discountValue: 10, minOrder: 0, maxDiscount: 0, usageLimit: 0, startsAt: '', endsAt: '', active: true };
const local = (d: Date | null) => (d ? new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '');

export default function Page() {
  const { uid } = useSeller(); const toast = useToast();
  const [list, setList] = useState<Coupon[] | null>(null); const [err, setErr] = useState('');
  const [f, setF] = useState<CouponForm>(EMPTY); const [editing, setEditing] = useState(false); const [busy, setBusy] = useState(false);
  const load = useCallback(() => listCoupons(uid).then(setList).catch((e) => { setErr(friendlyError(e)); setList([]); }), [uid]);
  useEffect(() => { void load(); }, [load]);
  const set = <K extends keyof CouponForm>(k: K, v: CouponForm[K]) => setF((x) => ({ ...x, [k]: v }));
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await saveCoupon(uid, f, editing); toast('Coupon saved', 'success'); setF(EMPTY); setEditing(false); await load(); }
    catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  const edit = (c: Coupon) => { setEditing(true); setF({ code: c.code, discountType: c.discountType, discountValue: c.discountValue, minOrder: c.minOrder, maxDiscount: c.maxDiscount, usageLimit: c.usageLimit, startsAt: local(c.startsAt), endsAt: local(c.endsAt), active: c.active }); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const act = async (fn: () => Promise<unknown>) => { try { await fn(); await load(); } catch (x) { toast(friendlyError(x), 'error'); } };
  return (
    <div className="space-y-4">
      <PageHead title="Coupons" />
      <p className="text-sm">Coupons apply only to your store&apos;s items. The discount is validated and applied by the server at checkout, never by the browser.</p>
      <Card>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-3">
          <Field label="Code (A–Z, 0–9)" required disabled={editing} maxLength={20} value={f.code} onChange={(e) => set('code', e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))} />
          <label className="text-sm font-medium">Type<select value={f.discountType} onChange={(e) => set('discountType', e.target.value as 'percent' | 'fixed')} className={`mt-1 w-full ${selectCls}`}><option value="percent">Percent off</option><option value="fixed">Fixed amount off</option></select></label>
          <Field label={f.discountType === 'percent' ? 'Percent (1–100)' : 'Amount off'} type="number" min={0.01} step="0.01" required value={f.discountValue || ''} onChange={(e) => set('discountValue', Number(e.target.value))} />
          <Field label="Minimum order (0 = none)" type="number" min={0} step="0.01" value={f.minOrder} onChange={(e) => set('minOrder', Number(e.target.value))} />
          <Field label="Max discount (0 = no cap)" type="number" min={0} step="0.01" value={f.maxDiscount} onChange={(e) => set('maxDiscount', Number(e.target.value))} />
          <Field label="Usage limit (0 = unlimited)" type="number" min={0} step={1} value={f.usageLimit} onChange={(e) => set('usageLimit', Number(e.target.value))} />
          <Field label="Starts (optional)" type="datetime-local" value={f.startsAt} onChange={(e) => set('startsAt', e.target.value)} />
          <Field label="Ends (optional)" type="datetime-local" value={f.endsAt} onChange={(e) => set('endsAt', e.target.value)} />
          <label className="flex min-h-11 items-center gap-2 self-end text-sm"><input type="checkbox" className="h-5 w-5" checked={f.active} onChange={(e) => set('active', e.target.checked)} />Active</label>
          <div className="flex gap-2 md:col-span-3"><Button type="submit" loading={busy}>{editing ? 'Save coupon' : 'Create coupon'}</Button>{editing ? <Button type="button" variant="ghost" onClick={() => { setEditing(false); setF(EMPTY); }}>Cancel edit</Button> : null}</div>
        </form>
      </Card>
      {err ? <ErrorState message={err} /> : list === null ? <LoadingState /> : !list.length ? <EmptyState title="No coupons yet" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {list.map((c) => (
            <li key={c.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1"><p className="font-mono font-bold">{c.code}</p><p className="text-xs">{c.discountType === 'percent' ? `${c.discountValue}% off` : `${formatMoney(c.discountValue)} off`}{c.minOrder ? ` · min ${formatMoney(c.minOrder)}` : ''}{c.maxDiscount ? ` · cap ${formatMoney(c.maxDiscount)}` : ''} · used {c.usedCount}{c.usageLimit ? `/${c.usageLimit}` : ''} · {fmtDate(c.startsAt)} → {fmtDate(c.endsAt)}</p></div>
              <Pill status={c.active ? 'approved' : 'draft'} label={c.active ? 'Active' : 'Paused'} />
              <Button variant="ghost" onClick={() => edit(c)}>Edit</Button>
              <Button variant="ghost" onClick={() => act(() => setCouponActive(c.id, !c.active))}>{c.active ? 'Pause' : 'Activate'}</Button>
              <Button variant="ghost" onClick={() => window.confirm(`Delete ${c.code}?`) && act(() => deleteCoupon(c.id))}>Delete</Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
