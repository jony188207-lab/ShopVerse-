import { RefreshButton } from '@/components/RefreshButton';
export const metadata = { title: 'Offline', robots: { index: false } };
// Precached by the service worker and shown when a page cannot be fetched without a connection.
export default function OfflinePage() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-20 text-center">
      <h1 className="text-2xl font-extrabold">You are offline</h1>
      <p className="text-sm text-navy-500 dark:text-navy-100">ShopVerse needs a connection to show products, orders and messages. Check your network and try again.</p>
      <RefreshButton />
    </div>
  );
}
