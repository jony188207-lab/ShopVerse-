import type { MetadataRoute } from 'next';

/** Served at /manifest.webmanifest. */
export default function manifest(): MetadataRoute.Manifest {
  return {
    id: '/', name: 'ShopVerse', short_name: 'ShopVerse', description: 'Shop • Watch • Shop — marketplace and video shopping.',
    start_url: '/?source=pwa', scope: '/', display: 'standalone', orientation: 'portrait', lang: 'en',
    background_color: '#0B1B36', theme_color: '#0B1B36', categories: ['shopping', 'lifestyle'],
    icons: [
      { src: '/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
    shortcuts: [
      { name: 'Shop', url: '/shop', icons: [{ src: '/icon-192.png', sizes: '192x192' }] },
      { name: 'Videos', url: '/video', icons: [{ src: '/icon-192.png', sizes: '192x192' }] },
      { name: 'My orders', url: '/orders', icons: [{ src: '/icon-192.png', sizes: '192x192' }] },
      { name: 'Messages', url: '/messages', icons: [{ src: '/icon-192.png', sizes: '192x192' }] },
    ],
  };
}
