'use client';
import Link from 'next/link';
import { useState } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { InstallPrompt } from '@/components/InstallPrompt';
import { NotificationToggle } from '@/components/NotificationToggle';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { requestPasswordReset } from '@/services/authService';

function Inner() {
  const { user } = useAuth(); const toast = useToast(); const [busy, setBusy] = useState(false);
  if (!user) return null;
  const reset = async () => {
    setBusy(true);
    try { await requestPasswordReset(user.email ?? ''); toast('Password reset email sent', 'success'); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  const link = 'block min-h-11 py-2 font-semibold text-brand-purple underline';
  return (
    <div className="mx-auto max-w-lg space-y-4 px-4">
      <h1 className="text-2xl font-extrabold">Settings</h1>
      <Card className="space-y-1"><h2 className="font-semibold">Account</h2><p className="text-sm">{user.email}</p>
        <Link href="/profile/edit" className={link}>Edit profile</Link><Link href="/profile/addresses" className={link}>Addresses</Link>
        {!user.emailVerified ? <Link href="/verify-email" className={link}>Verify email</Link> : null}
        <Button variant="ghost" loading={busy} onClick={reset}>Send password reset email</Button></Card>
      <Card className="space-y-2"><h2 className="font-semibold">Notifications</h2><NotificationToggle uid={user.uid} /><Link href="/notifications/preferences" className={link}>Choose what you get notified about</Link></Card>
      <Card className="flex items-center justify-between"><h2 className="font-semibold">Theme</h2><ThemeToggle /></Card>
      <InstallPrompt />
    </div>
  );
}
export default function Page() { return <AuthGuard><Inner /></AuthGuard>; }
