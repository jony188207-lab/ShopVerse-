'use client';
import { AuthGuard } from '@/components/AuthGuard';
import { AddressManager } from '@/components/AddressManager';

export default function AddressesPage() {
  return <AuthGuard><div className="mx-auto max-w-lg space-y-4 px-4"><h1 className="text-2xl font-extrabold">My addresses</h1><AddressManager /></div></AuthGuard>;
}
