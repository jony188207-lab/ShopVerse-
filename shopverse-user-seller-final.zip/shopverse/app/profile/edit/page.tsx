'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { Avatar } from '@/components/Avatar';
import { textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';
import { LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { getProfile, normalizeUsername, saveProfile, type Profile } from '@/services/userService';

function Form() {
  const { user, refresh } = useAuth(); const toast = useToast(); const router = useRouter();
  const [cur, setCur] = useState<Profile | null | undefined>(undefined);
  const [f, setF] = useState({ displayName: '', username: '', bio: '' });
  const [photo, setPhoto] = useState<File | null>(null); const [preview, setPreview] = useState(''); const [busy, setBusy] = useState(false);
  useEffect(() => { if (user) getProfile(user.uid).then((p) => { setCur(p); setF({ displayName: p?.displayName ?? user.displayName ?? '', username: p?.username ?? '', bio: p?.bio ?? '' }); }).catch(() => setCur(null)); }, [user?.uid]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!photo) { setPreview(''); return; } const u = URL.createObjectURL(photo); setPreview(u); return () => URL.revokeObjectURL(u); }, [photo]);
  if (!user || cur === undefined) return <LoadingState />;
  const submit = async (e: FormEvent) => {
    e.preventDefault(); if (busy) return; setBusy(true);
    try { await saveProfile(user, cur, f, photo); await refresh(); toast('Profile saved', 'success'); router.push('/profile'); }
    catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="mx-auto max-w-lg space-y-4 px-4" aria-busy={busy}>
      <h1 className="text-2xl font-extrabold">Edit profile</h1>
      <div className="flex items-center gap-4">
        <Avatar name={f.displayName || '?'} src={preview || cur?.photoURL || user.photoURL || undefined} size={80} />
        <div><label htmlFor="ph" className="text-sm font-medium">Profile photo</label><input id="ph" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setPhoto(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
      </div>
      <Field label="Name" required minLength={2} maxLength={60} value={f.displayName} onChange={(e) => setF({ ...f, displayName: e.target.value })} />
      <Field label="Username" maxLength={21} autoCapitalize="none" spellCheck={false} value={f.username} onChange={(e) => setF({ ...f, username: normalizeUsername(e.target.value) })} />
      <p className="-mt-2 text-xs">3–20 characters: lowercase letters, numbers, underscore. Must be unique.</p>
      <div><label htmlFor="bio" className="text-sm font-medium">Bio</label><textarea id="bio" rows={3} maxLength={300} value={f.bio} onChange={(e) => setF({ ...f, bio: e.target.value })} className={textareaCls} /></div>
      <Button type="submit" loading={busy} className="w-full">Save changes</Button>
    </form>
  );
}
export default function Page() { return <AuthGuard><Form /></AuthGuard>; }
