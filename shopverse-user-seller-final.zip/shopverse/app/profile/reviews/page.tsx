'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { StarRating } from '@/components/StarRating';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { friendlyError } from '@/lib/firebase/errors';
import { listMyReviews } from '@/services/socialService';
import type { Review } from '@/types';

function List() {
  const { user } = useAuth();
  const [rows, setRows] = useState<Review[] | null>(null); const [err, setErr] = useState('');
  const load = useCallback(() => { if (!user) return; setErr(''); setRows(null); listMyReviews(user.uid).then(setRows).catch((e) => setErr(friendlyError(e))); }, [user]);
  useEffect(() => { load(); }, [load]);
  if (err) return <ErrorState message={err} action={<Button onClick={load}>Try again</Button>} />;
  if (!rows) return <LoadingState />;
  return (
    <div className="mx-auto max-w-2xl space-y-3 px-4">
      <h1 className="text-2xl font-extrabold">My reviews</h1>
      {!rows.length ? <EmptyState title="No reviews yet" action={<Link href="/orders" className="font-semibold text-brand-purple underline">Review a delivered order</Link>}>You can review products after they are delivered.</EmptyState> : (
        <ul className="space-y-2">{rows.map((r) => (
          <li key={r.id}><Card className="space-y-1"><div className="flex items-center justify-between gap-2"><StarRating value={r.rating} /><span className="text-xs">{r.createdAt?.toLocaleDateString() ?? ''}</span></div>
            {r.text ? <p className="text-sm">{r.text}</p> : null}
            {r.sellerResponse ? <p className="rounded-lg bg-navy-50 p-2 text-sm dark:bg-navy-800"><strong>Seller reply:</strong> {r.sellerResponse}</p> : null}
            <Link href={`/product/${r.productId}`} className="text-sm font-semibold text-brand-purple underline">View product</Link></Card></li>))}</ul>
      )}
    </div>
  );
}
export default function Page() { return <AuthGuard><List /></AuthGuard>; }
