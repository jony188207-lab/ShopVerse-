'use client';
import { useCallback, useEffect, useState } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { Avatar } from '@/components/Avatar';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { friendlyError } from '@/lib/firebase/errors';
import { listFollowers, type PersonRow } from '@/services/socialService';

function List() {
  const { user } = useAuth();
  const [rows, setRows] = useState<PersonRow[] | null>(null); const [err, setErr] = useState('');
  const load = useCallback(() => { if (!user) return; setErr(''); setRows(null); listFollowers(user.uid).then(setRows).catch((e) => setErr(friendlyError(e))); }, [user]);
  useEffect(() => { load(); }, [load]);
  if (err) return <ErrorState message={err} action={<Button onClick={load}>Try again</Button>} />;
  if (!rows) return <LoadingState />;
  return (
    <div className="mx-auto max-w-lg space-y-3 px-4">
      <h1 className="text-2xl font-extrabold">Followers</h1>
      {!rows.length ? <EmptyState title="Nobody here yet">People who follow you will show up here.</EmptyState> : (
        <ul className="space-y-2">{rows.map((r) => <li key={r.uid}><Card className="flex items-center gap-3"><Avatar name={r.name} src={r.photoURL} /><div className="min-w-0"><p className="truncate font-semibold">{r.name}</p>{r.username ? <p className="text-sm text-brand-purple">@{r.username}</p> : null}</div></Card></li>)}</ul>
      )}
    </div>
  );
}
export default function Page() { return <AuthGuard><List /></AuthGuard>; }
