'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Heart, MapPin, Package, PlayCircle, Settings, Star, UserCheck, Users, type LucideIcon } from 'lucide-react';
import { AuthGuard } from '@/components/AuthGuard';
import { Avatar } from '@/components/Avatar';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { InstallPrompt } from '@/components/InstallPrompt';
import { useAuth } from '@/hooks/useAuth';
import { useSellerStatus } from '@/hooks/useSellerStatus';
import { logout } from '@/services/authService';
import { followCounts } from '@/services/socialService';
import { getProfile, type Profile } from '@/services/userService';

const TILES: { href: string; label: string; icon: LucideIcon }[] = [
  { href: '/orders', label: 'Orders', icon: Package }, { href: '/wishlist', label: 'Wishlist', icon: Heart }, { href: '/profile/reviews', label: 'Reviews', icon: Star },
  { href: '/video/saved', label: 'Saved videos', icon: PlayCircle }, { href: '/profile/following', label: 'Following', icon: UserCheck }, { href: '/profile/followers', label: 'Followers', icon: Users },
  { href: '/profile/addresses', label: 'Addresses', icon: MapPin }, { href: '/profile/settings', label: 'Settings', icon: Settings },
];

function SellerBlock() {
  const { state, application } = useSellerStatus();
  if (state === 'loading') return null;
  const box = 'space-y-2';
  if (state === 'approved') return <Card className={box}><h2 className="font-semibold">Seller Center</h2><p className="text-sm">Your store is approved.</p><Link href="/seller" className="inline-flex min-h-11 items-center rounded-xl bg-brand-orange px-4 text-sm font-semibold text-white">Open Seller Center</Link></Card>;
  if (state === 'pending') return <Card className={box}><h2 className="font-semibold">Seller Application: Pending</h2><p className="text-sm">We are reviewing “{application?.storeName}”. You will be notified when it is decided.</p><Link href="/become-seller" className="text-sm font-semibold text-brand-purple underline">View or edit application</Link></Card>;
  if (state === 'rejected') return <Card className={box}><h2 className="font-semibold">Seller Application: Rejected</h2><p className="text-sm">{application?.reviewNote || 'No reason was given.'}</p><Link href="/become-seller" className="text-sm font-semibold text-brand-purple underline">Fix and resubmit</Link></Card>;
  if (state === 'suspended') return <Card className={box}><h2 className="font-semibold">Seller account: Suspended</h2><p className="text-sm">{application?.reviewNote || 'Contact support for details.'}</p></Card>;
  return <Card className={box}><h2 className="font-semibold">Sell on ShopVerse</h2><p className="text-sm">Open your own store and reach our customers.</p><Link href="/become-seller" className="inline-flex min-h-11 items-center rounded-xl bg-brand-orange px-4 text-sm font-semibold text-white">Become a Seller</Link></Card>;
}

function ProfileInner() {
  const { user, refresh } = useAuth();
  const router = useRouter();
  const [p, setP] = useState<Profile | null>(null);
  const [c, setC] = useState<{ followers: number; following: number } | null>(null);
  useEffect(() => {
    if (!user) return;
    void refresh().catch(() => undefined); // pick up a role change made by the Admin App
    getProfile(user.uid).then(setP).catch(() => setP(null));
    followCounts(user.uid).then(setC).catch(() => setC(null));
  }, [user?.uid]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!user) return null;
  const name = p?.displayName || user.displayName || 'Shopper';
  return (
    <div className="mx-auto max-w-2xl space-y-4 px-4">
      <Card className="flex items-start gap-4">
        <Avatar name={name} src={p?.photoURL || user.photoURL || undefined} size={72} />
        <div className="min-w-0 flex-1 space-y-0.5">
          <h1 className="truncate text-xl font-extrabold">{name}</h1>
          {p?.username ? <p className="text-sm text-brand-purple">@{p.username}</p> : <p className="text-sm">No username yet</p>}
          <p className="truncate text-sm">{user.email}</p>
          {user.emailVerified ? <p className="text-xs text-green-700 dark:text-green-400">Email verified</p> : <p className="text-xs">Email not verified. <Link className="font-semibold text-brand-purple underline" href="/verify-email">Verify now</Link></p>}
          {p?.bio ? <p className="pt-1 text-sm">{p.bio}</p> : null}
          {c ? <p className="pt-1 text-sm"><strong>{c.followers}</strong> followers · <strong>{c.following}</strong> following</p> : null}
        </div>
        <Link href="/profile/edit" className="inline-flex min-h-11 shrink-0 items-center rounded-xl border border-navy-100 px-3 text-sm font-semibold dark:border-navy-500">Edit profile</Link>
      </Card>
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {TILES.map(({ href, label, icon: Icon }) => (
          <li key={href}><Link href={href} className="flex min-h-20 flex-col items-center justify-center gap-1 rounded-card border border-navy-100 bg-white p-3 text-center text-sm font-medium hover:border-brand-purple dark:border-navy-500 dark:bg-navy-700"><Icon className="h-5 w-5 text-brand-purple" aria-hidden />{label}</Link></li>
        ))}
      </ul>
      <SellerBlock />
      <InstallPrompt />
      <Button variant="ghost" className="w-full" onClick={async () => { await logout(); router.replace('/'); }}>Log out</Button>
    </div>
  );
}
export default function ProfilePage() { return <AuthGuard><ProfileInner /></AuthGuard>; }
