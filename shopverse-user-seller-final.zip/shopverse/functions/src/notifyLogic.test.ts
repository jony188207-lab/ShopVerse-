import { describe, expect, it } from 'vitest';
import { allowed, categoryOf, deriveRelated, orderEventType, safeLink, wishlistEvent } from './notifyLogic';

describe('preferences', () => {
  it('defaults to ON when nothing is saved', () => expect(allowed('new_message', undefined)).toEqual({ inApp: true, push: true }));
  it('a disabled category suppresses in-app AND push', () => expect(allowed('wishlist_price_drop', { wishlist: false })).toEqual({ inApp: false, push: false }));
  it('push off keeps the in-app notification', () => expect(allowed('order_shipped', { push: false })).toEqual({ inApp: true, push: false }));
  it('system notifications ignore category switches (but respect the push switch)', () => {
    expect(allowed('seller_suspend', { seller: false, orders: false })).toEqual({ inApp: true, push: true });
    expect(allowed('role_changed', { push: false })).toEqual({ inApp: true, push: false });
  });
  it('unknown types fail open as system; seller/buyer order events are separate categories', () => {
    expect(categoryOf('something_new')).toBe('system'); expect(categoryOf('new_order')).toBe('seller'); expect(categoryOf('order_shipped')).toBe('orders');
  });
});
describe('order events', () => {
  it('maps every buyer-facing transition', () => {
    expect(orderEventType('pending', 'confirmed')).toBe('order_confirmed'); expect(orderEventType('shipped', 'out_for_delivery')).toBe('order_out_for_delivery');
    expect(orderEventType('delivered', 'return_requested')).toBe('return_requested'); expect(orderEventType('return_requested', 'returned')).toBe('order_returned');
    expect(orderEventType('return_requested', 'delivered')).toBe('return_rejected'); expect(orderEventType('returned', 'refunded')).toBe('order_refunded');
    expect(orderEventType('pending', 'cancelled')).toBe('order_cancelled'); expect(orderEventType('pending', 'weird')).toBeNull();
  });
});
describe('deep links', () => {
  it('derives related ids only from real routes', () => {
    expect(deriveRelated('/orders/abc')).toEqual({ relatedType: 'order', relatedId: 'abc' }); expect(deriveRelated('/video?v=v1')).toEqual({ relatedType: 'video', relatedId: 'v1' });
    expect(deriveRelated('/messages/c1_s1')).toEqual({ relatedType: 'conversation', relatedId: 'c1_s1' }); expect(deriveRelated('/nowhere').relatedType).toBe('');
  });
  it('rejects external / protocol-relative links', () => {
    expect(safeLink('/shop')).toBe('/shop'); expect(safeLink('//evil.com')).toBe(''); expect(safeLink('https://evil.com')).toBe(''); expect(safeLink(undefined)).toBe('');
  });
});
describe('wishlist events', () => {
  const base = { price: 100, stock: 3, status: 'approved' };
  it('5% price drop or restock only', () => {
    expect(wishlistEvent(base, { ...base, price: 94 })).toBe('wishlist_price_drop'); expect(wishlistEvent(base, { ...base, price: 97 })).toBeNull();
    expect(wishlistEvent({ ...base, stock: 0 }, base)).toBe('wishlist_restock'); expect(wishlistEvent(base, { ...base, price: 50, status: 'suspended' })).toBeNull();
  });
});
