import { createHash } from 'crypto';
import { FieldValue, Timestamp, type DocumentData, type Transaction } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onDocumentCreated, onDocumentUpdated, onDocumentWritten } from 'firebase-functions/v2/firestore';
import { ADMINS, assertActive, db, notify, notifyStaff } from './common';
import { orderEventText, orderEventType } from './notifyLogic';
import { createEarningsForOrder, reverseEarningsForOrder } from './money';
import { OrderError, applyCouponCode, priceCart, type CartLine, type CouponData, type ProductData, type StoreData, type Variant } from './orderLogic';

const CURRENCY = 'USD'; // keep in sync with config/site.ts
const RETURN_WINDOW_DAYS = 7; // keep in sync with config/site.ts
const MAX_CART_ITEMS = 50;
const ID = /^[A-Za-z0-9_-]{16,64}$/;

const COUPON = /^[A-Z0-9]{3,20}$/;
const asDate = (v: unknown): Date | null => (v && typeof (v as { toDate?: unknown }).toDate === 'function' ? (v as Timestamp).toDate() : null);
const toCoupon = (d: DocumentData | undefined): CouponData | null => d ? ({
  active: d.active === true, discountType: d.discountType === 'fixed' ? 'fixed' : 'percent', discountValue: Number(d.discountValue), minOrder: Number(d.minOrder ?? 0), maxDiscount: Number(d.maxDiscount ?? 0),
  usageLimit: Number(d.usageLimit ?? 0), usedCount: Number(d.usedCount ?? 0), startsAt: asDate(d.startsAt), endsAt: asDate(d.endsAt),
}) : null;
const parseCode = (v: unknown): string => {
  if (v === undefined || v === null || v === '') return '';
  const c = typeof v === 'string' ? v.trim().toUpperCase() : '';
  if (!COUPON.test(c)) throw new HttpsError('invalid-argument', 'Enter a valid coupon code (letters and numbers).');
  return c;
};

const need = (uid: string | undefined): string => {
  if (!uid) throw new HttpsError('unauthenticated', 'Sign in first.');
  return uid;
};

/**
 * Trusted, transactional checkout. Price, stock, shipping and totals are computed HERE from Firestore documents read inside
 * the transaction — nothing numeric is accepted from the client. Retry-safe: `checkouts/{uid}_{checkoutId}` is written in the
 * same transaction, so a repeated call with the same checkoutId returns the original orders instead of creating new ones.
 */
export const placeOrder = onCall(async (req) => {
  const uid = need(req.auth?.uid);
  await assertActive(uid);
  if (req.auth!.token.email_verified !== true) throw new HttpsError('failed-precondition', 'Verify your email before ordering.');
  const { checkoutId, addressId, paymentMethod, deliveryMethod } = (req.data ?? {}) as Record<string, unknown>;
  const couponCode = parseCode((req.data as { couponCode?: unknown })?.couponCode);
  if (typeof checkoutId !== 'string' || !ID.test(checkoutId)) throw new HttpsError('invalid-argument', 'Invalid checkout id.');
  if (typeof addressId !== 'string' || !addressId) throw new HttpsError('invalid-argument', 'Choose a delivery address.');
  if (paymentMethod !== 'cod') throw new HttpsError('invalid-argument', 'Only cash on delivery is supported.');
  if (deliveryMethod !== undefined && deliveryMethod !== 'standard') throw new HttpsError('invalid-argument', 'Unsupported delivery method.');

  const markerRef = db.doc(`checkouts/${uid}_${checkoutId}`);
  try {
    return await db.runTransaction(async (tx) => {
      // ---- ALL reads first ----
      const marker = await tx.get(markerRef);
      if (marker.exists) return { orderIds: marker.get('orderIds') as string[], groupId: checkoutId, duplicate: true };
      const addr = await tx.get(db.doc(`addresses/${addressId}`));
      if (!addr.exists || addr.get('userId') !== uid) throw new HttpsError('not-found', 'Delivery address not found.');
      const cartSnap = await tx.get(db.collection('cartItems').where('userId', '==', uid).limit(MAX_CART_ITEMS + 1));
      if (cartSnap.empty) throw new HttpsError('failed-precondition', 'Your cart is empty.');
      if (cartSnap.size > MAX_CART_ITEMS) throw new HttpsError('failed-precondition', 'Your cart has too many items. Remove some and try again.');

      const lines: CartLine[] = cartSnap.docs.map((d) => ({ cartId: d.id, productId: String(d.get('productId')), variantKey: String(d.get('variantKey') || 'default'), quantity: Number(d.get('quantity')) }));
      const pIds = [...new Set(lines.map((l) => l.productId))];
      const pSnaps = await Promise.all(pIds.map((id) => tx.get(db.doc(`products/${id}`))));
      const products = new Map<string, ProductData>();
      pSnaps.forEach((s) => { if (s.exists) products.set(s.id, s.data() as ProductData); });
      const sIds = [...new Set([...products.values()].map((p) => p.storeId))];
      const sSnaps = await Promise.all(sIds.map((id) => tx.get(db.doc(`stores/${id}`))));
      const stores = new Map<string, StoreData>();
      for (const s of sSnaps) if (s.exists && s.get('status') === 'approved') stores.set(s.id, s.data() as StoreData);
      for (const p of products.values()) {
        if (!stores.has(p.storeId)) throw new HttpsError('failed-precondition', `The store for “${p.title}” is not available. Remove it from your cart.`);
        if (p.sellerId === uid) throw new HttpsError('failed-precondition', 'You cannot buy your own product.');
      }

      const couponSnaps = couponCode ? await Promise.all([...new Set([...products.values()].map((p) => p.sellerId)), 'platform'].map((sid) => tx.get(db.doc(`coupons/${sid}_${couponCode}`)))) : [];
      let priced;
      try {
        priced = priceCart(lines, products, stores);
        if (couponCode) { const m = new Map<string, CouponData | null>(couponSnaps.map((c): [string, CouponData | null] => [c.id.slice(0, -(couponCode.length + 1)), c.exists ? toCoupon(c.data()) : null])); priced.orders = applyCouponCode(priced.orders, couponCode, m, new Date(), m.get('platform') ?? null); }
      } catch (e) {
        if (e instanceof OrderError) throw new HttpsError('failed-precondition', e.message, { code: e.code });
        throw e;
      }

      // ---- writes ----
      const now = Timestamp.now();
      const a = addr.data()!;
      const address = { fullName: a.fullName, phone: a.phone, country: a.country, city: a.city, area: a.area ?? '', address: a.address, postalCode: a.postalCode ?? '', instructions: a.instructions ?? '' };
      const orderIds: string[] = [];
      for (const o of priced.orders) {
        const ref = db.collection('orders').doc();
        tx.set(ref, {
          orderNumber: 'SV-' + createHash('sha1').update(ref.id).digest('hex').slice(0, 8).toUpperCase(), groupId: checkoutId, buyerId: uid,
          sellerId: o.sellerId, storeId: o.storeId, storeName: o.storeName, status: 'pending', paymentMethod: 'cod', paymentStatus: 'unpaid', deliveryMethod: 'standard',
          subtotal: o.subtotal, discount: o.discount, shipping: o.shipping, total: o.total, ...(o.couponId ? { couponCode: o.couponCode, couponId: o.couponId, couponFundedBy: o.couponFundedBy, couponDiscount: o.couponDiscount } : {}), currency: CURRENCY, itemCount: o.lines.reduce((n, l) => n + l.quantity, 0),
          address, timeline: [{ status: 'pending', at: now }], createdAt: now, updatedAt: now,
        });
        o.lines.forEach((l, i) => tx.set(db.doc(`orderItems/${ref.id}_${i}`), {
          orderId: ref.id, buyerId: uid, sellerId: l.sellerId, storeId: l.storeId, productId: l.productId, title: l.title, image: l.image, sku: l.sku,
          variantKey: l.variantKey, variantLabel: l.variantLabel, unitPrice: l.unitPrice, quantity: l.quantity, lineTotal: l.lineTotal, couponShare: l.couponShare, couponFundedBy: o.couponFundedBy, status: 'pending', createdAt: now,
        }));
        orderIds.push(ref.id);
      }
      for (const [pid, ch] of priced.stock) {
        tx.update(db.doc(`products/${pid}`), { stock: ch.stock, ...(ch.variants ? { variants: ch.variants } : {}), ...(ch.stock <= 0 ? { status: 'out_of_stock' } : {}), updatedAt: now });
      }
      const used = new Map<string, number>();
      priced.orders.forEach((o) => { if (o.couponId) used.set(o.couponId, (used.get(o.couponId) ?? 0) + 1); });
      used.forEach((n, cid) => tx.update(db.doc(`coupons/${cid}`), { usedCount: FieldValue.increment(n) }));   // platform coupon: one use per store order
      cartSnap.docs.forEach((d) => tx.delete(d.ref));
      tx.set(markerRef, { userId: uid, groupId: checkoutId, orderIds, createdAt: now });
      return { orderIds, groupId: checkoutId, duplicate: false };
    });
  } catch (e) {
    if (e instanceof HttpsError) throw e;
    console.error('placeOrder failed', e);
    throw new HttpsError('aborted', 'We could not place your order. Nothing was charged; please try again.');
  }
});

/** Returns the stock of every item in an order (reads first, then writes). Caller must then update the order (stockRestored). */
async function restoreStock(tx: Transaction, orderId: string, couponId = ''): Promise<void> {
  const coupon = couponId ? await tx.get(db.doc(`coupons/${couponId}`)) : null;
  const items = await tx.get(db.collection('orderItems').where('orderId', '==', orderId));
  const byProduct = new Map<string, { total: number; byKey: Map<string, number> }>();
  items.forEach((d) => {
    const g = byProduct.get(d.get('productId')) ?? { total: 0, byKey: new Map() };
    g.total += Number(d.get('quantity'));
    const k = String(d.get('variantKey') || 'default');
    g.byKey.set(k, (g.byKey.get(k) ?? 0) + Number(d.get('quantity')));
    byProduct.set(d.get('productId'), g);
  });
  const snaps = await Promise.all([...byProduct.keys()].map((id) => tx.get(db.doc(`products/${id}`))));
  for (const s of snaps) {
    if (!s.exists) continue;
    const g = byProduct.get(s.id)!;
    const stock = Number(s.get('stock') ?? 0) + g.total;
    const variants = (s.get('variants') as Variant[] | undefined)?.map((v) => ({ ...v, stock: v.stock + (g.byKey.get(v.key) ?? 0) }));
    tx.update(s.ref, { stock, ...(variants?.length ? { variants } : {}), ...(s.get('status') === 'out_of_stock' && stock > 0 ? { status: 'approved' } : {}), updatedAt: Timestamp.now() });
  }
  if (coupon?.exists) tx.update(coupon.ref, { usedCount: FieldValue.increment(-1) });
}

/** Buyer cancels an order that the seller has not shipped yet; stock goes back in the same transaction. */
export const cancelOrder = onCall(async (req) => {
  const uid = need(req.auth?.uid);
  const { orderId, reason } = (req.data ?? {}) as Record<string, unknown>;
  if (typeof orderId !== 'string' || !orderId) throw new HttpsError('invalid-argument', 'Missing order.');
  const ref = db.doc(`orders/${orderId}`);
  await db.runTransaction(async (tx) => {
    const o = await tx.get(ref);
    if (!o.exists || o.get('buyerId') !== uid) throw new HttpsError('not-found', 'Order not found.');
    if (!['pending', 'confirmed'].includes(o.get('status'))) throw new HttpsError('failed-precondition', 'This order can no longer be cancelled.');
    if (o.get('stockRestored') !== true) await restoreStock(tx, orderId, String(o.get('couponId') ?? ''));
    tx.update(ref, { status: 'cancelled', stockRestored: true, cancelReason: typeof reason === 'string' ? reason.slice(0, 300) : '', cancelledAt: Timestamp.now(), updatedAt: Timestamp.now() });
  });
  return { ok: true };
});

/** Return request: only for the buyer, only when delivered, only inside the return window. */
export const requestReturn = onCall(async (req) => {
  const uid = need(req.auth?.uid);
  const { orderId, reason } = (req.data ?? {}) as Record<string, unknown>;
  if (typeof orderId !== 'string' || !orderId) throw new HttpsError('invalid-argument', 'Missing order.');
  if (typeof reason !== 'string' || reason.trim().length < 5 || reason.length > 500) throw new HttpsError('invalid-argument', 'Tell us why you want to return this (5–500 characters).');
  const ref = db.doc(`orders/${orderId}`);
  await db.runTransaction(async (tx) => {
    const o = await tx.get(ref);
    if (!o.exists || o.get('buyerId') !== uid) throw new HttpsError('not-found', 'Order not found.');
    if (o.get('status') !== 'delivered') throw new HttpsError('failed-precondition', 'Only delivered orders can be returned.');
    const at = o.get('deliveredAt') as Timestamp | undefined;
    if (!at) throw new HttpsError('failed-precondition', 'The delivery date is not recorded yet. Try again in a minute.');
    if (Date.now() > at.toMillis() + RETURN_WINDOW_DAYS * 86_400_000) throw new HttpsError('failed-precondition', `The ${RETURN_WINDOW_DAYS}-day return window has ended.`);
    tx.update(ref, { status: 'return_requested', returnReason: reason.trim(), updatedAt: Timestamp.now() });
  });
  return { ok: true };
});

/**
 * Runs for EVERY status change (buyer callables, seller, admin): appends the timeline, marks COD paid on delivery / refunded on refund,
 * mirrors status onto orderItems (reviews depend on it), restores stock for seller/admin cancellations, and counts sales on delivery.
 * Events are at-least-once, so each step is guarded.
 */
export const onOrderStatusChange = onDocumentUpdated('orders/{orderId}', async (event) => {
  const before = event.data?.before.data();
  const after = event.data?.after.data();
  if (!before || !after || before.status === after.status) return; // also stops our own patch below from looping
  const ref = event.data!.after.ref;
  const now = Timestamp.now();
  const tl = (after.timeline ?? []) as { status: string }[];
  const patch: Record<string, unknown> = {};
  if (tl.at(-1)?.status !== after.status) patch.timeline = FieldValue.arrayUnion({ status: after.status, at: now });
  if (after.status === 'delivered') { patch.deliveredAt = now; patch.paymentStatus = 'paid'; }
  if (after.status === 'refunded') patch.paymentStatus = 'refunded';
  if (Object.keys(patch).length) await ref.update(patch);

  const items = await db.collection('orderItems').where('orderId', '==', ref.id).get();
  const batch = db.batch();
  items.forEach((d) => batch.update(d.ref, { status: after.status }));
  if (after.status === 'delivered' && before.status !== 'delivered') {
    const sold = new Map<string, number>();
    items.forEach((d) => sold.set(d.get('productId'), (sold.get(d.get('productId')) ?? 0) + Number(d.get('quantity'))));
    sold.forEach((q, pid) => batch.update(db.doc(`products/${pid}`), { salesCount: FieldValue.increment(q) }));
    batch.set(db.doc(`stores/${after.storeId}`), { salesCount: FieldValue.increment(after.itemCount ?? 0) }, { merge: true });
  }
  await batch.commit();

  if (after.status === 'cancelled') {
    await db.runTransaction(async (tx) => {
      const o = await tx.get(ref);
      if (o.get('stockRestored') === true) return; // buyer path already restored it
      await restoreStock(tx, ref.id, String(o.get('couponId') ?? ''));
      tx.update(ref, { stockRestored: true });
    });
  }
});

/** Keeps rating, reviewCount, ratingSum and ratingDistribution on the product correct whenever a review is created/edited/removed/hidden. */
export const onReviewWritten = onDocumentWritten('reviews/{reviewId}', async (event) => {
  const pid = (event.data?.after.data() ?? event.data?.before.data())?.productId as string | undefined;
  if (!pid) return;
  const base = db.collection('reviews').where('productId', '==', pid).where('status', '==', 'published');
  const counts = await Promise.all([1, 2, 3, 4, 5].map((r) => base.where('rating', '==', r).count().get()));
  const dist: Record<string, number> = {};
  let n = 0, sum = 0;
  counts.forEach((c, i) => { const k = c.data().count; dist[String(i + 1)] = k; n += k; sum += k * (i + 1); });
  const ref = db.doc(`products/${pid}`);
  if ((await ref.get()).exists) await ref.update({ rating: n ? Math.round((sum / n) * 100) / 100 : 0, reviewCount: n, ratingSum: sum, ratingDistribution: dist });
});

/** follows/{followerId_ownerId} -> stores.followerCount (clients cannot write the counter). */
export const onFollowWritten = onDocumentWritten('follows/{id}', async (event) => {
  const b = event.data?.before, a = event.data?.after;
  const delta = !b?.exists && a?.exists ? 1 : b?.exists && !a?.exists ? -1 : 0;
  const ownerId = (a?.exists ? a : b)?.get('followingId') as string | undefined;
  if (!delta || !ownerId) return;
  const s = await db.collection('stores').where('ownerId', '==', ownerId).limit(1).get();
  if (s.empty) return;
  await s.docs[0].ref.update({ followerCount: FieldValue.increment(delta) });
  if (delta > 0) {
    const followerId = String(a?.get('followerId'));
    const name = String((await db.doc(`profiles/${followerId}`).get()).get('displayName') ?? 'Someone');
    await notify(ownerId, { type: 'new_follower', title: 'New follower', body: `${name} started following ${s.docs[0].get('name')}.`, link: `/store/${s.docs[0].get('slug')}`, dedupeUnread: false });
  }
});

export { reviewSellerApplication, onProductModerated } from './seller';
export { releaseEarnings, requestWithdrawal, cancelWithdrawal, reviewWithdrawal, confirmCodRemittance } from './money';
export { reviewPromotion, syncPromotions } from './promotions';

/** Seller is told about every new order (in-app + push). */
export const onOrderCreated = onDocumentCreated('orders/{orderId}', async (event) => {
  const o = event.data?.data();
  if (!o) return;
  await Promise.all([
    notify(o.sellerId, { type: 'new_order', title: 'New order', body: `${o.orderNumber}: ${o.itemCount} item(s), total ${Number(o.total).toFixed(2)}.`, link: `/seller/orders/${event.params.orderId}` }),
    notify(o.buyerId, { type: 'order_placed', ...orderEventText('order_placed', o.storeName ?? 'the seller'), link: `/orders/${event.params.orderId}` }),
  ]);
});

/** Status side-effects that are not about stock: earnings, reversals, notifications. Each step is idempotent (events are at-least-once). */
export const onOrderLifecycle = onDocumentUpdated('orders/{orderId}', async (event) => {
  const b = event.data?.before.data(), a = event.data?.after.data();
  if (!b || !a || b.status === a.status) return;
  const id = event.params.orderId;
  if (a.status === 'delivered') await createEarningsForOrder(id);
  if (a.status === 'returned' || a.status === 'refunded') await reverseEarningsForOrder(id);
  const type = orderEventType(b.status, a.status);
  if (type) await notify(a.buyerId, { type, ...orderEventText(type, a.storeName ?? 'the seller'), link: `/orders/${id}` });
  if (a.status === 'cancelled') await notify(a.sellerId, { type: 'seller_order_cancelled', title: `Order ${a.orderNumber} cancelled`, body: 'The order was cancelled and the stock was returned.', link: `/seller/orders/${id}` });
  if (a.status === 'return_requested') {
    await notify(a.sellerId, { type: 'seller_return_requested', title: `Return requested: ${a.orderNumber}`, body: `The buyer asked to return this order. Reason: ${String(a.returnReason ?? '').slice(0, 120)}`, link: `/seller/orders/${id}` });
    await notifyStaff(ADMINS, { type: 'admin_return', title: 'Return needs attention', body: `Order ${a.orderNumber} (${a.storeName}) has a return request.`, link: '/admin/orders' });
  }
});

/** Seller is told when a new review arrives. */
export const onReviewReceived = onDocumentCreated('reviews/{reviewId}', async (event) => {
  const r = event.data?.data();
  if (r?.sellerId) await notify(r.sellerId, { type: 'review_received', title: `New ${r.rating}★ review`, body: String(r.text ?? '').slice(0, 120) || 'A customer left a rating.', link: '/seller/reviews' });
});

/** Read-only coupon preview for the checkout page. placeOrder re-validates everything; this only tells the buyer what they will get. */
export const previewCoupon = onCall(async (req) => {
  const uid = need(req.auth?.uid);
  const code = parseCode((req.data as { code?: unknown })?.code);
  if (!code) throw new HttpsError('invalid-argument', 'Enter a coupon code.');
  const cart = await db.collection('cartItems').where('userId', '==', uid).limit(MAX_CART_ITEMS).get();
  if (cart.empty) throw new HttpsError('failed-precondition', 'Your cart is empty.');
  const lines: CartLine[] = cart.docs.map((d) => ({ cartId: d.id, productId: String(d.get('productId')), variantKey: String(d.get('variantKey') || 'default'), quantity: Number(d.get('quantity')) }));
  const pSnaps = await db.getAll(...[...new Set(lines.map((l) => l.productId))].map((id) => db.doc(`products/${id}`)));
  const products = new Map<string, ProductData>(); pSnaps.forEach((s) => { if (s.exists) products.set(s.id, s.data() as ProductData); });
  const sellers = [...new Set([...products.values()].map((p) => p.sellerId))];
  const cSnaps = await db.getAll(...[...sellers, 'platform'].map((sid) => db.doc(`coupons/${sid}_${code}`)));
  const sSnaps = await db.getAll(...[...new Set([...products.values()].map((p) => p.storeId))].map((id) => db.doc(`stores/${id}`)));
  const stores = new Map<string, StoreData>(); sSnaps.forEach((s) => { if (s.exists) stores.set(s.id, s.data() as StoreData); });
  try {
    const priced = priceCart(lines, products, stores);
    const ids = [...sellers, 'platform'];
    const cm = new Map<string, CouponData | null>(cSnaps.map((c, i): [string, CouponData | null] => [ids[i], c.exists ? toCoupon(c.data()) : null]));
    const orders = applyCouponCode(priced.orders, code, cm, new Date(), cm.get('platform') ?? null);
    const hit = orders.filter((o) => o.couponId);
    return { code, discount: hit.reduce((s, o) => s + o.couponDiscount, 0), stores: hit.map((o) => ({ storeName: o.storeName, discount: o.couponDiscount })) };
  } catch (e) {
    if (e instanceof OrderError) throw new HttpsError('failed-precondition', e.message);
    throw e;
  }
});
export { setUserStatus, setUserRole, sendAnnouncement, migrateStoreFinance } from './admin';
export { onPlatformPromotionWritten } from './promotions';
export { onVideoLikeWritten, onVideoSaveWritten, onVideoViewCreated, onVideoCommentWritten, onVideoModerated, rankVideos, onMessageCreated } from './social';

export * from './events';
