// Pure, dependency-free order pricing/validation. The placeOrder Cloud Function runs this INSIDE a Firestore
// transaction using documents it read itself, so client-supplied prices/stock are never trusted.
export interface CartLine { cartId: string; productId: string; variantKey: string; quantity: number }
export interface Variant { key: string; label: string; price?: number; stock: number }
export interface ProductData {
  title: string; status: string; price: number; originalPrice?: number; stock: number; sellerId: string; storeId: string;
  sku?: string; images?: string[]; variants?: Variant[];
}
export interface StoreData { name: string; shippingFee?: number; freeShippingOver?: number }
export interface PricedLine {
  cartId: string; productId: string; sellerId: string; storeId: string; title: string; image: string; sku: string;
  variantKey: string; variantLabel: string; unitPrice: number; quantity: number; lineTotal: number; savings: number; couponShare: number;
}
export interface SellerOrderDraft { sellerId: string; storeId: string; storeName: string; lines: PricedLine[]; subtotal: number; discount: number; shipping: number; total: number; couponCode: string; couponDiscount: number; couponId: string; couponFundedBy: 'seller' | 'platform' | '' }
export interface StockChange { stock: number; variants?: Variant[]; sold: number }
export type OrderErrorCode = 'not-found' | 'unavailable' | 'insufficient-stock' | 'invalid';
export class OrderError extends Error {
  constructor(public code: OrderErrorCode, message: string) { super(message); this.name = 'OrderError'; }
}
export const MAX_QTY = 99;
export const round2 = (n: number) => Math.round(n * 100) / 100;

export function priceCart(lines: CartLine[], products: Map<string, ProductData>, stores: Map<string, StoreData>): { orders: SellerOrderDraft[]; stock: Map<string, StockChange> } {
  if (!lines.length) throw new OrderError('invalid', 'Your cart is empty.');
  const stock = new Map<string, StockChange>();
  const priced: PricedLine[] = [];

  for (const l of lines) {
    if (!Number.isInteger(l.quantity) || l.quantity < 1 || l.quantity > MAX_QTY) throw new OrderError('invalid', 'Invalid quantity in your cart.');
    const p = products.get(l.productId);
    if (!p) throw new OrderError('not-found', 'An item in your cart is no longer available. Remove it and try again.');
    if (p.status !== 'approved') throw new OrderError('unavailable', `“${p.title}” is no longer available.`);
    const hasVariants = !!p.variants && p.variants.length > 0;
    const cur = stock.get(l.productId) ?? { stock: p.stock, variants: hasVariants ? p.variants!.map((v) => ({ ...v })) : undefined, sold: 0 };
    let unit = p.price; let label = '';
    if (hasVariants) {
      const v = cur.variants!.find((x) => x.key === l.variantKey);
      if (!v) throw new OrderError('invalid', `Choose an available option for “${p.title}”.`);
      if (v.stock < l.quantity) throw new OrderError('insufficient-stock', `Only ${Math.max(0, v.stock)} left of “${p.title}” (${v.label}).`);
      unit = v.price ?? p.price; label = v.label; v.stock -= l.quantity;
    } else if (l.variantKey !== 'default') throw new OrderError('invalid', `Invalid option for “${p.title}”.`);
    if (cur.stock < l.quantity) throw new OrderError('insufficient-stock', `Only ${Math.max(0, cur.stock)} left of “${p.title}”.`);
    cur.stock -= l.quantity; cur.sold += l.quantity;
    stock.set(l.productId, cur);
    if (!(unit > 0)) throw new OrderError('invalid', `“${p.title}” has an invalid price.`);
    priced.push({
      cartId: l.cartId, productId: l.productId, sellerId: p.sellerId, storeId: p.storeId, title: p.title, image: p.images?.[0] ?? '', sku: p.sku ?? '',
      variantKey: l.variantKey, variantLabel: label, unitPrice: unit, quantity: l.quantity, lineTotal: round2(unit * l.quantity),
      savings: round2(Math.max(0, (p.originalPrice ?? unit) - unit) * l.quantity), couponShare: 0,
    });
  }

  const bySeller = new Map<string, PricedLine[]>();
  for (const pl of priced) bySeller.set(pl.sellerId, [...(bySeller.get(pl.sellerId) ?? []), pl]);
  const orders = Array.from(bySeller.entries()).map(([sellerId, ls]): SellerOrderDraft => {
    const store = stores.get(ls[0].storeId);
    const subtotal = round2(ls.reduce((s, x) => s + x.lineTotal, 0));
    const free = store?.freeShippingOver != null && subtotal >= store.freeShippingOver;
    const shipping = free ? 0 : round2(store?.shippingFee ?? 0);
    return { sellerId, storeId: ls[0].storeId, storeName: store?.name ?? 'Store', lines: ls, subtotal, discount: round2(ls.reduce((s, x) => s + x.savings, 0)), shipping, total: round2(subtotal + shipping), couponCode: '', couponDiscount: 0, couponId: '', couponFundedBy: '' };
  });
  return { orders, stock };
}

// ---------------- seller coupons (validated + applied ONLY on the server) ----------------
export interface CouponData {
  active: boolean; discountType: 'percent' | 'fixed'; discountValue: number; minOrder: number; maxDiscount: number; usageLimit: number; usedCount: number;
  startsAt?: Date | null; endsAt?: Date | null;
}
export type CouponResult = { ok: true; amount: number } | { ok: false; reason: string };

export function couponDiscount(subtotal: number, c: CouponData, now: Date): CouponResult {
  if (!c.active) return { ok: false, reason: 'This coupon is not active.' };
  if (c.startsAt && now < c.startsAt) return { ok: false, reason: 'This coupon is not valid yet.' };
  if (c.endsAt && now > c.endsAt) return { ok: false, reason: 'This coupon has expired.' };
  if (c.usageLimit > 0 && c.usedCount >= c.usageLimit) return { ok: false, reason: 'This coupon has been fully redeemed.' };
  if (subtotal < c.minOrder) return { ok: false, reason: `This coupon needs a minimum order of ${round2(c.minOrder).toFixed(2)} from the store.` };
  let amount = c.discountType === 'percent' ? (subtotal * c.discountValue) / 100 : c.discountValue;
  if (c.maxDiscount > 0) amount = Math.min(amount, c.maxDiscount);
  amount = round2(Math.min(amount, subtotal));
  return amount > 0 ? { ok: true, amount } : { ok: false, reason: 'This coupon gives no discount on your items.' };
}

/**
 * A code applies to a store's order only when that store owns a valid coupon with the code (doc id {sellerId}_{CODE}).
 * Items from other stores are untouched. If it applies nowhere the whole checkout fails with the most useful reason — it is never silently dropped.
 * The discount is split across the store's lines in proportion to line totals (cent-exact) so earnings/commission can be computed per item.
 */
export function applyCouponCode(orders: SellerOrderDraft[], code: string, coupons: Map<string, CouponData | null>, now: Date, platform: CouponData | null = null): SellerOrderDraft[] {
  let applied = 0; let firstReason = '';
  const out = orders.map((o) => {
    // The store's own coupon wins; a PLATFORM coupon (platform-funded) is the fallback for any store's order.
    const own = coupons.get(o.sellerId) ?? null;
    let fundedBy: 'seller' | 'platform' = 'seller';
    let r: CouponResult = own ? couponDiscount(o.subtotal, own, now) : { ok: false, reason: '' };
    if (!r.ok && platform) { const pr = couponDiscount(o.subtotal, platform, now); if (pr.ok) { r = pr; fundedBy = 'platform'; } else r = { ok: false, reason: r.reason || pr.reason }; }
    if (!r.ok) { firstReason = firstReason || r.reason; return o; }
    applied++;
    let left = Math.round(r.amount * 100);
    const lines = o.lines.map((l, i) => {
      const share = i === o.lines.length - 1 ? left : Math.min(left, Math.floor((Math.round(r.amount * 100) * Math.round(l.lineTotal * 100)) / Math.round(o.subtotal * 100)));
      left -= share;
      return { ...l, couponShare: share / 100 };
    });
    return { ...o, lines, couponCode: code, couponId: fundedBy === 'platform' ? `platform_${code}` : `${o.sellerId}_${code}`, couponFundedBy: fundedBy, couponDiscount: r.amount, total: round2(o.subtotal - r.amount + o.shipping) };
  });
  if (!applied) throw new OrderError('invalid', firstReason || `The code ${code} does not apply to the items in your cart.`);
  return out;
}
