import { FieldValue, Timestamp, type QueryDocumentSnapshot } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { audit, authAdmin, clean, db, notify, requireAdmin, requireRole, roleOf } from './common';

/**
 * Suspend / reactivate a USER account. Real enforcement: the Firebase Auth account is disabled and refresh tokens are revoked,
 * so the person is signed out and cannot sign in. Staff accounts and sellers are excluded (sellers: suspend the seller first).
 */
export const setUserStatus = onCall(async (req) => {
  const adminId = await requireAdmin(req);
  const { uid, status } = (req.data ?? {}) as { uid?: unknown; status?: unknown };
  const reason = clean((req.data as { reason?: unknown })?.reason, 300);
  if (typeof uid !== 'string' || !uid || (status !== 'suspended' && status !== 'active')) throw new HttpsError('invalid-argument', 'Invalid request.');
  if (uid === adminId) throw new HttpsError('failed-precondition', 'You cannot change your own account status.');
  if (status === 'suspended' && reason.length < 5) throw new HttpsError('invalid-argument', 'Give a reason (at least 5 characters).');
  const role = await roleOf(uid);
  if (role !== 'user') throw new HttpsError('failed-precondition', role === 'seller' ? 'This user is a seller. Suspend the seller from /admin/sellers first.' : 'Staff accounts cannot be suspended here.');
  const ref = db.doc(`users/${uid}`);
  if (!(await ref.get()).exists) throw new HttpsError('not-found', 'User not found.');
  await authAdmin().updateUser(uid, { disabled: status === 'suspended' });
  if (status === 'suspended') await authAdmin().revokeRefreshTokens(uid);
  await ref.update(status === 'suspended' ? { status, suspendReason: reason, suspendedAt: Timestamp.now(), updatedAt: Timestamp.now() } : { status, suspendReason: '', updatedAt: Timestamp.now() });
  await audit(adminId, `user.${status === 'suspended' ? 'suspend' : 'reactivate'}`, 'user', uid, { note: reason });
  return { ok: true };
});

/** Grant/revoke moderator or admin. Super admin only. Sellers and super admins are not changeable here (super admins are created in the Console). */
export const setUserRole = onCall(async (req) => {
  const adminId = await requireRole(req, ['super_admin']);
  const { uid, role } = (req.data ?? {}) as { uid?: unknown; role?: unknown };
  if (typeof uid !== 'string' || !uid || !['user', 'moderator', 'admin'].includes(role as string)) throw new HttpsError('invalid-argument', 'Role must be user, moderator or admin.');
  if (uid === adminId) throw new HttpsError('failed-precondition', 'You cannot change your own role.');
  const current = await roleOf(uid);
  if (current === 'super_admin') throw new HttpsError('failed-precondition', 'Super admin roles are managed in the Firebase Console.');
  if (current === 'seller') throw new HttpsError('failed-precondition', 'This user is a seller. Suspend the seller first; sellers cannot be converted to staff.');
  if (!(await db.doc(`users/${uid}`).get()).exists) throw new HttpsError('not-found', 'User not found.');
  await db.doc(`roles/${uid}`).set({ role, updatedAt: Timestamp.now(), updatedBy: adminId });
  await audit(adminId, `role.${role}`, 'user', uid, { previous: current });
  await notify(uid, { type: 'role_changed', title: 'Your role changed', body: role === 'user' ? 'Your staff access was removed.' : `You are now a ${role}.`, link: role === 'user' ? '/' : '/admin' });
  return { ok: true };
});

const AUDIENCES = ['all', 'sellers', 'user'];
const MAX_RECIPIENTS = 5000;

/** Admin broadcast (in-app; not push, to keep fan-out cheap). Capped at 5,000 recipients per announcement. */
export const sendAnnouncement = onCall({ timeoutSeconds: 300 }, async (req) => {
  const adminId = await requireAdmin(req);
  const d = (req.data ?? {}) as Record<string, unknown>;
  const kind = d.kind === 'important' ? 'important' : 'promotion';
  const audience = clean(d.audience, 10); const title = clean(d.title, 80); const body = clean(d.body, 400); const link = clean(d.link, 200);
  if (!AUDIENCES.includes(audience)) throw new HttpsError('invalid-argument', 'Choose who should receive this.');
  if (title.length < 3 || body.length < 3) throw new HttpsError('invalid-argument', 'Add a title and a message.');
  if (link && !link.startsWith('/')) throw new HttpsError('invalid-argument', 'Links must be paths inside the app, like /shop.');
  let ids: string[] = [];
  if (audience === 'user') {
    const uid = clean(d.userId, 128);
    if (!uid || !(await db.doc(`users/${uid}`).get()).exists) throw new HttpsError('not-found', 'User not found.');
    ids = [uid];
  } else if (audience === 'sellers') {
    ids = (await db.collection('roles').where('role', '==', 'seller').limit(MAX_RECIPIENTS + 1).get()).docs.map((x) => x.id);
  } else {
    ids = (await db.collection('users').where('status', '==', 'active').select().limit(MAX_RECIPIENTS + 1).get()).docs.map((x) => x.id);
  }
  if (ids.length > MAX_RECIPIENTS) throw new HttpsError('failed-precondition', `That audience is larger than ${MAX_RECIPIENTS}. Send to sellers or one user, or split the announcement.`);
  const now = Timestamp.now();
  for (let i = 0; i < ids.length; i += 400) {
    const b = db.batch();
    ids.slice(i, i + 400).forEach((uid) => b.set(db.collection('notifications').doc(), { userId: uid, type: kind === 'important' ? 'announcement_important' : 'announcement_promo', category: kind === 'important' ? 'system' : 'promotions', title, body, image: '', relatedId: '', relatedType: '', link, read: false, createdAt: now }));
    await b.commit();
  }
  const ref = await db.collection('announcements').add({ audience, kind, title, body, link, recipients: ids.length, sentBy: adminId, createdAt: now });
  await audit(adminId, 'announcement.send', 'announcement', ref.id, { note: `${kind}/${audience}: ${title} (${ids.length})` });
  return { recipients: ids.length };
});

/** One-time cleanup: move legacy `commissionRate` off PUBLIC store docs into admin-only storeFinance. Super admin only; idempotent. */
export const migrateStoreFinance = onCall({ timeoutSeconds: 300 }, async (req) => {
  const adminId = await requireRole(req, ['super_admin']);
  let moved = 0; let last: QueryDocumentSnapshot | undefined;
  for (let page = 0; page < 20; page++) {
    let q = db.collection('stores').orderBy('__name__').limit(300);
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (snap.empty) break;
    const b = db.batch();
    for (const d of snap.docs) {
      if (typeof d.get('commissionRate') !== 'number') continue;
      b.set(db.doc(`storeFinance/${d.id}`), { commissionRate: d.get('commissionRate'), updatedAt: Timestamp.now() }, { merge: true });
      b.update(d.ref, { commissionRate: FieldValue.delete() });
      moved++;
    }
    await b.commit();
    last = snap.docs.at(-1);
    if (snap.size < 300) break;
  }
  await audit(adminId, 'store.migrate_finance', 'store', '*', { note: `moved ${moved}` });
  return { moved };
});
