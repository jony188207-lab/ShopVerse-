import { getApps, initializeApp } from 'firebase-admin/app';
import { Timestamp, getFirestore } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { getMessaging } from 'firebase-admin/messaging';
import { setGlobalOptions } from 'firebase-functions/v2';
import { allowed, categoryOf, deriveRelated, safeLink } from './notifyLogic';
import { HttpsError, type CallableRequest } from 'firebase-functions/v2/https';

if (!getApps().length) initializeApp();
setGlobalOptions({ region: 'us-central1', maxInstances: 10 }); // client region: NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION; imported first so it applies to every function
export const db = getFirestore();

export const DEFAULT_COMMISSION_PERCENT = 10; // fallbacks only: the live values come from platformSettings/main (super admin, /admin/settings)
export const EARNINGS_HOLD_DAYS = 7;          // should be >= the return window (config/site.ts)
export const MIN_WITHDRAWAL = 10;
export const PROMOTION_MAX_DAYS = 14;

export interface PlatformSettings { commissionDefaultPercent: number; earningsHoldDays: number; minWithdrawal: number; promotionMaxDays: number; pushEnabled: boolean }
let cache: { at: number; v: PlatformSettings } | null = null;
/** Reads platformSettings/main (cached 60s per instance); any missing/invalid field falls back to the constants above. */
export async function getSettings(): Promise<PlatformSettings> {
  if (cache && Date.now() - cache.at < 60_000) return cache.v;
  const d = (await db.doc('platformSettings/main').get()).data() ?? {};
  const num = (x: unknown, fb: number, lo: number, hi: number) => (typeof x === 'number' && x >= lo && x <= hi ? x : fb);
  const v: PlatformSettings = {
    commissionDefaultPercent: num(d.commissionDefaultPercent, DEFAULT_COMMISSION_PERCENT, 0, 50), earningsHoldDays: Math.floor(num(d.earningsHoldDays, EARNINGS_HOLD_DAYS, 0, 60)),
    minWithdrawal: num(d.minWithdrawal, MIN_WITHDRAWAL, 1, 100000), promotionMaxDays: Math.floor(num(d.promotionMaxDays, PROMOTION_MAX_DAYS, 1, 14)), pushEnabled: d.pushEnabled !== false,
  };
  cache = { at: Date.now(), v };
  return v;
}
export const authAdmin = () => getAuth();

/** Suspended accounts are refused immediately by trusted functions (an already-issued ID token can outlive the suspension by up to ~1h). */
export async function assertActive(uid: string): Promise<void> {
  const u = await db.doc(`users/${uid}`).get();
  if (u.exists && u.get('status') === 'suspended') throw new HttpsError('permission-denied', 'This account is suspended.');
}
export const money = (n: number): number => Math.round(n * 100) / 100;

export async function roleOf(uid: string): Promise<string> {
  const s = await db.doc(`roles/${uid}`).get();
  return s.exists ? String(s.get('role')) : 'user';
}

/** Authoritative server-side role check (reads /roles, the same source the Security Rules use). */
export async function requireRole(req: CallableRequest, allowed: string[]): Promise<string> {
  if (!req.auth) throw new HttpsError('unauthenticated', 'Sign in first.');
  if (!allowed.includes(await roleOf(req.auth.uid))) throw new HttpsError('permission-denied', 'You do not have permission to do that.');
  return req.auth.uid;
}

export const requireAdmin = (req: CallableRequest) => requireRole(req, ['admin', 'super_admin']);

export const audit = (adminId: string, action: string, targetType: string, targetId: string, extra: Record<string, unknown> = {}) =>
  db.collection('adminLogs').add({ adminId, action, targetType, targetId, ...extra, createdAt: Timestamp.now() });

export interface NotifyInput { type: string; title: string; body: string; link?: string; image?: string; relatedId?: string; relatedType?: string; dedupeUnread?: boolean }

const prefCache = new Map<string, { at: number; v: Record<string, unknown> }>();
async function getPrefs(uid: string): Promise<Record<string, unknown>> {
  const hit = prefCache.get(uid);
  if (hit && Date.now() - hit.at < 30_000) return hit.v;
  const v = (await db.doc(`notificationPrefs/${uid}`).get()).data() ?? {};
  prefCache.set(uid, { at: Date.now(), v });
  if (prefCache.size > 500) prefCache.clear();
  return v;
}

/**
 * The ONLY writer of /notifications (rules forbid client creates). Honours the user's preferences (mandatory 'system' types ignore category switches),
 * stores deep link + related entity, and sends a DATA-ONLY FCM push (the service worker renders it, so there are no duplicates).
 * Never throws: a failed notification must not fail the business operation.
 */
export async function notify(uid: string, n: NotifyInput): Promise<void> {
  try {
    const decision = allowed(n.type, await getPrefs(uid));
    if (!decision.inApp) return;
    const link = safeLink(n.link);
    const derived = deriveRelated(link);
    const relatedId = n.relatedId ?? derived.relatedId;
    if (n.dedupeUnread) {
      const dup = await db.collection('notifications').where('userId', '==', uid).where('type', '==', n.type).where('relatedId', '==', relatedId).where('read', '==', false).limit(1).get();
      if (!dup.empty) return;
    }
    const doc = { userId: uid, type: n.type, category: categoryOf(n.type), title: n.title.slice(0, 100), body: n.body.slice(0, 300), image: n.image ?? '', relatedId, relatedType: n.relatedType ?? derived.relatedType, link, read: false, createdAt: Timestamp.now() };
    const ref = await db.collection('notifications').add(doc);
    if (!decision.push || !(await getSettings()).pushEnabled) return;
    const tokens = await db.collection(`users/${uid}/fcmTokens`).limit(10).get();
    if (tokens.empty) return;
    const res = await getMessaging().sendEachForMulticast({
      tokens: tokens.docs.map((d) => d.id),
      data: { title: doc.title, body: doc.body, url: link || '/notifications', tag: `${n.type}:${relatedId || ref.id}`, image: doc.image, notificationId: ref.id },
      webpush: { headers: { Urgency: 'normal', TTL: '86400' } },
    });
    await Promise.all(res.responses.map((r, i) => (!r.success && /not-registered|invalid-registration|invalid-argument/.test(r.error?.code ?? '') ? tokens.docs[i].ref.delete() : null)));
  } catch (e) {
    console.error('notify failed', uid, n.type, e);
  }
}

/** Active staff ids by role (cached 5 min per instance; max 50). Used for admin/moderator alerts. */
const staffCache = new Map<string, { at: number; ids: string[] }>();
export async function staffIds(roles: string[]): Promise<string[]> {
  const key = roles.join(',');
  const hit = staffCache.get(key);
  if (hit && Date.now() - hit.at < 300_000) return hit.ids;
  const snap = await db.collection('roles').where('role', 'in', roles).limit(50).get();
  const ids = snap.docs.map((d) => d.id);
  staffCache.set(key, { at: Date.now(), ids });
  return ids;
}
export async function notifyStaff(roles: string[], n: NotifyInput, except?: string): Promise<void> {
  const ids = (await staffIds(roles)).filter((x) => x !== except);
  await Promise.all(ids.map((id) => notify(id, n)));
}
export const ADMINS = ['admin', 'super_admin'];
export const STAFF = ['moderator', 'admin', 'super_admin'];

export const clean = (v: unknown, max: number): string => (typeof v === 'string' ? v.trim().slice(0, max) : '');
