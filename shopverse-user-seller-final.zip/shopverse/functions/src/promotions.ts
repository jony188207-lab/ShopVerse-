import { FieldValue, Timestamp, type DocumentData } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { onDocumentWritten } from 'firebase-functions/v2/firestore';
import { audit, clean, db, getSettings, notify, requireAdmin } from './common';

async function applyPromotion(id: string, p: DocumentData, on: boolean): Promise<void> {
  const ref = db.doc(`products/${p.productId}`);
  if (!(await ref.get()).exists) return;
  const patch: Record<string, unknown> =
    p.type === 'featured' ? { featured: on } : { flashSaleEndsAt: on ? (p.endsAt as Timestamp) : FieldValue.delete() };
  await ref.update(patch);
  await db.doc(`promotions/${id}`).update({ applied: on, ...(on ? {} : { status: 'ended' }), updatedAt: Timestamp.now() });
}

/**
 * Admin decides a seller's promotion request. Approval is validated again here (product still approved, flash sale needs a real discount)
 * and is what sets product.featured / flashSaleEndsAt — sellers can never write those fields (see rules).
 */
export const reviewPromotion = onCall(async (req) => {
  const adminId = await requireAdmin(req);
  const { id, decision } = (req.data ?? {}) as { id?: unknown; decision?: unknown };
  const note = clean((req.data as { note?: unknown })?.note, 500);
  if (typeof id !== 'string' || (decision !== 'approved' && decision !== 'rejected')) throw new HttpsError('invalid-argument', 'Invalid request.');
  if (decision === 'rejected' && note.length < 5) throw new HttpsError('invalid-argument', 'Give a reason for the rejection.');
  const ref = db.doc(`promotions/${id}`);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Promotion not found.');
  const p = snap.data()!;
  if (p.status !== 'pending') throw new HttpsError('failed-precondition', `This request is already ${p.status}.`);
  if (decision === 'approved') {
    const prod = await db.doc(`products/${p.productId}`).get();
    if (!prod.exists || prod.get('status') !== 'approved' || prod.get('sellerId') !== p.sellerId) throw new HttpsError('failed-precondition', 'The product is no longer approved.');
    if (p.type === 'flash_sale' && !(Number(prod.get('originalPrice')) > Number(prod.get('price')))) throw new HttpsError('failed-precondition', 'Flash sales need a product that already has a discount (original price above price).');
    const maxDays = (await getSettings()).promotionMaxDays;
    if ((p.endsAt as Timestamp).toMillis() - (p.startsAt as Timestamp).toMillis() > maxDays * 86_400_000) throw new HttpsError('failed-precondition', `Seller promotions can last at most ${maxDays} days.`);
    if ((p.endsAt as Timestamp).toMillis() <= Date.now()) throw new HttpsError('failed-precondition', 'This promotion has already ended.');
  }
  await ref.update({ status: decision, note, decidedBy: adminId, decidedAt: Timestamp.now(), updatedAt: Timestamp.now(), applied: false });
  if (decision === 'approved' && (p.startsAt as Timestamp).toMillis() <= Date.now()) await applyPromotion(id, p, true);
  await audit(adminId, `promotion.${decision}`, 'promotion', id, { productId: p.productId, sellerId: p.sellerId, note });
  await notify(p.sellerId, { type: 'promotion_status', title: `Promotion ${decision}`, body: decision === 'approved' ? 'Your promotion request was approved.' : `Your promotion request was rejected. ${note}`, link: '/seller/promotions' });
  return { ok: true };
});

/** Hourly: start approved promotions whose window opened, end those whose window closed (unsets featured / flashSaleEndsAt). */
export const syncPromotions = onSchedule('every 60 minutes', async () => {
  const plat = await db.collection('platformPromotions').limit(300).get();
  for (const d of plat.docs) await reconcilePlatformPromotion(d.id);
  const snap = await db.collection('promotions').where('status', '==', 'approved').limit(300).get();
  const now = Date.now();
  for (const d of snap.docs) {
    const p = d.data();
    if (now >= (p.endsAt as Timestamp).toMillis()) await applyPromotion(d.id, p, false);
    else if (!p.applied && now >= (p.startsAt as Timestamp).toMillis()) await applyPromotion(d.id, p, true);
  }
});


// ---------------- platform (admin) campaigns: separate collection, separate flags bookkeeping ----------------
async function resolveTargets(p: DocumentData): Promise<string[]> {
  if (p.targetType === 'products') return (p.productIds as string[]).slice(0, 100);
  const col = db.collection('products').where('status', '==', 'approved');
  const q = p.targetType === 'category' ? col.where('categoryId', '==', p.categoryId) : col.where('sellerId', '==', p.storeOwnerId);
  return (await q.limit(100).get()).docs.map((d) => d.id);
}

/** Idempotent: make the products' flags match whether the campaign is live right now. Only touches products it applied itself. */
export async function reconcilePlatformPromotion(id: string): Promise<void> {
  const ref = db.doc(`platformPromotions/${id}`);
  const snap = await ref.get();
  const now = Date.now();
  const p = snap.data();
  const live = !!p && p.active === true && (p.startsAt as Timestamp).toMillis() <= now && now < (p.endsAt as Timestamp).toMillis();
  const applied = (p?.appliedProductIds as string[] | undefined) ?? [];
  const flag = (on: boolean, type: string, ends?: Timestamp) => (type === 'featured' ? { featured: on } : { flashSaleEndsAt: on && ends ? ends : FieldValue.delete() });
  if (live && !p!.applied) {
    const ids: string[] = [];
    const b = db.batch();
    for (const pid of await resolveTargets(p!)) {
      const prod = await db.doc(`products/${pid}`).get();
      if (prod.exists && prod.get('status') === 'approved') { b.update(prod.ref, flag(true, p!.type, p!.endsAt)); ids.push(pid); }
    }
    b.update(ref, { applied: true, appliedProductIds: ids });
    await b.commit();
  } else if (!live && applied.length && p?.applied) {
    const b = db.batch();
    for (const pid of applied) if ((await db.doc(`products/${pid}`).get()).exists) b.update(db.doc(`products/${pid}`), flag(false, p!.type));
    b.update(ref, { applied: false, appliedProductIds: [] });
    await b.commit();
  }
}

/** Fires on every create/edit/toggle/delete in /admin/promotions so changes take effect immediately (the hourly job covers start/end times). */
export const onPlatformPromotionWritten = onDocumentWritten('platformPromotions/{id}', async (event) => {
  const after = event.data?.after, before = event.data?.before;
  if (after?.exists) {
    // edits that change targets/type while applied: undo the old application first
    const a = after.data()!, b = before?.data();
    if (b && a.applied && (a.type !== b.type || a.targetType !== b.targetType || a.categoryId !== b.categoryId || a.storeOwnerId !== b.storeOwnerId || JSON.stringify(a.productIds) !== JSON.stringify(b.productIds))) {
      await after.ref.update({ active: false });   // re-triggers: reconcile unapplies, admin re-activates on purpose
      return;
    }
    await reconcilePlatformPromotion(event.params.id);
  } else if (before?.exists && before.data()!.applied) {
    const p = before.data()!; const b = db.batch();
    for (const pid of (p.appliedProductIds as string[]) ?? []) if ((await db.doc(`products/${pid}`).get()).exists) b.update(db.doc(`products/${pid}`), p.type === 'featured' ? { featured: false } : { flashSaleEndsAt: FieldValue.delete() });
    await b.commit();
  }
});
