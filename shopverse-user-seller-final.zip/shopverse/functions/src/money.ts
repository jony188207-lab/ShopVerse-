import { FieldValue, Timestamp, type Transaction } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { assertActive, audit, clean, db, getSettings, money, notify, requireAdmin, requireRole } from './common';

const inc = (n: number) => FieldValue.increment(money(n));
const balanceRef = (sellerId: string) => db.doc(`sellerBalances/${sellerId}`);

/**
 * Delivered order -> one sellerEarnings doc per order item (doc id == orderItemId, so the trigger is idempotent).
 * Commission is computed HERE from storeFinance.commissionRate (admin-only, not public). Money sits in `pending` for EARNINGS_HOLD_DAYS (the return window).
 */
export async function createEarningsForOrder(orderId: string): Promise<void> {
  const settings = await getSettings();
  await db.runTransaction(async (tx) => {
    const orderSnap = await tx.get(db.doc(`orders/${orderId}`));
    if (!orderSnap.exists) return;
    const sellerId = orderSnap.get('sellerId') as string;
    const storeSnap = await tx.get(db.doc(`stores/${orderSnap.get('storeId')}`));
    const finSnap = await tx.get(db.doc(`storeFinance/${orderSnap.get('storeId')}`));
    // storeFinance wins; legacy stores may still carry commissionRate on the store doc; then the platform default.
    const rate = Number(finSnap.get('commissionRate') ?? storeSnap.get('commissionRate') ?? settings.commissionDefaultPercent);
    const items = await tx.get(db.collection('orderItems').where('orderId', '==', orderId));
    const existing = await Promise.all(items.docs.map((d) => tx.get(db.doc(`sellerEarnings/${d.id}`))));
    const now = Timestamp.now();
    const availableAt = Timestamp.fromMillis(now.toMillis() + settings.earningsHoldDays * 86_400_000);
    let net = 0, gross = 0, commissionSum = 0, units = 0, created = 0;
    items.docs.forEach((d, i) => {
      if (existing[i].exists) return;
      const g = money(Number(d.get('lineTotal')));
      const couponShare = d.get('couponFundedBy') === 'platform' ? 0 : money(Number(d.get('couponShare') ?? 0)); // platform-funded coupons are absorbed by the platform
      const commission = money(((g - couponShare) * rate) / 100);
      const sellerAmount = money(g - couponShare - commission);
      tx.set(db.doc(`sellerEarnings/${d.id}`), {
        sellerId, storeId: orderSnap.get('storeId'), orderId, orderItemId: d.id, productId: d.get('productId'), title: d.get('title'), quantity: d.get('quantity'),
        gross: g, couponShare, commissionRate: rate, commission, sellerAmount, status: 'pending',
        // COD: the platform never saw the cash. Earnings only become withdrawable after an admin confirms the collected cash was remitted (confirmCodRemittance).
        remitted: orderSnap.get('paymentMethod') !== 'cod' || orderSnap.get('codRemitted') === true, createdAt: now, availableAt,
      });
      gross += g; commissionSum += commission; net += sellerAmount; units += Number(d.get('quantity')); created++;
    });
    if (!created) return;
    tx.set(balanceRef(sellerId), { pending: inc(net), grossSales: inc(gross), commissionTotal: inc(commissionSum), netTotal: inc(net), unitsSold: FieldValue.increment(units), ordersDelivered: FieldValue.increment(1), updatedAt: now }, { merge: true });
  });
}

/** Returned / refunded orders: reverse their earnings (idempotent: only touches pending/available docs). May leave `available` negative = seller owes the platform. */
export async function reverseEarningsForOrder(orderId: string): Promise<void> {
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(db.collection('sellerEarnings').where('orderId', '==', orderId));
    const live = snap.docs.filter((d) => d.get('status') === 'pending' || d.get('status') === 'available');
    if (!live.length) return;
    const sellerId = live[0].get('sellerId') as string;
    let pending = 0, available = 0, gross = 0, commission = 0, net = 0, units = 0;
    for (const d of live) {
      const amt = Number(d.get('sellerAmount'));
      if (d.get('status') === 'pending') pending += amt; else available += amt;
      gross += Number(d.get('gross')); commission += Number(d.get('commission')); net += amt; units += Number(d.get('quantity'));
      tx.update(d.ref, { status: 'reversed', reversedAt: Timestamp.now() });
    }
    tx.set(balanceRef(sellerId), { pending: inc(-pending), available: inc(-available), grossSales: inc(-gross), commissionTotal: inc(-commission), netTotal: inc(-net), unitsSold: FieldValue.increment(-units), updatedAt: Timestamp.now() }, { merge: true });
  });
}

/** Hourly: pending earnings whose hold period ended become withdrawable. */
export const releaseEarnings = onSchedule('every 60 minutes', async () => {
  for (let round = 0; round < 5; round++) {
    const due = await db.collection('sellerEarnings').where('status', '==', 'pending').where('remitted', '==', true).where('availableAt', '<=', Timestamp.now()).limit(200).get();
    for (const d of due.docs) {
      await db.runTransaction(async (tx) => {
        const fresh = await tx.get(d.ref);
        if (fresh.get('status') !== 'pending') return;
        const amt = Number(fresh.get('sellerAmount'));
        tx.update(d.ref, { status: 'available' });
        tx.set(balanceRef(fresh.get('sellerId')), { pending: inc(-amt), available: inc(amt), updatedAt: Timestamp.now() }, { merge: true });
      });
    }
    if (due.size < 200) break;
  }
});

const OPEN = ['pending', 'approved', 'processing'];
const METHODS = ['bank_transfer', 'mobile_money', 'cash_pickup'];

/** Balance-checked, idempotent (doc id = uid_requestId). available -> reserved inside one transaction, so two quick requests cannot overdraw. */
export const requestWithdrawal = onCall(async (req) => {
  const uid = await requireRole(req, ['seller']);
  await assertActive(uid);
  const d = (req.data ?? {}) as Record<string, unknown>;
  const requestId = clean(d.requestId, 64);
  const { minWithdrawal } = await getSettings();
  const amount = money(Number(d.amount));
  const method = clean(d.method, 30);
  const details = clean(d.details, 500);
  if (!/^[A-Za-z0-9_-]{16,64}$/.test(requestId)) throw new HttpsError('invalid-argument', 'Invalid request id.');
  if (!Number.isFinite(amount) || amount < minWithdrawal) throw new HttpsError('invalid-argument', `The minimum withdrawal is ${minWithdrawal}.`);
  if (!METHODS.includes(method)) throw new HttpsError('invalid-argument', 'Choose a payout method.');
  if (details.length < 5) throw new HttpsError('invalid-argument', 'Enter your payout details (account / phone / pickup info).');
  const ref = db.doc(`withdrawals/${uid}_${requestId}`);
  await db.runTransaction(async (tx) => {
    if ((await tx.get(ref)).exists) return; // retry of the same request
    const bal = await tx.get(balanceRef(uid));
    const open = await tx.get(db.collection('withdrawals').where('sellerId', '==', uid).where('status', 'in', OPEN).limit(4));
    const store = await tx.get(db.collection('stores').where('ownerId', '==', uid).limit(1));
    if (open.size >= 3) throw new HttpsError('failed-precondition', 'You already have 3 open withdrawal requests. Wait for them to be processed.');
    const available = money(Number(bal.get('available') ?? 0));
    if (amount > available) throw new HttpsError('failed-precondition', `Your available balance is ${available.toFixed(2)}.`);
    const now = Timestamp.now();
    tx.set(ref, { sellerId: uid, storeName: store.empty ? '' : store.docs[0].get('name'), amount, method, details, status: 'pending', timeline: [{ status: 'pending', at: now }], createdAt: now, updatedAt: now });
    tx.set(balanceRef(uid), { available: inc(-amount), reserved: inc(amount), updatedAt: now }, { merge: true });
  });
  return { id: ref.id };
});

function release(tx: Transaction, sellerId: string, amount: number, to: 'available' | 'paid') {
  const now = Timestamp.now();
  tx.set(balanceRef(sellerId), to === 'available' ? { reserved: inc(-amount), available: inc(amount), updatedAt: now } : { reserved: inc(-amount), paidOut: inc(amount), updatedAt: now }, { merge: true });
}

export const cancelWithdrawal = onCall(async (req) => {
  const uid = await requireRole(req, ['seller', 'user']); // a suspended seller can still cancel and recover pending money
  const id = clean((req.data as { id?: unknown })?.id, 120);
  const ref = db.doc(`withdrawals/${id}`);
  await db.runTransaction(async (tx) => {
    const w = await tx.get(ref);
    if (!w.exists || w.get('sellerId') !== uid) throw new HttpsError('not-found', 'Withdrawal not found.');
    if (w.get('status') !== 'pending') throw new HttpsError('failed-precondition', 'Only pending requests can be cancelled.');
    release(tx, uid, Number(w.get('amount')), 'available');
    tx.update(ref, { status: 'cancelled', updatedAt: Timestamp.now(), timeline: FieldValue.arrayUnion({ status: 'cancelled', at: Timestamp.now() }) });
  });
  return { ok: true };
});

const NEXT: Record<string, string[]> = { pending: ['approved', 'rejected'], approved: ['processing', 'rejected'], processing: ['completed', 'rejected'] };

export const reviewWithdrawal = onCall(async (req) => {
  const adminId = await requireAdmin(req);
  const { id, status } = (req.data ?? {}) as { id?: unknown; status?: unknown };
  const note = clean((req.data as { note?: unknown })?.note, 500);
  if (typeof id !== 'string' || typeof status !== 'string') throw new HttpsError('invalid-argument', 'Missing fields.');
  if (status === 'rejected' && note.length < 5) throw new HttpsError('invalid-argument', 'Give a reason for the rejection.');
  const ref = db.doc(`withdrawals/${id}`);
  let sellerId = '', amount = 0;
  await db.runTransaction(async (tx) => {
    const w = await tx.get(ref);
    if (!w.exists) throw new HttpsError('not-found', 'Withdrawal not found.');
    if (!(NEXT[w.get('status')] ?? []).includes(status)) throw new HttpsError('failed-precondition', `Cannot move a ${w.get('status')} withdrawal to ${status}.`);
    sellerId = w.get('sellerId'); amount = Number(w.get('amount'));
    if (status === 'rejected') release(tx, sellerId, amount, 'available');
    if (status === 'completed') release(tx, sellerId, amount, 'paid');
    const now = Timestamp.now();
    tx.update(ref, { status, note, processedBy: adminId, updatedAt: now, timeline: FieldValue.arrayUnion({ status, at: now }) });
  });
  await audit(adminId, `withdrawal.${status}`, 'withdrawal', id, { sellerId, amount, note });
  await notify(sellerId, { type: 'withdrawal_status', title: `Withdrawal ${status}`, body: `Your withdrawal of ${amount.toFixed(2)} is ${status}.${note ? ' ' + note : ''}`, link: '/seller/withdrawals' });
  return { ok: true };
});

/**
 * Admin confirms that the cash collected on delivery for this order reached the platform (courier / collection partner remittance).
 * Only then do the seller's earnings for the order start counting towards their withdrawable balance (after the hold period).
 */
export const confirmCodRemittance = onCall(async (req) => {
  const adminId = await requireAdmin(req);
  const orderId = clean((req.data as { orderId?: unknown })?.orderId, 128);
  if (!orderId) throw new HttpsError('invalid-argument', 'Missing order.');
  const ref = db.doc(`orders/${orderId}`);
  let sellerId = ''; let orderNumber = '';
  await db.runTransaction(async (tx) => {
    const o = await tx.get(ref);
    if (!o.exists) throw new HttpsError('not-found', 'Order not found.');
    if (o.get('status') !== 'delivered') throw new HttpsError('failed-precondition', 'Only delivered orders can be confirmed.');
    if (o.get('paymentMethod') !== 'cod') throw new HttpsError('failed-precondition', 'This order was not cash on delivery.');
    if (o.get('codRemitted') === true) return;   // idempotent
    sellerId = String(o.get('sellerId')); orderNumber = String(o.get('orderNumber'));
    const earn = await tx.get(db.collection('sellerEarnings').where('orderId', '==', orderId));
    tx.update(ref, { codRemitted: true, codRemittedBy: adminId, codRemittedAt: Timestamp.now(), updatedAt: Timestamp.now() });
    earn.forEach((d) => { if (d.get('status') !== 'reversed') tx.update(d.ref, { remitted: true }); });
  });
  if (sellerId) {
    await audit(adminId, 'order.cod_remitted', 'order', orderId, { note: orderNumber });
    await notify(sellerId, { type: 'withdrawal_status', title: 'Cash confirmed', body: `Order ${orderNumber}: the platform confirmed the cash. Your earnings release after the hold period.`, link: '/seller/earnings' });
  }
  return { ok: true };
});
