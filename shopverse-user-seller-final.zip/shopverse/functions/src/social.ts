import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import { onDocumentCreated, onDocumentUpdated, onDocumentWritten } from 'firebase-functions/v2/firestore';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { db, notify } from './common';

// Counters are written ONLY here (rules forbid clients). Triggers are at-least-once, so a rare retry can over-count by one;
// trendScore is recomputed hourly from the counters, which keeps ranking self-healing.
const bump = (videoId: string, field: string, n: number) => db.doc(`videos/${videoId}`).update({ [field]: FieldValue.increment(n) }).catch(() => undefined);

export const onVideoLikeWritten = onDocumentWritten('videoLikes/{id}', async (e) => {
  const b = e.data?.before, a = e.data?.after;
  const videoId = (a?.exists ? a : b)?.get('videoId') as string | undefined;
  if (!videoId) return;
  if (!b?.exists && a?.exists) {
    await bump(videoId, 'likeCount', 1);
    const v = (await db.doc(`videos/${videoId}`).get()).data();
    const liker = String(a.get('userId'));
    if (v?.ownerId && v.ownerId !== liker) await notify(String(v.ownerId), { type: 'video_like', title: 'Someone liked your video', body: `“${String(v.title).slice(0, 60)}” got a new like.`, link: `/video?v=${videoId}`, relatedId: videoId, relatedType: 'video', dedupeUnread: true });
  } else if (b?.exists && !a?.exists) await bump(videoId, 'likeCount', -1);
});

export const onVideoSaveWritten = onDocumentWritten('videoSaves/{id}', async (e) => {
  const b = e.data?.before, a = e.data?.after;
  const videoId = (a?.exists ? a : b)?.get('videoId') as string | undefined;
  if (!videoId) return;
  if (!b?.exists && a?.exists) await bump(videoId, 'saveCount', 1); else if (b?.exists && !a?.exists) await bump(videoId, 'saveCount', -1);
});

/** One view per signed-in user per video (doc id = videoId_uid; rules block updates), so refreshes and re-watches cannot inflate the count. */
export const onVideoViewCreated = onDocumentCreated('videoViews/{id}', async (e) => {
  const videoId = e.data?.get('videoId') as string | undefined;
  if (videoId) await bump(videoId, 'viewCount', 1);
});

/** commentCount = number of VISIBLE comments (hide/restore/delete by users or moderators keeps it right). */
export const onVideoCommentWritten = onDocumentWritten('videoComments/{id}', async (e) => {
  const b = e.data?.before, a = e.data?.after;
  const videoId = (a?.exists ? a : b)?.get('videoId') as string | undefined;
  if (!videoId) return;
  const was = b?.exists && b.get('status') === 'visible', is = a?.exists && a.get('status') === 'visible';
  if (!was && is) {
    await bump(videoId, 'commentCount', 1);
    if (!b?.exists) {   // brand-new comment (not a restore)
      const v = (await db.doc(`videos/${videoId}`).get()).data();
      if (v?.ownerId && v.ownerId !== a!.get('userId')) await notify(String(v.ownerId), { type: 'video_comment', title: `${String(a!.get('userName') ?? 'Someone')} commented`, body: String(a!.get('text') ?? '').slice(0, 120), link: `/video?v=${videoId}`, relatedId: videoId, relatedType: 'video' });
    }
  } else if (was && !is) await bump(videoId, 'commentCount', -1);
});

/** Tells the seller what moderation decided (and why). */
export const onVideoModerated = onDocumentUpdated('videos/{videoId}', async (e) => {
  const b = e.data?.before.data(), a = e.data?.after.data();
  if (!b || !a || b.status === a.status || !a.ownerId) return;
  const note = a.moderationNote ? ` Note: ${a.moderationNote}` : '';
  const link = '/seller/videos';
  if (a.status === 'published') await notify(a.ownerId, { type: b.status === 'suspended' ? 'video_restored' : 'video_approved', title: b.status === 'suspended' ? 'Video restored' : 'Video approved', body: `“${a.title}” is live in the video feed.`, link: `/video?v=${e.params.videoId}` });
  else if (a.status === 'rejected') await notify(a.ownerId, { type: 'video_rejected', title: 'Video rejected', body: `“${a.title}” was not approved.${note}`, link });
  else if (a.status === 'suspended') await notify(a.ownerId, { type: 'video_suspended', title: 'Video suspended', body: `“${a.title}” was taken down.${note}`, link });
});

/** Hourly: time-decayed engagement score for videos from the last 14 days (powers the Trending tab). Older videos drop to 0. */
export const rankVideos = onSchedule('every 60 minutes', async () => {
  const now = Date.now();
  const snap = await db.collection('videos').where('status', '==', 'published').where('visibility', '==', 'public')
    .where('createdAt', '>=', Timestamp.fromMillis(now - 14 * 86_400_000)).limit(500).get();
  let batch = db.batch(); let n = 0;
  for (const d of snap.docs) {
    const v = d.data();
    const ageH = Math.max(0, (now - (v.createdAt as Timestamp).toMillis()) / 3_600_000);
    const raw = 3 * Number(v.likeCount ?? 0) + 4 * Number(v.commentCount ?? 0) + 5 * Number(v.saveCount ?? 0) + 0.5 * Number(v.viewCount ?? 0);
    const score = Math.round((raw / Math.pow(ageH + 2, 1.4)) * 1000) / 1000;
    if (score !== v.trendScore) { batch.update(d.ref, { trendScore: score }); n++; }
    if (n === 400) { await batch.commit(); batch = db.batch(); n = 0; }
  }
  if (n) await batch.commit();
});

/**
 * Chat bookkeeping (trusted): on every message, bump the receiver's unread counter and last-message fields, and notify the receiver
 * when this is their FIRST unread message (so a busy thread produces one notification, not one per line). Clients cannot write these fields.
 */
export const onMessageCreated = onDocumentCreated('conversations/{cid}/messages/{mid}', async (e) => {
  const m = e.data?.data();
  if (!m) return;
  const ref = db.doc(`conversations/${e.params.cid}`);
  let prevUnread = 0; let sellerId = ''; let storeName = '';
  await db.runTransaction(async (tx) => {
    const c = await tx.get(ref);
    if (!c.exists) return;
    sellerId = String(c.get('sellerId'));
    const unread = { ...(c.get('unread') as Record<string, number>) };
    prevUnread = Number(unread[m.receiverId] ?? 0);
    unread[m.receiverId] = prevUnread + 1;
    tx.update(ref, { unread, lastMessage: String(m.text).slice(0, 120), lastMessageAt: m.createdAt, lastSenderId: m.senderId, updatedAt: m.createdAt, ...(m.productId ? { lastProductId: m.productId } : {}), ...(m.orderId ? { lastOrderId: m.orderId } : {}) });
  });
  if (prevUnread > 0 || !sellerId) return;
  const fromSeller = m.senderId === sellerId;
  if (fromSeller) storeName = String((await db.doc(`stores/${(await ref.get()).get('storeId')}`).get()).get('name') ?? 'The seller');
  await notify(m.receiverId, fromSeller
    ? { type: 'seller_response', title: `${storeName} replied`, body: String(m.text).slice(0, 100), link: `/messages/${e.params.cid}` }
    : { type: 'new_message', title: 'New message from a buyer', body: String(m.text).slice(0, 100), link: `/messages/${e.params.cid}` });
});
