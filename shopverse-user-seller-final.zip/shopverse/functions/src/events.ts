import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import { onDocumentCreated, onDocumentUpdated, onDocumentWritten } from 'firebase-functions/v2/firestore';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { ADMINS, STAFF, db, notify, notifyStaff } from './common';
import { wishlistEvent } from './notifyLogic';

// ===== Admin / moderator alerts =====
export const onSellerApplicationCreated = onDocumentCreated('sellerApplications/{uid}', async (e) => {
  const a = e.data?.data(); if (!a) return;
  await notifyStaff(ADMINS, { type: 'admin_seller_application', title: 'New seller application', body: `${a.storeName} (${a.city}, ${a.country}) is waiting for review.`, link: `/admin/sellers/${e.params.uid}` });
});
/** Resubmissions (rejected -> pending) alert admins again. */
export const onSellerApplicationResubmitted = onDocumentUpdated('sellerApplications/{uid}', async (e) => {
  const b = e.data?.before.data(), a = e.data?.after.data();
  if (b?.status === 'rejected' && a?.status === 'pending') await notifyStaff(ADMINS, { type: 'admin_seller_application', title: 'Seller application resubmitted', body: `${a.storeName} was resubmitted after a rejection.`, link: `/admin/sellers/${e.params.uid}` });
});

/** Products entering the review queue (new or resubmitted) -> moderators + admins; stock/price/wishlist side effects. */
export const onProductChanged = onDocumentWritten('products/{pid}', async (e) => {
  const b = e.data?.before.data(), a = e.data?.after.data();
  if (!a) return;
  const pid = e.params.pid;
  if (a.status === 'pending_review' && b?.status !== 'pending_review') {
    await notifyStaff(STAFF, { type: 'admin_product_pending', title: 'Product waiting for approval', body: `“${a.title}” was submitted for review.`, link: '/admin/products' });
  }
  if (!b) return;
  if (a.status === 'out_of_stock' && b.status !== 'out_of_stock') {
    await notify(a.sellerId, { type: 'product_out_of_stock', title: 'Product sold out', body: `“${a.title}” is out of stock. Restock it to sell again.`, link: `/seller/products/${pid}/edit` });
  }
  const ev = wishlistEvent({ price: Number(b.price), stock: Number(b.stock), status: String(b.status) }, { price: Number(a.price), stock: Number(a.stock), status: String(a.status) });
  if (ev) {
    // At most 200 wishlisters per event (bounded cost); each respects their own 'wishlist' preference.
    const w = await db.collection('wishlists').where('productId', '==', pid).limit(200).get();
    const body = ev === 'wishlist_price_drop' ? `“${a.title}” dropped to ${Number(a.price).toFixed(2)}.` : `“${a.title}” is back in stock.`;
    await Promise.all(w.docs.map((d) => notify(String(d.get('userId')), { type: ev, title: ev === 'wishlist_price_drop' ? 'Price drop on your wishlist' : 'Back in stock', body, link: `/product/${pid}`, image: a.images?.[0] ?? '', dedupeUnread: true })));
  }
});

export const onReportCreated = onDocumentCreated('reports/{id}', async (e) => {
  const r = e.data?.data(); if (!r) return;
  const adminOnly = r.targetType === 'conversation' || r.targetType === 'message';   // private chats: admins only (moderators cannot read them)
  await notifyStaff(adminOnly ? ADMINS : STAFF, { type: 'admin_report', title: `New ${r.targetType} report`, body: String(r.reason ?? '').slice(0, 120), link: '/admin/reports', dedupeUnread: true, relatedId: `${r.targetType}:${r.targetId}` });
});

export const onWithdrawalRequested = onDocumentCreated('withdrawals/{id}', async (e) => {
  const w = e.data?.data(); if (!w) return;
  await notifyStaff(ADMINS, { type: 'admin_withdrawal', title: 'Withdrawal request', body: `${w.storeName || 'A seller'} requested ${Number(w.amount).toFixed(2)}.`, link: '/admin/withdrawals' });
});

/** Security-relevant admin actions are echoed to super admins (except the actor). */
export const onAdminLogCreated = onDocumentCreated('adminLogs/{id}', async (e) => {
  const l = e.data?.data(); if (!l) return;
  const action = String(l.action ?? '');
  if (!/^(role\.|settings\.|ads\.|user\.suspend|user\.reactivate|seller\.suspend)/.test(action)) return;
  await notifyStaff(['super_admin'], { type: 'admin_security', title: 'Security-relevant admin action', body: `${action} on ${l.targetType}/${String(l.targetId).slice(0, 12)}`, link: '/admin/logs' }, String(l.adminId));
});

// ===== buyer / seller events =====
/** Seller replied to a review -> tell the reviewer. */
export const onReviewResponded = onDocumentUpdated('reviews/{id}', async (e) => {
  const b = e.data?.before.data(), a = e.data?.after.data();
  if (!b || !a || b.sellerResponse || !a.sellerResponse) return;
  await notify(String(a.userId), { type: 'review_response', title: 'The seller replied to your review', body: String(a.sellerResponse).slice(0, 120), link: `/product/${a.productId}` });
});

/** Seller learns when a coupon runs out. */
export const onCouponUpdated = onDocumentUpdated('coupons/{id}', async (e) => {
  const b = e.data?.before.data(), a = e.data?.after.data();
  if (!b || !a || a.sellerId === 'platform' || !(a.usageLimit > 0)) return;
  if (b.usedCount < b.usageLimit && a.usedCount >= a.usageLimit) await notify(String(a.sellerId), { type: 'coupon_exhausted', title: `Coupon ${a.code} fully used`, body: `All ${a.usageLimit} uses were redeemed.`, link: '/seller/coupons' });
});

// ===== maintenance =====
/** Daily: drop push tokens that no device has refreshed for 60 days. */
export const cleanupPushTokens = onSchedule('every 24 hours', async () => {
  const cutoff = Timestamp.fromMillis(Date.now() - 60 * 86_400_000);
  for (let i = 0; i < 5; i++) {
    const old = await db.collectionGroup('fcmTokens').where('lastSeenAt', '<', cutoff).limit(400).get();
    if (old.empty) return;
    const b = db.batch(); old.forEach((d) => b.delete(d.ref)); await b.commit();
    if (old.size < 400) return;
  }
});
/** Daily: notifications older than 90 days are deleted (bounded, 5 batches per run). */
export const pruneOldNotifications = onSchedule('every 24 hours', async () => {
  const cutoff = Timestamp.fromMillis(Date.now() - 90 * 86_400_000);
  for (let i = 0; i < 5; i++) {
    const old = await db.collection('notifications').where('createdAt', '<', cutoff).limit(400).get();
    if (old.empty) return;
    const b = db.batch(); old.forEach((d) => b.delete(d.ref)); await b.commit();
    if (old.size < 400) return;
  }
});
void FieldValue;
