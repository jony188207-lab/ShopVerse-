import { describe, expect, it } from 'vitest';
import { OrderError, applyCouponCode, couponDiscount, priceCart, type CouponData, type ProductData, type StoreData } from './orderLogic';

const P = (o: Partial<ProductData> = {}): ProductData => ({ title: 'Widget', status: 'approved', price: 10, originalPrice: 12, stock: 5, sellerId: 's1', storeId: 'st1', ...o });
const stores = new Map<string, StoreData>([['st1', { name: 'One', shippingFee: 4, freeShippingOver: 50 }], ['st2', { name: 'Two', shippingFee: 0 }]]);
const line = (productId: string, quantity: number, variantKey = 'default') => ({ cartId: `c-${productId}-${variantKey}`, productId, variantKey, quantity });
const code = (fn: () => unknown) => { try { fn(); return null; } catch (e) { return e instanceof OrderError ? e.code : 'other'; } };

describe('priceCart', () => {
  it('uses SERVER price, never client input', () => {
    const r = priceCart([line('a', 2)], new Map([['a', P()]]), stores);
    expect(r.orders[0].subtotal).toBe(20);
    expect(r.orders[0].discount).toBe(4);
    expect(r.orders[0].shipping).toBe(4);
    expect(r.orders[0].total).toBe(24);
  });
  it('free shipping over threshold', () => {
    const r = priceCart([line('a', 5)], new Map([['a', P({ price: 10, stock: 9 })]]), stores);
    expect(r.orders[0].shipping).toBe(0);
  });
  it('splits multi-seller carts into one order per seller', () => {
    const products = new Map([['a', P()], ['b', P({ sellerId: 's2', storeId: 'st2', title: 'Gadget', price: 7 })]]);
    const r = priceCart([line('a', 1), line('b', 3)], products, stores);
    expect(r.orders.length).toBe(2);
    expect(r.orders.find((o) => o.sellerId === 's2')!.total).toBe(21);
  });
  it('rejects overselling', () => {
    expect(code(() => priceCart([line('a', 6)], new Map([['a', P()]]), stores))).toBe('insufficient-stock');
  });
  it('counts stock across lines of the same product (variants)', () => {
    const variants = [{ key: 'red', label: 'Red', stock: 3 }, { key: 'blue', label: 'Blue', stock: 3 }];
    const p = P({ stock: 4, variants });
    expect(code(() => priceCart([line('a', 3, 'red'), line('a', 2, 'blue')], new Map([['a', p]]), stores))).toBe('insufficient-stock');
    const ok = priceCart([line('a', 2, 'red'), line('a', 2, 'blue')], new Map([['a', p]]), stores);
    expect(ok.stock.get('a')!.stock).toBe(0);
    expect(ok.stock.get('a')!.variants!.map((v) => v.stock)).toEqual([1, 1]);
  });
  it('variant price overrides base price; invalid variant rejected', () => {
    const p = P({ variants: [{ key: 'xl', label: 'XL', price: 15, stock: 2 }] });
    expect(priceCart([line('a', 1, 'xl')], new Map([['a', p]]), stores).orders[0].subtotal).toBe(15);
    expect(code(() => priceCart([line('a', 1, 'nope')], new Map([['a', p]]), stores))).toBe('invalid');
    expect(code(() => priceCart([line('a', 1)], new Map([['a', p]]), stores))).toBe('invalid');
  });
  it('rejects non-approved and missing products, bad quantities, empty cart', () => {
    expect(code(() => priceCart([line('a', 1)], new Map([['a', P({ status: 'suspended' })]]), stores))).toBe('unavailable');
    expect(code(() => priceCart([line('zzz', 1)], new Map(), stores))).toBe('not-found');
    expect(code(() => priceCart([line('a', 0)], new Map([['a', P()]]), stores))).toBe('invalid');
    expect(code(() => priceCart([line('a', 1.5)], new Map([['a', P()]]), stores))).toBe('invalid');
    expect(code(() => priceCart([], new Map(), stores))).toBe('invalid');
  });
});

const C = (o: Partial<CouponData> = {}): CouponData => ({ active: true, discountType: 'percent', discountValue: 10, minOrder: 0, maxDiscount: 0, usageLimit: 0, usedCount: 0, ...o });
const NOW = new Date('2026-06-15T12:00:00Z');

describe('couponDiscount', () => {
  it('percent, fixed, cap, and never more than the subtotal', () => {
    expect(couponDiscount(50, C(), NOW)).toEqual({ ok: true, amount: 5 });
    expect(couponDiscount(50, C({ discountType: 'fixed', discountValue: 8 }), NOW)).toEqual({ ok: true, amount: 8 });
    expect(couponDiscount(200, C({ discountValue: 50, maxDiscount: 20 }), NOW)).toEqual({ ok: true, amount: 20 });
    expect(couponDiscount(5, C({ discountType: 'fixed', discountValue: 99 }), NOW)).toEqual({ ok: true, amount: 5 });
  });
  it('rejects inactive, early, expired, redeemed, below minimum', () => {
    expect(couponDiscount(50, C({ active: false }), NOW).ok).toBe(false);
    expect(couponDiscount(50, C({ startsAt: new Date('2026-07-01') }), NOW).ok).toBe(false);
    expect(couponDiscount(50, C({ endsAt: new Date('2026-06-01') }), NOW).ok).toBe(false);
    expect(couponDiscount(50, C({ usageLimit: 3, usedCount: 3 }), NOW).ok).toBe(false);
    expect(couponDiscount(50, C({ minOrder: 100 }), NOW).ok).toBe(false);
  });
});

describe('applyCouponCode', () => {
  const two = () => priceCart([line('a', 1), line('b', 1)], new Map([['a', P({ price: 30 })], ['b', P({ sellerId: 's2', storeId: 'st2', price: 20 })]]), stores).orders;
  it('applies only to the store that owns the coupon; other stores untouched', () => {
    const out = applyCouponCode(two(), 'SAVE', new Map([['s1', C({ discountValue: 10 })], ['s2', null]]), NOW);
    const s1 = out.find((o) => o.sellerId === 's1')!; const s2 = out.find((o) => o.sellerId === 's2')!;
    expect(s1.couponDiscount).toBe(3); expect(s1.total).toBe(30 - 3 + 4); expect(s1.couponId).toBe('s1_SAVE');
    expect(s2.couponDiscount).toBe(0); expect(s2.total).toBe(20);
  });
  it('splits the discount across lines to the exact cent', () => {
    const o = priceCart([line('a', 1), line('b', 1), line('c', 1)], new Map([['a', P({ price: 10 })], ['b', P({ price: 10 })], ['c', P({ price: 10 })]]), stores).orders;
    const r = applyCouponCode(o, 'X', new Map([['s1', C({ discountType: 'fixed', discountValue: 10 })]]), NOW)[0];
    expect(Math.round(r.lines.reduce((s, l) => s + l.couponShare, 0) * 100)).toBe(1000);
  });
  it('fails closed with the real reason when it applies nowhere', () => {
    expect(() => applyCouponCode(two(), 'SAVE', new Map([['s1', C({ active: false })], ['s2', null]]), NOW)).toThrow(/not active/);
    expect(() => applyCouponCode(two(), 'NOPE', new Map([['s1', null], ['s2', null]]), NOW)).toThrow(/does not apply/);
  });
  it("another seller's coupon can never discount this seller's items", () => {
    const out = applyCouponCode(two(), 'SAVE', new Map([['s2', C()]]), NOW);
    expect(out.find((o) => o.sellerId === 's1')!.couponDiscount).toBe(0);
  });
});

describe('platform coupons', () => {
  const two = () => priceCart([line('a', 1), line('b', 1)], new Map([['a', P({ price: 30 })], ['b', P({ sellerId: 's2', storeId: 'st2', price: 20 })]]), stores).orders;
  it('applies to every store, platform-funded', () => {
    const out = applyCouponCode(two(), 'PLAT', new Map(), NOW, C({ discountValue: 10 }));
    expect(out.map((o) => [o.sellerId, o.couponDiscount, o.couponFundedBy, o.couponId])).toEqual([['s1', 3, 'platform', 'platform_PLAT'], ['s2', 2, 'platform', 'platform_PLAT']]);
  });
  it("a store's own coupon beats the platform one; an invalid own coupon falls back to platform", () => {
    let out = applyCouponCode(two(), 'X', new Map([['s1', C({ discountValue: 50 })]]), NOW, C({ discountValue: 10 }));
    expect(out[0]).toMatchObject({ couponDiscount: 15, couponFundedBy: 'seller' }); expect(out[1]).toMatchObject({ couponDiscount: 2, couponFundedBy: 'platform' });
    out = applyCouponCode(two(), 'X', new Map([['s1', C({ active: false })]]), NOW, C({ discountValue: 10 }));
    expect(out[0]).toMatchObject({ couponDiscount: 3, couponFundedBy: 'platform' });
  });
});
