// Pure notification rules (no Firebase imports) so they are unit-testable.
export type Category = 'orders' | 'promotions' | 'messages' | 'reviews' | 'wishlist' | 'video' | 'followers' | 'seller' | 'admin' | 'system';

/** type -> preference category. 'system' is MANDATORY (account/safety decisions) and ignores preferences. Unknown types fail OPEN as system. */
const CATEGORY: Record<string, Category> = {
  // buyer
  order_placed: 'orders', order_confirmed: 'orders', order_processing: 'orders', order_shipped: 'orders', order_out_for_delivery: 'orders', order_delivered: 'orders', order_cancelled: 'orders',
  return_requested: 'orders', order_returned: 'orders', return_rejected: 'orders', order_refunded: 'orders',
  review_response: 'reviews', wishlist_price_drop: 'wishlist', wishlist_restock: 'wishlist',
  new_message: 'messages', seller_response: 'messages', new_follower: 'followers', video_like: 'video', video_comment: 'video', announcement_promo: 'promotions',
  // seller business events
  new_order: 'seller', seller_order_cancelled: 'seller', seller_return_requested: 'seller', product_approved: 'seller', product_rejected: 'seller', product_restored: 'seller', product_out_of_stock: 'seller',
  review_received: 'seller', withdrawal_status: 'seller', promotion_status: 'seller', coupon_exhausted: 'seller', video_approved: 'seller', video_rejected: 'seller', video_restored: 'seller',
  // admin
  admin_seller_application: 'admin', admin_product_pending: 'admin', admin_report: 'admin', admin_withdrawal: 'admin', admin_return: 'admin', admin_security: 'admin',
  // mandatory
  seller_approve: 'system', seller_reject: 'system', seller_suspend: 'system', seller_reactivate: 'system', product_suspended: 'system', video_suspended: 'system', role_changed: 'system', announcement_important: 'system',
};
export const categoryOf = (type: string): Category => CATEGORY[type] ?? 'system';
export const PREF_KEYS: Exclude<Category, 'system'>[] = ['orders', 'promotions', 'messages', 'reviews', 'wishlist', 'video', 'followers', 'seller', 'admin'];

export interface Prefs { push: boolean; [k: string]: boolean }
export function allowed(type: string, prefs: Partial<Record<string, unknown>> | undefined): { inApp: boolean; push: boolean } {
  const cat = categoryOf(type);
  if (cat === 'system') return { inApp: true, push: prefs?.push !== false };
  const on = prefs?.[cat] !== false;   // default ON when the user never saved preferences
  return { inApp: on, push: on && prefs?.push !== false };
}

/** Buyer-facing type for an order status change (null = nothing to send). */
export function orderEventType(before: string, after: string): string | null {
  if (after === 'cancelled') return 'order_cancelled';
  if (after === 'return_requested') return 'return_requested';
  if (after === 'returned') return 'order_returned';              // return approved
  if (after === 'delivered' && before === 'return_requested') return 'return_rejected';
  if (after === 'refunded') return 'order_refunded';
  return ({ confirmed: 'order_confirmed', processing: 'order_processing', shipped: 'order_shipped', out_for_delivery: 'order_out_for_delivery', delivered: 'order_delivered' } as Record<string, string>)[after] ?? null;
}
export const orderEventText = (type: string, store: string): { title: string; body: string } => ({
  order_placed: { title: 'Order placed', body: `Your order from ${store} was received.` },
  order_confirmed: { title: 'Order confirmed', body: `${store} confirmed your order.` },
  order_processing: { title: 'Order being prepared', body: `${store} is preparing your order.` },
  order_shipped: { title: 'Order shipped', body: `${store} shipped your order.` },
  order_out_for_delivery: { title: 'Out for delivery', body: 'Your order is on its way to you today.' },
  order_delivered: { title: 'Order delivered', body: 'Your order was delivered. You can now review your items.' },
  order_cancelled: { title: 'Order cancelled', body: `Your order from ${store} was cancelled.` },
  return_requested: { title: 'Return requested', body: 'We received your return request.' },
  order_returned: { title: 'Return approved', body: 'Your return was approved.' },
  return_rejected: { title: 'Return not approved', body: 'Your return request was not approved. Your order stays delivered.' },
  order_refunded: { title: 'Refund issued', body: 'Your refund was processed.' },
}[type] ?? { title: 'Order update', body: `Your order from ${store} changed.` });

/** Derive relatedType/relatedId from an in-app deep link (only routes that exist in this app). */
export function deriveRelated(link: string): { relatedType: string; relatedId: string } {
  const rules: [RegExp, string][] = [[/^\/orders\/([^/?#]+)/, 'order'], [/^\/seller\/orders\/([^/?#]+)/, 'order'], [/^\/product\/([^/?#]+)/, 'product'], [/^\/seller\/products\/([^/?#]+)/, 'product'], [/^\/messages\/([^/?#]+)/, 'conversation'], [/^\/video\?v=([^&#]+)/, 'video'], [/^\/store\/([^/?#]+)/, 'store'], [/^\/admin\/sellers\/([^/?#]+)/, 'seller']];
  for (const [re, t] of rules) { const m = link.match(re); if (m) return { relatedType: t, relatedId: m[1] }; }
  if (link.startsWith('/seller/withdrawals') || link.startsWith('/admin/withdrawals')) return { relatedType: 'withdrawal', relatedId: '' };
  return { relatedType: '', relatedId: '' };
}
/** Only same-app relative paths may be stored as deep links. */
export const safeLink = (l: string | undefined): string => (l && l.startsWith('/') && !l.startsWith('//') && !l.includes('\\') ? l.slice(0, 300) : '');

/** Wishlist alerts: price dropped by >= 5%, or product is purchasable again. */
export function wishlistEvent(b: { price: number; stock: number; status: string }, a: { price: number; stock: number; status: string }): 'wishlist_price_drop' | 'wishlist_restock' | null {
  if (a.status !== 'approved') return null;
  if (b.stock <= 0 && a.stock > 0) return 'wishlist_restock';
  if (a.price > 0 && b.price > 0 && a.price <= b.price * 0.95) return 'wishlist_price_drop';
  return null;
}
