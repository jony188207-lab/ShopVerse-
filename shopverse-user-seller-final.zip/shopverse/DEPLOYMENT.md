# ShopVerse — deployment & production handoff

> **Status of this document:** every step below is *instructions*. Nothing here has been executed against a real Firebase project, host or device by the author (no network/registry access in the authoring environment). Run the verification commands in §0 first and treat any failure as a blocker.

**Stack:** Next.js 14 (App Router, server-rendered metadata + ISR) · Firebase Auth / Firestore / Storage / FCM · Cloud Functions (Node 20) · PWA (installable) · Android via Trusted Web Activity.

## 0. Verify before you deploy (on your machine)
```bash
node --version            # >= 18.18 (functions need Node 20 at deploy time)
npm install
npm --prefix functions install
npm run preflight         # offline packaging/config checks (this was run: see AUDIT.md)
npm run typecheck && npm run typecheck:functions
npm run lint
npm test                  # unit tests incl. checkout/coupon/notification logic
npm run test:rules        # Firestore rules tests (needs Java for the emulator)
npm run build
```
Fix every failure before continuing. None of `typecheck/lint/test/test:rules/build` could be run by the author.

## 1. Firebase project setup (console — cannot be automated from here)
1. https://console.firebase.google.com → **Add project** (Google Analytics optional).
2. **Upgrade to Blaze** (pay-as-you-go). Cloud Functions, scheduled jobs and Storage in new projects require it. Set a **budget alert** (Billing → Budgets).
3. **Project settings → Your apps → Web (</>)** → register “ShopVerse Web” → copy the config into your env vars (§2).
4. **Authentication → Sign-in method → Email/Password: Enable.** *Settings → Authorized domains:* add your production domain (and the Vercel preview domain if you use previews). *Settings → User actions:* enable **email enumeration protection**. Optionally enable the stricter password policy.
5. **Firestore Database → Create database** → *Production mode* → choose a region near your users (cannot change later).
6. **Storage → Get started** (production mode, same region family).
7. **Cloud Messaging → Web Push certificates → Generate key pair** → copy the **public** key to `NEXT_PUBLIC_FIREBASE_VAPID_KEY`.
8. (Recommended) **App Check → Apps → Web → reCAPTCHA v3**: create a v3 *site key* at https://www.google.com/recaptcha/admin, register it, put the site key in `NEXT_PUBLIC_RECAPTCHA_SITE_KEY`. Deploy, browse the site, confirm requests are “verified” in App Check metrics, **then** click *Enforce* for Firestore, Storage and Functions (enforcing earlier locks everyone out).
9. Install the CLI and select the project: `npx firebase login && npx firebase use --add` (creates `.firebaserc`; it is not committed).

## 2. Environment variables
Copy `.env.example` → `.env.local` for local work; set the same names in your host’s dashboard for production.

| Variable | Where from | Notes |
|---|---|---|
| `NEXT_PUBLIC_FIREBASE_API_KEY`, `_AUTH_DOMAIN`, `_PROJECT_ID`, `_STORAGE_BUCKET`, `_MESSAGING_SENDER_ID`, `_APP_ID` | Web app config | Public by design — **security comes from the rules** |
| `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` | Web app config | Optional |
| `NEXT_PUBLIC_FIREBASE_VAPID_KEY` | Cloud Messaging | Public key |
| `NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION` | default `us-central1` | Must match `functions/src/common.ts` |
| `NEXT_PUBLIC_SITE_URL` | your domain | Canonical URLs, sitemap, Open Graph |
| `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` | reCAPTCHA v3 | Optional App Check |
| `ANDROID_PACKAGE_NAME`, `ANDROID_CERT_SHA256` | Play Console | For `/.well-known/assetlinks.json` (§9) |

**Never** put a service-account JSON, `private_key`, passwords or Admin SDK credentials in the repo or in any `NEXT_PUBLIC_*` variable. Cloud Functions use the project’s default credentials automatically.

## 3. Deploy Firestore rules, Storage rules and indexes
```bash
npx firebase deploy --only firestore:rules,firestore:indexes,storage
```
Indexes build in the background (minutes). Until each is **Enabled** (Firestore → Indexes), the matching query fails with a “requires an index” error. Watch the console for the build status.

## 4. Deploy Cloud Functions
```bash
npm --prefix functions install && npm --prefix functions run build
npx firebase deploy --only functions
```
First deploy prompts to enable *Cloud Build, Artifact Registry, Cloud Scheduler, Eventarc* APIs — accept. Scheduled jobs: `releaseEarnings`, `syncPromotions`, `rankVideos`, `cleanupPushTokens`, `pruneOldNotifications`. Region is `us-central1`; changing it requires editing `functions/src/common.ts` **and** `NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION`.

## 5. Deploy the web app
**Recommendation: Vercel.** The app uses server-rendered metadata, ISR (`revalidate`), route handlers and `next/image` — Vercel runs Next.js natively with zero config, and Firebase stays the backend. Caveat: Vercel’s free *Hobby* plan is for non-commercial use; a real marketplace should use **Pro**. **Netlify** (Next runtime plugin, free tier allows commercial use) is the drop-in alternative. **Firebase Hosting** is possible (Web Frameworks) but still experimental for Next 14 and adds Cloud Run/Functions cost, so it is not recommended here.

Vercel: import the repo → framework *Next.js* (auto) → add the env vars from §2 for **Production** (and Preview) → deploy. The build runs `npm run build`, whose `prebuild` step generates `public/firebase-messaging-sw.js` from your env vars (so set them *before* building). Add your domain, then update Firebase *Authorized domains* and `NEXT_PUBLIC_SITE_URL`, and redeploy.

## 6. Create the first super admin (one-time, console)
1. Open the deployed site, **sign up**, verify the email.
2. Firebase console → Authentication → Users → copy your **UID**.
3. Firestore → create document `roles/<your-uid>` with field `role` (string) = `super_admin`.
4. Sign out/in. `/admin` now works. As super admin: **/admin/settings** → save once (creates settings docs); **/admin/categories** → *Import default categories*; if you had legacy stores, run *Move legacy commission fields*.
Admins/moderators are granted from `/admin/users/<id>` (super admin only). Staff accounts cannot be sellers — use a separate account.

## 7. Seller setup
Seller signs up → `/become-seller` (needs verified email) → an admin approves at `/admin/sellers` (creates the store + role) → the seller opens `/seller`, adds products (`pending_review`) → admin/moderator approves at `/admin/products` → products appear in the shop. Sellers can upload videos at `/video/upload` (moderated at `/admin/videos`).

**COD money flow (important):** earnings are created when an order is delivered but only become withdrawable after an admin clicks **“Confirm cash received”** on `/admin/orders` (cash reached the platform via your courier/collector) **and** the hold period passes. Without that confirmation no seller can withdraw COD earnings.

## 8. PWA
- `manifest.webmanifest` (name/short name ShopVerse, standalone, theme/background `#0B1B36`, 192/512/maskable icons, shortcuts) and a single service worker `/firebase-messaging-sw.js` (push + caching).
- Caching is deliberately minimal: only same-origin build assets/icons/fonts; **never** Firebase/Auth/Storage/ad traffic, never HTML; offline navigations show `/offline`. The worker registers in production only (not on localhost).
- Install: Chrome/Edge/Android show the *Install* prompt (also “Install ShopVerse” in the footer/profile); iOS Safari: Share → *Add to Home Screen*. Test with Chrome DevTools → Application → Manifest / Service Workers, and Lighthouse (PWA category) against the **production URL** (HTTPS is required).

## 9. Android packaging (Trusted Web Activity)
PWA-first; the Android app is a thin TWA around production (`android/twa-manifest.json`, package **`com.aistudio.shopverse.mktplc`**). No extra permissions are needed (file uploads use the Chrome picker; no camera/location).
1. Deploy the web app on HTTPS and confirm `/manifest.webmanifest` and `/icon-512.png` load.
2. Install JDK 17 + Android SDK, then `npm i -g @bubblewrap/cli`.
3. Copy `android/twa-manifest.json` to a working folder, replace every `YOUR_DOMAIN`, run `bubblewrap init --manifest=https://YOUR_DOMAIN/manifest.webmanifest` (or use the copied file), then `bubblewrap build`. Bubblewrap creates a **signing keystore** — back it up privately and **never commit it or its passwords**.
4. Upload the `.aab` to Google Play Console (Internal testing first) and enable **Play App Signing**.
5. **Digital Asset Links (required for full-screen, no URL bar):** Play Console → *Setup → App integrity → App signing* → copy the **SHA-256 certificate fingerprint** (app signing key; also add the upload-key fingerprint if you sideload). Put them in `ANDROID_CERT_SHA256` (comma separated), redeploy, and check `https://YOUR_DOMAIN/.well-known/assetlinks.json` lists them. Until this matches, the app shows a browser bar.
6. Deep links (`/product/…`, `/store/…`, `/video/…`, `/orders/…`, `/chat/…`, `/seller`, `/admin`) open in the app once assetlinks verifies (Bubblewrap adds the intent filters for your host). `/video/<id>` and `/chat/<id>` are real routes (the latter redirects to `/messages/<id>`).
7. Back navigation, external links (Custom Tabs) and notification permission are handled by the TWA/Chrome. Web push works inside the TWA through Chrome.

### Firebase ↔ Android
- The web app does **not** need `google-services.json`. FCM web push works in the TWA through the web SDK + VAPID key.
- The Android app `com.aistudio.shopverse.mktplc` registered in Firebase is only used if you add **native** Firebase features (Capacitor wrapper, native FCM, Crashlytics). In that case: Firebase console → Project settings → *Your apps → Android* → add the **SHA-1 and SHA-256** of your debug and Play signing keys → download `google-services.json` and keep it out of the web repo. This project does not invent or include that file.

## 10. FCM setup checklist
VAPID key set → site served over HTTPS → sign in → *Profile → Turn on push on this device* (or `/notifications/preferences`) → grant permission → a token appears under Firestore `users/<uid>/fcmTokens` → trigger an event (e.g. place an order as a different account; the seller gets “New order”). If nothing arrives: confirm the service worker is active, the browser allowed notifications, push is on in preferences, and check Cloud Functions logs for `notify failed`.

## 11. Production security checklist
- [ ] Rules + Storage rules + indexes deployed; `npm run test:rules` green.
- [ ] No service-account/private keys in the repo (`npm run preflight` scans) and none in host env vars named `NEXT_PUBLIC_*`.
- [ ] Authorized domains limited to your domains; email enumeration protection on; password policy set.
- [ ] App Check enforced (after verifying) for Firestore, Storage, Functions.
- [ ] Budget alerts configured; Cloud Scheduler jobs visible and succeeding.
- [ ] Only the intended people have `roles/*` documents (`admin`, `super_admin`, `moderator`).
- [ ] Ads: only a super admin edits ad code; confirm your ad network permits sandboxed-iframe delivery.
- [ ] Domain served via HTTPS only (hosts do this by default); consider HSTS at the host.
- [ ] Review `AUDIT.md` “Unresolved” items and decide each (notably CSP, upload quotas, token-URL privacy).

## 12. First production smoke test
Follow **SMOKE_TEST.md** end to end with at least three accounts (buyer, seller, admin) on the production URL, including one real push notification and one install of the PWA.
