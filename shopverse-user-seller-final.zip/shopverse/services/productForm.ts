import type { ProductStatus, Variant } from '@/types';
import { round2 } from '@/utils/money';

export const slugify = (s: string) => s.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 60);

export interface ProductForm {
  storeId: string; title: string; brand: string; categoryId: string; subcategoryId: string; description: string; price: number; originalPrice: number | null; stock: number;
  sku: string; weight: string; specsText: string; variantsText: string; shippingInfo: string; returnPolicy: string; featured: boolean; flashSaleEndsAt: string; status: ProductStatus;
}
export function parseSpecs(t: string) {
  return t.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { const i = l.indexOf(':'); return i > 0 ? { label: l.slice(0, i).trim(), value: l.slice(i + 1).trim() } : null; }).filter((x): x is { label: string; value: string } => !!x && !!x.value);
}
/** One variant per line: `Label | stock | optional price`. Keys are slugs of the label and must be unique. */
export function parseVariants(t: string): Variant[] {
  const out: Variant[] = []; const seen = new Set<string>();
  for (const line of t.split('\n').map((l) => l.trim()).filter(Boolean)) {
    const [label, stock, price] = line.split('|').map((x) => x.trim());
    const key = slugify(label ?? '');
    const st = Number(stock);
    if (!key || !Number.isInteger(st) || st < 0) throw new Error(`Invalid variant line: “${line}”. Use: Label | stock | optional price`);
    if (seen.has(key)) throw new Error(`Duplicate variant “${label}”.`);
    seen.add(key);
    const pr = price ? Number(price) : undefined;
    if (price && !(pr! > 0)) throw new Error(`Invalid variant price in “${line}”.`);
    out.push({ key, label, stock: st, ...(pr ? { price: round2(pr) } : {}) });
  }
  return out;
}
