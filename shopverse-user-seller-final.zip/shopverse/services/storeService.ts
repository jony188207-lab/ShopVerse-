import { collection, deleteDoc, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Store } from '@/types';
import type { Review } from '@/types';
import { mapReview, mapStore } from './mappers';
import type { Page } from './productService';

export async function getStore(id: string): Promise<Store | null> {
  try { const s = await getDoc(doc(db(), 'stores', id)); return s.exists() ? mapStore(s.id, s.data()) : null; } catch { return null; }
}
export async function getStoreBySlug(slug: string): Promise<Store | null> {
  const s = await getDocs(query(collection(db(), 'stores'), where('status', '==', 'approved'), where('slug', '==', slug), limit(1)));
  return s.empty ? null : mapStore(s.docs[0].id, s.docs[0].data());
}
export async function getStoresMap(ids: string[]): Promise<Map<string, Store>> {
  const uniq = Array.from(new Set(ids.filter(Boolean)));
  const res = await Promise.all(uniq.map(getStore));
  const m = new Map<string, Store>();
  res.forEach((s) => s && m.set(s.id, s));
  return m;
}
export async function getPopularStores(n = 8): Promise<Store[]> {
  const s = await getDocs(query(collection(db(), 'stores'), where('status', '==', 'approved'), orderBy('followerCount', 'desc'), limit(n)));
  return s.docs.map((d) => mapStore(d.id, d.data()));
}

// Follow = follows/{followerId_followingId}; followerCount is maintained by the onFollowWritten Cloud Function.
export const followId = (uid: string, ownerId: string) => `${uid}_${ownerId}`;
export async function isFollowing(uid: string, ownerId: string): Promise<boolean> {
  return (await getDoc(doc(db(), 'follows', followId(uid, ownerId)))).exists();
}
export const follow = (uid: string, ownerId: string) => setDoc(doc(db(), 'follows', followId(uid, ownerId)), { followerId: uid, followingId: ownerId, createdAt: serverTimestamp() });
export const unfollow = (uid: string, ownerId: string) => deleteDoc(doc(db(), 'follows', followId(uid, ownerId)));

/** Public, published reviews across all of a store's products (rules: status == published). */
export async function listStoreReviews(ownerId: string, cursor: QueryDocumentSnapshot | null = null, size = 10): Promise<Page<Review>> {
  const c = [where('sellerId', '==', ownerId), where('status', '==', 'published'), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)];
  const s = await getDocs(query(collection(db(), 'reviews'), ...c));
  return { items: s.docs.map((d) => mapReview(d.id, d.data())), cursor: s.docs.at(-1) ?? null, hasMore: s.size === size };
}
