import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';

/** Public, non-sensitive switches read by the storefront (publicSettings/main is written by the separate Admin App). */
export interface PublicSettings { adsEnabled: boolean; bannerRotateSeconds: number }
export const DEFAULT_PUBLIC: PublicSettings = { adsEnabled: true, bannerRotateSeconds: 5 };
export async function getPublicSettings(): Promise<PublicSettings> {
  try {
    const d = (await getDoc(doc(db(), 'publicSettings', 'main'))).data();
    const n = Number(d?.bannerRotateSeconds);
    return d ? { adsEnabled: d.adsEnabled !== false, bannerRotateSeconds: n > 0 ? n : 5 } : DEFAULT_PUBLIC;
  } catch { return DEFAULT_PUBLIC; }
}
