import { deleteObject, getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import { storage } from '@/lib/firebase/config';

/**
 * Storage/CDN abstraction for video + thumbnails. The rest of the app only talks to `videoProvider`, so moving to another
 * host (Mux, Cloudflare Stream, Bunny…) means writing one more implementation of this interface and changing the export below.
 * The Firestore document stores plain URLs (videoUrl / thumbnailUrl), which any provider can fill.
 */
export interface UploadOptions { kind: 'video' | 'image'; maxMB: number; onProgress?: (percent: number) => void }
export interface VideoStorageProvider {
  readonly name: string;
  upload(path: string, file: File, opts: UploadOptions): Promise<{ url: string; path: string }>;
  remove(path: string): Promise<void>;
}

const OK: Record<UploadOptions['kind'], RegExp> = { video: /^video\/(mp4|webm|quicktime)$/, image: /^image\/(jpeg|png|webp)$/ };

export const firebaseVideoProvider: VideoStorageProvider = {
  name: 'firebase-storage',
  async upload(path, file, opts) {
    if (file.size > opts.maxMB * 1024 * 1024) throw new Error(`“${file.name}” is larger than ${opts.maxMB} MB.`);
    if (!OK[opts.kind].test(file.type)) throw new Error(opts.kind === 'video' ? 'Use an MP4, WebM or MOV video.' : 'Use a JPG, PNG or WebP image.');
    const r = ref(storage(), path.replace(/[^\w./-]+/g, '_'));
    const task = uploadBytesResumable(r, file, { contentType: file.type, cacheControl: 'public,max-age=31536000' });
    await new Promise<void>((resolve, reject) => task.on('state_changed', (s) => opts.onProgress?.(Math.round((s.bytesTransferred / s.totalBytes) * 100)), reject, () => resolve()));
    return { url: await getDownloadURL(r), path: r.fullPath };
  },
  async remove(path) { await deleteObject(ref(storage(), path)).catch(() => undefined); },
};

export const videoProvider: VideoStorageProvider = firebaseVideoProvider;
