import {
  arrayRemove, arrayUnion, collection, doc, getDoc, getDocs, limit, onSnapshot, orderBy, query, serverTimestamp, setDoc, startAfter, updateDoc, where, writeBatch,
  type DocumentData, type QueryDocumentSnapshot, type Unsubscribe,
} from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { ChatMessage, Conversation } from '@/types/chat';
import type { Store } from '@/types';
import { toDate } from '@/utils/schedule';

const str = (v: unknown) => (typeof v === 'string' ? v : '');
export const conversationId = (buyerId: string, storeId: string) => `${buyerId}_${storeId}`;

export const mapConversation = (id: string, d: DocumentData): Conversation => ({
  id, buyerId: str(d.buyerId), sellerId: str(d.sellerId), storeId: str(d.storeId), participants: Array.isArray(d.participants) ? d.participants : [], unread: (d.unread ?? {}) as Record<string, number>,
  blockedBy: Array.isArray(d.blockedBy) ? d.blockedBy : [], lastMessage: str(d.lastMessage), lastMessageAt: toDate(d.lastMessageAt), lastSenderId: str(d.lastSenderId), createdAt: toDate(d.createdAt),
});
export const mapMessage = (id: string, d: DocumentData, pending = false): ChatMessage => ({
  id, conversationId: str(d.conversationId), senderId: str(d.senderId), receiverId: str(d.receiverId), text: str(d.text), productId: d.productId || undefined, orderId: d.orderId || undefined,
  createdAt: toDate(d.createdAt), readAt: toDate(d.readAt), pending,
});

/** Opens (or creates) the single conversation between this buyer and the store. Only buyers can create it (rules); the seller id comes from the store. */
export async function ensureConversation(buyerId: string, store: Pick<Store, 'id' | 'ownerId'>): Promise<string> {
  if (buyerId === store.ownerId) throw new Error('You cannot message your own store.');
  const id = conversationId(buyerId, store.id);
  const ref = doc(db(), 'conversations', id);
  if ((await getDoc(ref)).exists()) return id;
  await setDoc(ref, {
    buyerId, sellerId: store.ownerId, storeId: store.id, participants: [buyerId, store.ownerId], unread: { [buyerId]: 0, [store.ownerId]: 0 }, blockedBy: [], createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  return id;
}

/** Realtime list (≤30 newest). One listener powers both the inbox and the unread badge. */
export function watchConversations(uid: string, cb: (c: Conversation[]) => void, onError: (e: Error) => void): Unsubscribe {
  return onSnapshot(query(collection(db(), 'conversations'), where('participants', 'array-contains', uid), orderBy('updatedAt', 'desc'), limit(30)), (s) => cb(s.docs.map((d) => mapConversation(d.id, d.data()))), onError);
}
export function watchConversation(id: string, cb: (c: Conversation | null) => void, onError: (e: Error) => void): Unsubscribe {
  return onSnapshot(doc(db(), 'conversations', id), (s) => cb(s.exists() ? mapConversation(s.id, s.data()) : null), onError);
}
/** Realtime window of the latest 40 messages; older ones are fetched on demand with loadEarlier(). */
export function watchMessages(cid: string, cb: (m: ChatMessage[], oldest: QueryDocumentSnapshot | null) => void, onError: (e: Error) => void): Unsubscribe {
  return onSnapshot(query(collection(db(), 'conversations', cid, 'messages'), orderBy('createdAt', 'desc'), limit(40)), { includeMetadataChanges: true },
    (s) => cb(s.docs.map((d) => mapMessage(d.id, d.data({ serverTimestamps: 'estimate' }), d.metadata.hasPendingWrites)).reverse(), s.docs.at(-1) ?? null), onError);
}
export async function loadEarlier(cid: string, before: QueryDocumentSnapshot, size = 30): Promise<{ items: ChatMessage[]; oldest: QueryDocumentSnapshot | null; more: boolean }> {
  const s = await getDocs(query(collection(db(), 'conversations', cid, 'messages'), orderBy('createdAt', 'desc'), startAfter(before), limit(size)));
  return { items: s.docs.map((d) => mapMessage(d.id, d.data())).reverse(), oldest: s.docs.at(-1) ?? before, more: s.size === size };
}

export interface MessageRef { productId?: string; orderId?: string }
/** Writes ONLY the message. unread counters / lastMessage / notifications are maintained by the onMessageCreated Cloud Function. */
export async function sendMessage(c: Conversation, senderId: string, text: string, ref: MessageRef = {}): Promise<void> {
  const t = text.trim();
  if (!t) return;
  if (t.length > 2000) throw new Error('Messages can be up to 2000 characters.');
  if (c.blockedBy.length) throw new Error(c.blockedBy.includes(senderId) ? 'You blocked this chat. Unblock to send messages.' : 'This person is not accepting messages.');
  const receiverId = c.participants.find((p) => p !== senderId);
  if (!receiverId) throw new Error('Conversation is invalid.');
  await setDoc(doc(collection(db(), 'conversations', c.id, 'messages')), {
    senderId, receiverId, conversationId: c.id, text: t, ...(ref.productId ? { productId: ref.productId } : {}), ...(ref.orderId ? { orderId: ref.orderId } : {}), createdAt: serverTimestamp(), readAt: null,
  });
}

/** Marks received messages read and zeroes MY unread counter (rules allow touching only my own side). */
export async function markRead(c: Conversation, uid: string, unreadIds: string[]): Promise<void> {
  const b = writeBatch(db());
  unreadIds.slice(0, 100).forEach((id) => b.update(doc(db(), 'conversations', c.id, 'messages', id), { readAt: serverTimestamp() }));
  if ((c.unread[uid] ?? 0) > 0) b.update(doc(db(), 'conversations', c.id), { [`unread.${uid}`]: 0 });
  await b.commit();
}
export const setBlocked = (cid: string, uid: string, on: boolean) => updateDoc(doc(db(), 'conversations', cid), { blockedBy: on ? arrayUnion(uid) : arrayRemove(uid) });

/** Plain-text snapshot of the latest messages, attached to a report so moderators have evidence even if the thread changes. */
export const evidenceText = (msgs: ChatMessage[], nameOf: (uid: string) => string, n = 8) => msgs.slice(-n).map((m) => `${nameOf(m.senderId)}: ${m.text.slice(0, 160)}`).join('\n').slice(0, 1500);
