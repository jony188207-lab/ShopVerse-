import { collection, deleteDoc, doc, getCountFromServer, getDocs, limit, onSnapshot, orderBy, query, serverTimestamp, startAfter, updateDoc, where, writeBatch, type DocumentData, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { AppNotification } from '@/types/seller';
import { toDate } from '@/utils/schedule';
import type { Page } from './productService';

const s = (v: unknown) => (typeof v === 'string' ? v : '');
export const mapNotification = (id: string, d: DocumentData): AppNotification => ({
  id, type: s(d.type), category: s(d.category), title: s(d.title), body: s(d.body), image: s(d.image), relatedId: s(d.relatedId), relatedType: s(d.relatedType), link: s(d.link), read: d.read === true, createdAt: toDate(d.createdAt),
});
/** Only same-app paths are followed (a notification can never send you off-site). */
export const safeHref = (l: string) => (l.startsWith('/') && !l.startsWith('//') && !l.includes('\\') ? l : '/notifications');

/** Newest first, cursor-paginated. `unreadOnly` uses the (userId, read, createdAt) index. */
export async function listNotifications(uid: string, unreadOnly = false, cursor: QueryDocumentSnapshot | null = null, size = 20): Promise<Page<AppNotification>> {
  const c = [where('userId', '==', uid), ...(unreadOnly ? [where('read', '==', false)] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)];
  const snap = await getDocs(query(collection(db(), 'notifications'), ...c));
  return { items: snap.docs.map((d) => mapNotification(d.id, d.data())), cursor: snap.docs.at(-1) ?? null, hasMore: snap.size === size };
}
/** One small listener (max 20 docs) drives the header badge; the exact total comes from a count query. */
export function watchUnread(uid: string, cb: (count: number) => void): () => void {
  return onSnapshot(query(collection(db(), 'notifications'), where('userId', '==', uid), where('read', '==', false), limit(20)), (snap) => cb(snap.size), () => cb(0));
}
export async function unreadTotal(uid: string): Promise<number> {
  return (await getCountFromServer(query(collection(db(), 'notifications'), where('userId', '==', uid), where('read', '==', false)))).data().count;
}
export const markRead = (id: string) => updateDoc(doc(db(), 'notifications', id), { read: true, readAt: serverTimestamp() });
/** Marks EVERY unread notification (not only the loaded page) read, in batches of 400. */
export async function markAllReadForUser(uid: string): Promise<number> {
  let total = 0;
  for (let i = 0; i < 10; i++) {
    const snap = await getDocs(query(collection(db(), 'notifications'), where('userId', '==', uid), where('read', '==', false), limit(400)));
    if (snap.empty) break;
    const b = writeBatch(db()); snap.forEach((d) => b.update(d.ref, { read: true, readAt: serverTimestamp() })); await b.commit();
    total += snap.size; if (snap.size < 400) break;
  }
  return total;
}
export const deleteNotification = (id: string) => deleteDoc(doc(db(), 'notifications', id));
export async function deleteAllRead(uid: string): Promise<number> {
  let total = 0;
  for (let i = 0; i < 10; i++) {
    const snap = await getDocs(query(collection(db(), 'notifications'), where('userId', '==', uid), where('read', '==', true), limit(400)));
    if (snap.empty) break;
    const b = writeBatch(db()); snap.forEach((d) => b.delete(d.ref)); await b.commit();
    total += snap.size; if (snap.size < 400) break;
  }
  return total;
}
