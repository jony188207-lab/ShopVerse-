import {
  collection, deleteDoc, deleteField, doc, getCountFromServer, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, Timestamp, updateDoc, where,
  type DocumentData, type QueryDocumentSnapshot,
} from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { db, functions } from '@/lib/firebase/config';
import { categoryById } from '@/config/categories';
import type { Order, OrderItem, OrderStatus, Product, Review, Store } from '@/types';
import type { Balance, Coupon, Earning, Promotion, SellerApplication, SellerApplicationInput, StorePrivate, Withdrawal, WithdrawalStatus } from '@/types/seller';
import { buildSearchKeywords } from '@/utils/keywords';
import { discountPercent, round2 } from '@/utils/money';
import { toDate } from '@/utils/schedule';
import { parseSpecs, parseVariants, slugify, type ProductForm } from './productForm';
import { mapOrder, mapOrderItem, mapProduct, mapReview, mapStore } from './mappers';
import type { Page } from './productService';
import { uploadFile } from './uploadService';

const str = (v: unknown, d = '') => (typeof v === 'string' ? v : d);
const nm = (v: unknown, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const page = <T>(docs: QueryDocumentSnapshot[], map: (id: string, d: DocumentData) => T, size: number): Page<T> => ({ items: docs.map((d) => map(d.id, d.data())), cursor: docs.at(-1) ?? null, hasMore: docs.length === size });
const after = (c: QueryDocumentSnapshot | null) => (c ? [startAfter(c)] : []);

// ================= application =================
export const toStoreSlug = (s: string) => slugify(s).slice(0, 40);
export const mapApplication = (id: string, d: DocumentData): SellerApplication => ({
  id, ownerName: str(d.ownerName), storeName: str(d.storeName), slug: str(d.slug), description: str(d.description), phone: str(d.phone), email: str(d.email), country: str(d.country), city: str(d.city), address: str(d.address),
  returnPolicy: str(d.returnPolicy), shippingInfo: str(d.shippingInfo), logoUrl: str(d.logoUrl), bannerUrl: str(d.bannerUrl), status: (d.status ?? 'pending') as SellerApplication['status'],
  reviewNote: str(d.reviewNote), storeId: d.storeId || undefined, createdAt: toDate(d.createdAt), reviewedAt: toDate(d.reviewedAt),
});

export async function getMyApplication(uid: string): Promise<SellerApplication | null> {
  const s = await getDoc(doc(db(), 'sellerApplications', uid));
  return s.exists() ? mapApplication(s.id, s.data()) : null;
}

/** Soft check only (public approved stores). The authoritative uniqueness check runs in reviewSellerApplication. */
export async function slugLooksFree(slug: string): Promise<boolean> {
  const s = await getDocs(query(collection(db(), 'stores'), where('slug', '==', slug), where('status', '==', 'approved'), limit(1)));
  return s.empty;
}

/** Writes the application as `pending`. This never grants any role — only an admin action (Cloud Function) does. */
export async function submitApplication(uid: string, f: SellerApplicationInput, logo: File | null, banner: File | null, existing: SellerApplication | null): Promise<void> {
  const slug = toStoreSlug(f.slug);
  if (slug.length < 3) throw new Error('The store address must be at least 3 letters or numbers.');
  const up = (file: File, n: string) => uploadFile(`applications/${uid}/${n}-${Date.now()}-${file.name}`, file, { maxMB: 8, image: true });
  const [logoUrl, bannerUrl] = await Promise.all([logo ? up(logo, 'logo') : existing?.logoUrl ?? '', banner ? up(banner, 'banner') : existing?.bannerUrl ?? '']);
  const data = {
    ...(f.ownerName?.trim() ? { ownerName: f.ownerName.trim() } : {}), storeName: f.storeName.trim(), slug, logoUrl, bannerUrl, description: f.description.trim(), phone: f.phone.trim(), email: f.email.trim(), country: f.country.trim(), city: f.city.trim(),
    address: f.address.trim(), returnPolicy: f.returnPolicy.trim(), shippingInfo: f.shippingInfo.trim(), status: 'pending', updatedAt: serverTimestamp(),
  };
  if (existing) await updateDoc(doc(db(), 'sellerApplications', uid), data);
  else await setDoc(doc(db(), 'sellerApplications', uid), { ...data, userId: uid, createdAt: serverTimestamp() });
}

// ================= store =================
export async function getMyStore(uid: string): Promise<Store | null> {
  const s = await getDocs(query(collection(db(), 'stores'), where('ownerId', '==', uid), limit(1)));
  return s.empty ? null : mapStore(s.docs[0].id, s.docs[0].data());
}
export async function getMyStorePrivate(storeId: string): Promise<StorePrivate> {
  const s = await getDoc(doc(db(), 'storePrivate', storeId));
  const d = s.data() ?? {};
  return { phone: str(d.phone), email: str(d.email), address: str(d.address) };
}
export interface StoreSettings { name: string; description: string; city: string; country: string; shippingFee: number; freeShippingOver: number | null; returnPolicy: string; shippingInfo: string; phone: string; email: string; address: string }
export async function saveStoreSettings(store: Store, f: StoreSettings, logo: File | null, banner: File | null): Promise<void> {
  if (!(f.shippingFee >= 0)) throw new Error('Shipping fee cannot be negative.');
  const up = (file: File, n: string) => uploadFile(`stores/${store.ownerId}/${n}-${Date.now()}-${file.name}`, file, { maxMB: 8, image: true });
  const [logoUrl, bannerUrl] = await Promise.all([logo ? up(logo, 'logo') : store.logoUrl ?? '', banner ? up(banner, 'banner') : store.bannerUrl ?? '']);
  await updateDoc(doc(db(), 'stores', store.id), {
    name: f.name.trim(), description: f.description.trim(), city: f.city.trim(), country: f.country.trim(), logoUrl, bannerUrl, shippingFee: round2(f.shippingFee),
    freeShippingOver: f.freeShippingOver && f.freeShippingOver > 0 ? round2(f.freeShippingOver) : deleteField(), returnPolicy: f.returnPolicy.trim(), shippingInfo: f.shippingInfo.trim(), updatedAt: serverTimestamp(),
  });
  await updateDoc(doc(db(), 'storePrivate', store.id), { phone: f.phone.trim(), email: f.email.trim(), address: f.address.trim(), updatedAt: serverTimestamp() });
}

// ================= products =================
export async function listMyProducts(uid: string, status: string | '' = '', cursor: QueryDocumentSnapshot | null = null, size = 20): Promise<Page<Product>> {
  const c = [where('sellerId', '==', uid), ...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)];
  return page((await getDocs(query(collection(db(), 'products'), ...c))).docs, mapProduct, size);
}
export async function getMyProduct(id: string, uid: string): Promise<Product | null> {
  const s = await getDoc(doc(db(), 'products', id));
  return s.exists() && s.data().sellerId === uid ? mapProduct(s.id, s.data()) : null;
}
export const deleteMyProduct = (id: string) => deleteDoc(doc(db(), 'products', id));

export type SellerProductForm = Omit<ProductForm, 'featured' | 'flashSaleEndsAt' | 'status' | 'storeId'>;

/**
 * Seller create/edit. NEVER sends featured / flashSaleEndsAt / moderation fields (rules forbid it) and ALWAYS lands in draft or pending_review:
 * a seller can't publish anything. Editing an approved product sends it back to review.
 */
export async function saveSellerProduct(uid: string, store: Store, existing: Product | null, f: SellerProductForm, submit: boolean, images: File[], video: File | null): Promise<string> {
  if (existing && existing.sellerId !== uid) throw new Error('This is not your product.');
  const ref = existing ? doc(db(), 'products', existing.id) : doc(collection(db(), 'products'));
  const variants = parseVariants(f.variantsText);
  const stock = variants.length ? variants.reduce((s, v) => s + v.stock, 0) : f.stock;
  const price = round2(f.price);
  const original = round2(Math.max(f.originalPrice ?? price, price));
  if (!(price > 0)) throw new Error('Enter a price greater than 0.');
  if (!categoryById(f.categoryId)) throw new Error('Choose a category.');
  const base = `products/${uid}/${ref.id}`;
  const urls = await Promise.all(images.slice(0, 8).map((file, i) => uploadFile(`${base}/${Date.now()}-${i}-${file.name}`, file, { maxMB: 10, image: true })));
  const imageList = [...(existing?.images ?? []), ...urls].slice(0, 10);
  if (submit && !imageList.length) throw new Error('Add at least one image before submitting for review.');
  const videoUrl = video ? await uploadFile(`productVideos/${uid}/${ref.id}/${Date.now()}-${video.name}`, video, { maxMB: 100, video: true }) : existing?.video ?? '';
  const data = {
    sellerId: uid, storeId: store.id, title: f.title.trim(), brand: f.brand.trim(), categoryId: f.categoryId, subcategoryId: f.subcategoryId.trim(), description: f.description.trim(),
    images: imageList, video: videoUrl, price, originalPrice: original, discount: discountPercent(price, original), stock, sku: f.sku.trim(), weight: f.weight.trim(),
    specs: parseSpecs(f.specsText), variants, shippingInfo: f.shippingInfo.trim(), returnPolicy: f.returnPolicy.trim(), status: submit ? 'pending_review' : 'draft',
    searchKeywords: buildSearchKeywords({ title: f.title, brand: f.brand, categoryName: categoryById(f.categoryId)?.name, description: f.description }), updatedAt: serverTimestamp(),
  };
  if (existing) { const { sellerId: _s, storeId: _st, ...patch } = data; void _s; void _st; await updateDoc(ref, patch); }
  else await setDoc(ref, { ...data, slug: `${slugify(f.title)}-${ref.id.slice(0, 5).toLowerCase()}`, rating: 0, reviewCount: 0, ratingSum: 0, ratingDistribution: { '1': 0, '2': 0, '3': 0, '4': 0, '5': 0 }, salesCount: 0, createdAt: serverTimestamp() });
  return ref.id;
}

/** Stock-only update: allowed on live products without re-review (rules: only stock/variants/updatedAt change, price identical). */
export async function updateStockOnly(p: Product, stock: number, variants: Product['variants']): Promise<void> {
  const total = variants.length ? variants.reduce((s, v) => s + v.stock, 0) : stock;
  await updateDoc(doc(db(), 'products', p.id), { stock: Math.max(0, Math.floor(total)), variants, updatedAt: serverTimestamp() });
}

// ================= orders (seller sees ONLY sellerId == uid) =================
export const SELLER_NEXT: Record<OrderStatus, OrderStatus[]> = { // mirrors sellerMove() in firestore.rules
  pending: ['confirmed', 'cancelled'], confirmed: ['processing', 'cancelled'], processing: ['shipped', 'cancelled'], shipped: ['out_for_delivery', 'delivered'],
  out_for_delivery: ['delivered'], delivered: [], cancelled: [], return_requested: ['returned'], returned: [], refunded: [],
};
export async function listSellerOrders(uid: string, status: OrderStatus | '' = '', cursor: QueryDocumentSnapshot | null = null, size = 20): Promise<Page<Order>> {
  const c = [where('sellerId', '==', uid), ...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)];
  return page((await getDocs(query(collection(db(), 'orders'), ...c))).docs, mapOrder, size);
}
export async function getSellerOrder(id: string, uid: string): Promise<Order | null> {
  const s = await getDoc(doc(db(), 'orders', id));
  return s.exists() && s.data().sellerId === uid ? mapOrder(s.id, s.data()) : null;
}
export async function getSellerOrderItems(orderId: string, uid: string): Promise<OrderItem[]> {
  const s = await getDocs(query(collection(db(), 'orderItems'), where('orderId', '==', orderId), where('sellerId', '==', uid)));
  return s.docs.map((d) => mapOrderItem(d.id, d.data()));
}
export async function setSellerOrderStatus(order: Order, next: OrderStatus, tracking = '', carrier = ''): Promise<void> {
  if (!SELLER_NEXT[order.status].includes(next)) throw new Error(`An order cannot move from ${order.status} to ${next}.`);
  await updateDoc(doc(db(), 'orders', order.id), { status: next, updatedAt: serverTimestamp(), ...(tracking ? { trackingNumber: tracking.slice(0, 80) } : {}), ...(carrier ? { carrier: carrier.slice(0, 60) } : {}) });
}

// ================= reviews =================
export async function listSellerReviews(uid: string, cursor: QueryDocumentSnapshot | null = null, size = 15): Promise<Page<Review>> {
  const c = [where('sellerId', '==', uid), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)];
  return page((await getDocs(query(collection(db(), 'reviews'), ...c))).docs, mapReview, size);
}
export async function respondToReview(id: string, text: string): Promise<void> {
  const t = text.trim();
  if (!t || t.length > 1000) throw new Error('Write a response up to 1000 characters.');
  await updateDoc(doc(db(), 'reviews', id), { sellerResponse: t, sellerResponseAt: serverTimestamp(), updatedAt: serverTimestamp() });
}

// ================= money =================
const EMPTY_BALANCE: Balance = { pending: 0, available: 0, reserved: 0, paidOut: 0, grossSales: 0, commissionTotal: 0, netTotal: 0, unitsSold: 0, ordersDelivered: 0 };
export async function getBalance(uid: string): Promise<Balance> {
  const d = (await getDoc(doc(db(), 'sellerBalances', uid))).data();
  return d ? { pending: nm(d.pending), available: nm(d.available), reserved: nm(d.reserved), paidOut: nm(d.paidOut), grossSales: nm(d.grossSales), commissionTotal: nm(d.commissionTotal), netTotal: nm(d.netTotal), unitsSold: nm(d.unitsSold), ordersDelivered: nm(d.ordersDelivered) } : EMPTY_BALANCE;
}
export const mapEarning = (id: string, d: DocumentData): Earning => ({
  id, orderId: str(d.orderId), orderItemId: str(d.orderItemId), productId: str(d.productId), title: str(d.title), quantity: nm(d.quantity), gross: nm(d.gross), couponShare: nm(d.couponShare),
  commissionRate: nm(d.commissionRate), commission: nm(d.commission), sellerAmount: nm(d.sellerAmount), remitted: d.remitted !== false, status: d.status, createdAt: toDate(d.createdAt), availableAt: toDate(d.availableAt),
});
export async function listEarnings(uid: string, cursor: QueryDocumentSnapshot | null = null, size = 25): Promise<Page<Earning>> {
  const c = [where('sellerId', '==', uid), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)];
  return page((await getDocs(query(collection(db(), 'sellerEarnings'), ...c))).docs, mapEarning, size);
}
export const mapWithdrawal = (id: string, d: DocumentData): Withdrawal => ({
  id, sellerId: str(d.sellerId), storeName: str(d.storeName), amount: nm(d.amount), method: str(d.method), details: str(d.details), status: d.status as WithdrawalStatus, note: str(d.note), createdAt: toDate(d.createdAt),
});
export async function listWithdrawals(uid: string, cursor: QueryDocumentSnapshot | null = null, size = 20): Promise<Page<Withdrawal>> {
  const c = [where('sellerId', '==', uid), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)];
  return page((await getDocs(query(collection(db(), 'withdrawals'), ...c))).docs, mapWithdrawal, size);
}
export const requestWithdrawal = (i: { requestId: string; amount: number; method: string; details: string }) => httpsCallable(functions(), 'requestWithdrawal')(i);
export const cancelWithdrawal = (id: string) => httpsCallable(functions(), 'cancelWithdrawal')({ id });

// ================= coupons =================
export interface CouponForm { code: string; discountType: 'percent' | 'fixed'; discountValue: number; minOrder: number; maxDiscount: number; usageLimit: number; startsAt: string; endsAt: string; active: boolean }
export const mapCoupon = (id: string, d: DocumentData): Coupon => ({
  id, code: str(d.code), discountType: d.discountType === 'fixed' ? 'fixed' : 'percent', discountValue: nm(d.discountValue), minOrder: nm(d.minOrder), maxDiscount: nm(d.maxDiscount), usageLimit: nm(d.usageLimit),
  usedCount: nm(d.usedCount), startsAt: toDate(d.startsAt), endsAt: toDate(d.endsAt), active: d.active === true,
});
export async function listCoupons(uid: string): Promise<Coupon[]> {
  const s = await getDocs(query(collection(db(), 'coupons'), where('sellerId', '==', uid), orderBy('createdAt', 'desc'), limit(100)));
  return s.docs.map((d) => mapCoupon(d.id, d.data()));
}
export async function saveCoupon(uid: string, f: CouponForm, editing: boolean): Promise<void> {
  const code = f.code.trim().toUpperCase();
  if (!/^[A-Z0-9]{3,20}$/.test(code)) throw new Error('Code: 3–20 letters or numbers, no spaces.');
  if (!(f.discountValue > 0) || (f.discountType === 'percent' && f.discountValue > 100)) throw new Error('Enter a valid discount (percent must be 1–100).');
  const s = f.startsAt ? Timestamp.fromDate(new Date(f.startsAt)) : null, e = f.endsAt ? Timestamp.fromDate(new Date(f.endsAt)) : null;
  if (s && e && e <= s) throw new Error('The end date must be after the start date.');
  const data = { discountType: f.discountType, discountValue: f.discountValue, minOrder: Math.max(0, f.minOrder || 0), maxDiscount: Math.max(0, f.maxDiscount || 0), usageLimit: Math.max(0, Math.floor(f.usageLimit || 0)), startsAt: s, endsAt: e, active: f.active, updatedAt: serverTimestamp() };
  const ref = doc(db(), 'coupons', `${uid}_${code}`);
  if (editing) await updateDoc(ref, data);
  else {
    if ((await getDoc(ref)).exists()) throw new Error('You already have a coupon with this code.');
    await setDoc(ref, { ...data, sellerId: uid, code, usedCount: 0, createdAt: serverTimestamp() });
  }
}
export const setCouponActive = (id: string, active: boolean) => updateDoc(doc(db(), 'coupons', id), { active, updatedAt: serverTimestamp() });
export const deleteCoupon = (id: string) => deleteDoc(doc(db(), 'coupons', id));

// ================= promotions =================
export const mapPromotion = (id: string, d: DocumentData): Promotion => ({
  id, sellerId: str(d.sellerId), storeId: str(d.storeId), productId: str(d.productId), type: d.type === 'flash_sale' ? 'flash_sale' : 'featured', startsAt: toDate(d.startsAt), endsAt: toDate(d.endsAt),
  note: str(d.note), status: d.status, createdAt: toDate(d.createdAt),
});
export async function listPromotions(uid: string): Promise<Promotion[]> {
  const s = await getDocs(query(collection(db(), 'promotions'), where('sellerId', '==', uid), orderBy('createdAt', 'desc'), limit(100)));
  return s.docs.map((d) => mapPromotion(d.id, d.data()));
}
export async function submitPromotion(uid: string, storeId: string, f: { productId: string; type: 'featured' | 'flash_sale'; startsAt: string; endsAt: string; note: string }): Promise<void> {
  const s = new Date(f.startsAt), e = new Date(f.endsAt);
  if (!f.productId) throw new Error('Choose a product.');
  if (!(e > s) || e.getTime() - s.getTime() > 14 * 86_400_000) throw new Error('Promotions must end after they start and last at most 14 days.');
  await setDoc(doc(collection(db(), 'promotions')), { sellerId: uid, storeId, productId: f.productId, type: f.type, startsAt: Timestamp.fromDate(s), endsAt: Timestamp.fromDate(e), note: f.note.trim().slice(0, 500), status: 'pending', createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
}
export const cancelPromotion = (id: string) => updateDoc(doc(db(), 'promotions', id), { status: 'cancelled', updatedAt: serverTimestamp() });

// ================= analytics (server-side counts; nothing is estimated) =================
export interface SellerStats { products: number; approvedProducts: number; orders: number; pendingOrders: number; delivered: number; cancelled: number; balance: Balance }
export async function getSellerStats(uid: string): Promise<SellerStats> {
  const n = async (col: string, ...w: ReturnType<typeof where>[]) => (await getCountFromServer(query(collection(db(), col), ...w))).data().count;
  const [products, approvedProducts, orders, pendingOrders, delivered, cancelled, balance] = await Promise.all([
    n('products', where('sellerId', '==', uid)), n('products', where('sellerId', '==', uid), where('status', '==', 'approved')),
    n('orders', where('sellerId', '==', uid)), n('orders', where('sellerId', '==', uid), where('status', '==', 'pending')), n('orders', where('sellerId', '==', uid), where('status', '==', 'delivered')), n('orders', where('sellerId', '==', uid), where('status', '==', 'cancelled')), getBalance(uid),
  ]);
  return { products, approvedProducts, orders, pendingOrders, delivered, cancelled, balance };
}
