import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';

export const REPORT_TARGETS = ['user', 'seller', 'product', 'review', 'comment', 'video', 'store', 'conversation', 'message'] as const;
/** One report per user per target (the document id enforces it). The separate Admin App triages them. */
export async function fileReport(uid: string, targetType: (typeof REPORT_TARGETS)[number], targetId: string, reason: string, evidence = ''): Promise<void> {
  const r = reason.trim();
  if (r.length < 3 || r.length > 500) throw new Error('Describe the problem in 3–500 characters.');
  await setDoc(doc(db(), 'reports', `${uid}_${targetType}_${targetId}`), { reporterId: uid, targetType, targetId, reason: r, ...(evidence ? { evidence: evidence.slice(0, 1500) } : {}), status: 'open', createdAt: serverTimestamp() });
}
