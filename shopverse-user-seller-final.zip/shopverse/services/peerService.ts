import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Conversation } from '@/types/chat';
import { getStoresMap } from './storeService';

const profileCache = new Map<string, string>();
async function profileName(uid: string): Promise<string> {
  if (profileCache.has(uid)) return profileCache.get(uid)!;
  const n = String((await getDoc(doc(db(), 'profiles', uid)).catch(() => null))?.data()?.displayName ?? 'Shopper');   // profiles are public by design (name + avatar only)
  profileCache.set(uid, n);
  return n;
}
/** For each conversation: the OTHER side's display name + logo (store for buyers, buyer profile name for sellers). */
export async function getPeerNames(me: string, list: Conversation[]): Promise<Map<string, { name: string; logo: string }>> {
  const buyerSide = list.filter((c) => c.buyerId === me);
  const stores = await getStoresMap(buyerSide.map((c) => c.storeId));
  const out = new Map<string, { name: string; logo: string }>();
  await Promise.all(list.map(async (c) => {
    if (c.buyerId === me) { const s = stores.get(c.storeId); out.set(c.id, { name: s?.name ?? 'Store', logo: s?.logoUrl ?? '' }); }
    else out.set(c.id, { name: await profileName(c.buyerId), logo: '' });
  }));
  return out;
}
export const nameOfUser = profileName;
