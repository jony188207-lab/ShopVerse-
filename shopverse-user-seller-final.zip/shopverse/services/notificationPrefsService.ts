import { doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { PREF_LABELS } from '@/types/seller';

export type Prefs = Record<string, boolean>;
export const DEFAULT_PREFS: Prefs = { ...Object.fromEntries(PREF_LABELS.map((p) => [p.key, true])), push: true };
/** Missing doc / missing key = ON (matches the server, which treats only an explicit false as off). */
export async function getPrefs(uid: string): Promise<Prefs> {
  const d = (await getDoc(doc(db(), 'notificationPrefs', uid))).data() ?? {};
  return Object.fromEntries(Object.keys(DEFAULT_PREFS).map((k) => [k, d[k] !== false]));
}
export async function savePrefs(uid: string, p: Prefs): Promise<void> {
  const clean = Object.fromEntries(Object.keys(DEFAULT_PREFS).map((k) => [k, p[k] !== false]));
  await setDoc(doc(db(), 'notificationPrefs', uid), { ...clean, updatedAt: serverTimestamp() });
}
