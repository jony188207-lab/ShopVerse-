import { collection, getDocs, limit, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { AdDevice, AdSetting } from '@/types';
import { isLive, isSafeHttpsUrl, toDate } from '@/utils/schedule';

/** First live, valid ad for a placement + device. Bottom ad is independent of product banners. */
export async function getActiveAd(placement: 'bottom', device: Exclude<AdDevice, 'all'>, now: Date = new Date()): Promise<AdSetting | null> {
  const snap = await getDocs(query(collection(db(), 'adNetworkSettings'), where('active', '==', true), where('placement', '==', placement), limit(10)));
  const ads = snap.docs
    .map((s): AdSetting => {
      const d = s.data();
      return {
        id: s.id, networkName: d.networkName ?? '', adCode: d.adCode || undefined, adUrl: d.adUrl || undefined, placement,
        device: (d.device as AdDevice) ?? 'all', width: d.width ? Number(d.width) : undefined, height: d.height ? Number(d.height) : undefined,
        active: d.active === true, startDate: toDate(d.startDate), endDate: toDate(d.endDate),
      };
    })
    .filter((a) => isLive(a, now) && (a.device === 'all' || a.device === device))
    .filter((a) => a.adCode || (a.adUrl && isSafeHttpsUrl(a.adUrl)));
  return ads[0] ?? null;
}
