import { collection, getDocs, limit, orderBy, query } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Category } from '@/config/categories';

const map = (id: string, d: Record<string, unknown>): Category => ({
  id, name: String(d.name ?? id), order: typeof d.order === 'number' ? d.order : 0, active: d.active !== false, imageUrl: d.imageUrl ? String(d.imageUrl) : undefined, parentId: d.parentId ? String(d.parentId) : undefined,
});
export async function listCategories(): Promise<Category[]> {
  const s = await getDocs(query(collection(db(), 'categories'), orderBy('order', 'asc'), limit(200)));
  return s.docs.map((d) => map(d.id, d.data()));
}
