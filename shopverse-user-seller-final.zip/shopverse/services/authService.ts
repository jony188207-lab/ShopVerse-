import {
  createUserWithEmailAndPassword, sendEmailVerification, sendPasswordResetEmail,
  signInWithEmailAndPassword, signOut, updateProfile, type User,
} from 'firebase/auth';
import { auth } from '@/lib/firebase/config';
import { detachPush } from './pushService';
import { ensureUserDocs } from './userService';
import { slugLooksFree, submitApplication, toStoreSlug } from './sellerService';
import type { SellerApplicationInput } from '@/types/seller';

export async function signUp(input: { email: string; password: string; displayName: string }): Promise<User> {
  const cred = await createUserWithEmailAndPassword(auth(), input.email.trim(), input.password);
  await updateProfile(cred.user, { displayName: input.displayName.trim() });
  await ensureUserDocs(cred.user, input.displayName.trim());
  await sendEmailVerification(cred.user);
  return cred.user;
}

/** Thrown when the account was created but the Seller Application could not be saved; the user can finish it at /become-seller. */
export class ApplicationAfterSignupError extends Error {
  constructor() { super('Your account was created, but your seller application could not be saved. Please complete it now.'); this.name = 'ApplicationAfterSignupError'; }
}

/**
 * Seller signup = a normal account + a Seller Application with status `pending`.
 * No role is granted here: only the Admin App (reviewSellerApplication Cloud Function) can approve, and it requires a verified email.
 */
export async function signUpSeller(input: { email: string; password: string; app: SellerApplicationInput }): Promise<User> {
  const slug = toStoreSlug(input.app.slug);
  if (!(await slugLooksFree(slug))) throw new Error('That store address is already taken. Choose another.');
  const user = await signUp({ email: input.email, password: input.password, displayName: input.app.ownerName ?? input.app.storeName });
  try { await submitApplication(user.uid, { ...input.app, slug, email: input.app.email || input.email }, null, null, null); }
  catch { throw new ApplicationAfterSignupError(); }
  return user;
}

export async function login(email: string, password: string): Promise<User> {
  const cred = await signInWithEmailAndPassword(auth(), email.trim(), password);
  await ensureUserDocs(cred.user);
  return cred.user;
}

/** Detaches this device from push FIRST so the next person on a shared browser never receives the previous user's notifications. */
export async function logout(): Promise<void> {
  const u = auth().currentUser;
  if (u) await detachPush(u.uid);
  await signOut(auth());
}
export const requestPasswordReset = (email: string) => sendPasswordResetEmail(auth(), email.trim());

export async function resendVerification(): Promise<void> {
  const u = auth().currentUser;
  if (u && !u.emailVerified) await sendEmailVerification(u);
}

/** After the user clicks the emailed link: refresh the user AND the ID token (rules read email_verified from the token). */
export async function refreshVerification(): Promise<boolean> {
  const u = auth().currentUser;
  if (!u) return false;
  await u.reload();
  await u.getIdToken(true);
  return u.emailVerified;
}
