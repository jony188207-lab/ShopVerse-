import { collection, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, updateDoc, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { OrderItem, Review } from '@/types';
import { mapReview } from './mappers';
import type { Page } from './productService';
import { uploadFile } from './uploadService';

export async function listReviews(productId: string, cursor: QueryDocumentSnapshot | null = null, pageSize = 10): Promise<Page<Review>> {
  const c = [where('productId', '==', productId), where('status', '==', 'published'), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(pageSize)];
  const s = await getDocs(query(collection(db(), 'reviews'), ...c));
  return { items: s.docs.map((d) => mapReview(d.id, d.data())), cursor: s.docs.at(-1) ?? null, hasMore: s.size === pageSize };
}
export async function getMyReview(orderItemId: string): Promise<Review | null> {
  try { const s = await getDoc(doc(db(), 'reviews', orderItemId)); return s.exists() ? mapReview(s.id, s.data()) : null; } catch { return null; }
}

/** Review id == orderItemId (one review per purchase). Rules require a delivered order item owned by the reviewer => verified purchase. */
export async function createReview(uid: string, userName: string, item: OrderItem, rating: number, text: string, files: File[]): Promise<void> {
  const ref = doc(db(), 'reviews', item.id);
  await setDoc(ref, {
    orderItemId: item.id, productId: item.productId, sellerId: item.sellerId, userId: uid, userName: userName.slice(0, 60) || 'Verified buyer',
    rating, text: text.trim().slice(0, 2000), images: [], status: 'published', verifiedPurchase: true, createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  if (files.length) {
    // Storage rules only accept review media after the review doc exists and belongs to the uploader.
    const urls = await Promise.all(files.slice(0, 4).map((f, i) => uploadFile(`reviews/${uid}/${item.id}/${Date.now()}-${i}-${f.name}`, f, { maxMB: 5, image: true })));
    await updateDoc(ref, { images: urls, updatedAt: serverTimestamp() });
  }
}

/** Report id is deterministic, so a second report by the same user is rejected by rules (reports can't be updated by users). */
export const reportReview = (uid: string, reviewId: string, reason: string) =>
  setDoc(doc(db(), 'reports', `${uid}_review_${reviewId}`), { reporterId: uid, targetType: 'review', targetId: reviewId, reason: reason.slice(0, 300), status: 'open', createdAt: serverTimestamp() });
