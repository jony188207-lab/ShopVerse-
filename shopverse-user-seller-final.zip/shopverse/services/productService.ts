import {
  collection, doc, getDoc, getDocs, limit, orderBy, query, startAfter, Timestamp, where,
  type QueryConstraint, type QueryDocumentSnapshot,
} from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Product } from '@/types';
import { tokenizeQuery } from '@/utils/keywords';
import { mapProduct } from './mappers';

export const PAGE_SIZE = 24;
export type SortKey = 'newest' | 'popular' | 'price_asc' | 'price_desc' | 'rating';
export interface ProductQuery { categoryId?: string; storeId?: string; featured?: boolean; sort?: SortKey; minPrice?: number; maxPrice?: number }
export interface Page<T> { items: T[]; cursor: QueryDocumentSnapshot | null; hasMore: boolean }

const ORDER: Record<SortKey, QueryConstraint> = {
  newest: orderBy('createdAt', 'desc'), popular: orderBy('salesCount', 'desc'),
  price_asc: orderBy('price', 'asc'), price_desc: orderBy('price', 'desc'), rating: orderBy('rating', 'desc'),
};

/** Single product for the detail page. Returns null when missing OR not publicly readable (rules => permission-denied). */
export async function getProduct(id: string): Promise<Product | null> {
  try {
    const s = await getDoc(doc(db(), 'products', id));
    return s.exists() ? mapProduct(s.id, s.data()) : null;
  } catch {
    return null;
  }
}

export async function getProductsByIds(ids: string[]): Promise<Map<string, Product | null>> {
  const uniq = Array.from(new Set(ids));
  const res = await Promise.all(uniq.map((id) => getProduct(id)));
  return new Map(uniq.map((id, i) => [id, res[i]]));
}

/**
 * Catalog query (server-side filter + sort + cursor pagination, never loads the whole collection).
 * Supported index combos: category|store|featured (one of) + sort; category + price range. A price range forces a price sort
 * because Firestore requires the range field to be the first orderBy.
 */
export async function listProducts(q: ProductQuery = {}, cursor: QueryDocumentSnapshot | null = null, pageSize = PAGE_SIZE): Promise<Page<Product>> {
  const c: QueryConstraint[] = [where('status', '==', 'approved')];
  if (q.categoryId) c.push(where('categoryId', '==', q.categoryId));
  if (q.storeId) c.push(where('storeId', '==', q.storeId));
  if (q.featured) c.push(where('featured', '==', true));
  let sort: SortKey = q.sort ?? 'newest';
  const hasPrice = q.minPrice != null || q.maxPrice != null;
  if (hasPrice && !sort.startsWith('price')) sort = 'price_asc';
  if (q.minPrice != null) c.push(where('price', '>=', q.minPrice));
  if (q.maxPrice != null) c.push(where('price', '<=', q.maxPrice));
  c.push(ORDER[sort]);
  if (cursor) c.push(startAfter(cursor));
  c.push(limit(pageSize));
  const snap = await getDocs(query(collection(db(), 'products'), ...c));
  return { items: snap.docs.map((d) => mapProduct(d.id, d.data())), cursor: snap.docs.at(-1) ?? null, hasMore: snap.size === pageSize };
}

export interface SearchOptions { sort?: 'newest' | 'popular'; categoryId?: string; minPrice?: number; maxPrice?: number }

/**
 * Prefix keyword search over `searchKeywords` (see utils/keywords.ts). Firestore can array-contains only ONE token, so we query
 * the longest token and verify the remaining tokens + category/price filters client-side, fetching up to 3 batches per page.
 * Limitation: not typo tolerant, not relevance ranked. For that, plug Algolia/Typesense/Meilisearch in behind this function.
 */
export async function searchProducts(term: string, opts: SearchOptions = {}, cursor: QueryDocumentSnapshot | null = null, pageSize = PAGE_SIZE): Promise<Page<Product>> {
  const tokens = tokenizeQuery(term);
  if (!tokens.length) return { items: [], cursor: null, hasMore: false };
  const primary = [...tokens].sort((a, b) => b.length - a.length)[0];
  const rest = tokens.filter((t) => t !== primary);
  const order = opts.sort === 'popular' ? orderBy('salesCount', 'desc') : orderBy('createdAt', 'desc');
  const out: Product[] = [];
  let cur = cursor; let more = true;
  for (let i = 0; i < 3 && out.length < pageSize && more; i++) {
    const c: QueryConstraint[] = [where('status', '==', 'approved'), where('searchKeywords', 'array-contains', primary), order];
    if (cur) c.push(startAfter(cur));
    c.push(limit(pageSize));
    const snap = await getDocs(query(collection(db(), 'products'), ...c));
    more = snap.size === pageSize;
    cur = snap.docs.at(-1) ?? cur;
    for (const d of snap.docs) {
      const p = mapProduct(d.id, d.data());
      if (rest.some((t) => !p.searchKeywords.includes(t))) continue;
      if (opts.categoryId && p.categoryId !== opts.categoryId) continue;
      if (opts.minPrice != null && p.price < opts.minPrice) continue;
      if (opts.maxPrice != null && p.price > opts.maxPrice) continue;
      out.push(p);
    }
  }
  return { items: out, cursor: cur, hasMore: more };
}

export async function suggestProducts(term: string, n = 6): Promise<{ id: string; title: string }[]> {
  const tokens = tokenizeQuery(term);
  if (!tokens.length) return [];
  const primary = [...tokens].sort((a, b) => b.length - a.length)[0];
  const snap = await getDocs(query(collection(db(), 'products'), where('status', '==', 'approved'), where('searchKeywords', 'array-contains', primary), orderBy('salesCount', 'desc'), limit(n)));
  return snap.docs.map((d) => ({ id: d.id, title: String(d.data().title ?? '') }));
}

export const getPopular = (n = 12) => listProducts({ sort: 'popular' }, null, n).then((p) => p.items);
export const getNewArrivals = (n = 12) => listProducts({ sort: 'newest' }, null, n).then((p) => p.items);
export const getFeatured = (n = 12) => listProducts({ featured: true }, null, n).then((p) => p.items);

export async function getFlashSale(n = 12): Promise<Product[]> {
  const snap = await getDocs(query(collection(db(), 'products'), where('status', '==', 'approved'), where('flashSaleEndsAt', '>', Timestamp.now()), orderBy('flashSaleEndsAt', 'asc'), limit(n)));
  return snap.docs.map((d) => mapProduct(d.id, d.data())).filter((p) => p.stock > 0);
}

/** "Recommended" = best sellers in the categories you recently viewed (no personalization data is invented). */
export async function getRecommended(categoryIds: string[], excludeIds: string[], n = 12): Promise<Product[]> {
  const cats = Array.from(new Set(categoryIds)).slice(0, 3);
  if (!cats.length) return [];
  const snap = await getDocs(query(collection(db(), 'products'), where('status', '==', 'approved'), where('categoryId', 'in', cats), orderBy('salesCount', 'desc'), limit(n + excludeIds.length)));
  return snap.docs.map((d) => mapProduct(d.id, d.data())).filter((p) => !excludeIds.includes(p.id)).slice(0, n);
}
