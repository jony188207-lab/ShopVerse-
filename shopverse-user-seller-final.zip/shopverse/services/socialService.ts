import { collection, doc, getDoc, getDocs, limit, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Review } from '@/types';
import { mapReview } from './mappers';

export interface PersonRow { uid: string; name: string; username: string; photoURL: string }

export async function followCounts(uid: string): Promise<{ followers: number; following: number }> {
  const d = (await getDoc(doc(db(), 'profiles', uid))).data();
  return { followers: Number(d?.followerCount ?? 0), following: Number(d?.followingCount ?? 0) };
}

async function people(ids: string[]): Promise<PersonRow[]> {
  const rows = await Promise.all(ids.map(async (uid) => {
    try { const d = (await getDoc(doc(db(), 'profiles', uid))).data(); return { uid, name: String(d?.displayName ?? 'ShopVerse user'), username: String(d?.username ?? ''), photoURL: String(d?.photoURL ?? '') }; }
    catch { return { uid, name: 'ShopVerse user', username: '', photoURL: '' }; }
  }));
  return rows;
}
/** Rules let you read only follows you made or that point at you, so these two queries are exactly what you may see. */
export async function listFollowing(uid: string, size = 50): Promise<PersonRow[]> {
  const s = await getDocs(query(collection(db(), 'follows'), where('followerId', '==', uid), limit(size)));
  return people(s.docs.map((d) => String(d.get('followingId'))));
}
export async function listFollowers(uid: string, size = 50): Promise<PersonRow[]> {
  const s = await getDocs(query(collection(db(), 'follows'), where('followingId', '==', uid), limit(size)));
  return people(s.docs.map((d) => String(d.get('followerId'))));
}
/** My own reviews (newest first, sorted on the client so no extra index is needed). */
export async function listMyReviews(uid: string, size = 50): Promise<Review[]> {
  const s = await getDocs(query(collection(db(), 'reviews'), where('userId', '==', uid), limit(size)));
  return s.docs.map((d) => mapReview(d.id, d.data())).sort((a, b) => (b.createdAt?.getTime() ?? 0) - (a.createdAt?.getTime() ?? 0));
}
