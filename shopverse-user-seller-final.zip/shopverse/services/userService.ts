import { deleteField, doc, getDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { updateProfile as updateAuthProfile } from 'firebase/auth';
import { db } from '@/lib/firebase/config';
import type { Role } from '@/types';
import { uploadFile } from './uploadService';

const VALID: Role[] = ['user', 'seller', 'moderator', 'admin', 'super_admin'];

/** Role comes from /roles/{uid} (writable only per firestore.rules). Missing doc => plain user. */
export async function fetchRole(uid: string): Promise<Role> {
  const snap = await getDoc(doc(db(), 'roles', uid));
  const r = snap.exists() ? (snap.data().role as Role) : 'user';
  return VALID.includes(r) ? r : 'user';
}

/** Idempotent: creates the private user doc + public profile if missing (also repairs a half-finished signup). */
export async function ensureUserDocs(user: User, displayName?: string): Promise<void> {
  const userRef = doc(db(), 'users', user.uid);
  if ((await getDoc(userRef)).exists()) return;
  const name = displayName ?? user.displayName ?? (user.email ? user.email.split('@')[0] : 'Shopper');
  const batch = writeBatch(db());
  batch.set(userRef, {
    email: user.email ?? '', displayName: name, phone: '', status: 'active',
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  batch.set(doc(db(), 'profiles', user.uid), {
    displayName: name, photoURL: user.photoURL ?? null, bio: '', followerCount: 0, followingCount: 0,
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  await batch.commit();
}

// ---------------- public profile (name, @username, photo, bio) ----------------
export interface Profile { displayName: string; username: string; photoURL: string; bio: string }
export const USERNAME_RE = /^[a-z0-9_]{3,20}$/;
export const normalizeUsername = (s: string) => s.trim().toLowerCase().replace(/^@+/, '');

export async function getProfile(uid: string): Promise<Profile | null> {
  const s = await getDoc(doc(db(), 'profiles', uid));
  if (!s.exists()) return null;
  const d = s.data();
  return { displayName: String(d.displayName ?? ''), username: String(d.username ?? ''), photoURL: String(d.photoURL ?? ''), bio: String(d.bio ?? '') };
}

/** Soft check for the form; the claim document in saveProfile() is what actually guarantees uniqueness. */
export async function isUsernameFree(name: string): Promise<boolean> {
  return !(await getDoc(doc(db(), 'usernames', normalizeUsername(name)))).exists();
}

/** One atomic batch: claim the new username, release the old one, update profile + private user doc. A taken username fails the whole batch. */
export async function saveProfile(user: User, current: Profile | null, patch: { displayName: string; username: string; bio: string }, photo: File | null): Promise<Profile> {
  const displayName = patch.displayName.trim();
  const username = normalizeUsername(patch.username);
  const bio = patch.bio.trim();
  if (displayName.length < 2 || displayName.length > 60) throw new Error('Enter a name of 2–60 characters.');
  if (username && !USERNAME_RE.test(username)) throw new Error('Username: 3–20 characters, lowercase letters, numbers and underscore only.');
  if (bio.length > 300) throw new Error('Bio can be at most 300 characters.');
  const old = current?.username ?? '';
  if (username && username !== old && !(await isUsernameFree(username))) throw new Error('That username is already taken.');
  const photoURL = photo ? await uploadFile(`profiles/${user.uid}/${Date.now()}-${photo.name}`, photo, { maxMB: 4, image: true }) : current?.photoURL ?? '';
  const b = writeBatch(db());
  if (username !== old) {
    if (username) b.set(doc(db(), 'usernames', username), { uid: user.uid, createdAt: serverTimestamp() });
    if (old) b.delete(doc(db(), 'usernames', old));
  }
  b.update(doc(db(), 'profiles', user.uid), { displayName, bio, photoURL: photoURL || null, username: username || deleteField(), updatedAt: serverTimestamp() });
  b.update(doc(db(), 'users', user.uid), { displayName, updatedAt: serverTimestamp() });
  try { await b.commit(); } catch (e) {
    if (username && username !== old) throw new Error('That username was just taken. Choose another.');
    throw e;
  }
  await updateAuthProfile(user, { displayName, ...(photoURL ? { photoURL } : {}) });
  return { displayName, username, photoURL, bio };
}
