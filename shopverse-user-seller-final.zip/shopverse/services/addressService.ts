import { addDoc, collection, deleteDoc, doc, getDocs, limit, orderBy, query, serverTimestamp, updateDoc, where, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { Address, AddressInput } from '@/types';
import { mapAddress } from './mappers';

export async function listAddresses(uid: string): Promise<Address[]> {
  const s = await getDocs(query(collection(db(), 'addresses'), where('userId', '==', uid), orderBy('createdAt', 'desc'), limit(20)));
  return s.docs.map((d) => mapAddress(d.id, d.data())).sort((a, b) => Number(b.isDefault) - Number(a.isDefault));
}

/** First address becomes the default automatically. */
export async function addAddress(uid: string, input: AddressInput, makeDefault: boolean): Promise<string> {
  const ref = await addDoc(collection(db(), 'addresses'), { ...input, userId: uid, isDefault: false, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
  if (makeDefault) await setDefaultAddress(uid, ref.id);
  return ref.id;
}
export const updateAddress = (id: string, input: AddressInput, isDefault: boolean, uid: string) =>
  updateDoc(doc(db(), 'addresses', id), { ...input, userId: uid, isDefault, updatedAt: serverTimestamp() });
export const deleteAddress = (id: string) => deleteDoc(doc(db(), 'addresses', id));

export async function setDefaultAddress(uid: string, id: string): Promise<void> {
  const all = await listAddresses(uid);
  const b = writeBatch(db());
  all.forEach((a) => { if (a.isDefault !== (a.id === id)) b.update(doc(db(), 'addresses', a.id), { isDefault: a.id === id, updatedAt: serverTimestamp() }); });
  await b.commit();
}
