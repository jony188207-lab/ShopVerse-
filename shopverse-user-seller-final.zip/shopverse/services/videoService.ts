import {
  collection, deleteDoc, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, updateDoc, where, type DocumentData, type QueryConstraint, type QueryDocumentSnapshot,
} from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { FeedTab, Video, VideoComment, VideoStatus } from '@/types/video';
import { toDate } from '@/utils/schedule';
import type { Page } from './productService';
import { videoProvider } from './video/provider';

const str = (v: unknown) => (typeof v === 'string' ? v : '');
const nm = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
const arr = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []);

export const mapVideo = (id: string, d: DocumentData): Video => ({
  id, ownerId: str(d.ownerId), storeId: str(d.storeId), title: str(d.title), description: str(d.description), videoUrl: str(d.videoUrl), thumbnailUrl: str(d.thumbnailUrl), productIds: arr(d.productIds),
  hashtags: arr(d.hashtags), category: str(d.category), visibility: d.visibility === 'private' ? 'private' : 'public', status: (d.status ?? 'draft') as VideoStatus,
  views: nm(d.viewCount), likes: Math.max(0, nm(d.likeCount)), commentsCount: Math.max(0, nm(d.commentCount)), saves: Math.max(0, nm(d.saveCount)), trendScore: nm(d.trendScore),
  moderationNote: str(d.moderationNote), createdAt: toDate(d.createdAt),
});
const page = <T>(docs: QueryDocumentSnapshot[], map: (id: string, d: DocumentData) => T, size: number): Page<T> => ({ items: docs.map((d) => map(d.id, d.data())), cursor: docs.at(-1) ?? null, hasMore: docs.length === size });
const PUBLIC: QueryConstraint[] = [where('status', '==', 'published'), where('visibility', '==', 'public')];
const col = () => collection(db(), 'videos');

// ================= feed sources (always paginated; never the whole collection) =================
export interface FeedSource { next(): Promise<{ items: Video[]; done: boolean }> }

function queryPager(build: (cursor: QueryDocumentSnapshot | null, size: number) => QueryConstraint[], size: number): FeedSource {
  let cursor: QueryDocumentSnapshot | null = null; let done = false;
  return {
    async next() {
      if (done) return { items: [], done: true };
      const p = page((await getDocs(query(col(), ...build(cursor, size)))).docs, mapVideo, size);
      cursor = p.cursor; done = !p.hasMore;
      return { items: p.items, done };
    },
  };
}
const after = (c: QueryDocumentSnapshot | null) => (c ? [startAfter(c)] : []);
export const newestSource = (size = 6) => queryPager((c, n) => [...PUBLIC, orderBy('createdAt', 'desc'), ...after(c), limit(n)], size);
export const trendingSource = (size = 6) => queryPager((c, n) => [...PUBLIC, orderBy('trendScore', 'desc'), ...after(c), limit(n)], size);
export const productsSource = (size = 6) => queryPager((c, n) => [...PUBLIC, where('hasProducts', '==', true), orderBy('createdAt', 'desc'), ...after(c), limit(n)], size);
export const productVideosSource = (productId: string, size = 8) => queryPager((c, n) => [...PUBLIC, where('productIds', 'array-contains', productId), orderBy('createdAt', 'desc'), ...after(c), limit(n)], size);

/** Creators the user follows (first 30 — Firestore `in` limit), then their newest videos. */
export function followingSource(uid: string, size = 6): FeedSource {
  let ids: string[] | null = null;
  let inner: FeedSource | null = null;
  return {
    async next() {
      if (!ids) {
        ids = (await getDocs(query(collection(db(), 'follows'), where('followerId', '==', uid), limit(30)))).docs.map((d) => String(d.get('followingId')));
        const followed = ids;
        inner = followed.length ? queryPager((c, n) => [...PUBLIC, where('ownerId', 'in', followed), orderBy('createdAt', 'desc'), ...after(c), limit(n)], size) : null;
      }
      return inner ? inner.next() : { items: [], done: true };
    },
  };
}

/**
 * "For You" has no ML: it interleaves the newest videos with the top trending ones (deduplicated), so every session mixes fresh
 * uploads with what people are engaging with. Personalised ranking would need an external recommender.
 */
export function forYouSource(size = 4): FeedSource {
  const a = newestSource(size), b = trendingSource(size); const seen = new Set<string>(); let doneA = false, doneB = false;
  return {
    async next() {
      const [ra, rb] = await Promise.all([doneA ? { items: [] as Video[], done: true } : a.next(), doneB ? { items: [] as Video[], done: true } : b.next()]);
      doneA = ra.done; doneB = rb.done;
      const out: Video[] = [];
      for (let i = 0; i < Math.max(ra.items.length, rb.items.length); i++) for (const v of [rb.items[i], ra.items[i]]) if (v && !seen.has(v.id)) { seen.add(v.id); out.push(v); }
      return { items: out, done: doneA && doneB };
    },
  };
}
export function makeSource(tab: FeedTab, uid: string | null): FeedSource {
  switch (tab) {
    case 'trending': return trendingSource();
    case 'products': return productsSource();
    case 'new': return newestSource();
    case 'following': return uid ? followingSource(uid) : { next: async () => ({ items: [], done: true }) };
    default: return forYouSource();
  }
}
export async function getVideo(id: string): Promise<Video | null> {
  try { const s = await getDoc(doc(db(), 'videos', id)); return s.exists() ? mapVideo(s.id, s.data()) : null; } catch { return null; }
}

// ================= seller side =================
export async function listMyVideos(uid: string, cursor: QueryDocumentSnapshot | null = null, size = 20): Promise<Page<Video>> {
  const c = [where('ownerId', '==', uid), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)];
  return page((await getDocs(query(col(), ...c))).docs, mapVideo, size);
}
export interface VideoUploadInput { title: string; description: string; hashtags: string; category: string; visibility: 'public' | 'private'; productIds: string[] }
export const parseHashtags = (t: string): string[] => Array.from(new Set(t.split(/[\s,]+/).map((x) => x.replace(/^#+/, '').toLowerCase().replace(/[^a-z0-9_]/g, '')).filter(Boolean))).slice(0, 10);

/** Grab a frame ~1s in as a fallback thumbnail when the seller doesn't provide one. */
export function captureThumbnail(file: File): Promise<File | null> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file); const v = document.createElement('video');
    const done = (f: File | null) => { URL.revokeObjectURL(url); resolve(f); };
    v.muted = true; v.playsInline = true; v.preload = 'metadata'; v.src = url;
    v.onloadeddata = () => { v.currentTime = Math.min(1, (v.duration || 1) / 2); };
    v.onseeked = () => {
      const c = document.createElement('canvas'); c.width = Math.min(720, v.videoWidth || 720); c.height = Math.round(c.width * ((v.videoHeight || 1280) / (v.videoWidth || 720)));
      c.getContext('2d')?.drawImage(v, 0, 0, c.width, c.height);
      c.toBlob((b) => done(b ? new File([b], 'thumb.jpg', { type: 'image/jpeg' }) : null), 'image/jpeg', 0.8);
    };
    v.onerror = () => done(null);
  });
}
export function readDuration(file: File): Promise<number> {
  return new Promise((resolve) => { const url = URL.createObjectURL(file); const v = document.createElement('video'); v.preload = 'metadata'; v.src = url; v.onloadedmetadata = () => { URL.revokeObjectURL(url); resolve(v.duration); }; v.onerror = () => { URL.revokeObjectURL(url); resolve(0); }; });
}

/** Files go to Storage (videos/{uid}/{videoId}/…); only metadata + URLs go to Firestore. Always lands as draft or pending_review. */
export async function createVideo(uid: string, storeId: string, f: VideoUploadInput, video: File, thumb: File | null, submit: boolean, onProgress: (p: number) => void): Promise<string> {
  if (f.title.trim().length < 2) throw new Error('Enter a title.');
  const secs = await readDuration(video);
  if (secs > 180) throw new Error('Videos can be at most 3 minutes long.');
  const ref = doc(col());
  const base = `videos/${uid}/${ref.id}`;
  const thumbFile = thumb ?? (await captureThumbnail(video));
  const [v, t] = await Promise.all([
    videoProvider.upload(`${base}/video-${video.name}`, video, { kind: 'video', maxMB: 200, onProgress }),
    thumbFile ? videoProvider.upload(`${base}/thumb-${thumbFile.name}`, thumbFile, { kind: 'image', maxMB: 5 }) : Promise.resolve(null),
  ]);
  await setDoc(ref, {
    ownerId: uid, storeId, title: f.title.trim(), description: f.description.trim(), videoUrl: v.url, videoPath: v.path, thumbnailUrl: t?.url ?? '', productIds: f.productIds.slice(0, 5), hasProducts: f.productIds.length > 0,
    hashtags: parseHashtags(f.hashtags), category: f.category, visibility: f.visibility, status: submit ? 'pending_review' : 'draft',
    likeCount: 0, commentCount: 0, viewCount: 0, saveCount: 0, shareCount: 0, trendScore: 0, createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  return ref.id;
}
export const resubmitVideo = (id: string) => updateDoc(doc(db(), 'videos', id), { status: 'pending_review', updatedAt: serverTimestamp() });
export const setVideoVisibility = (id: string, visibility: 'public' | 'private') => updateDoc(doc(db(), 'videos', id), { visibility, updatedAt: serverTimestamp() });
/** Deletes the document and the video file we recorded the path of. (Thumbnails are small and keep their path-based URL; a cleanup job can remove orphans.) */
export async function deleteVideo(v: Video & { videoPath?: string }): Promise<void> {
  const snap = await getDoc(doc(db(), 'videos', v.id));
  const path = snap.exists() ? str(snap.data().videoPath) : '';
  await deleteDoc(doc(db(), 'videos', v.id));
  if (path) await videoProvider.remove(path);
}

// ================= interactions (all ids deterministic; rules make each user's docs their own) =================
export const interactionId = (videoId: string, uid: string) => `${videoId}_${uid}`;
const chunk = <T>(a: T[], n: number) => Array.from({ length: Math.ceil(a.length / n) }, (_, i) => a.slice(i * n, i * n + n));

/** Which of these videos has the user liked/saved? One `in` query per 30 videos instead of one read per video. */
export async function loadMyFlags(kind: 'videoLikes' | 'videoSaves', uid: string, videoIds: string[]): Promise<Set<string>> {
  const out = new Set<string>();
  await Promise.all(chunk(videoIds, 30).map(async (ids) => {
    (await getDocs(query(collection(db(), kind), where('userId', '==', uid), where('videoId', 'in', ids)))).docs.forEach((d) => out.add(String(d.get('videoId'))));
  }));
  return out;
}
export async function loadMyFollows(uid: string, ownerIds: string[]): Promise<Set<string>> {
  const out = new Set<string>();
  await Promise.all(chunk(Array.from(new Set(ownerIds)), 30).map(async (ids) => {
    (await getDocs(query(collection(db(), 'follows'), where('followerId', '==', uid), where('followingId', 'in', ids)))).docs.forEach((d) => out.add(String(d.get('followingId'))));
  }));
  return out;
}
export async function setFlag(kind: 'videoLikes' | 'videoSaves', uid: string, videoId: string, on: boolean): Promise<void> {
  const ref = doc(db(), kind, interactionId(videoId, uid));
  if (on) await setDoc(ref, { userId: uid, videoId, createdAt: serverTimestamp() }); else await deleteDoc(ref);
}
const seenViews = new Set<string>();
/** Counts a view once per signed-in user per video (doc id videoId_uid; rules reject a second write). Anonymous views are not counted. */
export async function recordView(uid: string, videoId: string): Promise<void> {
  const key = interactionId(videoId, uid);
  if (seenViews.has(key)) return;
  seenViews.add(key);
  try { await setDoc(doc(db(), 'videoViews', key), { userId: uid, videoId, createdAt: serverTimestamp() }); } catch { /* already counted (permission-denied) or offline */ }
}
export async function listSavedVideos(uid: string, cursor: QueryDocumentSnapshot | null = null, size = 12): Promise<Page<Video>> {
  const s = await getDocs(query(collection(db(), 'videoSaves'), where('userId', '==', uid), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)));
  const vids = await Promise.all(s.docs.map((d) => getVideo(String(d.get('videoId')))));
  return { items: vids.filter((v): v is Video => !!v && v.status === 'published'), cursor: s.docs.at(-1) ?? null, hasMore: s.size === size };
}

// ================= comments =================
export const mapComment = (id: string, d: DocumentData): VideoComment => ({ id, videoId: str(d.videoId), userId: str(d.userId), userName: str(d.userName) || 'Shopper', text: str(d.text), status: str(d.status), createdAt: toDate(d.createdAt) });
export async function listComments(videoId: string, cursor: QueryDocumentSnapshot | null = null, size = 15): Promise<Page<VideoComment>> {
  const c = [where('videoId', '==', videoId), where('status', '==', 'visible'), orderBy('createdAt', 'desc'), ...after(cursor), limit(size)];
  return page((await getDocs(query(collection(db(), 'videoComments'), ...c))).docs, mapComment, size);
}
export async function addComment(uid: string, userName: string, videoId: string, text: string): Promise<string> {
  const t = text.trim();
  if (!t || t.length > 500) throw new Error('Write a comment up to 500 characters.');
  const ref = doc(collection(db(), 'videoComments'));
  await setDoc(ref, { userId: uid, userName: userName.slice(0, 60), videoId, text: t, status: 'visible', createdAt: serverTimestamp() });
  return ref.id;
}
export const deleteComment = (id: string) => deleteDoc(doc(db(), 'videoComments', id));
