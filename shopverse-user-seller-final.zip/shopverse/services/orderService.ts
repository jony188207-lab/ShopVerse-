import { collection, doc, getDoc, getDocs, limit, orderBy, query, startAfter, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { db, functions } from '@/lib/firebase/config';
import type { Order, OrderItem } from '@/types';
import { mapOrder, mapOrderItem } from './mappers';
import type { Page } from './productService';

export async function listOrders(uid: string, cursor: QueryDocumentSnapshot | null = null, pageSize = 10): Promise<Page<Order>> {
  const c = [where('buyerId', '==', uid), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(pageSize)];
  const s = await getDocs(query(collection(db(), 'orders'), ...c));
  return { items: s.docs.map((d) => mapOrder(d.id, d.data())), cursor: s.docs.at(-1) ?? null, hasMore: s.size === pageSize };
}
export async function getOrder(id: string, uid: string): Promise<Order | null> {
  try {
    const s = await getDoc(doc(db(), 'orders', id));
    const o = s.exists() ? mapOrder(s.id, s.data()) : null;
    return o && o.buyerId === uid ? o : null;
  } catch { return null; }
}
export async function getOrderItems(orderId: string, uid: string): Promise<OrderItem[]> {
  const s = await getDocs(query(collection(db(), 'orderItems'), where('orderId', '==', orderId), where('buyerId', '==', uid)));
  return s.docs.map((d) => mapOrderItem(d.id, d.data()));
}

// ---- trusted backend calls (Cloud Functions) ----
export async function placeOrder(input: { checkoutId: string; addressId: string; couponCode?: string }): Promise<{ orderIds: string[]; groupId: string }> {
  const r = await httpsCallable<unknown, { orderIds: string[]; groupId: string }>(functions(), 'placeOrder')({ ...input, paymentMethod: 'cod', deliveryMethod: 'standard' });
  return r.data;
}
export interface CouponPreview { code: string; discount: number; stores: { storeName: string; discount: number }[] }
/** Read-only preview. The authoritative discount is recomputed by placeOrder. */
export async function previewCoupon(code: string): Promise<CouponPreview> {
  return (await httpsCallable<unknown, CouponPreview>(functions(), 'previewCoupon')({ code })).data;
}
export const cancelOrder = (orderId: string, reason: string) => httpsCallable(functions(), 'cancelOrder')({ orderId, reason });
export const requestReturn = (orderId: string, reason: string) => httpsCallable(functions(), 'requestReturn')({ orderId, reason });
