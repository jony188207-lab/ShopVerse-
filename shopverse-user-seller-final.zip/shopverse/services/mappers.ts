import type { DocumentData } from 'firebase/firestore';
import type { Address, CartItem, Order, OrderItem, OrderStatus, Product, ProductStatus, Review, Store, Variant } from '@/types';
import { toDate } from '@/utils/schedule';

const num = (v: unknown, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const s = (v: unknown, d = '') => (typeof v === 'string' ? v : d);

export function mapProduct(id: string, d: DocumentData): Product {
  const dist = (d.ratingDistribution ?? {}) as Record<string, number>;
  const price = num(d.price);
  return {
    id, sellerId: s(d.sellerId), storeId: s(d.storeId), title: s(d.title), slug: s(d.slug), description: s(d.description), brand: s(d.brand),
    categoryId: s(d.categoryId), subcategoryId: d.subcategoryId || undefined, images: Array.isArray(d.images) ? d.images : [], video: d.video || undefined,
    price, originalPrice: Math.max(num(d.originalPrice, price), price), discount: num(d.discount), stock: num(d.stock), sku: s(d.sku),
    rating: num(d.rating), reviewCount: num(d.reviewCount), salesCount: num(d.salesCount),
    ratingDistribution: { '1': num(dist['1']), '2': num(dist['2']), '3': num(dist['3']), '4': num(dist['4']), '5': num(dist['5']) },
    status: (d.status as ProductStatus) ?? 'draft', featured: d.featured === true,
    variants: (Array.isArray(d.variants) ? d.variants : []).map((v: Variant) => ({ key: s(v.key), label: s(v.label), stock: num(v.stock), price: typeof v.price === 'number' ? v.price : undefined })),
    specs: Array.isArray(d.specs) ? d.specs : [], shippingInfo: d.shippingInfo || undefined, returnPolicy: d.returnPolicy || undefined, weight: d.weight || undefined,
    flashSaleEndsAt: toDate(d.flashSaleEndsAt), searchKeywords: Array.isArray(d.searchKeywords) ? d.searchKeywords : [],
    moderationNote: d.moderationNote || undefined, createdAt: toDate(d.createdAt), updatedAt: toDate(d.updatedAt),
  };
}

export function mapStore(id: string, d: DocumentData): Store {
  return {
    id, ownerId: s(d.ownerId), name: s(d.name), slug: s(d.slug), description: s(d.description), logoUrl: d.logoUrl || undefined, bannerUrl: d.bannerUrl || undefined,
    city: d.city || undefined, country: d.country || undefined, status: s(d.status), ratingAvg: num(d.ratingAvg), ratingCount: num(d.ratingCount),
    followerCount: num(d.followerCount), shippingFee: num(d.shippingFee), freeShippingOver: typeof d.freeShippingOver === 'number' ? d.freeShippingOver : undefined,
    returnPolicy: d.returnPolicy || undefined, shippingInfo: d.shippingInfo || undefined,
  };
}

export const mapCartItem = (id: string, d: DocumentData): CartItem => ({
  id, userId: s(d.userId), productId: s(d.productId), sellerId: s(d.sellerId), storeId: s(d.storeId),
  variantKey: s(d.variantKey, 'default'), variantLabel: s(d.variantLabel), quantity: num(d.quantity, 1),
});

export const mapAddress = (id: string, d: DocumentData): Address => ({
  id, userId: s(d.userId), fullName: s(d.fullName), phone: s(d.phone), country: s(d.country), city: s(d.city), area: s(d.area),
  address: s(d.address), postalCode: s(d.postalCode), instructions: s(d.instructions), isDefault: d.isDefault === true,
});

export const mapOrder = (id: string, d: DocumentData): Order => ({
  id, orderNumber: s(d.orderNumber, id), groupId: s(d.groupId), buyerId: s(d.buyerId), sellerId: s(d.sellerId), storeId: s(d.storeId), storeName: s(d.storeName),
  status: d.status as OrderStatus, paymentMethod: 'cod', paymentStatus: s(d.paymentStatus, 'unpaid'), deliveryMethod: s(d.deliveryMethod, 'standard'),
  subtotal: num(d.subtotal), discount: num(d.discount), shipping: num(d.shipping), total: num(d.total), currency: s(d.currency, 'USD'), itemCount: num(d.itemCount),
  address: mapAddress('', d.address ?? {}), deliveredAt: toDate(d.deliveredAt), createdAt: toDate(d.createdAt), trackingNumber: d.trackingNumber || undefined, carrier: d.carrier || undefined, couponCode: d.couponCode || undefined, codRemitted: d.codRemitted === true, couponDiscount: d.couponDiscount ? num(d.couponDiscount) : undefined,
  timeline: (Array.isArray(d.timeline) ? d.timeline : []).map((t: { status: OrderStatus; at: unknown }) => ({ status: t.status, at: toDate(t.at) })),
});

export const mapOrderItem = (id: string, d: DocumentData): OrderItem => ({
  id, orderId: s(d.orderId), buyerId: s(d.buyerId), sellerId: s(d.sellerId), storeId: s(d.storeId), productId: s(d.productId), title: s(d.title), image: s(d.image),
  sku: s(d.sku), variantKey: s(d.variantKey, 'default'), variantLabel: s(d.variantLabel), unitPrice: num(d.unitPrice), quantity: num(d.quantity, 1),
  lineTotal: num(d.lineTotal), status: d.status as OrderStatus,
});

export const mapReview = (id: string, d: DocumentData): Review => ({
  id, orderItemId: s(d.orderItemId), productId: s(d.productId), sellerId: s(d.sellerId), userId: s(d.userId), userName: s(d.userName, 'Verified buyer'),
  rating: num(d.rating), text: s(d.text), images: Array.isArray(d.images) ? d.images : [], status: s(d.status), verifiedPurchase: d.verifiedPurchase === true,
  sellerResponse: d.sellerResponse || undefined, createdAt: toDate(d.createdAt),
});
