import { collection, doc, getDoc, getDocs, limit, orderBy, query, where, type DocumentData } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { LiveBanner, ProductBanner } from '@/types';
import { isLive, sortByPriorityDesc, toDate } from '@/utils/schedule';

function toBanner(id: string, d: DocumentData): ProductBanner {
  return {
    id, title: d.title ?? '', subtitle: d.subtitle ?? '', desktopImage: d.desktopImage ?? '', mobileImage: d.mobileImage ?? d.desktopImage ?? '',
    productId: d.productId ?? '', ctaText: d.ctaText || 'Shop now', priority: Number(d.priority ?? 0), active: d.active === true,
    startDate: toDate(d.startDate), endDate: toDate(d.endDate),
  };
}

/**
 * Banners shown on Home: active + inside schedule window, ordered by priority, and only if the linked product
 * still exists and is active (deleted/unavailable products silently drop the banner instead of linking to a dead page).
 */
export async function getLiveBanners(now: Date = new Date()): Promise<LiveBanner[]> {
  const snap = await getDocs(query(collection(db(), 'productBanners'), where('active', '==', true), orderBy('priority', 'desc'), limit(10)));
  const scheduled = sortByPriorityDesc(snap.docs.map((s) => toBanner(s.id, s.data())).filter((b) => b.productId && b.desktopImage && isLive(b, now)));
  const resolved = await Promise.all(
    scheduled.map(async (b): Promise<LiveBanner | null> => {
      try {
        const p = await getDoc(doc(db(), 'products', b.productId));
        // Rules only let the public read approved/out_of_stock products; a removed/hidden product throws permission-denied => caught below.
        if (!p.exists() || p.data().status !== 'approved' || Number(p.data().stock ?? 0) < 1) return null;
        return { ...b, productName: String(p.data().title ?? '') };
      } catch {
        return null;
      }
    }),
  );
  return resolved.filter((b): b is LiveBanner => b !== null);
}
