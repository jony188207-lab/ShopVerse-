import { collection, deleteDoc, doc, getDocs, limit, orderBy, query, runTransaction, serverTimestamp, updateDoc, where, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import type { CartItem, Product } from '@/types';
import { availableStock } from '@/utils/cartMath';
import { MAX_CART_ITEMS } from '@/config/site';
import { mapCartItem } from './mappers';

export class CartError extends Error {}
export const variantKeyOf = (k?: string) => k || 'default';
export const cartDocId = (uid: string, productId: string, variantKey: string) => `${uid}_${productId}_${variantKey}`;

export async function fetchCart(uid: string): Promise<CartItem[]> {
  const s = await getDocs(query(collection(db(), 'cartItems'), where('userId', '==', uid), orderBy('createdAt', 'desc'), limit(MAX_CART_ITEMS)));
  return s.docs.map((d) => mapCartItem(d.id, d.data()));
}

/** Adds (or increases) a line, capped at live stock. The transaction keeps concurrent taps from duplicating the line. Final stock is re-checked at checkout. */
export async function addToCart(uid: string, product: Product, variantKeyIn: string | undefined, qty: number): Promise<number> {
  const variantKey = variantKeyOf(variantKeyIn);
  const variant = product.variants.find((v) => v.key === variantKey);
  if (product.variants.length && !variant) throw new CartError('Choose an option first.');
  const max = Math.min(availableStock(product, variantKey), 99);
  if (max < 1) throw new CartError('This item is out of stock.');
  const ref = doc(db(), 'cartItems', cartDocId(uid, product.id, variantKey));
  return runTransaction(db(), async (tx) => {
    const snap = await tx.get(ref);
    const existing = snap.exists() ? Number(snap.data().quantity) : 0;
    if (existing >= max) throw new CartError(`You already have the maximum available (${max}) in your cart.`);
    const next = Math.min(existing + Math.max(1, Math.floor(qty)), max);
    if (snap.exists()) tx.update(ref, { quantity: next, updatedAt: serverTimestamp() });
    else tx.set(ref, { userId: uid, productId: product.id, sellerId: product.sellerId, storeId: product.storeId, variantKey, variantLabel: variant?.label ?? '', quantity: next, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
    return next;
  });
}

export const setCartQuantity = (id: string, quantity: number) => updateDoc(doc(db(), 'cartItems', id), { quantity, updatedAt: serverTimestamp() });
export const removeCartItem = (id: string) => deleteDoc(doc(db(), 'cartItems', id));
export async function clearCart(items: CartItem[]): Promise<void> {
  const b = writeBatch(db());
  items.forEach((i) => b.delete(doc(db(), 'cartItems', i.id)));
  await b.commit();
}
