import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { storage } from '@/lib/firebase/config';

/** Client-side guard (Storage rules are the real enforcement). Returns the public download URL. */
export async function uploadFile(path: string, file: File, opts: { maxMB: number; image?: boolean; video?: boolean }): Promise<string> {
  if (file.size > opts.maxMB * 1024 * 1024) throw new Error(`“${file.name}” is larger than ${opts.maxMB} MB.`);
  if (opts.image && !/^image\/(jpeg|png|webp|gif)$/.test(file.type)) throw new Error(`“${file.name}” must be a JPG, PNG, WebP or GIF image.`);
  if (opts.video && !/^video\/(mp4|webm|quicktime)$/.test(file.type)) throw new Error(`“${file.name}” must be an MP4, WebM or MOV video.`);
  const r = ref(storage(), path.replace(/[^\w./-]+/g, '_'));
  await uploadBytes(r, file, { contentType: file.type, cacheControl: 'public,max-age=31536000' });
  return getDownloadURL(r);
}
