import { deleteToken, getToken } from 'firebase/messaging';
import { collection, deleteDoc, doc, getDocs, limit, query, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { getMessagingIfSupported } from '@/lib/firebase/messaging';
import { toDate } from '@/utils/schedule';

export type PushResult = 'enabled' | 'denied' | 'unsupported' | 'missing-vapid';
const SW = '/firebase-messaging-sw.js';
const platform = () => (/iPhone|iPad|iPod/.test(navigator.userAgent) ? 'ios-web' : /Android/.test(navigator.userAgent) ? 'android-web' : 'desktop-web');

async function currentToken(): Promise<string | null> {
  const vapidKey = process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY;
  const messaging = await getMessagingIfSupported();
  if (!vapidKey || !messaging) return null;
  const registration = (await navigator.serviceWorker.getRegistration(SW)) ?? (await navigator.serviceWorker.register(SW));
  return getToken(messaging, { vapidKey, serviceWorkerRegistration: registration });
}
async function saveToken(uid: string, token: string, first: boolean): Promise<void> {
  await setDoc(doc(db(), 'users', uid, 'fcmTokens', token), { token, platform: platform(), userAgent: navigator.userAgent.slice(0, 300), lastSeenAt: serverTimestamp(), ...(first ? { createdAt: serverTimestamp() } : {}) }, { merge: true });
}

/** Asks permission (must be called from a click) and registers THIS device. One doc per device, so many devices per user work. */
export async function enablePush(uid: string): Promise<PushResult> {
  if (!process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY) return 'missing-vapid';
  if (!(await getMessagingIfSupported())) return 'unsupported';
  if ((await Notification.requestPermission()) !== 'granted') return 'denied';
  const token = await currentToken();
  if (!token) return 'unsupported';
  await saveToken(uid, token, true);
  return 'enabled';
}

/**
 * Token refresh: FCM rotates tokens silently, so on every app start with permission already granted we re-read the current token
 * and upsert it (new token = new doc; lastSeenAt keeps live devices fresh; the daily cleanup job removes devices unseen for 60 days).
 */
export async function syncPushToken(uid: string): Promise<void> {
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
  const token = await currentToken().catch(() => null);
  if (token) await saveToken(uid, token, false).catch(() => undefined);
}

/** Sign-out / turn-off on this device: stop pushes for this user here and invalidate the token. */
export async function detachPush(uid: string): Promise<void> {
  try {
    if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
    const token = await currentToken();
    if (token) await deleteDoc(doc(db(), 'users', uid, 'fcmTokens', token)).catch(() => undefined);
    const m = await getMessagingIfSupported();
    if (m) await deleteToken(m).catch(() => undefined);
  } catch { /* best effort: the server also prunes invalid tokens on send */ }
}
export const disablePush = detachPush;

export interface Device { token: string; platform: string; userAgent: string; lastSeenAt: Date | null; current: boolean }
export async function listDevices(uid: string): Promise<Device[]> {
  const mine = await currentToken().catch(() => null);
  const snap = await getDocs(query(collection(db(), 'users', uid, 'fcmTokens'), limit(20)));
  return snap.docs.map((d) => ({ token: d.id, platform: String(d.get('platform') ?? ''), userAgent: String(d.get('userAgent') ?? ''), lastSeenAt: toDate(d.get('lastSeenAt')), current: d.id === mine }));
}
export const removeDevice = (uid: string, token: string) => deleteDoc(doc(db(), 'users', uid, 'fcmTokens', token));
