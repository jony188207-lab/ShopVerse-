import { collection, deleteDoc, doc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, where } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';

const id = (uid: string, productId: string) => `${uid}_${productId}`;
/** Newest first, capped at 200 (one page of ids; product docs are loaded lazily by the wishlist page). */
export async function fetchWishlistIds(uid: string): Promise<string[]> {
  const s = await getDocs(query(collection(db(), 'wishlists'), where('userId', '==', uid), orderBy('createdAt', 'desc'), limit(200)));
  return s.docs.map((d) => String(d.data().productId));
}
export const addWish = (uid: string, productId: string) => setDoc(doc(db(), 'wishlists', id(uid, productId)), { userId: uid, productId, createdAt: serverTimestamp() });
export const removeWish = (uid: string, productId: string) => deleteDoc(doc(db(), 'wishlists', id(uid, productId)));
