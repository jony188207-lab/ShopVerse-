# ShopVerse — Phase 8 production audit

**Method and limits.** Static review of the whole repository (rules, Cloud Functions, services, pages), mechanical scans (secrets, broken/unused imports, links to missing routes, listener/query inventory) and plain-Node smoke runs of the pure logic. **Nothing was executed against Firebase; `npm install`, typecheck, vitest, the rules tests and the build were NOT RUN (package registry returned 403 in the authoring environment).** Offline `tsc` without dependencies only produces missing-type noise. No browser was available, so responsive/visual behaviour was reviewed in code, not on screens.

## Fixed during the audit
| # | Finding | Fix |
|---|---|---|
| 1 | `commissionRate` sat on the **world-readable** store document | New admin-only `storeFinance/{storeId}` (rules + functions + admin UI); `migrateStoreFinance` (super admin, Settings page) moves legacy values |
| 2 | Approved products/videos kept `moderationNote` + reviewer uid on a **public** doc | Cleared on approve/restore; who/why stays in `adminLogs` |
| 3 | Any signed-in user could read everyone's `follows` (social graph) | Read only if you are the follower, the followee, or admin |
| 4 | `users/{uid}/fcmTokens` had no shape validation; no stale cleanup | Validated shape (id must equal token), daily `cleanupPushTokens` (60 days unseen) |
| 5 | Push would have shown **two** notifications (auto + SW) | Server sends DATA-ONLY pushes; the service worker renders one, with a same-site-only click target |
| 6 | Logging out left this browser subscribed to the previous user's pushes | `logout()` detaches the device token first |
| 7 | No route error boundary / 404 page | `app/error.tsx`, `global-error.tsx`, `not-found.tsx` |
| 8 | No per-product SEO, sitemap, robots, canonical, JSON-LD | Server `generateMetadata` for product + store (public REST read, rules still apply), `sitemap.ts`, `robots.ts`, canonical + Open Graph, Product JSON-LD, skip link |
| 9 | No security headers | nosniff, Referrer-Policy, X-Frame-Options, Permissions-Policy, COOP; `poweredByHeader` off |
| 10 | Silent failures: seller withdrawals balance, promotion/video product pickers | Now toast the error |
| 11 | Unbounded active-ads query | `limit(10)` |
| 12 | `.gitignore` missed Firebase debug logs | Added |
| 13 | Notification model lacked image / related entity / deep-link derivation | `category`, `image`, `relatedId`, `relatedType`, validated same-app `link` on every notification |

## Verified by inspection (no change needed)
- **Secrets:** no service-account JSON, `private_key`, API keys or passwords anywhere; `.env*` and service-account patterns are git-ignored; Firebase **web** config comes only from `NEXT_PUBLIC_*` env vars; the Admin SDK is used only inside Cloud Functions (no key file).
- **Imports/routes:** zero broken imports, zero unused imports, no links to routes that do not exist (script in this audit).
- **Roles:** no client can write `/roles`; approval, suspension and staff roles go through admin-only functions; moderators cannot read users, orders, addresses or chats.
- **Orders/money:** price, stock, shipping, coupon and totals are computed inside the `placeOrder` transaction; idempotency marker `checkouts/{uid}_{id}`; buyers have no direct order writes; seller transitions follow a rules state machine; earnings/balances/withdrawals are function-only; withdrawal creation is balance-checked in a transaction.
- **Isolation:** one order per seller; seller queries are filtered by `sellerId == uid` and enforced by rules; `storePrivate`, `storeFinance`, balances, earnings, coupons, promotions, conversations are owner/participant-scoped. 62 rules tests encode these (never run).
- **Storage:** default deny; per-path ownership, content-type allow-lists (no SVG), size limits (images 2–10 MB, review video 50 MB, product video 100 MB, user video 200 MB); admin-only banners/categories.
- **Realtime listeners:** only 4 (unread notifications ≤20 docs, conversations ≤30, one conversation, one message window ≤40). All list queries are cursor-paginated or limited; the home rails use small pages.

## Unresolved (ordered by importance)
| # | File | Problem | Why it matters | Exact next action |
|---|---|---|---|---|
| 1 | ~~COD money model~~ **RESOLVED in Phase 9** | Earnings are still created on delivery but carry `remitted: false` for COD; `releaseEarnings` only releases `remitted == true`; an admin must click **Confirm cash received** (`confirmCodRemittance`, audited) after the courier/collector hands the cash to the platform | — | **Residual:** this assumes cash really reaches the platform; reconcile courier remittances outside the app before clicking confirm |
| 2 | ~~Suspended-user token window~~ **MOSTLY RESOLVED in Phase 9** | `verified()` now also requires the user doc not to be `suspended` (chat, video, comments, reviews, applications, conversations), and `placeOrder` / `requestWithdrawal` call `assertActive()`; the Auth account is disabled and sessions revoked | — | **Residual:** low-risk own-data writes (cart, wishlist, addresses, follows, likes, reports, preferences) by a suspended user remain possible until their ID token expires (≤1 h); add `notSuspended()` to those rules if that matters |
| 3 | all test files | **Nothing was executed** (install/typecheck/vitest/rules tests/build/emulator/browser) | Unknown compile errors and rule bugs are likely in ~20k lines of unrun code | Run the commands in the README, fix what fails, then run the manual checklists |
| 4 | `storage.rules` | No per-user upload quota (rules cannot count objects) | A seller/user can fill the bucket within size limits | Turn on App Check enforcement + a Cloud Billing budget alert; add a function that tallies bytes per owner and blocks at a cap |
| 5 | Review media / videos (Storage) | Firebase download URLs carry a token and bypass Storage rules | Hidden reviews / suspended videos stay reachable by anyone who already has the file URL | For stricter privacy, serve files through a signed-URL function or delete the file object when content is removed |
| 6 | `functions/src/common.ts` (`notify`) | No event-id dedupe: a trigger retry can create a duplicate notification | Rare duplicate notifications | Use `event.id` as the notification doc id (`create()` ignoring ALREADY_EXISTS) |
| 7 | `functions/src/events.ts` (`onProductChanged`) | Wishlist alerts capped at 200 recipients per product event | Popular products notify only part of their wishlisters | Fan out through Cloud Tasks / Pub/Sub in pages |
| 8 | `types`/`services/videoService.ts`, rules for `videoComments` | **Video replies are not implemented** (comments are flat) | The spec lists “video reply” notifications | Add `parentId` to comments (+ rule + UI), then notify the parent author in `onVideoCommentWritten` |
| 9 | spec vs routes | The spec examples use `/video/[id]` and `/chat/[id]`; the real routes are `/video?v=<id>` and `/messages/<id>` | None functionally (all deep links use the real routes) | Keep as is, or add thin redirect routes if external links must match the spec |
| 10 | `next.config.mjs` | No Content-Security-Policy | Defence-in-depth against XSS | Add `Content-Security-Policy-Report-Only` first (needs nonce for the theme script + Firebase + ad iframes), then enforce |
| 11 | `components/AuthGuard.tsx` | Route protection is client-side (no server session/middleware) | Data is protected by rules, but page shells are fetched before the guard runs | If server-side gating is wanted: session cookies + Next middleware |
| 12 | `app/messages/layout.tsx` + `hooks/useUnreadMessages.ts` | Two identical conversation listeners while the inbox is open | Slightly higher read cost | Lift into one context provider |
| 13 | `app/sitemap.ts` | Capped at 1,000 products / 500 stores | Large catalogs are partially listed | Generate a sitemap index with pagination |
| 14 | `hooks/useAuth.tsx` | A failed role lookup silently falls back to `user` | Staff/sellers see reduced UI after a transient error (rules still correct) | Surface a retry banner |
| 15 | Seller order pages | Sellers see the buyer's name/phone/address on the order | Needed to deliver; still personal data | Document in the privacy policy; consider masked phone relays |
| 16 | `functions/` | No emulator integration tests for functions; no end-to-end browser tests | Regressions in checkout/earnings would not be caught | Add Firebase emulator tests for `placeOrder`, `cancelOrder`, `requestWithdrawal`; add Playwright smoke flows |
| 17 | Firebase console | Password policy is Firebase's default (min 6); client enforces 8 | Weaker server-side policy | Enable the stricter password policy / Identity Platform; enable App Check enforcement; enable Auth email-enumeration protection |


## Phase 9 closure (final)
**Executed in the authoring environment:** `node scripts/preflight.mjs` — **54 passed, 0 warnings, 0 failed** (required files, env-var coverage in `.env.example`, icon sizes, manifest fields, service-worker generation + syntax + cross-origin/HTML-caching guards, rules/storage bracket balance, 58 composite indexes valid and unique, rules cover the money/role collections, no client write to `/roles`, all 14 callable names used by the client exist in `functions/`, every function re-exported, secrets scan, `.gitignore`, no `firebase-admin` in browser code, TWA package id / no passwords). Plain-Node smoke runs of `orderLogic` (pricing, stock, coupons, platform coupons) and `notifyLogic` (18 assertions) also passed.

**NOT RUN — reason: package registry unreachable (HTTP 403), no browser/device, no Firebase project:** `npm install`, `npm run typecheck`, `npm run typecheck:functions`, `npm run lint`, `npm test`, `npm run test:rules` (62 rules tests), `npm run build`, Firebase emulators, Lighthouse/axe, the five user journeys in `SMOKE_TEST.md`, a real push, a real PWA install, a real Android build.

**Android:** PWA-first; Trusted Web Activity template `android/twa-manifest.json` (package `com.aistudio.shopverse.mktplc`, no keystore or passwords in the repo); `/.well-known/assetlinks.json` is served from env (`ANDROID_PACKAGE_NAME`, `ANDROID_CERT_SHA256`) and returns `[]` until real fingerprints are supplied; no `google-services.json` was invented (not needed for web push in a TWA). No Capacitor project was added because the app needs a Next.js server (server-rendered metadata, ISR).
