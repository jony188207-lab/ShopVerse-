# ShopVerse ↔ Admin App contract

The Admin Panel is a **separate project** that uses the **same Firebase project** as this Customer/Seller app. This app contains no admin UI. Everything the Admin App needs already exists in the shared backend (`firestore.rules`, `storage.rules`, `functions/`). Deploy rules, indexes and functions from this repository; the Admin App must not carry its own copies that could diverge.

## 1. Identity and roles
- Roles live in `roles/{uid}.role` ∈ `user | seller | moderator | admin | super_admin`. **No client can write it** (rules: `write: if false`). Only Cloud Functions (`reviewSellerApplication`, `setUserRole`) or the Console change it.
- The first `super_admin` is created manually in the Console (`roles/{uid}` = `{ role: 'super_admin' }`).
- Admin App sign-in is a normal Firebase Auth sign-in; authorization is whatever the rules/functions decide from `roles/{uid}`. Hiding UI is not security.

## 2. Seller applications
- Customer/Seller app writes `sellerApplications/{uid}` with `status: 'pending'` (fields: `userId, ownerName, storeName, slug, description, phone, email, country, city, address, returnPolicy, shippingInfo, logoUrl, bannerUrl, createdAt, updatedAt`). An application grants **no** privileges.
- Admin App decides through the callable **`reviewSellerApplication`** `{ applicationId: <applicant uid>, action: 'approve'|'reject'|'suspend'|'reactivate', note }`:
  - `approve`: requires status `pending`, **applicant email verified** (checked server-side with Admin SDK), role `user`, unique slug. Creates `stores/{id}` (+ `storeFinance`, `storePrivate`), sets `roles/{uid}` = seller, notifies the user, writes `adminLogs`.
  - `reject` / `suspend` require a note (≥ 5 chars) that the applicant sees.
- The customer app shows: *Become a Seller* (no application) · *Seller Application: Pending* · *Rejected* (with note) · *Suspended* · *Seller Center* (role `seller`). Approved is decided by the **role**, never by the application document alone.

## 3. Callable functions available to the Admin App
`reviewSellerApplication`, `setUserStatus`, `setUserRole`, `sendAnnouncement`, `reviewWithdrawal`, `reviewPromotion`, `confirmCodRemittance`, `migrateStoreFinance` (see `functions/src/index.ts` for the exact exports and payloads). All verify the caller's role server-side.

## 4. Collections the Admin App reads/writes (all protected by `firestore.rules`)
| Area | Collections |
|---|---|
| Users | `users`, `profiles`, `usernames`, `roles` (read only) |
| Sellers/stores | `sellerApplications`, `stores`, `storePrivate`, `storeFinance` |
| Catalog | `products` (moderation fields), `categories`, `productBanners` |
| Orders/money | `orders`, `orderItems`, `sellerEarnings`, `sellerBalances`, `withdrawals`, `coupons`, `promotions` |
| Content | `reviews`, `videos`, `videoComments`, `reports` |
| Platform | `publicSettings/main` (read by this app: `adsEnabled`, `bannerRotateSeconds`), `platformSettings/main`, `adNetworkSettings`, `adminLogs` (append-only) |

## 5. What this app reads that the Admin App controls
- `productBanners` → home carousel (active + scheduled; click → `/product/[productId]`).
- `adNetworkSettings` + `publicSettings/main.adsEnabled` → bottom ad slot.
- `categories` → falls back to the built-in list until categories exist.
- `reports` → this app only **creates** them (`{uid}_{targetType}_{targetId}`); triage happens in the Admin App.

## 6. Rules for the Admin App team
1. Do not weaken or fork `firestore.rules` / `storage.rules`; change them here and redeploy.
2. Log every admin decision to `adminLogs` (`createdAt == request.time`; append-only).
3. Never use a service-account key in browser code.
4. Add the Admin App's domain to Firebase Auth → Authorized domains.
