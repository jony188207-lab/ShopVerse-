#!/usr/bin/env node
// Offline release preflight: verifies things that can be checked WITHOUT network, Firebase or node_modules.
// It does not replace typecheck / tests / build — it catches packaging and configuration mistakes early.
import { existsSync, readFileSync, readdirSync, statSync } from 'fs';
import { join, extname } from 'path';
import { execFileSync } from 'child_process';

const results = [];
const add = (status, name, detail = '') => results.push({ status, name, detail });
const read = (p) => readFileSync(p, 'utf8');
const walk = (d, out = []) => { for (const f of readdirSync(d)) { if (['node_modules', '.next', '.git', 'lib'].includes(f) && d === '.') continue; if (f === 'node_modules' || f === '.next') continue; const p = join(d, f); statSync(p).isDirectory() ? walk(p, out) : out.push(p); } return out; };

// 1. required files
for (const f of ['package.json', 'firestore.rules', 'storage.rules', 'firestore.indexes.json', 'firebase.json', '.env.example', 'app/manifest.ts', 'app/robots.ts', 'app/sitemap.ts', 'app/offline/page.tsx', 'public/icon-192.png', 'public/icon-512.png', 'public/icon-maskable-512.png', 'public/apple-touch-icon.png', 'functions/src/index.ts', 'android/twa-manifest.json', 'DEPLOYMENT.md', 'AUDIT.md'])
  add(existsSync(f) ? 'PASS' : 'FAIL', `file ${f}`);

// 2. env example has every variable the code reads (client + server)
const envEx = read('.env.example');
const used = new Set(); for (const f of walk('.').filter((f) => /\.(tsx?|mjs)$/.test(f) && !f.startsWith('functions') && !f.startsWith('tests'))) for (const m of read(f).matchAll(/process\.env\.([A-Z0-9_]+)/g)) used.add(m[1]);
const builtIn = new Set(['NODE_ENV', 'SW_VERSION']);
const missingEnv = [...used].filter((k) => !builtIn.has(k) && !new RegExp(`^${k}=`, 'm').test(envEx));
add(missingEnv.length ? 'FAIL' : 'PASS', '.env.example documents every env var used by the app', missingEnv.join(', '));

// 3. PNG sizes referenced by the manifest
const png = (p) => { const b = readFileSync(p); return b.readUInt32BE(16) + 'x' + b.readUInt32BE(20); };
for (const [f, want] of [['public/icon-192.png', '192x192'], ['public/icon-512.png', '512x512'], ['public/icon-maskable-512.png', '512x512'], ['public/apple-touch-icon.png', '180x180']]) { if (existsSync(f)) add(png(f) === want ? 'PASS' : 'FAIL', `icon size ${f}`, png(f)); }
const man = read('app/manifest.ts');
for (const key of ["display: 'standalone'", "short_name: 'ShopVerse'", "name: 'ShopVerse'", 'start_url', 'theme_color', 'background_color', "purpose: 'maskable'"]) add(man.includes(key) ? 'PASS' : 'FAIL', `manifest has ${key}`);

// 4. service worker generation + syntax
try { execFileSync('node', ['scripts/generate-sw.mjs'], { stdio: 'pipe' }); execFileSync('node', ['--check', 'public/firebase-messaging-sw.js']); add('PASS', 'service worker generates and parses'); } catch (e) { add('FAIL', 'service worker generation', String(e.message).slice(0, 120)); }
const sw = existsSync('public/firebase-messaging-sw.js') ? read('public/firebase-messaging-sw.js') : '';
add(/url\.origin !== self\.location\.origin\) return/.test(sw) ? 'PASS' : 'FAIL', 'SW never handles cross-origin (Firebase/Storage/ads) requests');
add(/req\.mode === 'navigate'/.test(sw) && !/put\(req, res\.clone\(\)\);\s*\}\s*return res;\s*\}\)\)\s*return;\s*\}\s*if \(req\.mode/.test(sw) ? 'PASS' : 'WARN', 'SW does not cache HTML navigations');

// 5. rules / indexes sanity
for (const f of ['firestore.rules', 'storage.rules']) { const t = read(f); add(t.split('{').length === t.split('}').length && t.split('(').length === t.split(')').length ? 'PASS' : 'FAIL', `${f} brackets balanced`); }
try {
  const ix = JSON.parse(read('firestore.indexes.json')); const seen = new Set(); let dup = 0, bad = 0;
  for (const i of ix.indexes) { const k = JSON.stringify([i.collectionGroup, i.queryScope, i.fields]); if (seen.has(k)) dup++; seen.add(k); if (!i.fields || i.fields.length < 2) bad++; }
  add(dup || bad ? 'FAIL' : 'PASS', `firestore.indexes.json valid (${ix.indexes.length} composite indexes)`, dup ? `${dup} duplicates` : bad ? `${bad} single-field` : '');
} catch (e) { add('FAIL', 'firestore.indexes.json JSON', e.message); }
const rules = read('firestore.rules'); const collections = [...rules.matchAll(/match \/([A-Za-z]+)\/\{/g)].map((m) => m[1]);
for (const c of ['roles', 'notifications', 'withdrawals', 'sellerEarnings', 'sellerBalances', 'storeFinance', 'adminLogs']) add(new RegExp(`match /${c}/`).test(rules) ? 'PASS' : 'FAIL', `rules cover ${c}`);
add(!/match \/roles\/\{uid\} \{[^}]*allow (create|update|write)[^;]*if (?!false)/.test(rules) ? 'PASS' : 'FAIL', 'no client can write /roles');

// 6. callable functions used by the client exist in functions/src
const fnSrc = readdirSync('functions/src').filter((f) => f.endsWith('.ts') && !f.endsWith('.test.ts')).map((f) => read(join('functions/src', f))).join('\n');
const exported = new Set([...fnSrc.matchAll(/export const ([A-Za-z0-9_]+)/g)].map((m) => m[1]));
const called = new Set(); for (const f of walk('.').filter((f) => /\.(tsx?)$/.test(f) && !f.startsWith('functions') && !f.startsWith('tests'))) for (const m of read(f).matchAll(/httpsCallable(?:<[^>]*(?:<[^>]*>[^>]*)*>)?\(functions\(\), '([A-Za-z0-9_]+)'/g)) called.add(m[1]);
const missingFn = [...called].filter((n) => !exported.has(n));
add(missingFn.length ? 'FAIL' : 'PASS', `all ${called.size} callable names used by the client are exported by functions/`, missingFn.join(', '));
const indexTs = read('functions/src/index.ts');
const notReExported = [...exported].filter((n) => !new RegExp(`\\b${n}\\b`).test(indexTs) && !/export \* from/.test(indexTs.replace(/\/\/.*$/gm, '')) ).slice(0, 5);
add(notReExported.length ? 'WARN' : 'PASS', 'every function is re-exported from functions/src/index.ts', notReExported.join(', '));

// 7. secrets scan (project text files only)
const bad = []; const pat = [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, /"private_key"\s*:/, /AIza[0-9A-Za-z_-]{30,}/, /"type"\s*:\s*"service_account"/, /sk_live_[0-9A-Za-z]+/, /xox[baprs]-[0-9A-Za-z-]+/];
for (const f of walk('.').filter((f) => ['.ts', '.tsx', '.js', '.mjs', '.json', '.md', '.env', '.example', ''].includes(extname(f)) && !f.endsWith('package-lock.json') && !f.endsWith('firebase-messaging-sw.js'))) { const t = read(f); for (const p of pat) if (p.test(t)) bad.push(f); }
add(bad.length ? 'FAIL' : 'PASS', 'no private keys / service accounts / live secrets in the repo', [...new Set(bad)].join(', '));
const gi = read('.gitignore'); for (const k of ['.env', 'service-account', 'firebase-debug.log', 'node_modules']) add(gi.includes(k) ? 'PASS' : 'FAIL', `.gitignore covers ${k}`);

// 8. client never imports firebase-admin
const adminInClient = walk('.').filter((f) => /\.(tsx?)$/.test(f) && !f.startsWith('functions') && /from 'firebase-admin/.test(read(f)));
add(adminInClient.length ? 'FAIL' : 'PASS', 'firebase-admin is not imported by browser code', adminInClient.join(', '));

// 9. Android
try { const t = JSON.parse(read('android/twa-manifest.json')); add(t.packageId === 'com.aistudio.shopverse.mktplc' ? 'PASS' : 'FAIL', 'TWA package id'); add(!/"[A-Za-z]*(password|storePass|keyPass)[A-Za-z]*"\s*:/i.test(read('android/twa-manifest.json')) ? 'PASS' : 'FAIL', 'TWA config has no password fields'); } catch (e) { add('FAIL', 'android/twa-manifest.json', e.message); }

const icon = { PASS: '✔', FAIL: '✖', WARN: '!' };
for (const r of results) console.log(`${icon[r.status]} ${r.status.padEnd(4)} ${r.name}${r.detail ? `  — ${r.detail}` : ''}`);
const f = results.filter((r) => r.status === 'FAIL').length, w = results.filter((r) => r.status === 'WARN').length;
console.log(`\n${results.length - f - w} passed, ${w} warnings, ${f} failed`);
console.log('NOTE: typecheck, unit tests, rules tests and the production build are separate commands and are NOT covered by this script.');
process.exit(f ? 1 : 0);
