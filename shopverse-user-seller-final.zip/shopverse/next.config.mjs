/** @type {import('next').NextConfig} */
const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=()' },
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin-allow-popups' },
];
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Lint runs as its own step (`npm run lint`); a style rule must never block a production deploy. Type errors still fail the build.
  eslint: { ignoreDuringBuilds: true },
  async rewrites() { return [{ source: '/.well-known/assetlinks.json', destination: '/api/assetlinks' }]; },
  async headers() { return [{ source: '/:path*', headers: securityHeaders }]; },
  images: { remotePatterns: [{ protocol: 'https', hostname: 'firebasestorage.googleapis.com' }, { protocol: 'https', hostname: 'storage.googleapis.com' }] },
};
export default nextConfig;
