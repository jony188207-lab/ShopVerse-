export type ApplicationStatus = 'pending' | 'approved' | 'rejected' | 'suspended';
export interface SellerApplicationInput {
  ownerName?: string; storeName: string; slug: string; description: string; phone: string; email: string; country: string; city: string; address: string; returnPolicy: string; shippingInfo: string;
}
export interface SellerApplication extends SellerApplicationInput {
  id: string; logoUrl: string; bannerUrl: string; status: ApplicationStatus; reviewNote: string; storeId?: string; createdAt: Date | null; reviewedAt: Date | null;
}
export interface StorePrivate { phone: string; email: string; address: string }
export interface Earning {
  id: string; orderId: string; orderItemId: string; productId: string; title: string; quantity: number; gross: number; couponShare: number; commissionRate: number;
  commission: number; sellerAmount: number; remitted: boolean; status: 'pending' | 'available' | 'reversed'; createdAt: Date | null; availableAt: Date | null;
}
export interface Balance {
  pending: number; available: number; reserved: number; paidOut: number; grossSales: number; commissionTotal: number; netTotal: number; unitsSold: number; ordersDelivered: number;
}
export type WithdrawalStatus = 'pending' | 'approved' | 'processing' | 'completed' | 'rejected' | 'cancelled';
export interface Withdrawal { id: string; sellerId: string; storeName: string; amount: number; method: string; details: string; status: WithdrawalStatus; note: string; createdAt: Date | null }
export interface Coupon {
  id: string; code: string; discountType: 'percent' | 'fixed'; discountValue: number; minOrder: number; maxDiscount: number; usageLimit: number; usedCount: number;
  startsAt: Date | null; endsAt: Date | null; active: boolean;
}
export type PromotionStatus = 'pending' | 'approved' | 'rejected' | 'cancelled' | 'ended';
export interface Promotion { id: string; sellerId: string; storeId: string; productId: string; type: 'featured' | 'flash_sale'; startsAt: Date | null; endsAt: Date | null; note: string; status: PromotionStatus; createdAt: Date | null }
/** isRead = read, actionUrl = link (field names kept for existing documents). */
export interface AppNotification { id: string; type: string; category: string; title: string; body: string; image: string; relatedId: string; relatedType: string; link: string; read: boolean; createdAt: Date | null }
export const PREF_LABELS: { key: string; label: string; hint: string; role?: 'seller' | 'staff' }[] = [
  { key: 'orders', label: 'Orders', hint: 'Placed, confirmed, shipped, delivered, cancelled, returns and refunds' },
  { key: 'messages', label: 'Messages', hint: 'New chat messages and seller replies' },
  { key: 'reviews', label: 'Reviews', hint: 'When a seller replies to your review' },
  { key: 'wishlist', label: 'Wishlist', hint: 'Price drops and back-in-stock for saved products' },
  { key: 'video', label: 'Video activity', hint: 'Likes and comments on your videos' },
  { key: 'followers', label: 'Followers', hint: 'When someone follows your store' },
  { key: 'promotions', label: 'Promotions', hint: 'Offers and announcements from ShopVerse' },
  { key: 'seller', label: 'Seller notifications', hint: 'New orders, reviews, products, withdrawals, coupons and promotions for your store', role: 'seller' },
  { key: 'admin', label: 'Admin alerts', hint: 'Applications, pending products, reports, withdrawals and security events', role: 'staff' },
];
export const WITHDRAWAL_LABEL: Record<WithdrawalStatus, string> = { pending: 'Pending', approved: 'Approved', processing: 'Processing', completed: 'Completed', rejected: 'Rejected', cancelled: 'Cancelled' };
export const PAYOUT_METHODS = [{ id: 'bank_transfer', label: 'Bank transfer' }, { id: 'mobile_money', label: 'Mobile money' }, { id: 'cash_pickup', label: 'Cash pickup' }] as const;
