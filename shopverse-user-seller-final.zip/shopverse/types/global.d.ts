// Side-effect stylesheet imports (e.g. './globals.css') for TypeScript 5.6+.
declare module '*.css';
