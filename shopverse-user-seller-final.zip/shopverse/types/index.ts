export type Role = 'user' | 'seller' | 'moderator' | 'admin' | 'super_admin';
export const STAFF_ROLES: Role[] = ['moderator', 'admin', 'super_admin'];
export const ADMIN_ROLES: Role[] = ['admin', 'super_admin'];

export interface ProductBanner {
  id: string;
  title: string;
  subtitle?: string;
  desktopImage: string;
  mobileImage: string;
  productId: string;
  ctaText: string;
  priority: number;
  active: boolean;
  startDate: Date | null;
  endDate: Date | null;
}

/** A banner whose product was verified to exist and be purchasable right now. */
export interface LiveBanner extends ProductBanner {
  productName: string;
}

export type AdDevice = 'all' | 'mobile' | 'desktop';
export interface AdSetting {
  id: string;
  networkName: string;
  adCode?: string; // approved HTML/script embed, rendered ONLY inside a sandboxed iframe
  adUrl?: string; // https URL rendered in a sandboxed iframe
  placement: 'bottom';
  device: AdDevice;
  width?: number;
  height?: number;
  active: boolean;
  startDate: Date | null;
  endDate: Date | null;
}

// ---------------- Phase 2: marketplace ----------------
export type ProductStatus = 'draft' | 'pending_review' | 'approved' | 'rejected' | 'out_of_stock' | 'suspended';
export const PRODUCT_STATUS_LABEL: Record<ProductStatus, string> = {
  draft: 'Draft', pending_review: 'Pending review', approved: 'Approved', rejected: 'Rejected', out_of_stock: 'Out of stock', suspended: 'Suspended',
};
export interface Variant { key: string; label: string; price?: number; stock: number }
export interface Product {
  id: string; sellerId: string; storeId: string; title: string; slug: string; description: string; brand: string;
  categoryId: string; subcategoryId?: string; images: string[]; video?: string;
  price: number; originalPrice: number; discount: number; stock: number; sku: string;
  rating: number; reviewCount: number; ratingDistribution: Record<'1' | '2' | '3' | '4' | '5', number>; salesCount: number;
  status: ProductStatus; featured: boolean; variants: Variant[]; specs: { label: string; value: string }[];
  shippingInfo?: string; returnPolicy?: string; weight?: string; flashSaleEndsAt: Date | null;
  searchKeywords: string[]; moderationNote?: string; createdAt: Date | null; updatedAt: Date | null;
}
export interface Store {
  id: string; ownerId: string; name: string; slug: string; description: string; logoUrl?: string; bannerUrl?: string;
  city?: string; country?: string; status: string; ratingAvg: number; ratingCount: number; followerCount: number;
  shippingFee: number; freeShippingOver?: number; returnPolicy?: string; shippingInfo?: string;
}
export interface CartItem {
  id: string; userId: string; productId: string; sellerId: string; storeId: string; variantKey: string; variantLabel: string; quantity: number;
}
export interface AddressInput {
  fullName: string; phone: string; country: string; city: string; area: string; address: string; postalCode: string; instructions: string;
}
export interface Address extends AddressInput { id: string; userId: string; isDefault: boolean }

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled' | 'return_requested' | 'returned' | 'refunded';
export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  pending: 'Pending', confirmed: 'Confirmed', processing: 'Processing', shipped: 'Shipped', out_for_delivery: 'Out for delivery',
  delivered: 'Delivered', cancelled: 'Cancelled', return_requested: 'Return requested', returned: 'Returned', refunded: 'Refunded',
};
export interface Order {
  id: string; orderNumber: string; groupId: string; buyerId: string; sellerId: string; storeId: string; storeName: string;
  status: OrderStatus; paymentMethod: 'cod'; paymentStatus: string; deliveryMethod: string;
  subtotal: number; discount: number; shipping: number; total: number; currency: string; itemCount: number;
  address: AddressInput; timeline: { status: OrderStatus; at: Date | null }[]; deliveredAt: Date | null; createdAt: Date | null; trackingNumber?: string; carrier?: string; couponCode?: string; couponDiscount?: number; codRemitted?: boolean;
}
export interface OrderItem {
  id: string; orderId: string; buyerId: string; sellerId: string; storeId: string; productId: string; title: string; image: string;
  sku: string; variantKey: string; variantLabel: string; unitPrice: number; quantity: number; lineTotal: number; status: OrderStatus;
}
export interface Review {
  id: string; orderItemId: string; productId: string; sellerId: string; userId: string; userName: string; rating: number;
  text: string; images: string[]; status: string; verifiedPurchase: boolean; sellerResponse?: string; createdAt: Date | null;
}
