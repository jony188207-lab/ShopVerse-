export type VideoStatus = 'draft' | 'pending_review' | 'published' | 'rejected' | 'suspended';
export const VIDEO_STATUS_LABEL: Record<VideoStatus, string> = { draft: 'Draft', pending_review: 'Pending review', published: 'Published', rejected: 'Rejected', suspended: 'Suspended' };
export type FeedTab = 'for-you' | 'trending' | 'following' | 'products' | 'new';
export const FEED_TABS: { id: FeedTab; label: string }[] = [
  { id: 'for-you', label: 'For You' }, { id: 'trending', label: 'Trending' }, { id: 'following', label: 'Following' }, { id: 'products', label: 'Products' }, { id: 'new', label: 'New' },
];
// Field names follow the existing rules: views=viewCount, likes=likeCount, commentsCount=commentCount, sellerId/creatorId=ownerId.
export interface Video {
  id: string; ownerId: string; storeId: string; title: string; description: string; videoUrl: string; thumbnailUrl: string; productIds: string[]; hashtags: string[]; category: string;
  visibility: 'public' | 'private'; status: VideoStatus; views: number; likes: number; commentsCount: number; saves: number; trendScore: number; moderationNote: string; createdAt: Date | null;
}
export interface VideoComment { id: string; videoId: string; userId: string; userName: string; text: string; status: string; createdAt: Date | null }
