export interface Conversation {
  id: string; buyerId: string; sellerId: string; storeId: string; participants: string[]; unread: Record<string, number>; blockedBy: string[];
  lastMessage: string; lastMessageAt: Date | null; lastSenderId: string; createdAt: Date | null;
}
export interface ChatMessage { id: string; conversationId: string; senderId: string; receiverId: string; text: string; productId?: string; orderId?: string; createdAt: Date | null; readAt: Date | null; pending: boolean }
