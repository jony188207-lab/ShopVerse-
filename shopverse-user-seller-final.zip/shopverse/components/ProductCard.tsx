import Link from 'next/link';
import Image from 'next/image';
import type { Product } from '@/types';
import { Price } from './Price';
import { StarRating } from './StarRating';
import { WishlistButton } from './WishlistButton';
import { availableStock } from '@/utils/cartMath';

export function ProductCard({ p, priority = false }: { p: Product; priority?: boolean }) {
  const out = availableStock(p, p.variants[0]?.key ?? 'default') <= 0 && p.stock <= 0;
  return (
    <article className="group relative">
      <Link href={`/product/${p.id}`} className="block space-y-2">
        <div className="relative aspect-square overflow-hidden rounded-card bg-navy-50 dark:bg-navy-700">
          {p.images[0] ? (
            <Image src={p.images[0]} alt={p.title} fill sizes="(min-width:1024px) 22vw, (min-width:768px) 30vw, 46vw" priority={priority} className="object-cover" />
          ) : null}
          {out ? <span className="absolute left-2 top-2 rounded-md bg-navy-900/85 px-2 py-1 text-xs font-semibold text-white">Out of stock</span> : null}
        </div>
        <h3 className="line-clamp-2 min-h-[2.5rem] text-sm font-medium">{p.title}</h3>
        <Price price={p.price} original={p.originalPrice} />
        <div><StarRating value={p.rating} count={p.reviewCount} size={13} /></div>
      </Link>
      <WishlistButton productId={p.id} className="absolute right-1 top-1 bg-white/90 text-navy-900 dark:bg-navy-900/90 dark:text-white" />
    </article>
  );
}
