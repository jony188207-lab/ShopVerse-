import { formatMoney } from '@/utils/money';
import { discountPercent } from '@/utils/money';

export function Price({ price, original, large = false }: { price: number; original?: number; large?: boolean }) {
  const pct = original ? discountPercent(price, original) : 0;
  return (
    <span className="inline-flex flex-wrap items-baseline gap-x-2">
      <span className={`${large ? 'text-2xl' : 'text-base'} font-extrabold`}>{formatMoney(price)}</span>
      {pct > 0 && original ? (
        <>
          <s className="text-sm text-navy-500 dark:text-navy-100">{formatMoney(original)}</s>
          <span className="rounded-md bg-brand-orange/15 px-1.5 py-0.5 text-xs font-bold text-brand-orange">-{pct}%</span>
        </>
      ) : null}
    </span>
  );
}
