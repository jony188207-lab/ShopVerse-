'use client';
import { useEffect } from 'react';

/**
 * Registers the ONE service worker (/firebase-messaging-sw.js: FCM background push + PWA caching share it, because a scope can only
 * have one worker). Production only; the worker itself also stays inert on localhost.
 */
export function PwaRegister() {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production' || !('serviceWorker' in navigator)) return;
    const reg = () => navigator.serviceWorker.register('/firebase-messaging-sw.js').catch(() => undefined);
    if (document.readyState === 'complete') void reg(); else window.addEventListener('load', reg, { once: true });
  }, []);
  return null;
}
