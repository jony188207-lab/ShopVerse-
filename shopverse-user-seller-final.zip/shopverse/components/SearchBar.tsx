'use client';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Clock, Search, TrendingUp } from 'lucide-react';
import { useDebounce } from '@/hooks/useDebounce';
import { getPopular, suggestProducts } from '@/services/productService';
import { isFirebaseConfigured } from '@/lib/firebase/config';
import { addRecentSearch, clearRecentSearches, getRecentSearches } from '@/utils/recent';

interface Sug { id: string; title: string }

/** Debounced (300 ms) suggestions from real products, recent searches (this device) and top sellers as "popular". */
export function SearchBar({ className = '' }: { className?: string }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [recent, setRecent] = useState<string[]>([]);
  const [popular, setPopular] = useState<Sug[] | null>(null);
  const [sugs, setSugs] = useState<Sug[]>([]);
  const dq = useDebounce(q.trim(), 300);
  const box = useRef<HTMLFormElement>(null);
  const router = useRouter();

  useEffect(() => {
    const away = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', away);
    return () => document.removeEventListener('mousedown', away);
  }, []);

  useEffect(() => {
    if (!open || !isFirebaseConfigured) return;
    setRecent(getRecentSearches());
    if (popular === null) getPopular(5).then((p) => setPopular(p.map((x) => ({ id: x.id, title: x.title })))).catch(() => setPopular([]));
  }, [open, popular]);

  useEffect(() => {
    if (dq.length < 2 || !isFirebaseConfigured) { setSugs([]); return; }
    let off = false;
    suggestProducts(dq).then((s) => !off && setSugs(s)).catch(() => !off && setSugs([]));
    return () => { off = true; };
  }, [dq]);

  const go = (term: string) => {
    const t = term.trim();
    if (!t) return;
    addRecentSearch(t); setOpen(false); setQ(t);
    router.push(`/shop?q=${encodeURIComponent(t)}`);
  };
  const submit = (e: FormEvent) => { e.preventDefault(); go(q); };
  const showTyped = q.trim().length >= 2;

  return (
    <form ref={box} onSubmit={submit} role="search" className={`relative ${className}`} onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}>
      <label htmlFor="global-search" className="sr-only">Search products</label>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-navy-500" aria-hidden />
      <input id="global-search" type="search" value={q} autoComplete="off" onFocus={() => setOpen(true)} onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        placeholder="Search products, brands, categories" aria-expanded={open}
        className="min-h-11 w-full rounded-xl border border-navy-100 bg-white pl-10 pr-3 text-base text-navy-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-purple dark:border-navy-500 dark:bg-navy-900 dark:text-white" />
      {open ? (
        <div className="absolute inset-x-0 top-12 z-50 max-h-[70vh] overflow-y-auto rounded-card border border-navy-100 bg-white p-2 text-navy-900 shadow-xl dark:border-navy-500 dark:bg-navy-900 dark:text-white">
          {showTyped ? (
            <ul>
              <li><button type="button" onClick={() => go(q)} className="flex min-h-11 w-full items-center gap-2 rounded-lg px-3 text-left text-sm font-semibold hover:bg-navy-50 dark:hover:bg-navy-700"><Search className="h-4 w-4" aria-hidden />Search for “{q.trim()}”</button></li>
              {sugs.map((s) => <li key={s.id}><Link href={`/product/${s.id}`} onClick={() => setOpen(false)} className="flex min-h-11 items-center rounded-lg px-3 text-sm hover:bg-navy-50 dark:hover:bg-navy-700">{s.title}</Link></li>)}
            </ul>
          ) : (
            <div className="space-y-2">
              {recent.length ? (
                <section>
                  <div className="flex items-center justify-between px-3 py-1 text-xs font-semibold text-navy-500 dark:text-navy-100"><span>Recent searches</span><button type="button" onClick={() => { clearRecentSearches(); setRecent([]); }} className="underline">Clear</button></div>
                  <ul>{recent.map((r) => <li key={r}><button type="button" onClick={() => go(r)} className="flex min-h-11 w-full items-center gap-2 rounded-lg px-3 text-left text-sm hover:bg-navy-50 dark:hover:bg-navy-700"><Clock className="h-4 w-4" aria-hidden />{r}</button></li>)}</ul>
                </section>
              ) : null}
              {popular?.length ? (
                <section>
                  <p className="px-3 py-1 text-xs font-semibold text-navy-500 dark:text-navy-100">Popular right now</p>
                  <ul>{popular.map((p) => <li key={p.id}><button type="button" onClick={() => go(p.title)} className="flex min-h-11 w-full items-center gap-2 rounded-lg px-3 text-left text-sm hover:bg-navy-50 dark:hover:bg-navy-700"><TrendingUp className="h-4 w-4" aria-hidden />{p.title}</button></li>)}</ul>
                </section>
              ) : null}
              {!recent.length && !popular?.length ? <p className="px-3 py-3 text-sm text-navy-500 dark:text-navy-100">Type at least 2 letters to search.</p> : null}
            </div>
          )}
        </div>
      ) : null}
    </form>
  );
}
