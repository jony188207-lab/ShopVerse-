'use client';
import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import type { Product } from '@/types';
import type { Page } from '@/services/productService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState } from '@/components/ui/States';
import { ProductGridSkeleton } from '@/components/ui/Skeleton';
import { ProductCard } from './ProductCard';

/** Paginated grid. `resetKey` changes => list restarts. Only one page of documents is read at a time. */
export function ProductGrid({ fetchPage, resetKey, emptyTitle, emptyText, emptyAction }: {
  fetchPage: (cursor: QueryDocumentSnapshot | null) => Promise<Page<Product>>; resetKey: string; emptyTitle: string; emptyText?: string; emptyAction?: ReactNode;
}) {
  const [items, setItems] = useState<Product[]>([]);
  const [cursor, setCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const fetchRef = useRef(fetchPage);
  fetchRef.current = fetchPage;
  const gen = useRef(0);

  const load = useCallback(async (reset: boolean, cur: QueryDocumentSnapshot | null) => {
    const my = ++gen.current;
    setLoading(true); setError('');
    try {
      const page = await fetchRef.current(reset ? null : cur);
      if (my !== gen.current) return;
      setItems((x) => (reset ? page.items : [...x, ...page.items]));
      setCursor(page.cursor); setHasMore(page.hasMore);
    } catch (e) { if (my === gen.current) setError(friendlyError(e)); } finally { if (my === gen.current) setLoading(false); }
  }, []);

  useEffect(() => { setItems([]); void load(true, null); }, [resetKey, load]);

  if (error && !items.length) return <ErrorState message={error} action={<Button onClick={() => load(true, null)}>Try again</Button>} />;
  if (loading && !items.length) return <ProductGridSkeleton />;
  if (!items.length) return <EmptyState title={emptyTitle} action={emptyAction}>{emptyText}</EmptyState>;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">{items.map((p, i) => <ProductCard key={p.id} p={p} priority={i < 4} />)}</div>
      {error ? <p role="alert" className="text-center text-sm text-red-600">{error}</p> : null}
      {hasMore ? <div className="flex justify-center"><Button variant="secondary" loading={loading} onClick={() => load(false, cursor)}>Load more</Button></div> : null}
    </div>
  );
}
