'use client';
import { Heart } from 'lucide-react';
import { useWishlist } from '@/hooks/useWishlist';

export function WishlistButton({ productId, className = '', label = false }: { productId: string; className?: string; label?: boolean }) {
  const { has, toggle } = useWishlist();
  const on = has(productId);
  return (
    <button type="button" onClick={(e) => { e.preventDefault(); e.stopPropagation(); void toggle(productId); }} aria-pressed={on}
      aria-label={on ? 'Remove from wishlist' : 'Add to wishlist'}
      className={`inline-flex min-h-11 min-w-11 items-center justify-center gap-2 rounded-xl ${className}`}>
      <Heart className={`h-5 w-5 ${on ? 'fill-brand-orange text-brand-orange' : ''}`} aria-hidden />
      {label ? <span className="text-sm font-semibold">{on ? 'Saved' : 'Wishlist'}</span> : null}
    </button>
  );
}
