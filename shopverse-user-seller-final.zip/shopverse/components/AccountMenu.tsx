'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { Heart, LogOut, MapPin, MessageSquare, Moon, Package, PlayCircle, Settings, Store, User as UserIcon, Sun } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useSellerStatus } from '@/hooks/useSellerStatus';
import { useUnreadMessages } from '@/hooks/useUnreadMessages';
import { logout } from '@/services/authService';
import { Avatar } from './Avatar';

const row = 'flex min-h-11 w-full items-center gap-3 px-4 text-sm hover:bg-navy-50 dark:hover:bg-navy-700';

export function AccountMenu() {
  const { user, loading } = useAuth();
  const { state } = useSellerStatus();
  const unread = useUnreadMessages();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    setDark(document.documentElement.classList.contains('dark'));
    const click = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', click); document.addEventListener('keydown', key);
    return () => { document.removeEventListener('mousedown', click); document.removeEventListener('keydown', key); };
  }, [open]);

  if (loading) return <span className="inline-block h-11 w-11" aria-hidden />; // reserve space, no layout jump
  if (!user) return <Link href="/login" className="rounded-xl bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white">Sign in</Link>;

  const go = (href: string) => () => setOpen(false);
  const toggleTheme = () => {
    const next = !document.documentElement.classList.contains('dark');
    document.documentElement.classList.toggle('dark', next);
    try { localStorage.setItem('sv-theme', next ? 'dark' : 'light'); } catch { /* private mode */ }
    setDark(next);
  };
  const seller =
    state === 'approved' ? { href: '/seller', label: 'Seller Center', icon: Store }
    : state === 'pending' ? { href: '/become-seller', label: 'Seller Application: Pending', icon: Store }
    : state === 'rejected' ? { href: '/become-seller', label: 'Seller Application: Rejected', icon: Store }
    : state === 'suspended' ? { href: '/become-seller', label: 'Seller account: Suspended', icon: Store }
    : state === 'none' ? { href: '/become-seller', label: 'Become a Seller', icon: Store } : null;

  return (
    <div ref={box} className="relative">
      <button type="button" aria-haspopup="menu" aria-expanded={open} aria-label="Account menu" onClick={() => setOpen((o) => !o)} className="grid h-11 w-11 place-items-center rounded-xl hover:bg-navy-50 dark:hover:bg-navy-700">
        <Avatar name={user.displayName || user.email || '?'} src={user.photoURL ?? undefined} size={32} />
      </button>
      {open ? (
        <div role="menu" className="absolute right-0 top-12 z-50 w-64 overflow-hidden rounded-card border border-navy-100 bg-white py-1 shadow-lg dark:border-navy-500 dark:bg-navy-800">
          <div className="border-b border-navy-100 px-4 py-2 dark:border-navy-500"><p className="truncate text-sm font-semibold">{user.displayName || 'Shopper'}</p><p className="truncate text-xs">{user.email}</p></div>
          <Link role="menuitem" href="/profile" onClick={go('')} className={row}><UserIcon className="h-4 w-4" aria-hidden />Profile</Link>
          <Link role="menuitem" href="/orders" onClick={go('')} className={row}><Package className="h-4 w-4" aria-hidden />Orders</Link>
          <Link role="menuitem" href="/wishlist" onClick={go('')} className={row}><Heart className="h-4 w-4" aria-hidden />Wishlist</Link>
          <Link role="menuitem" href="/video/saved" onClick={go('')} className={row}><PlayCircle className="h-4 w-4" aria-hidden />Saved videos</Link>
          <Link role="menuitem" href="/messages" onClick={go('')} className={row}><MessageSquare className="h-4 w-4" aria-hidden />Messages{unread ? <span className="ml-auto rounded-full bg-brand-orange px-1.5 text-xs font-bold text-white">{unread > 9 ? '9+' : unread}</span> : null}</Link>
          <Link role="menuitem" href="/profile/addresses" onClick={go('')} className={row}><MapPin className="h-4 w-4" aria-hidden />Addresses</Link>
          {seller ? <Link role="menuitem" href={seller.href} onClick={go('')} className={`${row} font-semibold text-brand-purple`}><seller.icon className="h-4 w-4" aria-hidden />{seller.label}</Link> : null}
          <Link role="menuitem" href="/profile/settings" onClick={go('')} className={row}><Settings className="h-4 w-4" aria-hidden />Settings</Link>
          <button role="menuitem" type="button" onClick={toggleTheme} className={row}>{dark ? <Sun className="h-4 w-4" aria-hidden /> : <Moon className="h-4 w-4" aria-hidden />}{dark ? 'Light theme' : 'Dark theme'}</button>
          <button role="menuitem" type="button" onClick={async () => { setOpen(false); await logout(); router.replace('/'); }} className={`${row} border-t border-navy-100 text-red-600 dark:border-navy-500`}><LogOut className="h-4 w-4" aria-hidden />Log out</button>
        </div>
      ) : null}
    </div>
  );
}
