'use client';
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { getMyStore } from '@/services/sellerService';
import { friendlyError } from '@/lib/firebase/errors';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import type { Store } from '@/types';

interface Ctx { store: Store; uid: string; setStore: (s: Store) => void }
const C = createContext<Ctx | null>(null);
export const useSeller = (): Ctx => { const v = useContext(C); if (!v) throw new Error('useSeller outside SellerProvider'); return v; };

export function SellerProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [store, setStore] = useState<Store | null | undefined>(undefined);
  const [err, setErr] = useState('');
  useEffect(() => { if (user) getMyStore(user.uid).then(setStore).catch((e) => { setErr(friendlyError(e)); setStore(null); }); }, [user]);
  if (store === undefined) return <LoadingState />;
  if (err) return <ErrorState message={err} />;
  if (!store || store.status !== 'approved') return <EmptyState title="Your store is not active">Your store is not approved, or it is suspended. Check your application status on the Become a seller page.</EmptyState>;
  return <C.Provider value={{ store, uid: user!.uid, setStore }}>{children}</C.Provider>;
}
