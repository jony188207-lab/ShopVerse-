'use client';
import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { useSeller } from './SellerProvider';
import { textareaCls, selectCls } from './ui';
import { useToast } from '@/hooks/useToast';
import { useCategories } from '@/hooks/useCategories';
import { friendlyError } from '@/lib/firebase/errors';
import { saveSellerProduct, type SellerProductForm as F } from '@/services/sellerService';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';
import type { Product } from '@/types';

const init = (p: Product | null): F => ({
  title: p?.title ?? '', brand: p?.brand ?? '', categoryId: p?.categoryId ?? '', subcategoryId: p?.subcategoryId ?? '', description: p?.description ?? '', price: p?.price ?? 0,
  originalPrice: p && p.originalPrice > p.price ? p.originalPrice : null, stock: p?.stock ?? 0, sku: p?.sku ?? '', weight: p?.weight ?? '',
  specsText: p?.specs.map((s) => `${s.label}: ${s.value}`).join('\n') ?? '', variantsText: p?.variants.map((v) => `${v.label} | ${v.stock}${v.price ? ` | ${v.price}` : ''}`).join('\n') ?? '',
  shippingInfo: p?.shippingInfo ?? '', returnPolicy: p?.returnPolicy ?? '',
});

export function SellerProductForm({ existing }: { existing: Product | null }) {
  const { uid, store } = useSeller(); const toast = useToast(); const router = useRouter();
  const { categories } = useCategories();
  const [f, setF] = useState<F>(() => init(existing));
  const [images, setImages] = useState<File[]>([]);
  const [video, setVideo] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof F>(k: K, v: F[K]) => setF((x) => ({ ...x, [k]: v }));
  const text = (k: keyof F) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => set(k, e.target.value as never);
  const hasVariants = f.variantsText.trim().length > 0;
  const go = async (submit: boolean) => {
    setBusy(true);
    try { await saveSellerProduct(uid, store, existing, f, submit, images, video); toast(submit ? 'Submitted for review' : 'Draft saved', 'success'); router.push('/seller/products'); }
    catch (err) { toast(err instanceof Error && !('code' in err) ? err.message : friendlyError(err), 'error'); } finally { setBusy(false); }
  };
  const onSubmit = (e: FormEvent) => { e.preventDefault(); void go(true); };
  return (
    <form onSubmit={onSubmit} className="grid gap-3 md:grid-cols-2">
      {existing?.status === 'rejected' && existing.moderationNote ? <p role="alert" className="rounded-card border border-red-300 bg-red-50 p-3 text-sm text-red-800 md:col-span-2">Rejected: {existing.moderationNote}</p> : null}
      {existing?.status === 'approved' ? <p className="rounded-card border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 md:col-span-2">This product is live. Saving changes sends it back to review and hides it until it is approved again. To only change stock, use “Update stock” on the products list.</p> : null}
      <div className="md:col-span-2"><Field label="Title" required minLength={2} maxLength={200} value={f.title} onChange={text('title')} /></div>
      <Field label="Brand" value={f.brand} onChange={text('brand')} />
      <label className="text-sm font-medium">Category<select required value={f.categoryId} onChange={text('categoryId')} className={`mt-1 w-full ${selectCls}`}><option value="">Choose…</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <Field label="Subcategory (optional)" value={f.subcategoryId} onChange={text('subcategoryId')} />
      <Field label="SKU" value={f.sku} onChange={text('sku')} />
      <Field label="Price" type="number" required min={0.01} step="0.01" value={f.price || ''} onChange={(e) => set('price', Number(e.target.value))} />
      <Field label="Original price (shows a discount, optional)" type="number" min={0} step="0.01" value={f.originalPrice ?? ''} onChange={(e) => set('originalPrice', e.target.value === '' ? null : Number(e.target.value))} />
      <Field label={hasVariants ? 'Stock (sum of options)' : 'Stock'} type="number" min={0} step={1} disabled={hasVariants} value={hasVariants ? '' : f.stock} onChange={(e) => set('stock', Math.max(0, Math.floor(Number(e.target.value))))} />
      <Field label="Weight (optional)" value={f.weight} onChange={text('weight')} />
      <div className="md:col-span-2"><label className="text-sm font-medium" htmlFor="d">Description</label><textarea id="d" rows={5} value={f.description} onChange={text('description')} className={textareaCls} /></div>
      <div><label className="text-sm font-medium" htmlFor="s">Specifications (one per line: Label: value)</label><textarea id="s" rows={4} value={f.specsText} onChange={text('specsText')} className={textareaCls} /></div>
      <div><label className="text-sm font-medium" htmlFor="v">Options — size / color (one per line: Label | stock | optional price)</label><textarea id="v" rows={4} value={f.variantsText} onChange={text('variantsText')} className={textareaCls} placeholder={'Red / M | 10\nBlue / L | 4 | 24.99'} /></div>
      <Field label="Shipping info (optional, overrides store)" value={f.shippingInfo} onChange={text('shippingInfo')} />
      <Field label="Return policy (optional, overrides store)" value={f.returnPolicy} onChange={text('returnPolicy')} />
      <div><label className="text-sm font-medium" htmlFor="i">Add images (max 8 at a time, 10 MB each){existing ? ` · ${existing.images.length} saved` : ''}</label><input id="i" type="file" multiple accept="image/jpeg,image/png,image/webp" onChange={(e) => setImages([...(e.target.files ?? [])])} className="block text-sm" /></div>
      <div><label className="text-sm font-medium" htmlFor="vid">Product video (MP4/WebM, max 100 MB)</label><input id="vid" type="file" accept="video/mp4,video/webm,video/quicktime" onChange={(e) => setVideo(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
      <div className="flex flex-wrap gap-2 md:col-span-2">
        <Button type="submit" loading={busy}>Submit for review</Button>
        <Button type="button" variant="ghost" disabled={busy} onClick={() => go(false)}>Save as draft</Button>
      </div>
    </form>
  );
}
