'use client';
import { useRouter } from 'next/navigation';
import { Flag } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { fileReport, type REPORT_TARGETS } from '@/services/reportService';

/** One report per user per target (the document id enforces it). The Admin App triages it. */
export function ReportButton({ targetType, targetId, label = 'Report', evidence }: { targetType: (typeof REPORT_TARGETS)[number]; targetId: string; label?: string; evidence?: () => string }) {
  const { user } = useAuth(); const toast = useToast(); const router = useRouter();
  const click = async () => {
    if (!user) return router.push(`/login?next=${encodeURIComponent(window.location.pathname)}`);
    const reason = window.prompt(`What is wrong with this ${targetType}?`); if (!reason) return;
    try { await fileReport(user.uid, targetType, targetId, reason, evidence?.() ?? ''); toast('Thanks — our moderators will take a look', 'success'); }
    catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : (e as { code?: string })?.code === 'permission-denied' ? 'You have already reported this' : friendlyError(e), 'error'); }
  };
  return <button type="button" onClick={click} className="inline-flex min-h-11 items-center gap-1 rounded-xl px-3 text-sm text-navy-500 hover:bg-navy-50 dark:text-navy-100 dark:hover:bg-navy-700"><Flag className="h-4 w-4" aria-hidden />{label}</button>;
}
