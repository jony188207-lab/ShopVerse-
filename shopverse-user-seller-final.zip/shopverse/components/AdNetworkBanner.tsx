'use client';
import { useEffect, useState } from 'react';
import { getActiveAd } from '@/services/adService';
import { getPublicSettings } from '@/services/settingsService';
import { isFirebaseConfigured } from '@/lib/firebase/config';
import { isSafeHttpsUrl } from '@/utils/schedule';
import type { AdSetting } from '@/types';

const SANDBOX = 'allow-scripts allow-popups allow-popups-to-escape-sandbox';

function wrapDoc(code: string): string {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><base target="_blank"><style>html,body{margin:0;padding:0;overflow:hidden;background:transparent}body{display:flex;justify-content:center}</style></head><body>${code}</body></html>`;
}

/**
 * Network-agnostic bottom ad slot. Admin-pasted code runs inside a sandboxed iframe WITHOUT allow-same-origin,
 * so ad scripts cannot read ShopVerse cookies, storage, or the DOM. The slot sits in normal page flow (see Footer),
 * with a fixed reserved height, so it never overlays navigation, buttons or checkout controls and causes no layout shift.
 */
export type AdFrameAd = Pick<AdSetting, 'id' | 'networkName' | 'adCode' | 'adUrl' | 'width' | 'height'>;

/** Pure renderer (also used for the admin preview). Sandboxed, fixed reserved size, in normal flow. */
export function AdFrame({ ad }: { ad: AdFrameAd }) {
  const w = ad.width ?? 728;
  const h = ad.height ?? 90;
  const common = { title: `Advertisement from ${ad.networkName || 'ad network'}`, sandbox: SANDBOX, loading: 'lazy' as const, referrerPolicy: 'strict-origin-when-cross-origin' as const };
  return (
    <aside aria-label="Advertisement" className="mx-auto w-full max-w-full overflow-hidden px-2 py-2 text-center" data-ad-id={ad.id}>
      <p className="mb-1 text-[10px] text-navy-500 dark:text-navy-100">Advertisement</p>
      <div className="mx-auto max-w-full overflow-hidden" style={{ width: w, height: h }}>
        {ad.adCode ? (
          <iframe {...common} srcDoc={wrapDoc(ad.adCode)} width={w} height={h} style={{ border: 0, maxWidth: '100%' }} />
        ) : ad.adUrl && isSafeHttpsUrl(ad.adUrl) ? (
          <iframe {...common} src={ad.adUrl} width={w} height={h} style={{ border: 0, maxWidth: '100%' }} />
        ) : null}
      </div>
    </aside>
  );
}

/** Bottom ad slot: respects the global switch (Admin App settings) and the active, scheduled, device-matching config (Admin App ads). */
export function AdNetworkBanner({ placement = 'bottom' }: { placement?: 'bottom' }) {
  const [ad, setAd] = useState<AdSetting | null>(null);
  useEffect(() => {
    if (!isFirebaseConfigured) return;
    let cancelled = false;
    const device = window.matchMedia('(min-width: 768px)').matches ? 'desktop' : 'mobile';
    getPublicSettings().then((s) => (s.adsEnabled ? getActiveAd(placement, device) : null)).then((a) => !cancelled && setAd(a)).catch(() => !cancelled && setAd(null));
    return () => { cancelled = true; };
  }, [placement]);
  return ad ? <AdFrame ad={ad} /> : null;
}
