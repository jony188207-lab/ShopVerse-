'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getLiveBanners } from '@/services/bannerService';
import { isFirebaseConfigured } from '@/lib/firebase/config';
import { getPublicSettings } from '@/services/settingsService';
import type { LiveBanner } from '@/types';

/** Admin-controlled product banners. Every slide links to /product/[productId] of a product verified to exist. */
export function TopBannerCarousel() {
  const [banners, setBanners] = useState<LiveBanner[] | null>(null);
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const [secs, setSecs] = useState(5);
  useEffect(() => { if (isFirebaseConfigured) getPublicSettings().then((s) => setSecs(s.bannerRotateSeconds)); }, []);

  useEffect(() => {
    if (!isFirebaseConfigured) { setBanners([]); return; }
    let cancelled = false;
    getLiveBanners().then((b) => !cancelled && setBanners(b)).catch(() => !cancelled && setBanners([]));
    return () => { cancelled = true; };
  }, []);

  const count = banners?.length ?? 0;
  useEffect(() => {
    if (count < 2 || paused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const t = setInterval(() => setI((n) => (n + 1) % count), secs * 1000);
    return () => clearInterval(t);
  }, [count, paused, secs]);

  if (banners === null) return <div className="mx-4 aspect-[16/7] animate-pulse rounded-card bg-navy-100 motion-reduce:animate-none dark:bg-navy-700 md:aspect-[21/6]" aria-hidden />;
  if (count === 0) return null; // nothing live: render nothing rather than a fake banner

  const b = banners[i % count];
  return (
    <section aria-roledescription="carousel" aria-label="Featured products" className="relative mx-4"
      onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}>
      <Link href={`/product/${encodeURIComponent(b.productId)}`} className="group relative block aspect-[16/7] overflow-hidden rounded-card md:aspect-[21/6]" aria-label={`${b.title} — ${b.ctaText}`}>
        <picture>
          <source media="(min-width: 768px)" srcSet={b.desktopImage} />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={b.mobileImage} alt="" className="h-full w-full object-cover" />
        </picture>
        <div className="absolute inset-0 flex flex-col justify-end gap-1 bg-gradient-to-t from-navy-900/80 to-transparent p-4 text-white md:max-w-xl md:justify-center md:bg-gradient-to-r md:p-8">
          <h2 className="text-xl font-extrabold md:text-3xl">{b.title}</h2>
          {b.subtitle ? <p className="text-sm md:text-base">{b.subtitle}</p> : null}
          <span className="mt-2 w-fit rounded-xl bg-brand-orange px-4 py-2 text-sm font-semibold">{b.ctaText}</span>
        </div>
      </Link>
      {count > 1 ? (
        <div className="absolute bottom-2 right-3 flex gap-1.5">
          {banners.map((x, idx) => (
            <button key={x.id} onClick={() => setI(idx)} aria-label={`Show banner ${idx + 1} of ${count}`} aria-current={idx === i % count}
              className={`h-2.5 w-2.5 rounded-full ${idx === i % count ? 'bg-brand-orange' : 'bg-white/70'}`} />
          ))}
        </div>
      ) : null}
    </section>
  );
}
