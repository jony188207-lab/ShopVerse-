'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { ReportButton } from '@/components/ReportButton';
import { getProduct } from '@/services/productService';
import { formatMoney } from '@/utils/money';
import type { ChatMessage } from '@/types/chat';
import type { Product } from '@/types';

function ProductRef({ id }: { id: string }) {
  const [p, setP] = useState<Product | null | undefined>(undefined);
  useEffect(() => { getProduct(id).then(setP).catch(() => setP(null)); }, [id]);
  return <Link href={`/product/${id}`} className="mb-1 block rounded-lg bg-black/10 px-2 py-1 text-xs underline-offset-2 hover:underline">{p === undefined ? 'Product…' : p ? `About: ${p.title} · ${formatMoney(p.price)}` : 'About a product (no longer available)'}</Link>;
}

export function MessageBubble({ m, mine, cid, seen }: { m: ChatMessage; mine: boolean; cid: string; seen: boolean }) {
  return (
    <li className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${mine ? 'bg-brand-purple text-white' : 'bg-navy-50 dark:bg-navy-700'} ${m.pending ? 'opacity-60' : ''}`}>
        {m.productId ? <ProductRef id={m.productId} /> : null}
        {m.orderId ? <Link href={`/orders/${m.orderId}`} className="mb-1 block rounded-lg bg-black/10 px-2 py-1 text-xs underline-offset-2 hover:underline">About an order</Link> : null}
        <p className="whitespace-pre-wrap break-words">{m.text}</p>
        <p className={`mt-1 flex items-center gap-2 text-[10px] ${mine ? 'justify-end text-white/70' : 'text-navy-500 dark:text-navy-100'}`}>
          {m.createdAt ? m.createdAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'sending…'}{mine && !m.pending ? <span>{seen ? '· Seen' : '· Sent'}</span> : null}
          {!mine && !m.pending ? <ReportButton targetType="message" targetId={`${cid}_${m.id}`} label="Report" evidence={() => `${m.text.slice(0, 300)}`} /> : null}
        </p>
      </div>
    </li>
  );
}
