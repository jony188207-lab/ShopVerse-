'use client';
import { useCallback, useEffect, useState } from 'react';
import Image from 'next/image';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { BadgeCheck, Flag } from 'lucide-react';
import { listReviews, reportReview } from '@/services/reviewService';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { StarRating } from './StarRating';
import { Button } from './ui/Button';
import { EmptyState } from './ui/States';
import type { Product, Review } from '@/types';

export function ReviewsSection({ product }: { product: Product }) {
  const { user } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState<Review[]>([]);
  const [cursor, setCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [more, setMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async (cur: QueryDocumentSnapshot | null) => {
    setLoading(true); setError('');
    try { const p = await listReviews(product.id, cur); setItems((x) => (cur ? [...x, ...p.items] : p.items)); setCursor(p.cursor); setMore(p.hasMore); }
    catch (e) { setError(friendlyError(e)); } finally { setLoading(false); }
  }, [product.id]);
  useEffect(() => { void load(null); }, [load]);

  const report = async (r: Review) => {
    if (!user) return toast('Sign in to report a review', 'info');
    try { await reportReview(user.uid, r.id, 'Reported by a buyer'); toast('Thanks — our team will take a look', 'success'); }
    catch (e) { toast((e as { code?: string }).code === 'permission-denied' ? 'You already reported this review' : friendlyError(e), 'error'); }
  };
  const total = product.reviewCount;
  return (
    <section aria-labelledby="reviews" className="space-y-4">
      <h2 id="reviews" className="text-xl font-bold">Reviews</h2>
      {total > 0 ? (
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div><p className="text-4xl font-extrabold">{product.rating.toFixed(1)}</p><StarRating value={product.rating} /><p className="text-sm text-navy-500 dark:text-navy-100">{total} verified review{total > 1 ? 's' : ''}</p></div>
          <ul className="flex-1 space-y-1" aria-label="Rating distribution">
            {([5, 4, 3, 2, 1] as const).map((n) => {
              const c = product.ratingDistribution[String(n) as '1'];
              return (
                <li key={n} className="flex items-center gap-2 text-sm"><span className="w-10">{n} star</span>
                  <span className="h-2 flex-1 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-700"><span className="block h-full bg-brand-orange" style={{ width: `${total ? (c / total) * 100 : 0}%` }} /></span>
                  <span className="w-8 text-right">{c}</span></li>
              );
            })}
          </ul>
        </div>
      ) : null}
      {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
      {!loading && !items.length && !error ? <EmptyState title="No reviews yet">Only buyers with a delivered order can review this product.</EmptyState> : null}
      <ul className="space-y-4">
        {items.map((r) => (
          <li key={r.id} className="space-y-1 border-b border-navy-100 pb-4 dark:border-navy-500">
            <div className="flex flex-wrap items-center gap-2"><StarRating value={r.rating} /><span className="text-sm font-semibold">{r.userName}</span>
              {r.verifiedPurchase ? <span className="inline-flex items-center gap-1 text-xs font-semibold text-green-700 dark:text-green-400"><BadgeCheck className="h-4 w-4" aria-hidden />Verified purchase</span> : null}</div>
            {r.text ? <p className="text-sm">{r.text}</p> : null}
            {r.images.length ? <div className="flex gap-2">{r.images.map((u) => <div key={u} className="relative h-20 w-20 overflow-hidden rounded-lg"><Image src={u} alt="Review photo" fill sizes="80px" className="object-cover" /></div>)}</div> : null}
            {r.sellerResponse ? <p className="rounded-lg bg-navy-50 p-2 text-sm dark:bg-navy-700"><strong>Seller response:</strong> {r.sellerResponse}</p> : null}
            <button onClick={() => report(r)} className="inline-flex min-h-11 items-center gap-1 text-xs text-navy-500 underline dark:text-navy-100"><Flag className="h-3.5 w-3.5" aria-hidden />Report</button>
          </li>
        ))}
      </ul>
      {more ? <Button variant="secondary" loading={loading} onClick={() => load(cursor)}>Load more reviews</Button> : null}
    </section>
  );
}
