'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { getPopularStores } from '@/services/storeService';
import { isFirebaseConfigured } from '@/lib/firebase/config';
import { StarRating } from '@/components/StarRating';
import { EmptyRail, Section } from './Rail';
import type { Store } from '@/types';

export function StoresRail() {
  const [stores, setStores] = useState<Store[] | null>(null);
  useEffect(() => {
    if (!isFirebaseConfigured) { setStores([]); return; }
    getPopularStores(8).then(setStores).catch(() => setStores([]));
  }, []);
  return (
    <Section title="Popular stores">
      {stores === null ? <p className="text-sm text-navy-500">Loading…</p> : stores.length === 0 ? <EmptyRail text="No stores are open yet." /> : (
        <ul className="flex gap-3 overflow-x-auto pb-2">
          {stores.map((s) => (
            <li key={s.id} className="shrink-0">
              <Link href={`/store/${s.slug}`} className="flex w-44 flex-col items-center gap-2 rounded-card border border-navy-100 p-3 text-center dark:border-navy-500">
                <span className="relative h-14 w-14 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-700">{s.logoUrl ? <Image src={s.logoUrl} alt="" fill sizes="56px" className="object-cover" /> : null}</span>
                <span className="line-clamp-1 text-sm font-semibold">{s.name}</span>
                <StarRating value={s.ratingAvg} count={s.ratingCount} size={12} />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Section>
  );
}
