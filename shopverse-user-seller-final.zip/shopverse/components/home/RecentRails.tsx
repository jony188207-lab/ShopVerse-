'use client';
import { useState, useEffect } from 'react';
import { getProductsByIds, getRecommended } from '@/services/productService';
import { getRecentlyViewed } from '@/utils/recent';
import { ProductRail } from './Rail';
import type { Product } from '@/types';

/** Recently viewed ids are per-device; Recommended = best sellers in those products' categories. */
export function RecentRails() {
  const [ids, setIds] = useState<string[] | null>(null);
  useEffect(() => setIds(getRecentlyViewed()), []);
  if (ids === null) return null;
  const viewed = async (): Promise<Product[]> => Array.from((await getProductsByIds(ids.slice(0, 8))).values()).filter((p): p is Product => !!p && p.status === 'approved');
  return (
    <>
      <ProductRail title="Recommended for you" deps={ids.join(',')} empty="Browse a few products and we'll suggest best sellers from the same categories."
        fetcher={async () => { const v = await viewed(); return getRecommended(v.map((p) => p.categoryId), v.map((p) => p.id)); }} />
      <ProductRail title="Recently viewed" deps={ids.join(',')} empty="Products you open will show up here." fetcher={viewed} />
    </>
  );
}
