'use client';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import Link from 'next/link';
import type { Product } from '@/types';
import { ProductCard } from '@/components/ProductCard';
import { ProductGridSkeleton } from '@/components/ui/Skeleton';
import { friendlyError } from '@/lib/firebase/errors';
import { isFirebaseConfigured } from '@/lib/firebase/config';

/** Renders (and fetches) only once scrolled near the viewport, so a Home visit doesn't read every section up-front. */
export function LazyMount({ children, eager = false }: { children: ReactNode; eager?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [show, setShow] = useState(eager);
  useEffect(() => {
    if (show || !ref.current) return;
    const io = new IntersectionObserver((e) => { if (e[0].isIntersecting) { setShow(true); io.disconnect(); } }, { rootMargin: '300px' });
    io.observe(ref.current);
    return () => io.disconnect();
  }, [show]);
  return <div ref={ref} className={show ? '' : 'min-h-40'}>{show ? children : null}</div>;
}

export function Section({ title, href, children }: { title: string; href?: string; children: ReactNode }) {
  return (
    <section aria-label={title} className="px-4">
      <div className="mb-2 flex items-baseline justify-between">
        <h2 className="text-lg font-bold">{title}</h2>
        {href ? <Link href={href} className="text-sm font-semibold text-brand-purple underline">See all</Link> : null}
      </div>
      {children}
    </section>
  );
}

export function EmptyRail({ text }: { text: string }) {
  return <p className="rounded-card border border-dashed border-navy-100 p-4 text-sm text-navy-500 dark:border-navy-500 dark:text-navy-100">{text}</p>;
}

export function ProductRail({ title, href, fetcher, empty, deps = '' }: { title: string; href?: string; fetcher: () => Promise<Product[]>; empty: string; deps?: string }) {
  const [items, setItems] = useState<Product[] | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!isFirebaseConfigured) { setItems([]); return; }
    let off = false;
    fetcher().then((x) => !off && setItems(x)).catch((e) => { if (!off) { setError(friendlyError(e)); setItems([]); } });
    return () => { off = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deps]);
  return (
    <Section title={title} href={href}>
      {items === null ? <ProductGridSkeleton n={4} /> : error ? <p role="alert" className="text-sm text-red-600">{error}</p> : items.length === 0 ? <EmptyRail text={empty} /> : (
        <ul className="flex snap-x gap-3 overflow-x-auto pb-2 md:grid md:grid-cols-4 lg:grid-cols-6">
          {items.map((p) => <li key={p.id} className="w-40 shrink-0 snap-start md:w-auto"><ProductCard p={p} /></li>)}
        </ul>
      )}
    </Section>
  );
}
