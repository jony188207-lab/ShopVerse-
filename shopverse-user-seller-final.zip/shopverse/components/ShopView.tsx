'use client';
import { useCallback, useMemo } from 'react';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useCategories } from '@/hooks/useCategories';
import { listProducts, searchProducts, type SortKey } from '@/services/productService';
import { ProductGrid } from './ProductGrid';
import { Button } from './ui/Button';

const SORTS: { v: SortKey; l: string }[] = [
  { v: 'newest', l: 'Newest' }, { v: 'popular', l: 'Best selling' }, { v: 'rating', l: 'Top rated' }, { v: 'price_asc', l: 'Price: low to high' }, { v: 'price_desc', l: 'Price: high to low' },
];
const num = (v: string | null) => { const n = v ? Number(v) : NaN; return Number.isFinite(n) && n >= 0 ? n : undefined; };

/** Filters live in the URL (shareable + back button friendly). `fixedCategory` / `storeId` pin a scope; store pages are newest-only. */
export function ShopView({ fixedCategory, storeId }: { fixedCategory?: string; storeId?: string }) {
  const { categories, byId } = useCategories();
  const sp = useSearchParams(); const router = useRouter(); const path = usePathname();
  const q = sp.get('q')?.trim() ?? '';
  const categoryId = fixedCategory ?? sp.get('category') ?? undefined;
  const sortParam = (sp.get('sort') as SortKey) ?? 'newest';
  const min = num(sp.get('min')); const max = num(sp.get('max'));
  const sortOptions = q ? SORTS.filter((s) => s.v === 'newest' || s.v === 'popular') : SORTS;
  const sort = sortOptions.some((s) => s.v === sortParam) ? sortParam : 'newest';

  const set = useCallback((patch: Record<string, string>) => {
    const n = new URLSearchParams(sp.toString());
    Object.entries(patch).forEach(([k, v]) => (v ? n.set(k, v) : n.delete(k)));
    router.replace(`${path}?${n.toString()}`);
  }, [sp, router, path]);

  const fetchPage = useMemo(() => (cursor: Parameters<typeof listProducts>[1]) =>
    q ? searchProducts(q, { sort: sort === 'popular' ? 'popular' : 'newest', categoryId, minPrice: min, maxPrice: max }, cursor)
      : listProducts({ categoryId, storeId, sort: storeId ? 'newest' : sort, minPrice: storeId ? undefined : min, maxPrice: storeId ? undefined : max }, cursor),
  [q, sort, categoryId, storeId, min, max]);

  const title = q ? `Results for “${q}”` : categoryId ? byId(categoryId)?.name ?? 'Category' : 'Shop';
  return (
    <div className="space-y-4 px-4">
      <h1 className="text-2xl font-extrabold">{title}</h1>
      {!storeId ? (
        <form className="grid grid-cols-2 gap-2 md:grid-cols-5" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); set({ min: String(f.get('min') ?? ''), max: String(f.get('max') ?? '') }); }}>
          {!fixedCategory ? (
            <label className="text-sm font-medium">Category
              <select value={categoryId ?? ''} onChange={(e) => set({ category: e.target.value })} className="mt-1 min-h-11 w-full rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900">
                <option value="">All categories</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
          ) : null}
          <label className="text-sm font-medium">Sort by
            <select value={sort} onChange={(e) => set({ sort: e.target.value })} className="mt-1 min-h-11 w-full rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900">
              {sortOptions.map((s) => <option key={s.v} value={s.v}>{s.l}</option>)}
            </select>
          </label>
          <label className="text-sm font-medium">Min price
            <input name="min" type="number" min={0} inputMode="decimal" defaultValue={min ?? ''} className="mt-1 min-h-11 w-full rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900" />
          </label>
          <label className="text-sm font-medium">Max price
            <input name="max" type="number" min={0} inputMode="decimal" defaultValue={max ?? ''} className="mt-1 min-h-11 w-full rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900" />
          </label>
          <div className="col-span-2 flex items-end gap-2 md:col-span-1"><Button type="submit" variant="secondary" className="flex-1">Apply prices</Button></div>
        </form>
      ) : null}
      {!storeId && (min != null || max != null) && !q && !sort.startsWith('price') ? <p className="text-xs text-navy-500 dark:text-navy-100">Price filters sort results by price.</p> : null}
      <ProductGrid fetchPage={fetchPage} resetKey={`${q}|${categoryId}|${storeId}|${sort}|${min}|${max}`} emptyTitle={q ? 'No products match your search' : 'No products here yet'}
        emptyText={q ? 'Try a shorter word, check the spelling, or browse a category.' : 'Approved products will appear here as soon as sellers publish them.'}
        emptyAction={<Link className="font-semibold text-brand-purple underline" href="/categories">Browse categories</Link>} />
    </div>
  );
}
