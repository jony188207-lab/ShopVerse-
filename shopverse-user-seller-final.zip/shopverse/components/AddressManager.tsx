'use client';
import { useCallback, useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { addAddress, deleteAddress, listAddresses, setDefaultAddress, updateAddress } from '@/services/addressService';
import { friendlyError } from '@/lib/firebase/errors';
import { AddressForm } from './AddressForm';
import { Button } from './ui/Button';
import { Card } from './ui/Card';
import { EmptyState, ErrorState, LoadingState } from './ui/States';
import type { Address } from '@/types';

/** Shared by /profile/addresses (manage) and /checkout/address (`onSelect` shows a "Deliver here" button). */
export function AddressManager({ onSelect }: { onSelect?: (a: Address) => void }) {
  const { user } = useAuth();
  const toast = useToast();
  const [list, setList] = useState<Address[] | null>(null);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState<Address | 'new' | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    try { setError(''); setList(await listAddresses(user.uid)); } catch (e) { setError(friendlyError(e)); }
  }, [user]);
  useEffect(() => { void load(); }, [load]);

  if (!user) return null;
  if (error) return <ErrorState message={error} action={<Button onClick={load}>Try again</Button>} />;
  if (list === null) return <LoadingState />;

  const wrap = async (fn: () => Promise<unknown>, ok: string) => { try { await fn(); toast(ok, 'success'); await load(); } catch (e) { toast(friendlyError(e), 'error'); } };

  if (editing) {
    const a = editing === 'new' ? undefined : editing;
    return (
      <Card><h2 className="mb-3 text-lg font-bold">{a ? 'Edit address' : 'New address'}</h2>
        <AddressForm initial={a} initialDefault={a?.isDefault ?? list.length === 0} onCancel={() => setEditing(null)}
          onSubmit={async (v, def) => {
            if (a) { await updateAddress(a.id, v, a.isDefault, user.uid); if (def && !a.isDefault) await setDefaultAddress(user.uid, a.id); }
            else await addAddress(user.uid, v, def || list.length === 0);
            setEditing(null); toast('Address saved', 'success'); await load();
          }} />
      </Card>
    );
  }
  return (
    <div className="space-y-3">
      {list.length === 0 ? <EmptyState title="No saved addresses">Add where you want your orders delivered.</EmptyState> : list.map((a) => (
        <Card key={a.id} className="space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="text-sm"><p className="font-semibold">{a.fullName} {a.isDefault ? <span className="ml-1 rounded-md bg-brand-purple/15 px-1.5 py-0.5 text-xs font-bold text-brand-purple">Default</span> : null}</p>
              <p>{a.address}{a.area ? `, ${a.area}` : ''}</p><p>{a.city}{a.postalCode ? ` ${a.postalCode}` : ''}, {a.country}</p><p>{a.phone}</p>
              {a.instructions ? <p className="text-navy-500 dark:text-navy-100">Note: {a.instructions}</p> : null}</div>
          </div>
          <div className="flex flex-wrap gap-2">
            {onSelect ? <Button onClick={() => onSelect(a)}>Deliver here</Button> : null}
            <Button variant="ghost" onClick={() => setEditing(a)}>Edit</Button>
            {!a.isDefault ? <Button variant="ghost" onClick={() => wrap(() => setDefaultAddress(user.uid, a.id), 'Default address updated')}>Make default</Button> : null}
            <Button variant="ghost" onClick={() => { if (window.confirm('Delete this address?')) void wrap(() => deleteAddress(a.id), 'Address deleted'); }}>Delete</Button>
          </div>
        </Card>
      ))}
      {list.length < 20 ? <Button variant="secondary" onClick={() => setEditing('new')}>Add new address</Button> : <p className="text-sm">You can save up to 20 addresses.</p>}
    </div>
  );
}
