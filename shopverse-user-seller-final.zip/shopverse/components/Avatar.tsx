/* eslint-disable @next/next/no-img-element */
export function Avatar({ name, src, size = 40 }: { name: string; src?: string; size?: number }) {
  const initial = (name.trim()[0] ?? '?').toUpperCase();
  return src
    ? <img src={src} alt="" width={size} height={size} loading="lazy" className="shrink-0 rounded-full bg-navy-100 object-cover" style={{ width: size, height: size }} />
    : <span aria-hidden className="grid shrink-0 place-items-center rounded-full bg-brand-purple font-bold text-white" style={{ width: size, height: size, fontSize: size * 0.42 }}>{initial}</span>;
}
