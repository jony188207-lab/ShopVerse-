'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Bell } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { watchUnread } from '@/services/notificationService';

export function NotificationBell() {
  const { user } = useAuth();
  const [n, setN] = useState(0);
  useEffect(() => { if (!user) { setN(0); return; } return watchUnread(user.uid, setN); }, [user]);
  if (!user) return null;
  return (
    <Link href="/notifications" aria-label={n ? `${n} unread notifications` : 'Notifications'} className="relative grid h-11 w-11 place-items-center rounded-xl hover:bg-navy-50 dark:hover:bg-navy-700">
      <Bell className="h-5 w-5" aria-hidden />
      {n ? <span className="absolute right-1.5 top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-brand-orange px-1 text-[10px] font-bold text-white">{n > 9 ? '9+' : n}</span> : null}
    </Link>
  );
}
