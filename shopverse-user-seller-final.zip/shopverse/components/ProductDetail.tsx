'use client';
import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Minus, Plus, Share2 } from 'lucide-react';
import type { Product, Store } from '@/types';
import { getProduct } from '@/services/productService';
import { getStore } from '@/services/storeService';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/hooks/useToast';
import { availableStock } from '@/utils/cartMath';
import { addRecentlyViewed } from '@/utils/recent';
import { formatMoney } from '@/utils/money';
import { useCategories } from '@/hooks/useCategories';
import { ReportButton } from '@/components/ReportButton';
import { RETURN_WINDOW_DAYS } from '@/config/site';
import { Button } from './ui/Button';
import { EmptyState, LoadingState } from './ui/States';
import { Price } from './Price';
import { StarRating } from './StarRating';
import { WishlistButton } from './WishlistButton';
import { SellerBox } from './SellerBox';
import { ProductVideos } from './ProductVideos';
import { ReviewsSection } from './ReviewsSection';

export function ProductDetail({ id }: { id: string }) {
  const [product, setProduct] = useState<Product | null | undefined>(undefined);
  const [store, setStore] = useState<Store | null>(null);
  useEffect(() => {
    let off = false;
    setProduct(undefined);
    getProduct(id).then(async (p) => {
      if (off) return;
      setProduct(p);
      if (p) { if (p.status === 'approved') addRecentlyViewed(p.id); setStore(await getStore(p.storeId)); }
    });
    return () => { off = true; };
  }, [id]);
  if (product === undefined) return <LoadingState />;
  // missing, draft, rejected, suspended => not publicly readable, so all look the same to a buyer
  if (!product) return <EmptyState title="This product is unavailable">It may have been removed or is not for sale right now.</EmptyState>;
  return <Body product={product} store={store} />;
}

function Body({ product, store }: { product: Product; store: Store | null }) {
  const { add } = useCart();
  const toast = useToast();
  const router = useRouter();
  const [img, setImg] = useState(0);
  const [showVideo, setShowVideo] = useState(false);
  const [variantKey, setVariantKey] = useState<string>(product.variants.length === 1 ? product.variants[0].key : '');
  const [qty, setQty] = useState(1);
  const [busy, setBusy] = useState(false);

  const variant = product.variants.find((v) => v.key === variantKey);
  const needsVariant = product.variants.length > 0 && !variant;
  const available = useMemo(() => availableStock(product, variantKey || 'default'), [product, variantKey]);
  const forSale = product.status === 'approved';
  const price = variant?.price ?? product.price;
  const stockText = !forSale ? 'Not available' : product.variants.length && !variant ? `${product.stock} in stock` : available <= 0 ? 'Out of stock' : available <= 5 ? `Only ${available} left` : 'In stock';
  const canBuy = forSale && !needsVariant && available > 0;
  const { byId } = useCategories();
  const cat = byId(product.categoryId);

  const act = async (buyNow: boolean) => {
    if (needsVariant) return toast('Choose an option first', 'info');
    setBusy(true);
    const ok = await add(product, variantKey || undefined, qty);
    setBusy(false);
    if (ok && buyNow) router.push('/checkout/address');
  };
  const share = async () => {
    const url = window.location.href;
    try { if (navigator.share) await navigator.share({ title: product.title, url }); else { await navigator.clipboard.writeText(url); toast('Link copied', 'success'); } } catch { /* user cancelled */ }
  };
  const shipping = product.shippingInfo ?? store?.shippingInfo ?? (store ? `${store.shippingFee > 0 ? `Shipping ${formatMoney(store.shippingFee)}` : 'Free shipping'}${store.freeShippingOver != null ? ` · free over ${formatMoney(store.freeShippingOver)}` : ''}. Cash on delivery.` : 'Cash on delivery.');
  const returns = product.returnPolicy ?? store?.returnPolicy ?? `Return requests are accepted within ${RETURN_WINDOW_DAYS} days of delivery.`;

  return (
    <div className="space-y-8 px-4">
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <div className="relative aspect-square overflow-hidden rounded-card bg-navy-50 dark:bg-navy-700">
            {showVideo && product.video ? <video src={product.video} controls playsInline preload="metadata" poster={product.images[0]} className="h-full w-full object-contain" />
              : product.images[img] ? <Image src={product.images[img]} alt={product.title} fill priority sizes="(min-width:768px) 50vw, 100vw" className="object-cover" /> : null}
          </div>
          <ul className="flex gap-2 overflow-x-auto">
            {product.images.map((u, i) => (
              <li key={u}><button onClick={() => { setImg(i); setShowVideo(false); }} aria-label={`Show image ${i + 1}`} aria-current={!showVideo && i === img}
                className={`relative h-16 w-16 overflow-hidden rounded-lg border-2 ${!showVideo && i === img ? 'border-brand-orange' : 'border-transparent'}`}><Image src={u} alt="" fill sizes="64px" className="object-cover" /></button></li>
            ))}
            {product.video ? <li><button onClick={() => setShowVideo(true)} className={`h-16 rounded-lg border-2 px-3 text-sm font-semibold ${showVideo ? 'border-brand-orange' : 'border-navy-100 dark:border-navy-500'}`}>Video</button></li> : null}
          </ul>
        </div>
        <div className="space-y-4">
          <div>
            {product.brand ? <p className="text-sm font-semibold text-brand-purple">{product.brand}</p> : null}
            <h1 className="text-2xl font-extrabold">{product.title}</h1>
            <div className="mt-1"><StarRating value={product.rating} count={product.reviewCount} /></div>
          </div>
          <Price price={price} original={variant?.price ? undefined : product.originalPrice} large />
          <p className={`text-sm font-semibold ${canBuy ? 'text-green-700 dark:text-green-400' : 'text-red-600'}`} role="status">{stockText}</p>
          {product.variants.length ? (
            <fieldset><legend className="mb-1 text-sm font-semibold">Options</legend>
              <div className="flex flex-wrap gap-2">
                {product.variants.map((v) => {
                  const out = v.stock <= 0;
                  return <button key={v.key} type="button" disabled={out} aria-pressed={variantKey === v.key} onClick={() => { setVariantKey(v.key); setQty(1); }}
                    className={`min-h-11 rounded-xl border px-4 text-sm font-medium disabled:line-through disabled:opacity-50 ${variantKey === v.key ? 'border-brand-orange bg-brand-orange/10' : 'border-navy-100 dark:border-navy-500'}`}>{v.label}</button>;
                })}
              </div>
            </fieldset>
          ) : null}
          <div className="flex items-center gap-2" role="group" aria-label="Quantity">
            <button type="button" aria-label="Decrease quantity" disabled={qty <= 1} onClick={() => setQty(qty - 1)} className="grid h-11 w-11 place-items-center rounded-xl border border-navy-100 disabled:opacity-40 dark:border-navy-500"><Minus className="h-4 w-4" /></button>
            <span className="w-10 text-center font-semibold" aria-live="polite">{qty}</span>
            <button type="button" aria-label="Increase quantity" disabled={qty >= Math.min(available, 99)} onClick={() => setQty(qty + 1)} className="grid h-11 w-11 place-items-center rounded-xl border border-navy-100 disabled:opacity-40 dark:border-navy-500"><Plus className="h-4 w-4" /></button>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => act(false)} disabled={!canBuy} loading={busy} className="flex-1">Add to cart</Button>
            <Button variant="secondary" onClick={() => act(true)} disabled={!canBuy || busy} className="flex-1">Buy now</Button>
          </div>
          <div className="flex flex-wrap gap-2">
            <WishlistButton productId={product.id} label className="border border-navy-100 px-4 dark:border-navy-500" />
            <Button variant="ghost" onClick={share} className="border border-navy-100 dark:border-navy-500"><Share2 className="h-4 w-4" aria-hidden />Share</Button>
            <ReportButton targetType="product" targetId={product.id} />
          </div>
          <dl className="grid grid-cols-[auto,1fr] gap-x-4 gap-y-1 text-sm">
            {product.sku ? <><dt className="text-navy-500 dark:text-navy-100">SKU</dt><dd>{product.sku}</dd></> : null}
            {cat ? <><dt className="text-navy-500 dark:text-navy-100">Category</dt><dd>{cat.name}</dd></> : null}
            {product.weight ? <><dt className="text-navy-500 dark:text-navy-100">Weight</dt><dd>{product.weight}</dd></> : null}
          </dl>
          {store ? <SellerBox store={store} productId={product.id} /> : null}
        </div>
      </div>
      <section className="space-y-2"><h2 className="text-xl font-bold">Description</h2><p className="whitespace-pre-line text-sm leading-relaxed">{product.description || 'No description provided.'}</p></section>
      {product.specs.length ? (
        <section className="space-y-2"><h2 className="text-xl font-bold">Specifications</h2>
          <dl className="divide-y divide-navy-100 rounded-card border border-navy-100 text-sm dark:divide-navy-500 dark:border-navy-500">
            {product.specs.map((s, i) => <div key={i} className="grid grid-cols-2 gap-2 p-3"><dt className="font-medium">{s.label}</dt><dd>{s.value}</dd></div>)}
          </dl>
        </section>
      ) : null}
      <section className="grid gap-4 md:grid-cols-2">
        <div><h2 className="text-xl font-bold">Shipping</h2><p className="mt-1 text-sm">{shipping}</p></div>
        <div><h2 className="text-xl font-bold">Returns</h2><p className="mt-1 text-sm">{returns}</p></div>
      </section>
      <ProductVideos productId={product.id} />
      <ReviewsSection product={product} />
    </div>
  );
}
