'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { MOBILE_NAV, SELLER_NAV } from '@/config/nav';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';

/** Fixed mobile nav. Height is exposed as --bottom-nav-h so the page footer/ad slot can reserve exactly this space. */
export function BottomNav() {
  const pathname = usePathname();
  const { count } = useCart();
  const { role } = useAuth();
  // Sellers get their own 4-tab bar while inside Seller Center; everywhere else they see the normal customer bar.
  const seller = role === 'seller' && pathname.startsWith('/seller');
  const items = seller ? SELLER_NAV : MOBILE_NAV;
  return (
    <nav aria-label="Primary mobile" className="fixed inset-x-0 bottom-0 z-50 border-t border-navy-100 bg-white pb-[env(safe-area-inset-bottom)] dark:border-navy-500 dark:bg-navy-900 md:hidden">
      <ul className={`grid h-[var(--bottom-nav-h)] ${seller ? 'grid-cols-4' : 'grid-cols-5'}`}>
        {items.map(({ href, label, icon: Icon }) => {
          const active = href === '/' || href === '/seller' ? pathname === href : pathname.startsWith(href);
          return (
            <li key={href}>
              <Link href={href} aria-current={active ? 'page' : undefined}
                className={`flex h-full flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${active ? 'text-brand-orange' : 'text-navy-500 dark:text-navy-100'}`}>
                <span className="relative"><Icon className="h-5 w-5" aria-hidden />{href === '/cart' && count > 0 ? <span className="absolute -right-2 -top-1.5 min-w-4 rounded-full bg-brand-orange px-1 text-center text-[10px] font-bold leading-4 text-white" aria-label={`${count} items in cart`}>{count > 99 ? '99+' : count}</span> : null}</span>
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
