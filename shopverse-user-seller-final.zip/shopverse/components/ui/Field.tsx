import type { InputHTMLAttributes } from 'react';
interface Props extends InputHTMLAttributes<HTMLInputElement> { label: string; error?: string }
export function Field({ label, error, id, className = '', ...rest }: Props) {
  const fid = id ?? `f-${label.replace(/\W+/g, '-').toLowerCase()}`;
  return (
    <div className="space-y-1">
      <label htmlFor={fid} className="text-sm font-medium">{label}</label>
      <input
        id={fid}
        aria-invalid={!!error}
        className={`min-h-11 w-full rounded-xl border border-navy-100 bg-white px-3 text-base text-navy-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-purple dark:border-navy-500 dark:bg-navy-900 dark:text-white ${className}`}
        {...rest}
      />
      {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
    </div>
  );
}
