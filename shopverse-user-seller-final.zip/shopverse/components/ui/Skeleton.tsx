export function Skeleton({ className = '' }: { className?: string }) {
  return <div aria-hidden className={`animate-pulse rounded-lg bg-navy-100 motion-reduce:animate-none dark:bg-navy-700 ${className}`} />;
}
export function ProductGridSkeleton({ n = 8 }: { n?: number }) {
  return (
    <div role="status" aria-label="Loading products" className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
      {Array.from({ length: n }, (_, i) => (
        <div key={i} className="space-y-2"><Skeleton className="aspect-square w-full" /><Skeleton className="h-4 w-3/4" /><Skeleton className="h-4 w-1/3" /></div>
      ))}
    </div>
  );
}
