import type { HTMLAttributes } from 'react';
export function Card({ className = '', ...rest }: HTMLAttributes<HTMLDivElement>) {
  return <div className={`rounded-card border border-navy-100 bg-white p-4 dark:border-navy-500 dark:bg-navy-700 ${className}`} {...rest} />;
}
