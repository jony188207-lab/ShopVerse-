import type { ReactNode } from 'react';
import { AlertTriangle, Inbox, Loader2 } from 'lucide-react';

export function LoadingState({ label = 'Loading…' }: { label?: string }) {
  return (
    <div role="status" className="flex items-center justify-center gap-2 py-16 text-navy-500 dark:text-navy-100">
      <Loader2 className="h-5 w-5 animate-spin motion-reduce:animate-none" aria-hidden /> {label}
    </div>
  );
}

export function EmptyState({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-16 text-center">
      <Inbox className="h-8 w-8 text-brand-purple" aria-hidden />
      <h2 className="text-lg font-semibold">{title}</h2>
      {children ? <p className="text-sm text-navy-500 dark:text-navy-100">{children}</p> : null}
      {action}
    </div>
  );
}

export function ErrorState({ title = 'Something went wrong', message, action }: { title?: string; message?: string; action?: ReactNode }) {
  return (
    <div role="alert" className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-16 text-center">
      <AlertTriangle className="h-8 w-8 text-red-600" aria-hidden />
      <h2 className="text-lg font-semibold">{title}</h2>
      {message ? <p className="text-sm text-navy-500 dark:text-navy-100">{message}</p> : null}
      {action}
    </div>
  );
}

/** Marks a feature whose architecture exists but is not built yet — no fake data is rendered in its place. */
export function Pending({ title, phase, children }: { title: string; phase: string; children?: ReactNode }) {
  return (
    <EmptyState title={title}>
      Not built yet — planned for {phase}. {children}
    </EmptyState>
  );
}
