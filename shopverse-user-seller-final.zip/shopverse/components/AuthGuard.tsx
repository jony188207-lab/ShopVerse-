'use client';
import { useEffect, type ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/hooks/useAuth';
import type { Role } from '@/types';
import { ErrorState, LoadingState } from '@/components/ui/States';

/**
 * UI-level route protection only. The real enforcement is firestore.rules / storage.rules —
 * a user who bypasses this component still cannot read or write data they are not allowed to.
 */
export function AuthGuard({ children, roles, requireVerified = false }: { children: ReactNode; roles?: Role[]; requireVerified?: boolean }) {
  const { user, role, loading, configured } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (configured && !loading && !user) router.replace(`/login?next=${encodeURIComponent(pathname)}`);
  }, [configured, loading, user, router, pathname]);

  if (!configured) return <ErrorState title="Firebase is not configured" message="Copy .env.example to .env.local and add your Firebase web app values." />;
  if (loading || !user) return <LoadingState />;
  if (requireVerified && !user.emailVerified) {
    return <ErrorState title="Verify your email" message="Confirm your email address to use this page." action={<Link className="font-semibold text-brand-purple underline" href="/verify-email">Go to verification</Link>} />;
  }
  if (roles && !roles.includes(role)) return <ErrorState title="No access" message="Your account does not have permission to view this page." action={<Link className="font-semibold text-brand-purple underline" href="/">Back to home</Link>} />;
  return <>{children}</>;
}
