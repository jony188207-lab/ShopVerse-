'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { BadgeCheck } from 'lucide-react';
import { createReview, getMyReview } from '@/services/reviewService';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from './ui/Button';
import { StarInput, StarRating } from './StarRating';
import type { OrderItem, Review } from '@/types';

export function ReviewForm({ item }: { item: OrderItem }) {
  const { user } = useAuth();
  const toast = useToast();
  const [mine, setMine] = useState<Review | null | undefined>(undefined);
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [text, setText] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => { getMyReview(item.id).then(setMine); }, [item.id]);
  if (mine === undefined || !user) return null;
  if (mine) return <p className="flex items-center gap-2 text-sm"><BadgeCheck className="h-4 w-4 text-green-700" aria-hidden />You reviewed this <StarRating value={mine.rating} /></p>;
  if (!open) return <Button variant="ghost" className="border border-navy-100 dark:border-navy-500" onClick={() => setOpen(true)}>Write a review</Button>;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (rating < 1) return toast('Choose a star rating', 'info');
    setBusy(true);
    try { await createReview(user.uid, user.displayName ?? '', item, rating, text, files); toast('Thanks for your review', 'success'); setMine(await getMyReview(item.id)); }
    catch (err) { toast(friendlyError(err), 'error'); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-2 rounded-xl border border-navy-100 p-3 dark:border-navy-500">
      <StarInput value={rating} onChange={setRating} />
      <label className="block text-sm font-medium" htmlFor={`rv-${item.id}`}>Your review (optional)</label>
      <textarea id={`rv-${item.id}`} rows={3} maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} className="w-full rounded-xl border border-navy-100 bg-white p-3 text-base text-navy-900 dark:border-navy-500 dark:bg-navy-900 dark:text-white" />
      <label className="block text-sm font-medium" htmlFor={`rf-${item.id}`}>Photos (up to 4, max 5 MB each)</label>
      <input id={`rf-${item.id}`} type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => setFiles(Array.from(e.target.files ?? []).slice(0, 4))} className="text-sm" />
      <div className="flex gap-2"><Button type="submit" loading={busy}>Submit review</Button><Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button></div>
    </form>
  );
}
