'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Heart, ShoppingCart } from 'lucide-react';
import { DESKTOP_NAV } from '@/config/nav';
import { SITE } from '@/config/site';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import { useWishlist } from '@/hooks/useWishlist';
import { SearchBar } from './SearchBar';
import { NotificationBell } from './NotificationBell';
import { AccountMenu } from './AccountMenu';

const iconLink = 'relative grid h-11 w-11 place-items-center rounded-xl hover:bg-navy-50 dark:hover:bg-navy-700';
const badge = 'absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-brand-orange px-1 text-[10px] font-bold text-white';

/** Logo · search · notifications · wishlist · cart · account menu. Everything else lives in the account menu / profile, not the bottom bar. */
export function Header() {
  const pathname = usePathname();
  const { role } = useAuth();
  const { count } = useCart();
  const { ids } = useWishlist();
  const nav = [...DESKTOP_NAV, ...(role === 'seller' ? [{ href: '/seller', label: 'Seller Center' }] : [])];
  return (
    <header className="sticky top-0 z-40 border-b border-navy-100 bg-white/95 pt-[env(safe-area-inset-top)] backdrop-blur dark:border-navy-500 dark:bg-navy-900/95">
      <div className="mx-auto flex max-w-7xl items-center gap-2 px-4 py-2">
        <Link href="/" className="flex shrink-0 flex-col leading-none" aria-label={`${SITE.name} home`}>
          <span className="text-xl font-extrabold tracking-tight text-navy-900 dark:text-white">Shop<span className="text-brand-orange">Verse</span></span>
          <span className="text-[11px] font-medium text-brand-purple">{SITE.tagline}</span>
        </Link>
        <nav aria-label="Primary" className="ml-3 hidden items-center gap-1 lg:flex">
          {nav.map((n) => {
            const active = n.href === '/' ? pathname === '/' : pathname.startsWith(n.href);
            return <Link key={n.href} href={n.href} aria-current={active ? 'page' : undefined} className={`rounded-lg px-3 py-2 text-sm font-medium ${active ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'hover:bg-navy-50 dark:hover:bg-navy-700'}`}>{n.label}</Link>;
          })}
        </nav>
        <SearchBar className="ml-auto hidden w-64 md:block lg:w-80" />
        <div className="ml-auto flex items-center md:ml-0">
          <NotificationBell />
          <Link href="/wishlist" aria-label={ids.length ? `Wishlist, ${ids.length} saved` : 'Wishlist'} className={iconLink}><Heart className="h-5 w-5" aria-hidden />{ids.length ? <span className={badge}>{ids.length > 99 ? '99+' : ids.length}</span> : null}</Link>
          <Link href="/cart" aria-label={count ? `Cart, ${count} items` : 'Cart'} className={iconLink}><ShoppingCart className="h-5 w-5" aria-hidden />{count ? <span className={badge}>{count > 99 ? '99+' : count}</span> : null}</Link>
          <AccountMenu />
        </div>
      </div>
      <div className="px-4 pb-2 md:hidden"><SearchBar /></div>
    </header>
  );
}
