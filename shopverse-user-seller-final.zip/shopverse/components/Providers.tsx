'use client';
import type { ReactNode } from 'react';
import { AuthProvider } from '@/hooks/useAuth';
import { CategoryProvider } from '@/hooks/useCategories';
import { ToastProvider } from '@/hooks/useToast';
import { WishlistProvider } from '@/hooks/useWishlist';
import { CartProvider } from '@/hooks/useCart';
import { FcmBridge } from './FcmBridge';

export function Providers({ children }: { children: ReactNode }) {
  return (
    <AuthProvider>
      <ToastProvider>
        <CategoryProvider>
          <WishlistProvider>
            <CartProvider>{children}<FcmBridge /></CartProvider>
          </WishlistProvider>
        </CategoryProvider>
      </ToastProvider>
    </AuthProvider>
  );
}
