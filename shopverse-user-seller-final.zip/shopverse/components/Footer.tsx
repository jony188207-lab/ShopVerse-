'use client';
import { usePathname } from 'next/navigation';
import { AdNetworkBanner } from './AdNetworkBanner';
import { InstallPrompt } from './InstallPrompt';

const NO_AD_PREFIXES = ['/admin', '/seller', '/login', '/signup', '/forgot-password', '/verify-email', '/checkout', '/video', '/messages'];

/**
 * Bottom of the app. Bottom padding on mobile = bottom-nav height + safe area, so nothing (ad included)
 * can end up hidden behind the fixed nav. The ad is in flow, never position:fixed over content.
 */
export function Footer() {
  const pathname = usePathname();
  const showAd = !NO_AD_PREFIXES.some((p) => pathname.startsWith(p));
  return (
    <footer className="mt-8 border-t border-navy-100 pb-[calc(var(--bottom-nav-h)+env(safe-area-inset-bottom))] dark:border-navy-500 md:pb-0">
      {showAd ? <AdNetworkBanner placement="bottom" /> : null}
      <div className="flex flex-col items-center gap-2 px-4 py-4 text-center text-xs text-navy-500 dark:text-navy-100"><InstallPrompt /><p>© ShopVerse</p></div>
    </footer>
  );
}
