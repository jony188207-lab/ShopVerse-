'use client';
import { Star } from 'lucide-react';

export function StarRating({ value, count, size = 16 }: { value: number; count?: number; size?: number }) {
  return (
    <span className="inline-flex items-center gap-1 text-sm" aria-label={`Rated ${value.toFixed(1)} out of 5${count != null ? ` from ${count} reviews` : ''}`}>
      <span className="inline-flex" aria-hidden>
        {[1, 2, 3, 4, 5].map((i) => <Star key={i} width={size} height={size} className={i <= Math.round(value) ? 'fill-brand-orange text-brand-orange' : 'text-navy-100 dark:text-navy-500'} />)}
      </span>
      {count != null ? <span className="text-navy-500 dark:text-navy-100">{count > 0 ? `${value.toFixed(1)} (${count})` : 'No reviews yet'}</span> : null}
    </span>
  );
}

export function StarInput({ value, onChange }: { value: number; onChange: (n: number) => void }) {
  return (
    <div role="radiogroup" aria-label="Your rating" className="flex gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <button key={i} type="button" role="radio" aria-checked={value === i} aria-label={`${i} star${i > 1 ? 's' : ''}`} onClick={() => onChange(i)} className="grid h-11 w-9 place-items-center">
          <Star className={i <= value ? 'fill-brand-orange text-brand-orange' : 'text-navy-100 dark:text-navy-500'} />
        </button>
      ))}
    </div>
  );
}
