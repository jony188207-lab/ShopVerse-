'use client';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { Bookmark, Heart, MessageCircle, Pause, Play, Share2, Volume2, VolumeX } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { formatMoney } from '@/utils/money';
import type { Product, Store } from '@/types';
import type { Video } from '@/types/video';

const compact = (n: number) => (n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}K` : String(n));

export interface SlideSocial { liked: boolean; saved: boolean; following: boolean; likeDelta: number; commentDelta: number }
interface Props {
  video: Video; store: Store | null; products: (Product | null)[]; social: SlideSocial; active: boolean; near: boolean; muted: boolean; own: boolean;
  onToggleMute: () => void; onLike: () => void; onSave: () => void; onFollow: () => void; onComments: () => void; onShare: () => void; onViewed: () => void;
}

/**
 * Thumbnail-first: the poster image is always painted; a <video> element exists only for the active slide and its neighbour
 * (neighbour only fetches metadata), so at most two video elements are alive at any time.
 */
export function VideoSlide(p: Props) {
  const { video: v } = p;
  const { user } = useAuth();
  const ref = useRef<HTMLVideoElement | null>(null);
  const [playing, setPlaying] = useState(false); const [ready, setReady] = useState(false); const [failed, setFailed] = useState(false);
  const viewed = useRef(false);

  useEffect(() => {
    const el = ref.current; if (!el) return;
    if (p.active) { el.play().then(() => setPlaying(true)).catch(() => setPlaying(false)); } else { el.pause(); setPlaying(false); if (!p.near) el.removeAttribute('src'); }
  }, [p.active, p.near]);
  useEffect(() => { if (ref.current) ref.current.muted = p.muted; }, [p.muted]);
  useEffect(() => {   // count a view after 3s of actual playback
    if (!p.active || !playing || viewed.current) return;
    const t = setTimeout(() => { viewed.current = true; p.onViewed(); }, 3000);
    return () => clearTimeout(t);
  }, [p.active, playing]); // eslint-disable-line react-hooks/exhaustive-deps
  const toggle = () => { const el = ref.current; if (!el) return; if (el.paused) { void el.play(); setPlaying(true); } else { el.pause(); setPlaying(false); } };

  return (
    <section className="relative h-full w-full snap-start overflow-hidden bg-black" aria-label={v.title}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {v.thumbnailUrl ? <img src={v.thumbnailUrl} alt="" loading={p.near ? 'eager' : 'lazy'} className={`absolute inset-0 h-full w-full object-cover transition-opacity ${ready && playing ? 'opacity-0' : 'opacity-100'}`} /> : null}
      {p.active || p.near ? (
        <video ref={ref} src={v.videoUrl} poster={v.thumbnailUrl || undefined} playsInline loop muted={p.muted} preload={p.active ? 'auto' : 'metadata'} onCanPlay={() => setReady(true)} onError={() => setFailed(true)}
          onClick={toggle} className="absolute inset-0 h-full w-full object-cover md:object-contain" aria-label={`Video: ${v.title}`} />
      ) : null}
      {failed ? <p role="alert" className="absolute inset-x-6 top-1/2 -translate-y-1/2 rounded-xl bg-black/70 p-3 text-center text-sm text-white">This video could not be played.</p> : null}
      {!playing && p.active && !failed ? <button onClick={toggle} aria-label="Play" className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-black/50 text-white"><Play className="h-8 w-8" /></button> : null}
      {playing ? <button onClick={toggle} aria-label="Pause" className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-black/0 text-transparent focus-visible:bg-black/50 focus-visible:text-white"><Pause className="h-8 w-8" /></button> : null}

      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
      <div className="absolute bottom-[calc(env(safe-area-inset-bottom)+0.75rem)] right-2 z-10 flex flex-col items-center gap-3 text-white">
        {[
          { icon: <Heart className={`h-7 w-7 ${p.social.liked ? 'fill-red-500 text-red-500' : ''}`} />, label: p.social.liked ? 'Unlike' : 'Like', n: v.likes + p.social.likeDelta, on: p.onLike },
          { icon: <MessageCircle className="h-7 w-7" />, label: 'Comments', n: v.commentsCount + p.social.commentDelta, on: p.onComments },
          { icon: <Bookmark className={`h-7 w-7 ${p.social.saved ? 'fill-yellow-400 text-yellow-400' : ''}`} />, label: p.social.saved ? 'Unsave' : 'Save', n: null, on: p.onSave },
          { icon: <Share2 className="h-7 w-7" />, label: 'Share', n: null, on: p.onShare },
          { icon: p.muted ? <VolumeX className="h-7 w-7" /> : <Volume2 className="h-7 w-7" />, label: p.muted ? 'Unmute' : 'Mute', n: null, on: p.onToggleMute },
        ].map((b) => (
          <button key={b.label} onClick={b.on} aria-label={b.label} className="flex min-h-11 min-w-11 flex-col items-center text-xs drop-shadow">{b.icon}{b.n !== null ? <span>{compact(b.n)}</span> : null}</button>
        ))}
      </div>

      <div className="absolute inset-x-0 bottom-0 z-10 space-y-2 p-3 pb-[calc(env(safe-area-inset-bottom)+0.75rem)] pr-16 text-white">
        <div className="flex items-center gap-2">
          {p.store ? <Link href={`/store/${p.store.slug}`} className="min-w-0 truncate text-sm font-bold underline-offset-2 hover:underline">@{p.store.name}</Link> : <span className="text-sm font-bold">@seller</span>}
          {!p.own && p.store ? <button onClick={p.onFollow} className="min-h-8 rounded-md border border-white px-2 text-xs font-semibold">{p.social.following ? 'Following' : 'Follow'}</button> : null}
          <span className="ml-auto text-xs">{compact(v.views)} views</span>
        </div>
        <p className="line-clamp-2 text-sm font-semibold">{v.title}</p>
        {v.hashtags.length ? <p className="line-clamp-1 text-xs text-white/80">{v.hashtags.map((h) => `#${h}`).join(' ')}</p> : null}
        {p.products.length ? (
          <ul className="flex gap-2 overflow-x-auto pb-1">
            {p.products.map((pr, i) => {
              const id = v.productIds[i];
              const ok = !!pr && pr.status === 'approved' && pr.stock > 0;
              return (
                <li key={id} className="flex w-60 shrink-0 items-center gap-2 rounded-xl bg-white/95 p-2 text-navy-900">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  {pr?.images[0] ? <img src={pr.images[0]} alt="" loading="lazy" className="h-12 w-12 shrink-0 rounded-lg object-cover" /> : <div className="h-12 w-12 shrink-0 rounded-lg bg-navy-100" />}
                  <div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold">{pr?.title ?? 'Product unavailable'}</p><p className="text-xs">{pr && ok ? formatMoney(pr.price) : pr ? 'Out of stock' : 'No longer available'}</p></div>
                  {pr ? <Link href={`/product/${id}`} className={`min-h-9 shrink-0 rounded-lg px-3 py-2 text-xs font-bold text-white ${ok ? 'bg-brand-orange' : 'bg-navy-500'}`}>{ok ? 'Shop Now' : 'View'}</Link> : null}
                </li>
              );
            })}
          </ul>
        ) : null}
        {!user ? <p className="text-[11px] text-white/70">Sign in to like, save, comment and follow.</p> : null}
      </div>
    </section>
  );
}
