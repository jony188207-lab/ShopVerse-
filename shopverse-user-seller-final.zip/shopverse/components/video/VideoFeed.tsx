'use client';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { CommentsSheet } from './CommentsSheet';
import { VideoSlide, type SlideSocial } from './VideoSlide';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { follow, getStoresMap, unfollow } from '@/services/storeService';
import { getProductsByIds } from '@/services/productService';
import { getVideo, loadMyFlags, loadMyFollows, makeSource, recordView, setFlag, type FeedSource } from '@/services/videoService';
import { FEED_TABS, type FeedTab, type Video } from '@/types/video';
import type { Product, Store } from '@/types';

export function VideoFeed({ initialId }: { initialId?: string } = {}) {
  const { user, role } = useAuth(); const toast = useToast(); const router = useRouter(); const sp = useSearchParams();
  const [tab, setTab] = useState<FeedTab>('for-you');
  const [videos, setVideos] = useState<Video[]>([]); const [loading, setLoading] = useState(true); const [done, setDone] = useState(false); const [error, setError] = useState('');
  const [active, setActive] = useState(0); const [muted, setMuted] = useState(true); const [commentsFor, setCommentsFor] = useState<string | null>(null);
  const [stores, setStores] = useState<Map<string, Store>>(new Map()); const [products, setProducts] = useState<Map<string, Product | null>>(new Map());
  const [likes, setLikes] = useState<Set<string>>(new Set()); const [saves, setSaves] = useState<Set<string>>(new Set()); const [follows, setFollows] = useState<Set<string>>(new Set());
  const [delta, setDelta] = useState<Record<string, { like: number; comment: number }>>({});
  const source = useRef<FeedSource | null>(null); const busy = useRef(false); const loadedMeta = useRef(new Set<string>());
  const scroller = useRef<HTMLDivElement | null>(null);
  const deep = initialId ?? sp.get('v');

  const loadMore = useCallback(async () => {
    if (busy.current || !source.current) return;
    busy.current = true; setLoading(true); setError('');
    try {
      const r = await source.current.next();
      setVideos((cur) => { const seen = new Set(cur.map((v) => v.id)); return [...cur, ...r.items.filter((v) => !seen.has(v.id))]; });
      setDone(r.done);
    } catch (e) { setError(friendlyError(e)); setDone(true); } finally { busy.current = false; setLoading(false); }
  }, []);

  useEffect(() => {   // (re)start the feed whenever the tab or the signed-in user changes
    source.current = makeSource(tab, user?.uid ?? null); busy.current = false; loadedMeta.current = new Set();
    setVideos([]); setDone(false); setActive(0); setCommentsFor(null); scroller.current?.scrollTo({ top: 0 });
    let cancelled = false;
    (async () => {
      if (deep && tab === 'for-you') { const d = await getVideo(deep); if (!cancelled && d && d.status === 'published') setVideos([d]); }
      if (!cancelled) await loadMore();
    })();
    return () => { cancelled = true; };
  }, [tab, user?.uid, deep, loadMore]);

  // Lazily load store / product / flag data only for videos near the viewport (active ±2).
  useEffect(() => {
    const win = videos.slice(Math.max(0, active - 1), active + 3).filter((v) => !loadedMeta.current.has(v.id));
    if (!win.length) return;
    win.forEach((v) => loadedMeta.current.add(v.id));
    getStoresMap(win.map((v) => v.storeId)).then((m) => setStores((o) => new Map([...o, ...m]))).catch(() => undefined);
    getProductsByIds(win.flatMap((v) => v.productIds)).then((m) => setProducts((o) => new Map([...o, ...m]))).catch(() => undefined);
    if (user) {
      const ids = win.map((v) => v.id);
      loadMyFlags('videoLikes', user.uid, ids).then((s) => setLikes((o) => new Set([...o, ...s]))).catch(() => undefined);
      loadMyFlags('videoSaves', user.uid, ids).then((s) => setSaves((o) => new Set([...o, ...s]))).catch(() => undefined);
      loadMyFollows(user.uid, win.map((v) => v.ownerId)).then((s) => setFollows((o) => new Set([...o, ...s]))).catch(() => undefined);
    }
  }, [videos, active, user]);

  // Which slide is on screen? (IntersectionObserver, 70% visible)
  useEffect(() => {
    const root = scroller.current; if (!root) return;
    const io = new IntersectionObserver((entries) => entries.forEach((e) => { if (e.isIntersecting && e.intersectionRatio >= 0.7) setActive(Number((e.target as HTMLElement).dataset.i)); }), { root, threshold: [0.7] });
    root.querySelectorAll('[data-i]').forEach((n) => io.observe(n));
    return () => io.disconnect();
  }, [videos.length]);
  useEffect(() => { if (!done && !loading && videos.length - active <= 3) void loadMore(); }, [active, videos.length, done, loading, loadMore]);

  const needLogin = () => { toast('Sign in first', 'info'); router.push('/login?next=/video'); };
  const act = async (fn: () => Promise<unknown>) => { try { await fn(); } catch (e) { toast(friendlyError(e), 'error'); } };
  const toggleFlag = (kind: 'videoLikes' | 'videoSaves', v: Video) => {
    if (!user) return needLogin();
    const set = kind === 'videoLikes' ? likes : saves; const setSet = kind === 'videoLikes' ? setLikes : setSaves; const on = !set.has(v.id);
    setSet((o) => { const n = new Set(o); if (on) n.add(v.id); else n.delete(v.id); return n; });
    if (kind === 'videoLikes') setDelta((d) => ({ ...d, [v.id]: { like: (d[v.id]?.like ?? 0) + (on ? 1 : -1), comment: d[v.id]?.comment ?? 0 } }));
    void act(async () => { try { await setFlag(kind, user.uid, v.id, on); } catch (e) { setSet((o) => { const n = new Set(o); if (on) n.delete(v.id); else n.add(v.id); return n; }); throw e; } });
  };
  const toggleFollow = (v: Video) => {
    if (!user) return needLogin();
    const on = !follows.has(v.ownerId);
    setFollows((o) => { const n = new Set(o); if (on) n.add(v.ownerId); else n.delete(v.ownerId); return n; });
    void act(() => (on ? follow(user.uid, v.ownerId) : unfollow(user.uid, v.ownerId)));
  };
  const share = async (v: Video) => {
    const url = `${window.location.origin}/video/${v.id}`;
    try { if (navigator.share) await navigator.share({ title: v.title, url }); else { await navigator.clipboard.writeText(url); toast('Link copied', 'success'); } } catch { /* cancelled */ }
  };
  // Browser/Android back also works because the feed is a normal route; this button goes to the previous page (or Home with no history).
  const goBack = () => { if (window.history.length > 1) router.back(); else router.push('/'); };
  const empty = !loading && !videos.length;
  const slideSocial = useMemo(() => (v: Video): SlideSocial => ({ liked: likes.has(v.id), saved: saves.has(v.id), following: follows.has(v.ownerId), likeDelta: delta[v.id]?.like ?? 0, commentDelta: delta[v.id]?.comment ?? 0 }), [likes, saves, follows, delta]);

  return (
    <div className="fixed inset-0 z-[60] flex h-[100dvh] w-screen flex-col bg-black" role="region" aria-label="Video feed">
      <div className="absolute inset-x-0 top-0 z-30 flex items-center gap-1 bg-gradient-to-b from-black/70 to-transparent px-2 pl-[max(0.5rem,env(safe-area-inset-left))] pr-[max(0.5rem,env(safe-area-inset-right))] pt-[calc(env(safe-area-inset-top)+0.25rem)] text-white">
        <button type="button" onClick={goBack} aria-label="Back" className="flex min-h-11 shrink-0 items-center gap-1 rounded-full bg-black/40 px-3 text-sm font-semibold backdrop-blur"><span aria-hidden>←</span> Back</button>
        <nav aria-label="Video feed" className="flex flex-1 overflow-x-auto"><ul className="mx-auto flex">{FEED_TABS.map((t) => (
          <li key={t.id}><button onClick={() => setTab(t.id)} aria-current={tab === t.id ? 'page' : undefined} className={`min-h-11 whitespace-nowrap px-3 text-sm ${tab === t.id ? 'border-b-2 border-brand-orange font-bold' : 'text-white/70'}`}>{t.label}</button></li>
        ))}</ul></nav>
        {role === 'seller' ? <Link href="/video/upload" className="min-h-11 px-2 py-3 text-xs font-semibold">Upload</Link> : user ? <Link href="/video/saved" className="min-h-11 px-2 py-3 text-xs font-semibold">Saved</Link> : null}
      </div>
      <div ref={scroller} className="h-full snap-y snap-mandatory overflow-y-scroll overscroll-contain" tabIndex={0} aria-label="Videos">
        {videos.map((v, i) => (
          <div key={v.id} data-i={i} className="h-full w-full snap-start">
            <VideoSlide video={v} store={stores.get(v.storeId) ?? null} products={v.productIds.map((id) => products.get(id) ?? null)} social={slideSocial(v)} active={i === active} near={i === active + 1} muted={muted} own={user?.uid === v.ownerId}
              onToggleMute={() => setMuted((m) => !m)} onLike={() => toggleFlag('videoLikes', v)} onSave={() => toggleFlag('videoSaves', v)} onFollow={() => toggleFollow(v)} onComments={() => setCommentsFor(v.id)} onShare={() => share(v)} onViewed={() => user && void recordView(user.uid, v.id)} />
          </div>
        ))}
        {loading && videos.length ? <div className="grid h-24 place-items-center text-sm text-white">Loading…</div> : null}
        {empty ? (
          <div className="grid h-full place-items-center p-6 text-center text-white">
            {error ? <div role="alert"><p className="font-bold">Could not load videos</p><p className="text-sm">{error}</p><button className="mt-3 rounded-xl bg-brand-orange px-4 py-2 font-semibold" onClick={() => { source.current = makeSource(tab, user?.uid ?? null); setDone(false); void loadMore(); }}>Try again</button></div>
              : tab === 'following' ? <div><p className="font-bold">{user ? 'Nothing from creators you follow yet' : 'Sign in to see creators you follow'}</p><p className="text-sm text-white/70">Follow a seller from any video or store page.</p>{!user ? <Link href="/login?next=/video" className="mt-3 inline-block rounded-xl bg-brand-orange px-4 py-2 font-semibold">Sign in</Link> : null}</div>
              : <div><p className="font-bold">No videos here yet</p><p className="text-sm text-white/70">Approved seller videos will appear here.</p></div>}
          </div>
        ) : null}
        {loading && !videos.length ? <div className="grid h-full place-items-center text-white" role="status">Loading videos…</div> : null}
      </div>
      {commentsFor ? <CommentsSheet videoId={commentsFor} onClose={() => setCommentsFor(null)} onDelta={(n) => setDelta((d) => ({ ...d, [commentsFor]: { like: d[commentsFor]?.like ?? 0, comment: (d[commentsFor]?.comment ?? 0) + n } }))} /> : null}
    </div>
  );
}
