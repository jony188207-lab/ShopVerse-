'use client';
import Link from 'next/link';
import { useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import { ReportButton } from '@/components/ReportButton';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/hooks/useAuth';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { addComment, deleteComment, listComments } from '@/services/videoService';
import type { VideoComment } from '@/types/video';

export function CommentsSheet({ videoId, onClose, onDelta }: { videoId: string; onClose: () => void; onDelta: (n: number) => void }) {
  const { user } = useAuth(); const toast = useToast();
  const { items, setItems, more, error, busy, loadMore } = usePaged((c) => listComments(videoId, c), [videoId]);
  const [text, setText] = useState(''); const [sending, setSending] = useState(false);
  const send = async (e: FormEvent) => {
    e.preventDefault(); if (!user) return;
    setSending(true);
    try {
      const id = await addComment(user.uid, user.displayName ?? 'Shopper', videoId, text);
      const mine: VideoComment = { id, videoId, userId: user.uid, userName: user.displayName ?? 'Shopper', text: text.trim(), status: 'visible', createdAt: new Date() };
      setItems((l) => [mine, ...(l ?? [])]); onDelta(1); setText('');
    } catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setSending(false); }
  };
  const remove = async (c: VideoComment) => { try { await deleteComment(c.id); setItems((l) => l?.filter((x) => x.id !== c.id) ?? null); onDelta(-1); } catch (x) { toast(friendlyError(x), 'error'); } };
  return (
    <div role="dialog" aria-label="Comments" className="absolute inset-x-0 bottom-0 z-20 flex max-h-[75%] flex-col rounded-t-2xl bg-white text-navy-900 shadow-2xl dark:bg-navy-900 dark:text-white">
      <div className="flex items-center justify-between border-b border-navy-100 p-3 dark:border-navy-500"><h2 className="font-bold">Comments</h2><button onClick={onClose} aria-label="Close comments" className="grid h-11 w-11 place-items-center"><X className="h-5 w-5" /></button></div>
      <div className="min-h-24 flex-1 overflow-y-auto p-3">
        {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : items === null ? <p className="text-sm">Loading…</p> : !items.length ? <p className="py-6 text-center text-sm">No comments yet. Be the first.</p> : (
          <ul className="space-y-3">{items.map((c) => (
            <li key={c.id} className="text-sm"><p><strong>{c.userName}</strong> <span className="text-xs text-navy-500 dark:text-navy-100">{c.createdAt?.toLocaleDateString()}</span></p><p className="break-words">{c.text}</p>
              <div className="flex gap-1">{c.userId === user?.uid ? <button onClick={() => remove(c)} className="min-h-11 px-2 text-xs text-red-600">Delete</button> : <ReportButton targetType="comment" targetId={c.id} label="Report" />}</div></li>
          ))}</ul>
        )}
        {more ? <Button variant="ghost" loading={busy} onClick={loadMore}>Load more</Button> : null}
      </div>
      {user ? (user.emailVerified ? (
        <form onSubmit={send} className="flex gap-2 border-t border-navy-100 p-3 dark:border-navy-500">
          <input value={text} onChange={(e) => setText(e.target.value)} maxLength={500} placeholder="Add a comment…" aria-label="Add a comment" className="min-h-11 min-w-0 flex-1 rounded-xl border border-navy-100 bg-white px-3 dark:border-navy-500 dark:bg-navy-700" />
          <Button type="submit" loading={sending} disabled={!text.trim()}>Post</Button>
        </form>
      ) : <p className="border-t border-navy-100 p-3 text-sm dark:border-navy-500"><Link className="underline" href="/verify-email">Verify your email</Link> to comment.</p>
      ) : <p className="border-t border-navy-100 p-3 text-sm dark:border-navy-500"><Link className="underline" href="/login?next=/video">Sign in</Link> to comment.</p>}
    </div>
  );
}
