'use client';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/Button';

interface BIPEvent extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> }

/** "Install app": native prompt where the browser offers it (Chrome/Edge/Android); Add-to-Home-Screen steps on iOS Safari. Hidden once installed. */
export function InstallPrompt() {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [ios, setIos] = useState(false);
  useEffect(() => {
    const standalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
    setInstalled(standalone);
    setIos(/iPhone|iPad|iPod/.test(navigator.userAgent) && !standalone);
    const onPrompt = (e: Event) => { e.preventDefault(); setEvt(e as BIPEvent); };
    const onInstalled = () => { setInstalled(true); setEvt(null); };
    window.addEventListener('beforeinstallprompt', onPrompt); window.addEventListener('appinstalled', onInstalled);
    return () => { window.removeEventListener('beforeinstallprompt', onPrompt); window.removeEventListener('appinstalled', onInstalled); };
  }, []);
  if (installed) return null;
  if (evt) return <Button variant="secondary" onClick={async () => { await evt.prompt(); await evt.userChoice.catch(() => undefined); setEvt(null); }}>Install ShopVerse app</Button>;
  if (ios) return <p className="text-sm">To install: tap <strong>Share</strong>, then <strong>Add to Home Screen</strong>.</p>;
  return null;
}
