'use client';
import { useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { isFirebaseConfigured } from '@/lib/firebase/config';
import { onForegroundMessage } from '@/lib/firebase/messaging';
import { getPrefs } from '@/services/notificationPrefsService';
import { syncPushToken } from '@/services/pushService';

/**
 * Mounted once. While signed in: (1) refresh this device's token if permission was already granted (respecting the push switch),
 * (2) show pushes that arrive while the app is open as a toast (the service worker handles background ones).
 */
export function FcmBridge() {
  const { user } = useAuth(); const toast = useToast();
  useEffect(() => {
    if (!user || !isFirebaseConfigured) return;
    let off: (() => void) | undefined; let cancelled = false;
    (async () => {
      const prefs = await getPrefs(user.uid).catch(() => ({ push: true }));
      if (prefs.push !== false) await syncPushToken(user.uid);
      const unsub = await onForegroundMessage((p) => {
        const d = p.data ?? {};
        toast(`${d.title ?? 'ShopVerse'}${d.body ? `: ${d.body}` : ''}`, 'info');
      });
      if (cancelled) unsub(); else off = unsub;
    })();
    return () => { cancelled = true; off?.(); };
  }, [user, toast]);
  return null;
}
