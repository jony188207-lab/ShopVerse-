'use client';
import { useState, type FormEvent } from 'react';
import { Button } from './ui/Button';
import { Field } from './ui/Field';
import type { AddressInput } from '@/types';

const EMPTY: AddressInput = { fullName: '', phone: '', country: '', city: '', area: '', address: '', postalCode: '', instructions: '' };

export function AddressForm({ initial, initialDefault = false, onSubmit, onCancel }: {
  initial?: AddressInput; initialDefault?: boolean; onSubmit: (v: AddressInput, makeDefault: boolean) => Promise<void>; onCancel?: () => void;
}) {
  const [v, setV] = useState<AddressInput>(initial ?? EMPTY);
  const [def, setDef] = useState(initialDefault);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const set = (k: keyof AddressInput) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setV({ ...v, [k]: e.target.value });

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setError(''); setBusy(true);
    try { await onSubmit({ ...v, fullName: v.fullName.trim(), address: v.address.trim() }, def); } catch (err) { setError(err instanceof Error ? err.message : 'Could not save the address.'); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Field label="Full name" autoComplete="name" required minLength={2} maxLength={100} value={v.fullName} onChange={set('fullName')} />
      <Field label="Phone" type="tel" autoComplete="tel" required minLength={5} maxLength={40} value={v.phone} onChange={set('phone')} />
      <div className="grid grid-cols-2 gap-3">
        <Field label="Country" autoComplete="country-name" required maxLength={80} value={v.country} onChange={set('country')} />
        <Field label="City" autoComplete="address-level2" required maxLength={80} value={v.city} onChange={set('city')} />
      </div>
      <Field label="Area / district" maxLength={80} value={v.area} onChange={set('area')} />
      <Field label="Street address" autoComplete="street-address" required minLength={3} maxLength={300} value={v.address} onChange={set('address')} />
      <Field label="Postal code" autoComplete="postal-code" maxLength={20} value={v.postalCode} onChange={set('postalCode')} />
      <div className="space-y-1">
        <label htmlFor="instr" className="text-sm font-medium">Delivery instructions (optional)</label>
        <textarea id="instr" maxLength={300} rows={2} value={v.instructions} onChange={set('instructions')} className="w-full rounded-xl border border-navy-100 bg-white p-3 text-base text-navy-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-purple dark:border-navy-500 dark:bg-navy-900 dark:text-white" />
      </div>
      <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={def} onChange={(e) => setDef(e.target.checked)} className="h-5 w-5" />Use as my default address</label>
      {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
      <div className="flex gap-2"><Button type="submit" loading={busy}>Save address</Button>{onCancel ? <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button> : null}</div>
    </form>
  );
}
