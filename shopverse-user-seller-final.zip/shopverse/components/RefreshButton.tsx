'use client';
export function RefreshButton() {
  return <button onClick={() => window.location.reload()} className="min-h-11 rounded-xl bg-brand-orange px-5 text-sm font-semibold text-white">Try again</button>;
}
