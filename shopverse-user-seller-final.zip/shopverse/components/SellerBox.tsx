'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { follow, isFollowing, unfollow } from '@/services/storeService';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { StarRating } from './StarRating';
import { Button } from './ui/Button';
import { Card } from './ui/Card';
import type { Store } from '@/types';

export function SellerBox({ store, productId }: { store: Store; productId?: string }) {
  const { user } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const [following, setFollowing] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const own = user?.uid === store.ownerId;

  useEffect(() => { if (user && !own) isFollowing(user.uid, store.ownerId).then(setFollowing).catch(() => setFollowing(false)); else setFollowing(false); }, [user, own, store.ownerId]);

  const toggle = async () => {
    if (!user) return router.push(`/login?next=${encodeURIComponent(window.location.pathname)}`);
    setBusy(true);
    try { if (following) await unfollow(user.uid, store.ownerId); else await follow(user.uid, store.ownerId); setFollowing(!following); toast(following ? 'Unfollowed' : 'Following store', 'success'); }
    catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  return (
    <Card className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-900">{store.logoUrl ? <Image src={store.logoUrl} alt="" fill sizes="56px" className="object-cover" /> : null}</div>
        <div className="min-w-0"><p className="truncate font-bold">{store.name}</p><StarRating value={store.ratingAvg} count={store.ratingCount} size={13} /></div>
      </div>
      <div className="flex flex-wrap gap-2">
        <Link href={`/store/${store.slug}`} className="inline-flex min-h-11 items-center rounded-xl bg-navy-900 px-4 text-sm font-semibold text-white dark:bg-white dark:text-navy-900">Visit store</Link>
        {!own ? <Button variant="ghost" className="border border-navy-100 dark:border-navy-500" loading={busy} disabled={following === null} onClick={toggle}>{following ? 'Following' : 'Follow'}</Button> : null}
        {!own ? <Link href={user ? `/messages/new?store=${store.id}${productId ? `&product=${productId}` : ''}` : `/login?next=${encodeURIComponent(`/messages/new?store=${store.id}${productId ? `&product=${productId}` : ''}`)}`} className="inline-flex min-h-11 items-center rounded-xl border border-navy-100 px-4 text-sm font-semibold dark:border-navy-500">Message seller</Link> : null}
      </div>
    </Card>
  );
}
