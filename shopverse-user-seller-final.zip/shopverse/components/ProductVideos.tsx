'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { productVideosSource } from '@/services/videoService';
import type { Video } from '@/types/video';

/** Videos that feature this product (published + public only). One small paginated query (8) — hidden when there are none. */
export function ProductVideos({ productId }: { productId: string }) {
  const [v, setV] = useState<Video[]>([]);
  useEffect(() => { productVideosSource(productId, 8).next().then((r) => setV(r.items)).catch(() => setV([])); }, [productId]);
  if (!v.length) return null;
  return (
    <section aria-labelledby="pv" className="space-y-2 px-4">
      <h2 id="pv" className="text-lg font-bold">Watch this product</h2>
      <ul className="flex gap-3 overflow-x-auto pb-2">{v.map((x) => (
        <li key={x.id} className="w-28 shrink-0"><Link href={`/video?v=${x.id}`} className="block space-y-1">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {x.thumbnailUrl ? <img src={x.thumbnailUrl} alt="" loading="lazy" className="aspect-[9/16] w-full rounded-card object-cover" /> : <div className="aspect-[9/16] w-full rounded-card bg-navy-100" />}
          <p className="line-clamp-2 text-xs font-semibold">{x.title}</p></Link></li>))}</ul>
    </section>
  );
}
