'use client';
import Link from 'next/link';
import { MessageSquare } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useUnreadMessages } from '@/hooks/useUnreadMessages';

export function MessagesLink() {
  const { user } = useAuth();
  const n = useUnreadMessages();
  if (!user) return null;
  return (
    <Link href="/messages" aria-label={n ? `Messages, ${n} unread` : 'Messages'} className="relative grid h-11 w-11 place-items-center rounded-xl hover:bg-navy-50 dark:hover:bg-navy-700">
      <MessageSquare className="h-5 w-5" aria-hidden />
      {n ? <span className="absolute right-1.5 top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-brand-orange px-1 text-[10px] font-bold text-white">{n > 9 ? '9+' : n}</span> : null}
    </Link>
  );
}
