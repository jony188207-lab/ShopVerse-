'use client';
import { useState } from 'react';
import { enablePush, type PushResult } from '@/services/pushService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';

const MSG: Record<PushResult, string> = {
  enabled: 'Push is on for this device.',
  denied: 'Notifications are blocked. Allow them in your browser site settings, then try again.',
  unsupported: 'This browser does not support push notifications.',
  'missing-vapid': 'Push is not configured on this site yet.',
};
export function NotificationToggle({ uid }: { uid: string }) {
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState('');
  const run = async () => { setBusy(true); try { setMsg(MSG[await enablePush(uid)]); } catch (e) { setMsg(friendlyError(e)); } finally { setBusy(false); } };
  return <div className="space-y-2"><Button variant="secondary" onClick={run} loading={busy}>Turn on push on this device</Button>{msg ? <p role="status" className="text-sm">{msg}</p> : null}</div>;
}
