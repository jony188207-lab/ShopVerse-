import type { ReactNode } from 'react';
import { Card } from '@/components/ui/Card';

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return <Card className="space-y-1"><p className="text-xs font-medium text-navy-500 dark:text-navy-100">{label}</p><p className="text-2xl font-extrabold">{value}</p>{hint ? <p className="text-xs text-navy-500 dark:text-navy-100">{hint}</p> : null}</Card>;
}
export function PageHead({ title, children }: { title: string; children?: ReactNode }) {
  return <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h1 className="text-2xl font-extrabold">{title}</h1>{children}</div>;
}
const TONE: Record<string, string> = { green: 'bg-green-100 text-green-800', amber: 'bg-amber-100 text-amber-800', red: 'bg-red-100 text-red-800', gray: 'bg-navy-100 text-navy-700', purple: 'bg-purple-100 text-purple-800' };
const MAP: Record<string, string> = {
  approved: 'green', delivered: 'green', completed: 'green', available: 'green', published: 'green', pending: 'amber', pending_review: 'amber', processing: 'amber', confirmed: 'purple', shipped: 'purple', out_for_delivery: 'purple',
  rejected: 'red', cancelled: 'red', suspended: 'red', reversed: 'red', return_requested: 'amber', returned: 'gray', refunded: 'gray', draft: 'gray', out_of_stock: 'gray', ended: 'gray',
};
export function Pill({ status, label }: { status: string; label?: string }) {
  return <span className={`inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${TONE[MAP[status] ?? 'gray']}`}>{label ?? status.replace(/_/g, ' ')}</span>;
}
export const fmtDate = (d: Date | null) => (d ? d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—');
export const selectCls = 'min-h-11 rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900';
export const textareaCls = 'w-full rounded-xl border border-navy-100 bg-white p-3 text-base text-navy-900 dark:border-navy-500 dark:bg-navy-900 dark:text-white';
