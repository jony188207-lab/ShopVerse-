'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { DESKTOP_NAV } from '@/config/nav';
import { SITE } from '@/config/site';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import { SearchBar } from './SearchBar';
import { ThemeToggle } from './ThemeToggle';
import { NotificationBell } from './NotificationBell';
import { MessagesLink } from './MessagesLink';

export function Header() {
  const pathname = usePathname();
  const { user, role, loading } = useAuth();
  const { count } = useCart();
  const extra = [
    ...(role === 'seller' ? [{ href: '/seller', label: 'Seller Center' }] : []),
    ...(['moderator', 'admin', 'super_admin'].includes(role) ? [{ href: '/admin', label: 'Admin' }] : []),
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-navy-100 bg-white/95 pt-[env(safe-area-inset-top)] backdrop-blur dark:border-navy-500 dark:bg-navy-900/95">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-2">
        <Link href="/" className="flex shrink-0 flex-col leading-none" aria-label={`${SITE.name} home`}>
          <span className="text-xl font-extrabold tracking-tight text-navy-900 dark:text-white">Shop<span className="text-brand-orange">Verse</span></span>
          <span className="text-[11px] font-medium text-brand-purple">{SITE.tagline}</span>
        </Link>
        <nav aria-label="Primary" className="ml-4 hidden items-center gap-1 md:flex">
          {[...DESKTOP_NAV, ...extra].map((n) => {
            const active = n.href === '/' ? pathname === '/' : pathname.startsWith(n.href);
            return (
              <Link key={n.href} href={n.href} aria-current={active ? 'page' : undefined}
                className={`rounded-lg px-3 py-2 text-sm font-medium ${active ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'hover:bg-navy-50 dark:hover:bg-navy-700'}`}>
                {n.label}{n.href === '/cart' && count > 0 ? <span className="ml-1 rounded-full bg-brand-orange px-1.5 text-xs font-bold text-white">{count}</span> : null}
              </Link>
            );
          })}
        </nav>
        <SearchBar className="ml-auto hidden w-64 md:block lg:w-80" />
        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <MessagesLink />
          <NotificationBell />
          <ThemeToggle />
          {loading ? <span className="h-11 w-20" aria-hidden /> : !user ? <Link href="/login" className="rounded-xl bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white">Sign in</Link> : null}
        </div>
      </div>
      <div className="px-4 pb-2 md:hidden"><SearchBar /></div>
    </header>
  );
}
