'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { MOBILE_NAV } from '@/config/nav';
import { useCart } from '@/hooks/useCart';

/** Fixed mobile nav. Height is exposed as --bottom-nav-h so the page footer/ad slot can reserve exactly this space. */
export function BottomNav() {
  const pathname = usePathname();
  const { count } = useCart();
  return (
    <nav aria-label="Primary mobile" className="fixed inset-x-0 bottom-0 z-50 border-t border-navy-100 bg-white pb-[env(safe-area-inset-bottom)] dark:border-navy-500 dark:bg-navy-900 md:hidden">
      <ul className="grid h-[var(--bottom-nav-h)] grid-cols-5">
        {MOBILE_NAV.map(({ href, label, icon: Icon }) => {
          const active = href === '/' ? pathname === '/' : pathname.startsWith(href);
          return (
            <li key={href}>
              <Link href={href} aria-current={active ? 'page' : undefined}
                className={`flex h-full flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${active ? 'text-brand-orange' : 'text-navy-500 dark:text-navy-100'}`}>
                <span className="relative"><Icon className="h-5 w-5" aria-hidden />{href === '/cart' && count > 0 ? <span className="absolute -right-2 -top-1.5 min-w-4 rounded-full bg-brand-orange px-1 text-center text-[10px] font-bold leading-4 text-white" aria-label={`${count} items in cart`}>{count > 99 ? '99+' : count}</span> : null}</span>
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
