'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { listAllProducts, setProductStatus } from '@/services/adminService';
import { friendlyError } from '@/lib/firebase/errors';
import { formatMoney } from '@/utils/money';
import { Button } from '@/components/ui/Button';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { PRODUCT_STATUS_LABEL, type Product, type ProductStatus } from '@/types';

export function ProductAdmin() {
  const { user, role } = useAuth(); const toast = useToast();
  const [items, setItems] = useState<Product[] | null>(null);
  const [cursor, setCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [more, setMore] = useState(false);
  const [filter, setFilter] = useState<ProductStatus | ''>('');
  const load = useCallback(async (cur: QueryDocumentSnapshot | null) => {
    try { const p = await listAllProducts(cur, filter || undefined); setItems((x) => (cur ? [...(x ?? []), ...p.items] : p.items)); setCursor(p.cursor); setMore(p.hasMore); }
    catch (e) { toast(friendlyError(e), 'error'); setItems((x) => x ?? []); }
  }, [filter, toast]);
  useEffect(() => { setItems(null); void load(null); }, [load]);
  const act = async (p: Product, s: ProductStatus) => {
    if (!user) return;
    let note = '';
    if (s === 'rejected' || s === 'suspended') { const r = window.prompt(`Reason for ${s === 'rejected' ? 'rejecting' : 'suspending'} “${p.title}” (the seller will see this):`); if (!r || r.trim().length < 5) return toast('A reason of at least 5 characters is required', 'error'); note = r.trim(); }
    try { await setProductStatus(user.uid, p.id, s, note); setItems((x) => x?.map((i) => (i.id === p.id ? { ...i, status: s } : i)) ?? null); toast(`Marked ${PRODUCT_STATUS_LABEL[s].toLowerCase()}`, 'success'); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2"><h1 className="text-2xl font-extrabold">Products</h1>
        {['admin', 'super_admin'].includes(role) ? <Link href="/admin/products/new" className="inline-flex min-h-11 items-center rounded-xl bg-brand-orange px-4 text-sm font-semibold text-white">Add product</Link> : null}</div>
      <label className="block text-sm font-medium">Status<select value={filter} onChange={(e) => setFilter(e.target.value as ProductStatus | '')} className="ml-2 min-h-11 rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900"><option value="">All</option>{Object.entries(PRODUCT_STATUS_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
      {items === null ? <LoadingState /> : !items.length ? <EmptyState title="No products">Nothing matches this filter yet.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1"><p className="truncate font-semibold">{p.title}</p><p className="text-xs">{formatMoney(p.price)} · stock {p.stock} · {PRODUCT_STATUS_LABEL[p.status]}</p></div>
              <div className="flex flex-wrap gap-1">
                {p.status !== 'approved' && p.status !== 'out_of_stock' ? <Button variant="ghost" onClick={() => act(p, 'approved')}>{p.status === 'suspended' ? 'Restore' : 'Approve'}</Button> : null}
                {p.status !== 'rejected' ? <Button variant="ghost" onClick={() => act(p, 'rejected')}>Reject</Button> : null}
                {p.status !== 'suspended' ? <Button variant="ghost" onClick={() => act(p, 'suspended')}>Suspend</Button> : null}
                {['admin', 'super_admin'].includes(role) ? <Link href={`/admin/products/${p.id}`} className="inline-flex min-h-11 items-center rounded-xl px-4 text-sm font-semibold underline">Edit</Link> : null}
              </div>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" onClick={() => load(cursor)}>Load more</Button> : null}
    </div>
  );
}
