'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { listStores, saveProduct, type ProductForm as F } from '@/services/adminService';
import { useCategories } from '@/hooks/useCategories';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';
import { LoadingState } from '@/components/ui/States';
import { PRODUCT_STATUS_LABEL, type Product, type ProductStatus, type Store } from '@/types';

const toLocal = (d: Date | null) => (d ? new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '');
const init = (p: Product | null, storeId: string): F => ({
  storeId: p?.storeId ?? storeId, title: p?.title ?? '', brand: p?.brand ?? '', categoryId: p?.categoryId ?? '', subcategoryId: p?.subcategoryId ?? '', description: p?.description ?? '',
  price: p?.price ?? 0, originalPrice: p && p.originalPrice > p.price ? p.originalPrice : null, stock: p?.stock ?? 0, sku: p?.sku ?? '', weight: p?.weight ?? '',
  specsText: p?.specs.map((s) => `${s.label}: ${s.value}`).join('\n') ?? '', variantsText: p?.variants.map((v) => `${v.label} | ${v.stock}${v.price ? ` | ${v.price}` : ''}`).join('\n') ?? '',
  shippingInfo: p?.shippingInfo ?? '', returnPolicy: p?.returnPolicy ?? '', featured: p?.featured ?? false, flashSaleEndsAt: toLocal(p?.flashSaleEndsAt ?? null), status: p?.status ?? 'approved',
});

export function ProductForm({ existing }: { existing: Product | null }) {
  const { user } = useAuth(); const toast = useToast(); const router = useRouter();
  const { categories } = useCategories();
  const [stores, setStores] = useState<Store[] | null>(null);
  const [f, setF] = useState<F>(() => init(existing, ''));
  const [images, setImages] = useState<File[]>([]);
  const [video, setVideo] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { listStores().then((s) => { setStores(s); setF((x) => (x.storeId ? x : { ...x, storeId: s[0]?.id ?? '' })); }).catch(() => setStores([])); }, []);
  if (stores === null) return <LoadingState />;
  if (!stores.length) return <p className="rounded-card border border-dashed p-4 text-sm">Create a store first (Admin → Stores); every product belongs to a store.</p>;
  const set = <K extends keyof F>(k: K, v: F[K]) => setF((x) => ({ ...x, [k]: v }));
  const text = (k: keyof F) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => set(k, e.target.value as never);
  const hasVariants = f.variantsText.trim().length > 0;

  const submit = async (e: FormEvent) => {
    e.preventDefault(); if (!user) return;
    const store = stores.find((s) => s.id === f.storeId);
    if (!store) return toast('Choose a store', 'error');
    setBusy(true);
    try { const id = await saveProduct(user.uid, existing, f, store, images, video); toast('Product saved', 'success'); router.push(`/product/${id}`); }
    catch (err) { toast(err instanceof Error && !('code' in err) ? err.message : friendlyError(err), 'error'); } finally { setBusy(false); }
  };
  const ta = 'w-full rounded-xl border border-navy-100 bg-white p-3 text-base text-navy-900 dark:border-navy-500 dark:bg-navy-900 dark:text-white';
  const sel = 'mt-1 min-h-11 w-full rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900';
  return (
    <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
      <label className="text-sm font-medium">Store<select value={f.storeId} onChange={text('storeId')} disabled={!!existing} className={sel}>{stores.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
      <label className="text-sm font-medium">Status<select value={f.status} onChange={(e) => set('status', e.target.value as ProductStatus)} className={sel}>{Object.entries(PRODUCT_STATUS_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
      <div className="md:col-span-2"><Field label="Title" required minLength={2} maxLength={200} value={f.title} onChange={text('title')} /></div>
      <Field label="Brand" value={f.brand} onChange={text('brand')} />
      <label className="text-sm font-medium">Category<select required value={f.categoryId} onChange={text('categoryId')} className={sel}><option value="">Choose…</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <Field label="Subcategory (optional)" value={f.subcategoryId} onChange={text('subcategoryId')} />
      <Field label="SKU" value={f.sku} onChange={text('sku')} />
      <Field label="Price" type="number" required min={0.01} step="0.01" value={f.price || ''} onChange={(e) => set('price', Number(e.target.value))} />
      <Field label="Original price (for discount, optional)" type="number" min={0} step="0.01" value={f.originalPrice ?? ''} onChange={(e) => set('originalPrice', e.target.value === '' ? null : Number(e.target.value))} />
      <Field label={hasVariants ? 'Stock (sum of options)' : 'Stock'} type="number" min={0} step={1} disabled={hasVariants} value={hasVariants ? '' : f.stock} onChange={(e) => set('stock', Math.max(0, Math.floor(Number(e.target.value))))} />
      <Field label="Weight (optional)" value={f.weight} onChange={text('weight')} />
      <div className="md:col-span-2"><label className="text-sm font-medium" htmlFor="desc">Description</label><textarea id="desc" rows={5} value={f.description} onChange={text('description')} className={ta} /></div>
      <div><label className="text-sm font-medium" htmlFor="specs">Specifications (one per line: Label: value)</label><textarea id="specs" rows={4} value={f.specsText} onChange={text('specsText')} className={ta} /></div>
      <div><label className="text-sm font-medium" htmlFor="vars">Options (one per line: Label | stock | optional price)</label><textarea id="vars" rows={4} value={f.variantsText} onChange={text('variantsText')} className={ta} placeholder="Red / M | 10&#10;Blue / L | 4 | 24.99" /></div>
      <Field label="Shipping info (optional, overrides store)" value={f.shippingInfo} onChange={text('shippingInfo')} />
      <Field label="Return policy (optional, overrides store)" value={f.returnPolicy} onChange={text('returnPolicy')} />
      <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={f.featured} onChange={(e) => set('featured', e.target.checked)} />Featured on Home</label>
      <Field label="Flash sale ends (optional)" type="datetime-local" value={f.flashSaleEndsAt} onChange={text('flashSaleEndsAt')} />
      <div><label className="text-sm font-medium" htmlFor="imgs">Add images (max 8 at a time, 10 MB each){existing ? ` · ${existing.images.length} saved` : ''}</label><input id="imgs" type="file" multiple accept="image/jpeg,image/png,image/webp" onChange={(e) => setImages(Array.from(e.target.files ?? []))} className="block text-sm" /></div>
      <div><label className="text-sm font-medium" htmlFor="vid">Product video (MP4/WebM, max 100 MB)</label><input id="vid" type="file" accept="video/mp4,video/webm,video/quicktime" onChange={(e) => setVideo(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
      <div className="md:col-span-2"><Button type="submit" loading={busy}>{existing ? 'Save changes' : 'Create product'}</Button></div>
    </form>
  );
}
