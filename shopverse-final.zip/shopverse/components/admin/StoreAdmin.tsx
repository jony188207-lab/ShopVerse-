'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { createStore, listStores } from '@/services/adminService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, LoadingState } from '@/components/ui/States';
import type { Store } from '@/types';

export function StoreAdmin() {
  const { user } = useAuth(); const toast = useToast();
  const [stores, setStores] = useState<Store[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({ ownerId: '', name: '', description: '', city: '', country: '', shippingFee: '0', freeShippingOver: '', returnPolicy: '', shippingInfo: '' });
  const [logo, setLogo] = useState<File | null>(null);
  const load = () => listStores().then(setStores).catch((e) => { toast(friendlyError(e), 'error'); setStores([]); });
  useEffect(() => { void load(); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: FormEvent) => {
    e.preventDefault(); if (!user) return; setBusy(true);
    try {
      await createStore(user.uid, { ...f, shippingFee: Number(f.shippingFee) || 0, freeShippingOver: f.freeShippingOver === '' ? null : Number(f.freeShippingOver) }, logo);
      toast('Store created', 'success'); setF({ ...f, name: '', description: '' }); setLogo(null); await load();
    } catch (err) { toast(err instanceof Error && !('code' in err) ? err.message : friendlyError(err), 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-extrabold">Stores</h1>
      <Card><form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
        <p className="text-sm md:col-span-2">Creates an approved store for a seller account. The full seller application flow arrives in the seller phase; until then admins open stores here.</p>
        <Field label="Owner user ID (Firebase UID)" required value={f.ownerId} onChange={set('ownerId')} />
        <Field label="Store name" required minLength={2} maxLength={80} value={f.name} onChange={set('name')} />
        <Field label="City" value={f.city} onChange={set('city')} /><Field label="Country" value={f.country} onChange={set('country')} />
        <Field label="Shipping fee" type="number" min={0} step="0.01" value={f.shippingFee} onChange={set('shippingFee')} />
        <Field label="Free shipping over (optional)" type="number" min={0} step="0.01" value={f.freeShippingOver} onChange={set('freeShippingOver')} />
        <div className="md:col-span-2"><Field label="Description" value={f.description} onChange={set('description')} /></div>
        <Field label="Shipping information" value={f.shippingInfo} onChange={set('shippingInfo')} /><Field label="Return policy" value={f.returnPolicy} onChange={set('returnPolicy')} />
        <div><label className="text-sm font-medium" htmlFor="logo">Logo</label><input id="logo" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setLogo(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
        <div className="md:col-span-2"><Button type="submit" loading={busy}>Create store</Button></div>
      </form></Card>
      {stores === null ? <LoadingState /> : !stores.length ? <EmptyState title="No stores yet">Create the first store above.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 text-sm dark:divide-navy-500 dark:border-navy-500">
          {stores.map((s) => <li key={s.id} className="flex flex-wrap justify-between gap-2 p-3"><span><strong>{s.name}</strong> · {s.status}</span><span className="break-all text-xs text-navy-500 dark:text-navy-100">store id {s.id} · owner {s.ownerId}</span></li>)}
        </ul>
      )}
    </div>
  );
}
