'use client';
import { useCallback, useEffect, useState } from 'react';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { NEXT_STATUSES, confirmCodRemittance, listAllOrders, setOrderStatus } from '@/services/adminService';
import { friendlyError } from '@/lib/firebase/errors';
import { formatMoney } from '@/utils/money';
import { Button } from '@/components/ui/Button';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { ORDER_STATUS_LABEL, type Order, type OrderStatus } from '@/types';

export function OrderAdmin() {
  const { user } = useAuth(); const toast = useToast();
  const [items, setItems] = useState<Order[] | null>(null);
  const [cursor, setCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [more, setMore] = useState(false);
  const [filter, setFilter] = useState<OrderStatus | ''>('');
  const [busy, setBusy] = useState('');
  const load = useCallback(async (cur: QueryDocumentSnapshot | null) => {
    try { const p = await listAllOrders(cur, filter || undefined); setItems((x) => (cur ? [...(x ?? []), ...p.items] : p.items)); setCursor(p.cursor); setMore(p.hasMore); }
    catch (e) { toast(friendlyError(e), 'error'); setItems((x) => x ?? []); }
  }, [filter, toast]);
  useEffect(() => { setItems(null); void load(null); }, [load]);
  const move = async (o: Order, next: OrderStatus) => {
    if (!user || (next === 'cancelled' && !window.confirm('Cancel this order? Stock will be returned to the shelf.'))) return;
    setBusy(o.id);
    try { await setOrderStatus(user.uid, o, next); setItems((x) => x?.map((i) => (i.id === o.id ? { ...i, status: next } : i)) ?? null); toast(`Order ${o.orderNumber}: ${ORDER_STATUS_LABEL[next]}`, 'success'); }
    catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(''); }
  };
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-extrabold">Orders</h1>
      <label className="block text-sm font-medium">Status
        <select value={filter} onChange={(e) => setFilter(e.target.value as OrderStatus | '')} className="ml-2 min-h-11 rounded-xl border border-navy-100 bg-white px-2 dark:border-navy-500 dark:bg-navy-900">
          <option value="">All</option>{(Object.keys(ORDER_STATUS_LABEL) as OrderStatus[]).map((s) => <option key={s} value={s}>{ORDER_STATUS_LABEL[s]}</option>)}
        </select>
      </label>
      {items === null ? <LoadingState /> : !items.length ? <EmptyState title="No orders">No orders match this filter yet.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((o) => (
            <li key={o.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{o.orderNumber} · {o.storeName}</p>
                <p className="text-xs">{o.createdAt?.toLocaleString() ?? ''} · {o.itemCount} item(s) · {formatMoney(o.total)} · COD · <strong>{ORDER_STATUS_LABEL[o.status]}</strong></p>
                <p className="truncate text-xs">{o.address.fullName}, {o.address.city}</p>
              </div>
              <div className="flex flex-wrap gap-1">
                {o.status === 'delivered' && !o.codRemitted ? <Button variant="secondary" loading={busy === o.id} onClick={async () => { setBusy(o.id); try { await confirmCodRemittance(o.id); setItems((x) => x?.map((i) => (i.id === o.id ? { ...i, codRemitted: true } : i)) ?? null); toast('Cash confirmed — seller earnings can now release', 'success'); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(''); } }}>Confirm cash received</Button> : null}
                {NEXT_STATUSES[o.status].map((n) => <Button key={n} variant={n === 'cancelled' ? 'danger' : 'ghost'} loading={busy === o.id} onClick={() => move(o, n)}>{ORDER_STATUS_LABEL[n]}</Button>)}
              </div>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" onClick={() => load(cursor)}>Load more</Button> : null}
    </div>
  );
}
