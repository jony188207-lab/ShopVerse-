'use client';
import { useEffect, useState, type FormEvent } from 'react';
import Image from 'next/image';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { deleteBanner, listBanners, moveBanner, saveBanner, setBannerActive, type BannerForm } from '@/services/adminService';
import { getProduct, searchProducts } from '@/services/productService';
import { useDebounce } from '@/hooks/useDebounce';
import { friendlyError } from '@/lib/firebase/errors';
import { isLive } from '@/utils/schedule';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { LoadingState } from '@/components/ui/States';
import type { Product, ProductBanner } from '@/types';

const toLocal = (d: Date | null) => (d ? new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '');
const blank: BannerForm = { title: '', subtitle: '', productId: '', ctaText: 'Shop now', priority: 0, active: true, startDate: '', endDate: '' };

/** Product picker searches REAL approved products; the banner stores only productId, so the link is always /product/[id]. */
function ProductPicker({ value, onPick }: { value: Product | null; onPick: (p: Product) => void }) {
  const [q, setQ] = useState(''); const dq = useDebounce(q, 300);
  const [res, setRes] = useState<Product[]>([]);
  useEffect(() => { if (dq.trim().length < 2) { setRes([]); return; } searchProducts(dq, {}, null, 8).then((p) => setRes(p.items)).catch(() => setRes([])); }, [dq]);
  return (
    <div className="space-y-2 md:col-span-2">
      <p className="text-sm font-medium">Product</p>
      {value ? <p className="rounded-xl bg-navy-50 p-2 text-sm dark:bg-navy-700">Selected: <strong>{value.title}</strong> <span className="text-xs">({value.id})</span></p> : <p className="text-sm text-red-600">No product selected yet.</p>}
      <Field label="Search approved products" value={q} onChange={(e) => setQ(e.target.value)} />
      {res.length ? <ul className="rounded-xl border border-navy-100 dark:border-navy-500">{res.map((p) => <li key={p.id}><button type="button" onClick={() => { onPick(p); setQ(''); setRes([]); }} className="min-h-11 w-full px-3 text-left text-sm hover:bg-navy-50 dark:hover:bg-navy-700">{p.title}</button></li>)}</ul> : null}
    </div>
  );
}

export function BannerAdmin() {
  const { user } = useAuth(); const toast = useToast();
  const [list, setList] = useState<ProductBanner[] | null>(null);
  const [editing, setEditing] = useState<ProductBanner | 'new' | null>(null);
  const [f, setF] = useState<BannerForm>(blank);
  const [product, setProduct] = useState<Product | null>(null);
  const [desktop, setDesktop] = useState<File | null>(null); const [mobile, setMobile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const load = () => listBanners().then(setList).catch((e) => { toast(friendlyError(e), 'error'); setList([]); });
  useEffect(() => { void load(); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const open = async (b: ProductBanner | 'new') => {
    setEditing(b); setDesktop(null); setMobile(null);
    if (b === 'new') { setF(blank); setProduct(null); return; }
    setF({ title: b.title, subtitle: b.subtitle ?? '', productId: b.productId, ctaText: b.ctaText, priority: b.priority, active: b.active, startDate: toLocal(b.startDate), endDate: toLocal(b.endDate) });
    setProduct(await getProduct(b.productId));
  };
  const submit = async (e: FormEvent) => {
    e.preventDefault(); if (!user) return; setBusy(true);
    try { await saveBanner(user.uid, editing === 'new' ? null : editing, f, desktop, mobile); toast('Banner saved', 'success'); setEditing(null); await load(); }
    catch (err) { toast(err instanceof Error && !('code' in err) ? err.message : friendlyError(err), 'error'); } finally { setBusy(false); }
  };
  const run = async (fn: () => Promise<void>, ok: string) => { try { await fn(); toast(ok, 'success'); await load(); } catch (e) { toast(friendlyError(e), 'error'); } };

  if (list === null) return <LoadingState />;
  if (editing) {
    return (
      <Card><h1 className="mb-3 text-xl font-extrabold">{editing === 'new' ? 'New banner' : 'Edit banner'}</h1>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
          <Field label="Title" required maxLength={80} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <Field label="Subtitle" maxLength={120} value={f.subtitle} onChange={(e) => setF({ ...f, subtitle: e.target.value })} />
          <Field label="Button text" maxLength={24} value={f.ctaText} onChange={(e) => setF({ ...f, ctaText: e.target.value })} />
          <Field label="Priority (higher shows first)" type="number" value={f.priority} onChange={(e) => setF({ ...f, priority: Number(e.target.value) })} />
          <ProductPicker value={product} onPick={(p) => { setProduct(p); setF({ ...f, productId: p.id }); }} />
          <Field label="Start (optional)" type="datetime-local" value={f.startDate} onChange={(e) => setF({ ...f, startDate: e.target.value })} />
          <Field label="End (optional)" type="datetime-local" value={f.endDate} onChange={(e) => setF({ ...f, endDate: e.target.value })} />
          <div><label className="text-sm font-medium" htmlFor="bd">Desktop image (wide, e.g. 2100×600)</label><input id="bd" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setDesktop(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
          <div><label className="text-sm font-medium" htmlFor="bm">Mobile image (e.g. 1200×525)</label><input id="bm" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setMobile(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />Active</label>
          <div className="flex gap-2 md:col-span-2"><Button type="submit" loading={busy}>Save banner</Button><Button type="button" variant="ghost" onClick={() => setEditing(null)}>Cancel</Button></div>
        </form></Card>
    );
  }
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">Product banners</h1><Button onClick={() => open('new')}>New banner</Button></div>
      {!list.length ? <p className="rounded-card border border-dashed p-4 text-sm">No banners yet. Create one and pick a product.</p> : (
        <ul className="space-y-3">{list.map((b, idx) => {
          const live = isLive(b);
          return (
            <li key={b.id}><Card className="flex flex-wrap gap-3">
              <div className="relative h-20 w-40 shrink-0 overflow-hidden rounded-lg bg-navy-50">{b.desktopImage ? <Image src={b.desktopImage} alt="" fill sizes="160px" className="object-cover" /> : null}</div>
              <div className="min-w-0 flex-1 text-sm"><p className="font-bold">{b.title}</p><p>Priority {b.priority} · {b.active ? (live ? 'Live now' : 'Active, outside schedule') : 'Inactive'}</p>
                <p className="break-all text-xs">→ /product/{b.productId}</p>
                <p className="text-xs">{b.startDate ? `From ${b.startDate.toLocaleString()} ` : ''}{b.endDate ? `until ${b.endDate.toLocaleString()}` : ''}</p></div>
              <div className="flex flex-wrap items-start gap-1">
                <Button variant="ghost" aria-label="Move up (higher priority)" disabled={idx === 0} onClick={() => user && run(() => moveBanner(user.uid, list, idx, -1), 'Moved')}>↑</Button>
                <Button variant="ghost" aria-label="Move down" disabled={idx === list.length - 1} onClick={() => user && run(() => moveBanner(user.uid, list, idx, 1), 'Moved')}>↓</Button>
                <Button variant="ghost" onClick={() => open(b)}>Edit</Button>
                <Button variant="ghost" onClick={() => user && run(() => setBannerActive(user.uid, b, !b.active), b.active ? 'Banner paused' : 'Banner activated')}>{b.active ? 'Pause' : 'Activate'}</Button>
                <Button variant="ghost" onClick={() => { if (user && window.confirm('Delete this banner?')) void run(() => deleteBanner(user.uid, b.id), 'Banner deleted'); }}>Delete</Button>
              </div></Card></li>
          );
        })}</ul>
      )}
    </div>
  );
}
