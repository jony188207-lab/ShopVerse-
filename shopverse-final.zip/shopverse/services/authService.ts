import {
  createUserWithEmailAndPassword, sendEmailVerification, sendPasswordResetEmail,
  signInWithEmailAndPassword, signOut, updateProfile, type User,
} from 'firebase/auth';
import { auth } from '@/lib/firebase/config';
import { detachPush } from './pushService';
import { ensureUserDocs } from './userService';

export async function signUp(input: { email: string; password: string; displayName: string }): Promise<User> {
  const cred = await createUserWithEmailAndPassword(auth(), input.email.trim(), input.password);
  await updateProfile(cred.user, { displayName: input.displayName.trim() });
  await ensureUserDocs(cred.user, input.displayName.trim());
  await sendEmailVerification(cred.user);
  return cred.user;
}

export async function login(email: string, password: string): Promise<User> {
  const cred = await signInWithEmailAndPassword(auth(), email.trim(), password);
  await ensureUserDocs(cred.user);
  return cred.user;
}

/** Detaches this device from push FIRST so the next person on a shared browser never receives the previous user's notifications. */
export async function logout(): Promise<void> {
  const u = auth().currentUser;
  if (u) await detachPush(u.uid);
  await signOut(auth());
}
export const requestPasswordReset = (email: string) => sendPasswordResetEmail(auth(), email.trim());

export async function resendVerification(): Promise<void> {
  const u = auth().currentUser;
  if (u && !u.emailVerified) await sendEmailVerification(u);
}

/** After the user clicks the emailed link: refresh the user AND the ID token (rules read email_verified from the token). */
export async function refreshVerification(): Promise<boolean> {
  const u = auth().currentUser;
  if (!u) return false;
  await u.reload();
  await u.getIdToken(true);
  return u.emailVerified;
}
