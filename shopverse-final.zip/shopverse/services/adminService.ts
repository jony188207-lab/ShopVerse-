import { addDoc, collection, deleteDoc, deleteField, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, Timestamp, updateDoc, where, writeBatch, type QueryDocumentSnapshot } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { db, functions } from '@/lib/firebase/config';
import { categoryById } from '@/config/categories';
import type { Order, OrderStatus, Product, ProductBanner, ProductStatus, Store, Variant } from '@/types';
import { buildSearchKeywords } from '@/utils/keywords';
import { discountPercent, round2 } from '@/utils/money';
import { toDate } from '@/utils/schedule';
import { mapOrder, mapProduct, mapStore } from './mappers';
import { uploadFile } from './uploadService';
import type { Page } from './productService';

/** Append-only audit trail (rules: createdAt must equal request.time, admins only). */
export const logAdmin = (adminId: string, action: string, targetType: string, targetId: string, note = '') =>
  addDoc(collection(db(), 'adminLogs'), { adminId, action, targetType, targetId, ...(note ? { note: note.slice(0, 500) } : {}), createdAt: serverTimestamp() }).catch(() => undefined);

export const slugify = (s: string) => s.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 60);

// ---------------- stores ----------------
export interface StoreForm { ownerId: string; name: string; description: string; city: string; country: string; shippingFee: number; freeShippingOver: number | null; returnPolicy: string; shippingInfo: string }
export async function listStores(): Promise<Store[]> {
  const s = await getDocs(query(collection(db(), 'stores'), orderBy('name'), limit(100)));
  return s.docs.map((d) => mapStore(d.id, d.data()));
}
export async function createStore(adminId: string, f: StoreForm, logo: File | null): Promise<string> {
  const ref = doc(collection(db(), 'stores'));
  const slug = `${slugify(f.name)}-${ref.id.slice(0, 4).toLowerCase()}`;
  const logoUrl = logo ? await uploadFile(`stores/${f.ownerId}/${ref.id}-logo-${logo.name}`, logo, { maxMB: 8, image: true }) : '';
  await setDoc(ref, {
    ownerId: f.ownerId.trim(), name: f.name.trim(), slug, description: f.description.trim(), logoUrl, city: f.city.trim(), country: f.country.trim(),
    status: 'approved', ratingAvg: 0, ratingCount: 0, ratingSum: 0, followerCount: 0, shippingFee: round2(f.shippingFee),
    ...(f.freeShippingOver != null ? { freeShippingOver: round2(f.freeShippingOver) } : {}), returnPolicy: f.returnPolicy.trim(), shippingInfo: f.shippingInfo.trim(),
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  await logAdmin(adminId, 'store.create', 'store', ref.id);
  return ref.id;
}

// ---------------- products ----------------
export interface ProductForm {
  storeId: string; title: string; brand: string; categoryId: string; subcategoryId: string; description: string; price: number; originalPrice: number | null; stock: number;
  sku: string; weight: string; specsText: string; variantsText: string; shippingInfo: string; returnPolicy: string; featured: boolean; flashSaleEndsAt: string; status: ProductStatus;
}
export function parseSpecs(t: string) {
  return t.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { const i = l.indexOf(':'); return i > 0 ? { label: l.slice(0, i).trim(), value: l.slice(i + 1).trim() } : null; }).filter((x): x is { label: string; value: string } => !!x && !!x.value);
}
/** One variant per line: `Label | stock | optional price`. Keys are slugs of the label and must be unique. */
export function parseVariants(t: string): Variant[] {
  const out: Variant[] = []; const seen = new Set<string>();
  for (const line of t.split('\n').map((l) => l.trim()).filter(Boolean)) {
    const [label, stock, price] = line.split('|').map((x) => x.trim());
    const key = slugify(label ?? '');
    const st = Number(stock);
    if (!key || !Number.isInteger(st) || st < 0) throw new Error(`Invalid variant line: “${line}”. Use: Label | stock | optional price`);
    if (seen.has(key)) throw new Error(`Duplicate variant “${label}”.`);
    seen.add(key);
    const pr = price ? Number(price) : undefined;
    if (price && !(pr! > 0)) throw new Error(`Invalid variant price in “${line}”.`);
    out.push({ key, label, stock: st, ...(pr ? { price: round2(pr) } : {}) });
  }
  return out;
}

export async function listAllProducts(cursor: QueryDocumentSnapshot | null = null, status?: ProductStatus, pageSize = 25): Promise<Page<Product>> {
  const c = [...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(pageSize)];
  const s = await getDocs(query(collection(db(), 'products'), ...c));
  return { items: s.docs.map((d) => mapProduct(d.id, d.data())), cursor: s.docs.at(-1) ?? null, hasMore: s.size === pageSize };
}
export async function getProductAdmin(id: string): Promise<Product | null> {
  const s = await getDoc(doc(db(), 'products', id));
  return s.exists() ? mapProduct(s.id, s.data()) : null;
}

export async function saveProduct(adminId: string, existing: Product | null, f: ProductForm, store: Store, images: File[], video: File | null): Promise<string> {
  const ref = existing ? doc(db(), 'products', existing.id) : doc(collection(db(), 'products'));
  const variants = parseVariants(f.variantsText);
  const stock = variants.length ? variants.reduce((s, v) => s + v.stock, 0) : f.stock;
  const price = round2(f.price);
  const original = round2(Math.max(f.originalPrice ?? price, price));
  if (!(price > 0)) throw new Error('Enter a price greater than 0.');
  if (!categoryById(f.categoryId)) throw new Error('Choose a category.');
  const sellerId = store.ownerId;
  const base = `products/${sellerId}/${ref.id}`;
  const newUrls = await Promise.all(images.slice(0, 8).map((file, i) => uploadFile(`${base}/${Date.now()}-${i}-${file.name}`, file, { maxMB: 10, image: true })));
  const imageList = [...(existing?.images ?? []), ...newUrls].slice(0, 10);
  const videoUrl = video ? await uploadFile(`productVideos/${sellerId}/${ref.id}/${Date.now()}-${video.name}`, video, { maxMB: 100, video: true }) : existing?.video ?? '';
  const data = {
    sellerId, storeId: store.id, title: f.title.trim(), brand: f.brand.trim(), categoryId: f.categoryId, subcategoryId: f.subcategoryId.trim(), description: f.description.trim(),
    images: imageList, video: videoUrl, price, originalPrice: original, discount: discountPercent(price, original), stock, sku: f.sku.trim(), weight: f.weight.trim(),
    specs: parseSpecs(f.specsText), variants, shippingInfo: f.shippingInfo.trim(), returnPolicy: f.returnPolicy.trim(), featured: f.featured, status: f.status,
    flashSaleEndsAt: f.flashSaleEndsAt ? Timestamp.fromDate(new Date(f.flashSaleEndsAt)) : null,
    searchKeywords: buildSearchKeywords({ title: f.title, brand: f.brand, categoryName: categoryById(f.categoryId)?.name, description: f.description }),
    updatedAt: serverTimestamp(),
  };
  if (existing) await updateDoc(ref, data);
  else {
    await setDoc(ref, { ...data, slug: `${slugify(f.title)}-${ref.id.slice(0, 5).toLowerCase()}`, rating: 0, reviewCount: 0, ratingSum: 0, ratingDistribution: { '1': 0, '2': 0, '3': 0, '4': 0, '5': 0 }, salesCount: 0, createdAt: serverTimestamp() });
  }
  await logAdmin(adminId, existing ? 'product.update' : 'product.create', 'product', ref.id);
  return ref.id;
}
export async function setProductStatus(adminId: string, id: string, status: ProductStatus, note = ''): Promise<void> {
  // Approved/restored products are PUBLIC documents: do not leave reviewer ids or internal notes on them (who/why lives in adminLogs).
  const live = status === 'approved';
  await updateDoc(doc(db(), 'products', id), live ? { status, moderationNote: deleteField(), moderatedBy: deleteField(), moderatedAt: deleteField(), updatedAt: serverTimestamp() } : { status, moderationNote: note, moderatedBy: adminId, moderatedAt: serverTimestamp(), updatedAt: serverTimestamp() });
  await logAdmin(adminId, `product.${status}`, 'product', id, note);
}
export async function removeProductImage(p: Product, url: string): Promise<void> {
  await updateDoc(doc(db(), 'products', p.id), { images: p.images.filter((u) => u !== url), updatedAt: serverTimestamp() });
}

// ---------------- banners ----------------
export interface BannerForm { title: string; subtitle: string; productId: string; ctaText: string; priority: number; active: boolean; startDate: string; endDate: string }
export async function listBanners(): Promise<ProductBanner[]> {
  const s = await getDocs(query(collection(db(), 'productBanners'), orderBy('priority', 'desc'), limit(50)));
  return s.docs.map((d) => { const x = d.data(); return { id: d.id, title: x.title ?? '', subtitle: x.subtitle ?? '', desktopImage: x.desktopImage ?? '', mobileImage: x.mobileImage ?? '', productId: x.productId ?? '', ctaText: x.ctaText ?? 'Shop now', priority: Number(x.priority ?? 0), active: x.active === true, startDate: toDate(x.startDate), endDate: toDate(x.endDate) }; });
}
export async function saveBanner(adminId: string, existing: ProductBanner | null, f: BannerForm, desktop: File | null, mobile: File | null): Promise<void> {
  if (!f.productId) throw new Error('Select a product for this banner.');
  const ref = existing ? doc(db(), 'productBanners', existing.id) : doc(collection(db(), 'productBanners'));
  const desktopImage = desktop ? await uploadFile(`banners/${ref.id}-desktop-${desktop.name}`, desktop, { maxMB: 5, image: true }) : existing?.desktopImage ?? '';
  const mobileImage = mobile ? await uploadFile(`banners/${ref.id}-mobile-${mobile.name}`, mobile, { maxMB: 5, image: true }) : existing?.mobileImage ?? desktopImage;
  if (!desktopImage) throw new Error('Upload a desktop image.');
  const start = f.startDate ? new Date(f.startDate) : null; const end = f.endDate ? new Date(f.endDate) : null;
  if (start && end && end <= start) throw new Error('End date must be after the start date.');
  const data = {
    title: f.title.trim(), subtitle: f.subtitle.trim(), desktopImage, mobileImage: mobileImage || desktopImage, productId: f.productId, ctaText: f.ctaText.trim() || 'Shop now',
    priority: Math.round(f.priority), active: f.active, startDate: start ? Timestamp.fromDate(start) : null, endDate: end ? Timestamp.fromDate(end) : null, updatedAt: serverTimestamp(),
  };
  if (existing) await updateDoc(ref, data); else await setDoc(ref, { ...data, createdAt: serverTimestamp() });
  await logAdmin(adminId, existing ? 'banner.update' : 'banner.create', 'banner', ref.id);
}
export async function setBannerActive(adminId: string, b: ProductBanner, active: boolean): Promise<void> {
  // Re-save goes through the same rule (product must exist and be approved) so a stale banner can't be re-activated.
  await updateDoc(doc(db(), 'productBanners', b.id), { active, updatedAt: serverTimestamp() });
  await logAdmin(adminId, active ? 'banner.activate' : 'banner.deactivate', 'banner', b.id);
}
/** Re-ranks banners: swaps the clicked one with its neighbour, then rewrites priorities as 10,20,30… so ties never occur. */
export async function moveBanner(adminId: string, list: ProductBanner[], index: number, dir: -1 | 1): Promise<void> {
  const j = index + dir;
  if (j < 0 || j >= list.length) return;
  const next = [...list]; [next[index], next[j]] = [next[j], next[index]];
  const batch = writeBatch(db());
  next.forEach((b, i) => { const p = (next.length - i) * 10; if (b.priority !== p) batch.update(doc(db(), 'productBanners', b.id), { priority: p, updatedAt: serverTimestamp() }); });
  await batch.commit();
  await logAdmin(adminId, 'banner.reorder', 'banner', list[index].id);
}
export async function deleteBanner(adminId: string, id: string): Promise<void> {
  await deleteDoc(doc(db(), 'productBanners', id));
  await logAdmin(adminId, 'banner.delete', 'banner', id);
}

// ---------------- orders (interim fulfilment tooling until the Phase 4 Seller Center) ----------------
export async function listAllOrders(cursor: QueryDocumentSnapshot | null = null, status?: OrderStatus, pageSize = 20): Promise<Page<Order>> {
  const c = [...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(pageSize)];
  const s = await getDocs(query(collection(db(), 'orders'), ...c));
  return { items: s.docs.map((d) => mapOrder(d.id, d.data())), cursor: s.docs.at(-1) ?? null, hasMore: s.size === pageSize };
}

/** Forward-only fulfilment steps an admin may apply. The onOrderStatusChange Cloud Function does the timeline, item sync, stock restore on cancel and sales counting. */
export const NEXT_STATUSES: Record<OrderStatus, OrderStatus[]> = {
  pending: ['confirmed', 'cancelled'], confirmed: ['processing', 'cancelled'], processing: ['shipped', 'cancelled'],
  shipped: ['out_for_delivery', 'delivered'], out_for_delivery: ['delivered'], delivered: [],
  cancelled: [], return_requested: ['returned', 'delivered'], returned: ['refunded'], refunded: [],
};
export const confirmCodRemittance = (orderId: string) => httpsCallable<unknown, { ok: boolean }>(functions(), 'confirmCodRemittance')({ orderId });
export async function setOrderStatus(adminId: string, order: Order, next: OrderStatus): Promise<void> {
  if (!NEXT_STATUSES[order.status].includes(next)) throw new Error(`Cannot move an order from ${order.status} to ${next}.`);
  await updateDoc(doc(db(), 'orders', order.id), { status: next, updatedAt: serverTimestamp() });
  await logAdmin(adminId, `order.${next}`, 'order', order.id);
}
