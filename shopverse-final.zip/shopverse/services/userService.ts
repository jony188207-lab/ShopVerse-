import { doc, getDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { db } from '@/lib/firebase/config';
import type { Role } from '@/types';

const VALID: Role[] = ['user', 'seller', 'moderator', 'admin', 'super_admin'];

/** Role comes from /roles/{uid} (writable only per firestore.rules). Missing doc => plain user. */
export async function fetchRole(uid: string): Promise<Role> {
  const snap = await getDoc(doc(db(), 'roles', uid));
  const r = snap.exists() ? (snap.data().role as Role) : 'user';
  return VALID.includes(r) ? r : 'user';
}

/** Idempotent: creates the private user doc + public profile if missing (also repairs a half-finished signup). */
export async function ensureUserDocs(user: User, displayName?: string): Promise<void> {
  const userRef = doc(db(), 'users', user.uid);
  if ((await getDoc(userRef)).exists()) return;
  const name = displayName ?? user.displayName ?? (user.email ? user.email.split('@')[0] : 'Shopper');
  const batch = writeBatch(db());
  batch.set(userRef, {
    email: user.email ?? '', displayName: name, phone: '', status: 'active',
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  batch.set(doc(db(), 'profiles', user.uid), {
    displayName: name, photoURL: user.photoURL ?? null, bio: '', followerCount: 0, followingCount: 0,
    createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
  });
  await batch.commit();
}
