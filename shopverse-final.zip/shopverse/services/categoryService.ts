import { collection, deleteDoc, doc, getCountFromServer, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, updateDoc, where, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { DEFAULT_CATEGORIES, categorySlug, type Category } from '@/config/categories';
import { uploadFile } from './uploadService';
import { logAdmin } from './adminService';

const map = (id: string, d: Record<string, unknown>): Category => ({
  id, name: String(d.name ?? id), order: typeof d.order === 'number' ? d.order : 0, active: d.active !== false, imageUrl: d.imageUrl ? String(d.imageUrl) : undefined, parentId: d.parentId ? String(d.parentId) : undefined,
});
export async function listCategories(): Promise<Category[]> {
  const s = await getDocs(query(collection(db(), 'categories'), orderBy('order', 'asc'), limit(200)));
  return s.docs.map((d) => map(d.id, d.data()));
}
export interface CategoryForm { name: string; order: number; active: boolean; parentId: string }
export async function saveCategory(adminId: string, id: string | null, f: CategoryForm, image: File | null, existingImage?: string): Promise<void> {
  const name = f.name.trim();
  if (name.length < 2) throw new Error('Enter a category name.');
  const slug = id ?? categorySlug(name);
  if (!slug) throw new Error('Use letters or numbers in the name.');
  if (f.parentId && f.parentId === slug) throw new Error('A category cannot be its own parent.');
  const imageUrl = image ? await uploadFile(`categories/${slug}-${Date.now()}-${image.name}`, image, { maxMB: 2, image: true }) : existingImage ?? '';
  const data = { name, order: Math.max(0, Math.floor(f.order)), active: f.active, imageUrl, parentId: f.parentId, updatedAt: serverTimestamp() };
  const ref = doc(db(), 'categories', slug);
  if (id) await updateDoc(ref, data);
  else {
    if ((await getDoc(ref)).exists()) throw new Error('A category with this name already exists.');
    await setDoc(ref, { ...data, createdAt: serverTimestamp() });
  }
  await logAdmin(adminId, id ? 'category.update' : 'category.create', 'category', slug, name);
}
export async function setCategoryActive(adminId: string, id: string, active: boolean): Promise<void> {
  await updateDoc(doc(db(), 'categories', id), { active, updatedAt: serverTimestamp() });
  await logAdmin(adminId, active ? 'category.activate' : 'category.deactivate', 'category', id);
}
/** Swapping `order` values moves a category up/down in every storefront list. */
export async function swapOrder(adminId: string, a: Category, b: Category): Promise<void> {
  const batch = writeBatch(db());
  batch.update(doc(db(), 'categories', a.id), { order: b.order ?? 0, updatedAt: serverTimestamp() });
  batch.update(doc(db(), 'categories', b.id), { order: a.order ?? 0, updatedAt: serverTimestamp() });
  await batch.commit();
  await logAdmin(adminId, 'category.reorder', 'category', a.id, `${a.id} <-> ${b.id}`);
}
/** Deleting is only allowed when no product uses the category (otherwise deactivate it). */
export async function deleteCategory(adminId: string, id: string): Promise<void> {
  const n = (await getCountFromServer(query(collection(db(), 'products'), where('categoryId', '==', id)))).data().count;
  if (n > 0) throw new Error(`${n} product(s) use this category. Deactivate it instead of deleting.`);
  await deleteDoc(doc(db(), 'categories', id));
  await logAdmin(adminId, 'category.delete', 'category', id);
}
/** One-click import of the built-in taxonomy (only when the collection is empty). */
export async function importDefaults(adminId: string): Promise<number> {
  if ((await listCategories()).length) throw new Error('Categories already exist.');
  const batch = writeBatch(db());
  DEFAULT_CATEGORIES.forEach((c) => batch.set(doc(db(), 'categories', c.id), { name: c.name, order: c.order ?? 0, active: true, imageUrl: '', parentId: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
  await batch.commit();
  await logAdmin(adminId, 'category.import_defaults', 'category', '*');
  return DEFAULT_CATEGORIES.length;
}
