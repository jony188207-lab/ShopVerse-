import {
  collection, deleteField, doc, getAggregateFromServer, getCountFromServer, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, sum, Timestamp, updateDoc, where, writeBatch,
  type DocumentData, type QueryDocumentSnapshot, type QueryConstraint,
} from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { db, functions } from '@/lib/firebase/config';
import type { Review } from '@/types';
import { toDate } from '@/utils/schedule';
import { logAdmin } from './adminService';
import { mapReview } from './mappers';
import type { Page } from './productService';

const pg = <T>(docs: QueryDocumentSnapshot[], map: (id: string, d: DocumentData) => T, size: number): Page<T> => ({ items: docs.map((d) => map(d.id, d.data())), cursor: docs.at(-1) ?? null, hasMore: docs.length === size });
const str = (v: unknown) => (typeof v === 'string' ? v : '');
const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);

// ============ dashboard (server-side aggregates; each card fails independently, e.g. moderators lack some permissions) ============
export type Stat = { value: number | null; money?: boolean };
export async function getDashboard(): Promise<Record<string, Stat>> {
  const n = async (col: string, ...w: QueryConstraint[]) => (await getCountFromServer(query(collection(db(), col), ...w))).data().count;
  const jobs: [string, () => Promise<number>, boolean?][] = [
    ['users', () => n('users')], ['activeUsers', () => n('users', where('status', '==', 'active'))], ['sellers', () => n('stores', where('status', '==', 'approved'))],
    ['pendingApplications', () => n('sellerApplications', where('status', '==', 'pending'))], ['products', () => n('products')], ['pendingProducts', () => n('products', where('status', '==', 'pending_review'))],
    ['orders', () => n('orders')], ['completedOrders', () => n('orders', where('status', '==', 'delivered'))], ['cancelledOrders', () => n('orders', where('status', '==', 'cancelled'))],
    ['totalSales', async () => num((await getAggregateFromServer(query(collection(db(), 'orders'), where('status', '==', 'delivered')), { total: sum('total') })).data().total), true],
    ['pendingWithdrawals', () => n('withdrawals', where('status', '==', 'pending'))], ['videos', () => n('videos')], ['reviews', () => n('reviews')], ['reports', () => n('reports', where('status', 'in', ['open', 'under_review']))],
  ];
  const res = await Promise.allSettled(jobs.map(([, f]) => f()));
  return Object.fromEntries(jobs.map(([k, , money], i) => [k, { value: res[i].status === 'fulfilled' ? (res[i] as PromiseFulfilledResult<number>).value : null, money }]));
}

// ============ users ============
export interface AdminUser { id: string; email: string; displayName: string; status: string; suspendReason: string; createdAt: Date | null }
const mapUser = (id: string, d: DocumentData): AdminUser => ({ id, email: str(d.email), displayName: str(d.displayName), status: str(d.status) || 'active', suspendReason: str(d.suspendReason), createdAt: toDate(d.createdAt) });
export async function listUsers(term: string, status: string, cursor: QueryDocumentSnapshot | null, size = 20): Promise<Page<AdminUser>> {
  const t = term.trim();
  const base = collection(db(), 'users');
  const after = cursor ? [startAfter(cursor)] : [];
  if (!t) return pg((await getDocs(query(base, ...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...after, limit(size)))).docs, mapUser, size);
  // Prefix search on email (lowercase) or display name (case-sensitive). Firestore has no contains-search.
  const field = t.includes('@') || t === t.toLowerCase() ? 'email' : 'displayName';
  const v = field === 'email' ? t.toLowerCase() : t;
  return pg((await getDocs(query(base, where(field, '>=', v), where(field, '<=', v + '\uf8ff'), orderBy(field), ...after, limit(size)))).docs, mapUser, size);
}
export async function getUserDetail(uid: string) {
  const [u, role, app, orders, reviews, reports] = await Promise.all([
    getDoc(doc(db(), 'users', uid)), getDoc(doc(db(), 'roles', uid)), getDoc(doc(db(), 'sellerApplications', uid)),
    getCountFromServer(query(collection(db(), 'orders'), where('buyerId', '==', uid))), getCountFromServer(query(collection(db(), 'reviews'), where('userId', '==', uid))),
    getCountFromServer(query(collection(db(), 'reports'), where('targetId', '==', uid))),
  ]);
  return { user: u.exists() ? mapUser(u.id, u.data()) : null, role: role.exists() ? str(role.data().role) : 'user', applicationStatus: app.exists() ? str(app.data().status) : '', orders: orders.data().count, reviews: reviews.data().count, reportsAgainst: reports.data().count };
}
export const setUserStatus = (uid: string, status: 'active' | 'suspended', reason = '') => httpsCallable(functions(), 'setUserStatus')({ uid, status, reason });
export const setUserRole = (uid: string, role: 'user' | 'moderator' | 'admin') => httpsCallable(functions(), 'setUserRole')({ uid, role });

// ============ reviews moderation ============
export async function listReviewsAdmin(status: string, cursor: QueryDocumentSnapshot | null, size = 20): Promise<Page<Review>> {
  const c = [...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)];
  return pg((await getDocs(query(collection(db(), 'reviews'), ...c))).docs, mapReview, size);
}
/** Hide = removed from the product page, ratings and store page (onReviewWritten recomputes aggregates); Restore reverses it. Always with who/why. */
export async function moderateReview(adminId: string, id: string, status: 'published' | 'hidden', note = ''): Promise<void> {
  await updateDoc(doc(db(), 'reviews', id), { status, moderationNote: note, moderatedBy: adminId, moderatedAt: serverTimestamp(), updatedAt: serverTimestamp() });
  await logAdmin(adminId, status === 'hidden' ? 'review.hide' : 'review.restore', 'review', id, note);
}

// ============ reports ============
export type ReportStatus = 'open' | 'under_review' | 'resolved' | 'rejected';
export const REPORT_LABEL: Record<ReportStatus, string> = { open: 'Pending', under_review: 'Under review', resolved: 'Resolved', rejected: 'Rejected' };
export const REPORT_TARGETS = ['user', 'seller', 'product', 'review', 'comment', 'video', 'store', 'conversation', 'message'] as const;
export interface Report { id: string; reporterId: string; targetType: string; targetId: string; reason: string; evidence: string; status: ReportStatus; internalNote: string; action: string; resolution: string; createdAt: Date | null }
const mapReport = (id: string, d: DocumentData): Report => ({ id, reporterId: str(d.reporterId), targetType: str(d.targetType) || 'review', targetId: str(d.targetId) || str(d.reviewId), reason: str(d.reason), evidence: str(d.evidence), status: (d.status ?? 'open') as ReportStatus, internalNote: str(d.internalNote), action: str(d.action), resolution: str(d.resolution), createdAt: toDate(d.createdAt) });
export async function listReports(status: string, targetType: string, cursor: QueryDocumentSnapshot | null, size = 20): Promise<Page<Report>> {
  const c = [...(status ? [where('status', '==', status)] : []), ...(targetType ? [where('targetType', '==', targetType)] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)];
  return pg((await getDocs(query(collection(db(), 'reports'), ...c))).docs, mapReport, size);
}
/** Update + audit log in ONE batch so a decision can't be saved without its log entry. */
export async function updateReport(adminId: string, r: Report, patch: { status: ReportStatus; internalNote: string; resolution?: string; action?: string }): Promise<void> {
  const b = writeBatch(db());
  const closed = patch.status === 'resolved' || patch.status === 'rejected';
  b.update(doc(db(), 'reports', r.id), { status: patch.status, internalNote: patch.internalNote.slice(0, 1000), resolution: (patch.resolution ?? r.resolution).slice(0, 300), action: patch.action ?? r.action, updatedAt: serverTimestamp(), ...(closed ? { resolvedBy: adminId, resolvedAt: serverTimestamp() } : {}) });
  b.set(doc(collection(db(), 'adminLogs')), { adminId, action: `report.${patch.status}`, targetType: 'report', targetId: r.id, note: `${r.targetType}/${r.targetId}${patch.action ? ` · ${patch.action}` : ''}`.slice(0, 500), createdAt: serverTimestamp() });
  await b.commit();
}
export async function hideReportedContent(adminId: string, r: Report): Promise<void> {
  if (r.targetType === 'review') await moderateReview(adminId, r.targetId, 'hidden', `Report ${r.id}: ${r.reason}`.slice(0, 300));
  else if (r.targetType === 'comment') { await updateDoc(doc(db(), 'videoComments', r.targetId), { status: 'hidden', updatedAt: serverTimestamp() }); await logAdmin(adminId, 'comment.hide', 'comment', r.targetId, r.reason); }
  else throw new Error('Use the linked admin page to act on this type of content.');
}
export const reportTargetLink = (r: Report): string =>
  ({ product: `/product/${r.targetId}`, store: '/admin/stores', seller: `/admin/sellers/${r.targetId}`, user: `/admin/users/${r.targetId}`, video: '/admin/videos', review: '/admin/reviews', comment: '/admin/videos', conversation: `/admin/conversations/${r.targetId}`, message: `/admin/conversations/${r.targetId.slice(0, r.targetId.lastIndexOf('_'))}` } as Record<string, string>)[r.targetType] ?? '/admin';
export async function fileReport(uid: string, targetType: (typeof REPORT_TARGETS)[number], targetId: string, reason: string, evidence = ''): Promise<void> {
  const r = reason.trim();
  if (r.length < 3 || r.length > 500) throw new Error('Describe the problem in 3–500 characters.');
  await setDoc(doc(db(), 'reports', `${uid}_${targetType}_${targetId}`), { reporterId: uid, targetType, targetId, reason: r, ...(evidence ? { evidence: evidence.slice(0, 1500) } : {}), status: 'open', createdAt: serverTimestamp() });
}

// ============ videos (moderation shell; the feed itself arrives in the video phase) ============
export interface AdminVideo { id: string; title: string; description: string; ownerId: string; storeId: string; status: string; visibility: string; createdAt: Date | null; moderationNote: string; videoUrl: string; thumbnailUrl: string; productIds: string[] }
export async function listVideosAdmin(status: string, cursor: QueryDocumentSnapshot | null, size = 20): Promise<Page<AdminVideo>> {
  const c = [...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)];
  return pg((await getDocs(query(collection(db(), 'videos'), ...c))).docs, (id, d) => ({ id, title: str(d.title), description: str(d.description), ownerId: str(d.ownerId), storeId: str(d.storeId), status: str(d.status), visibility: str(d.visibility), createdAt: toDate(d.createdAt), moderationNote: str(d.moderationNote), videoUrl: str(d.videoUrl), thumbnailUrl: str(d.thumbnailUrl), productIds: Array.isArray(d.productIds) ? d.productIds : [] }), size);
}
export async function moderateVideo(adminId: string, id: string, status: 'published' | 'rejected' | 'suspended', note = '', restore = false): Promise<void> {
  await updateDoc(doc(db(), 'videos', id), status === 'published' ? { status, moderationNote: deleteField(), moderatedBy: deleteField(), moderatedAt: deleteField(), updatedAt: serverTimestamp() } : { status, moderationNote: note, moderatedBy: adminId, moderatedAt: serverTimestamp(), updatedAt: serverTimestamp() });
  await logAdmin(adminId, restore ? 'video.restore' : `video.${status === 'published' ? 'approve' : status === 'rejected' ? 'reject' : 'suspend'}`, 'video', id, note);
}

// ============ platform coupons (coupons/platform_{CODE}; platform-funded; applied server-side in placeOrder) ============
export interface AdminCoupon { id: string; sellerId: string; code: string; discountType: 'percent' | 'fixed'; discountValue: number; minOrder: number; maxDiscount: number; usageLimit: number; usedCount: number; startsAt: Date | null; endsAt: Date | null; active: boolean }
const mapCoupon = (id: string, d: DocumentData): AdminCoupon => ({ id, sellerId: str(d.sellerId), code: str(d.code), discountType: d.discountType === 'fixed' ? 'fixed' : 'percent', discountValue: num(d.discountValue), minOrder: num(d.minOrder), maxDiscount: num(d.maxDiscount), usageLimit: num(d.usageLimit), usedCount: num(d.usedCount), startsAt: toDate(d.startsAt), endsAt: toDate(d.endsAt), active: d.active === true });
export async function listCouponsAdmin(scope: 'platform' | 'all', cursor: QueryDocumentSnapshot | null, size = 25): Promise<Page<AdminCoupon>> {
  const c = [...(scope === 'platform' ? [where('sellerId', '==', 'platform')] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)];
  return pg((await getDocs(query(collection(db(), 'coupons'), ...c))).docs, mapCoupon, size);
}
export interface PlatformCouponForm { code: string; discountType: 'percent' | 'fixed'; discountValue: number; minOrder: number; maxDiscount: number; usageLimit: number; startsAt: string; endsAt: string; active: boolean }
export async function savePlatformCoupon(adminId: string, f: PlatformCouponForm, editing: boolean): Promise<void> {
  const code = f.code.trim().toUpperCase();
  if (!/^[A-Z0-9]{3,20}$/.test(code)) throw new Error('Code: 3–20 letters or numbers.');
  if (!(f.discountValue > 0) || (f.discountType === 'percent' && f.discountValue > 100)) throw new Error('Enter a valid discount (percent must be 1–100).');
  const s = f.startsAt ? Timestamp.fromDate(new Date(f.startsAt)) : null, e = f.endsAt ? Timestamp.fromDate(new Date(f.endsAt)) : null;
  if (s && e && e <= s) throw new Error('The end date must be after the start date.');
  const data = { discountType: f.discountType, discountValue: f.discountValue, minOrder: Math.max(0, f.minOrder || 0), maxDiscount: Math.max(0, f.maxDiscount || 0), usageLimit: Math.max(0, Math.floor(f.usageLimit || 0)), startsAt: s, endsAt: e, active: f.active, updatedAt: serverTimestamp() };
  const ref = doc(db(), 'coupons', `platform_${code}`);
  if (editing) await updateDoc(ref, data);
  else {
    if ((await getDoc(ref)).exists()) throw new Error('A platform coupon with this code already exists.');
    await setDoc(ref, { ...data, sellerId: 'platform', code, usedCount: 0, createdAt: serverTimestamp() });
  }
  await logAdmin(adminId, editing ? 'coupon.update' : 'coupon.create', 'coupon', `platform_${code}`);
}
export async function setCouponActiveAdmin(adminId: string, id: string, active: boolean): Promise<void> {
  await updateDoc(doc(db(), 'coupons', id), { active, updatedAt: serverTimestamp() });
  await logAdmin(adminId, active ? 'coupon.activate' : 'coupon.deactivate', 'coupon', id);
}

// ============ platform promotions ============
export interface PlatformPromotion { id: string; title: string; type: 'featured' | 'flash_sale'; targetType: 'products' | 'category' | 'seller'; productIds: string[]; categoryId: string; storeOwnerId: string; startsAt: Date | null; endsAt: Date | null; active: boolean; applied: boolean; appliedCount: number }
const mapPP = (id: string, d: DocumentData): PlatformPromotion => ({ id, title: str(d.title), type: d.type === 'flash_sale' ? 'flash_sale' : 'featured', targetType: (d.targetType ?? 'products') as PlatformPromotion['targetType'], productIds: Array.isArray(d.productIds) ? d.productIds : [], categoryId: str(d.categoryId), storeOwnerId: str(d.storeOwnerId), startsAt: toDate(d.startsAt), endsAt: toDate(d.endsAt), active: d.active === true, applied: d.applied === true, appliedCount: Array.isArray(d.appliedProductIds) ? d.appliedProductIds.length : 0 });
export async function listPlatformPromotions(): Promise<PlatformPromotion[]> {
  return (await getDocs(query(collection(db(), 'platformPromotions'), orderBy('createdAt', 'desc'), limit(100)))).docs.map((d) => mapPP(d.id, d.data()));
}
export interface PPForm { title: string; type: 'featured' | 'flash_sale'; targetType: 'products' | 'category' | 'seller'; productIds: string[]; categoryId: string; storeOwnerId: string; startsAt: string; endsAt: string; active: boolean }
export async function savePlatformPromotion(adminId: string, id: string | null, f: PPForm): Promise<void> {
  const s = new Date(f.startsAt), e = new Date(f.endsAt);
  if (f.title.trim().length < 2) throw new Error('Enter a title.');
  if (!(e > s) || e.getTime() - s.getTime() > 90 * 86_400_000) throw new Error('A campaign must end after it starts and last at most 90 days.');
  if (f.targetType === 'products' && !f.productIds.length) throw new Error('Select at least one product.');
  if (f.targetType === 'category' && !f.categoryId) throw new Error('Choose a category.');
  if (f.targetType === 'seller' && !f.storeOwnerId) throw new Error('Choose a seller.');
  const data = { title: f.title.trim(), type: f.type, targetType: f.targetType, productIds: f.targetType === 'products' ? f.productIds.slice(0, 100) : [], categoryId: f.targetType === 'category' ? f.categoryId : '', storeOwnerId: f.targetType === 'seller' ? f.storeOwnerId : '', startsAt: Timestamp.fromDate(s), endsAt: Timestamp.fromDate(e), active: f.active, updatedAt: serverTimestamp() };
  if (id) await updateDoc(doc(db(), 'platformPromotions', id), data);
  else await setDoc(doc(collection(db(), 'platformPromotions')), { ...data, applied: false, appliedProductIds: [], createdBy: adminId, createdAt: serverTimestamp() });
  await logAdmin(adminId, id ? 'promotion.platform_update' : 'promotion.platform_create', 'platformPromotion', id ?? 'new', f.title);
}
export async function setPlatformPromotionActive(adminId: string, id: string, active: boolean): Promise<void> {
  await updateDoc(doc(db(), 'platformPromotions', id), { active, updatedAt: serverTimestamp() });
  await logAdmin(adminId, active ? 'promotion.platform_activate' : 'promotion.platform_deactivate', 'platformPromotion', id);
}
export async function deletePlatformPromotion(adminId: string, id: string): Promise<void> {
  const { deleteDoc } = await import('firebase/firestore');
  await deleteDoc(doc(db(), 'platformPromotions', id));
  await logAdmin(adminId, 'promotion.platform_delete', 'platformPromotion', id);
}

// ============ announcements ============
export interface Announcement { id: string; audience: string; title: string; body: string; recipients: number; createdAt: Date | null }
export async function listAnnouncements(): Promise<Announcement[]> {
  return (await getDocs(query(collection(db(), 'announcements'), orderBy('createdAt', 'desc'), limit(30)))).docs.map((d) => ({ id: d.id, audience: str(d.data().audience), title: str(d.data().title), body: str(d.data().body), recipients: num(d.data().recipients), createdAt: toDate(d.data().createdAt) }));
}
export const sendAnnouncement = (i: { audience: 'all' | 'sellers' | 'user'; kind: 'promotion' | 'important'; userId?: string; title: string; body: string; link?: string }) => httpsCallable<unknown, { recipients: number }>(functions(), 'sendAnnouncement')(i);

// ============ ad network (adNetworkSettings) ============
export interface AdConfig { id: string; networkName: string; adCode: string; adUrl: string; device: 'all' | 'mobile' | 'desktop'; width: number; height: number; active: boolean; startDate: Date | null; endDate: Date | null }
const mapAd = (id: string, d: DocumentData): AdConfig => ({ id, networkName: str(d.networkName), adCode: str(d.adCode), adUrl: str(d.adUrl), device: (d.device ?? 'all') as AdConfig['device'], width: num(d.width) || 320, height: num(d.height) || 50, active: d.active === true, startDate: toDate(d.startDate), endDate: toDate(d.endDate) });
export async function listAds(): Promise<AdConfig[]> {
  return (await getDocs(query(collection(db(), 'adNetworkSettings'), orderBy('createdAt', 'desc'), limit(50)))).docs.map((d) => mapAd(d.id, d.data()));
}
export interface AdForm { networkName: string; adCode: string; adUrl: string; device: 'all' | 'mobile' | 'desktop'; width: number; height: number; active: boolean; startDate: string; endDate: string }
export async function saveAd(adminId: string, id: string | null, f: AdForm): Promise<void> {
  if (!f.networkName.trim()) throw new Error('Enter the ad network name.');
  if (!f.adCode.trim() && !/^https:\/\/.+/.test(f.adUrl.trim())) throw new Error('Paste the ad code, or enter an https:// ad URL.');
  const s = f.startDate ? Timestamp.fromDate(new Date(f.startDate)) : null, e = f.endDate ? Timestamp.fromDate(new Date(f.endDate)) : null;
  if (s && e && e <= s) throw new Error('The end date must be after the start date.');
  const data = { networkName: f.networkName.trim(), adCode: f.adCode.trim(), adUrl: f.adUrl.trim(), placement: 'bottom', device: f.device, width: Math.round(f.width), height: Math.round(f.height), active: f.active, startDate: s, endDate: e, updatedAt: serverTimestamp() };
  if (id) await updateDoc(doc(db(), 'adNetworkSettings', id), data);
  else await setDoc(doc(collection(db(), 'adNetworkSettings')), { ...data, createdAt: serverTimestamp() });
  await logAdmin(adminId, id ? 'ads.update' : 'ads.create', 'adNetwork', id ?? 'new', `${f.networkName} (${f.device}${f.active ? ', active' : ''})`);   // the code itself is never logged
}
export async function setAdActive(adminId: string, id: string, active: boolean): Promise<void> {
  await updateDoc(doc(db(), 'adNetworkSettings', id), { active, updatedAt: serverTimestamp() });
  await logAdmin(adminId, active ? 'ads.activate' : 'ads.pause', 'adNetwork', id);
}
export async function deleteAd(adminId: string, id: string): Promise<void> {
  const { deleteDoc } = await import('firebase/firestore');
  await deleteDoc(doc(db(), 'adNetworkSettings', id));
  await logAdmin(adminId, 'ads.delete', 'adNetwork', id);
}

// ============ settings ============
export interface PlatformSettings { commissionDefaultPercent: number; earningsHoldDays: number; minWithdrawal: number; promotionMaxDays: number; pushEnabled: boolean }
export interface PublicSettings { adsEnabled: boolean; bannerRotateSeconds: number }
export const DEFAULT_PLATFORM: PlatformSettings = { commissionDefaultPercent: 10, earningsHoldDays: 7, minWithdrawal: 10, promotionMaxDays: 14, pushEnabled: true };
export const DEFAULT_PUBLIC: PublicSettings = { adsEnabled: true, bannerRotateSeconds: 5 };
export async function getPlatformSettings(): Promise<PlatformSettings> {
  const d = (await getDoc(doc(db(), 'platformSettings', 'main'))).data();
  return d ? { commissionDefaultPercent: num(d.commissionDefaultPercent), earningsHoldDays: num(d.earningsHoldDays), minWithdrawal: num(d.minWithdrawal) || 10, promotionMaxDays: num(d.promotionMaxDays) || 14, pushEnabled: d.pushEnabled !== false } : DEFAULT_PLATFORM;
}
export async function getPublicSettings(): Promise<PublicSettings> {
  try { const d = (await getDoc(doc(db(), 'publicSettings', 'main'))).data(); return d ? { adsEnabled: d.adsEnabled !== false, bannerRotateSeconds: num(d.bannerRotateSeconds) || 5 } : DEFAULT_PUBLIC; } catch { return DEFAULT_PUBLIC; }
}
export async function saveSettings(adminId: string, p: PlatformSettings, pub: PublicSettings): Promise<void> {
  const b = writeBatch(db());
  b.set(doc(db(), 'platformSettings', 'main'), { ...p, updatedAt: serverTimestamp(), updatedBy: adminId });
  b.set(doc(db(), 'publicSettings', 'main'), { ...pub, updatedAt: serverTimestamp(), updatedBy: adminId });
  b.set(doc(collection(db(), 'adminLogs')), { adminId, action: 'settings.update', targetType: 'settings', targetId: 'main', note: JSON.stringify({ ...p, ...pub }).slice(0, 500), createdAt: serverTimestamp() });
  await b.commit();
}
