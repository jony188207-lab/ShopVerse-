import { collection, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, startAfter, updateDoc, where, type DocumentData, type QueryDocumentSnapshot } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { db, functions } from '@/lib/firebase/config';
import type { Store } from '@/types';
import type { Promotion, SellerApplication, StorePrivate, Withdrawal } from '@/types/seller';
import { toDate } from '@/utils/schedule';
import { logAdmin } from './adminService';
import { mapStore } from './mappers';
import type { Page } from './productService';
import { mapApplication, mapPromotion, mapWithdrawal } from './sellerService';

const pg = <T>(docs: QueryDocumentSnapshot[], map: (id: string, d: DocumentData) => T, size: number): Page<T> => ({ items: docs.map((d) => map(d.id, d.data())), cursor: docs.at(-1) ?? null, hasMore: docs.length === size });
const list = async <T>(col: string, status: string, cursor: QueryDocumentSnapshot | null, map: (id: string, d: DocumentData) => T, size = 20) =>
  pg((await getDocs(query(collection(db(), col), ...(status ? [where('status', '==', status)] : []), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)))).docs, map, size);

export const listApplications = (status = '', cursor: QueryDocumentSnapshot | null = null) => list('sellerApplications', status, cursor, mapApplication);
export async function getApplicationById(id: string): Promise<SellerApplication | null> {
  const s = await getDoc(doc(db(), 'sellerApplications', id));
  return s.exists() ? mapApplication(s.id, s.data()) : null;
}
export async function getStoreOfOwner(ownerId: string): Promise<Store | null> {
  const s = await getDocs(query(collection(db(), 'stores'), where('ownerId', '==', ownerId), limit(1)));
  return s.empty ? null : mapStore(s.docs[0].id, s.docs[0].data());
}
export async function getStorePrivateAdmin(storeId: string): Promise<StorePrivate | null> {
  const d = (await getDoc(doc(db(), 'storePrivate', storeId))).data();
  return d ? { phone: String(d.phone ?? ''), email: String(d.email ?? ''), address: String(d.address ?? '') } : null;
}
export const reviewApplication = (applicationId: string, action: 'approve' | 'reject' | 'suspend' | 'reactivate', note = '') =>
  httpsCallable(functions(), 'reviewSellerApplication')({ applicationId, action, note });
export async function setCommission(adminId: string, storeId: string, percent: number): Promise<void> {
  if (!(percent >= 0 && percent <= 50)) throw new Error('Commission must be between 0 and 50 percent.');
  await setDoc(doc(db(), 'storeFinance', storeId), { commissionRate: percent, updatedAt: serverTimestamp() });
  await logAdmin(adminId, 'store.commission', 'store', storeId);
}

export const listWithdrawalsAdmin = (status = '', cursor: QueryDocumentSnapshot | null = null) => list<Withdrawal>('withdrawals', status, cursor, mapWithdrawal);
export const reviewWithdrawal = (id: string, status: 'approved' | 'processing' | 'completed' | 'rejected', note = '') => httpsCallable(functions(), 'reviewWithdrawal')({ id, status, note });
export const listPromotionsAdmin = (status = '', cursor: QueryDocumentSnapshot | null = null) => list<Promotion>('promotions', status, cursor, mapPromotion);
export const reviewPromotion = (id: string, decision: 'approved' | 'rejected', note = '') => httpsCallable(functions(), 'reviewPromotion')({ id, decision, note });

export interface AdminLog { id: string; adminId: string; action: string; targetType: string; targetId: string; note: string; createdAt: Date | null }
export async function listLogs(cursor: QueryDocumentSnapshot | null = null, size = 30): Promise<Page<AdminLog>> {
  const s = await getDocs(query(collection(db(), 'adminLogs'), orderBy('createdAt', 'desc'), ...(cursor ? [startAfter(cursor)] : []), limit(size)));
  return pg(s.docs, (id, d) => ({ id, adminId: String(d.adminId ?? ''), action: String(d.action ?? ''), targetType: String(d.targetType ?? ''), targetId: String(d.targetId ?? ''), note: String(d.note ?? ''), createdAt: toDate(d.createdAt) }), size);
}

export async function getCommission(storeId: string): Promise<number | null> {
  const d = (await getDoc(doc(db(), 'storeFinance', storeId))).data();
  return typeof d?.commissionRate === 'number' ? d.commissionRate : null;
}
export const migrateStoreFinance = () => httpsCallable<unknown, { moved: number }>(functions(), 'migrateStoreFinance')({});
