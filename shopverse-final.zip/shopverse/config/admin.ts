import type { Role } from '@/types';

export interface AdminSection { href: string; label: string; roles: Role[] }
const STAFF: Role[] = ['moderator', 'admin', 'super_admin'];
const ADMIN: Role[] = ['admin', 'super_admin'];

// `roles` mirrors firestore.rules. The rules are the real enforcement; this only controls UI + route guard.
export const ADMIN_SECTIONS: AdminSection[] = [
  { href: '/admin', label: 'Overview', roles: STAFF },
  { href: '/admin/users', label: 'Users', roles: ADMIN },
  { href: '/admin/sellers', label: 'Sellers', roles: ADMIN },
  { href: '/admin/stores', label: 'Stores', roles: ADMIN },
  { href: '/admin/products', label: 'Products', roles: STAFF },
  { href: '/admin/categories', label: 'Categories', roles: ADMIN },
  { href: '/admin/orders', label: 'Orders', roles: ADMIN },
  { href: '/admin/videos', label: 'Videos', roles: STAFF },
  { href: '/admin/reviews', label: 'Reviews', roles: STAFF },
  { href: '/admin/reports', label: 'Reports', roles: STAFF },
  { href: '/admin/withdrawals', label: 'Withdrawals', roles: ADMIN },
  { href: '/admin/coupons', label: 'Coupons', roles: ADMIN },
  { href: '/admin/promotions', label: 'Promotions', roles: ADMIN },
  { href: '/admin/notifications', label: 'Notifications', roles: ADMIN },
  { href: '/admin/banners', label: 'Product banners', roles: ADMIN },
  { href: '/admin/ads', label: 'Ad network', roles: ADMIN },
  { href: '/admin/settings', label: 'Settings', roles: ADMIN },
  { href: '/admin/logs', label: 'Audit logs', roles: ADMIN },
];
