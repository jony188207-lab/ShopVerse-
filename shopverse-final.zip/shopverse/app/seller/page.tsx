'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useSeller } from '@/components/seller/SellerProvider';
import { PageHead, Stat } from '@/components/seller/ui';
import { ErrorState, LoadingState } from '@/components/ui/States';
import { friendlyError } from '@/lib/firebase/errors';
import { getSellerStats, type SellerStats } from '@/services/sellerService';
import { formatMoney } from '@/utils/money';

export default function Overview() {
  const { uid, store } = useSeller();
  const [s, setS] = useState<SellerStats | null>(null);
  const [err, setErr] = useState('');
  useEffect(() => { getSellerStats(uid).then(setS).catch((e) => setErr(friendlyError(e))); }, [uid]);
  if (err) return <ErrorState message={err} />;
  if (!s) return <LoadingState />;
  const open = s.orders - s.delivered - s.cancelled;
  return (
    <div className="space-y-4">
      <PageHead title={`Welcome, ${store.name}`}><Link href="/seller/products/new" className="rounded-xl bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white">Add product</Link></PageHead>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Products" value={s.products} hint={`${s.approvedProducts} live`} />
        <Stat label="Orders" value={s.orders} hint={`${open} still open`} />
        <Stat label="Available to withdraw" value={formatMoney(s.balance.available)} />
        <Stat label="Pending earnings" value={formatMoney(s.balance.pending)} hint="released after the return window" />
      </div>
      {!s.products ? <p className="rounded-card border border-dashed border-navy-100 p-4 text-sm dark:border-navy-500">You have no products yet. Add your first product; it goes live after review.</p> : null}
    </div>
  );
}
