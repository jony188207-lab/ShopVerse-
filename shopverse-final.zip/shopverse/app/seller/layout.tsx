'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { ReactNode } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { SellerProvider, useSeller } from '@/components/seller/SellerProvider';

const NAV = [
  ['/seller', 'Overview'], ['/seller/products', 'Products'], ['/seller/products/new', 'Add product'], ['/seller/orders', 'Orders'], ['/seller/customers', 'Customers'], ['/seller/reviews', 'Reviews'], ['/seller/videos', 'Videos'], ['/messages', 'Messages'],
  ['/seller/earnings', 'Earnings'], ['/seller/withdrawals', 'Withdrawals'], ['/seller/coupons', 'Coupons'], ['/seller/promotions', 'Promotions'], ['/seller/analytics', 'Analytics'], ['/seller/settings', 'Store settings'],
] as const;

function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const { store } = useSeller();
  const current = [...NAV].sort((a, b) => b[0].length - a[0].length).find(([h]) => (h === '/seller' ? path === '/seller' : path.startsWith(h)))?.[0];
  return (
    <div className="flex flex-col gap-4 px-4 md:flex-row">
      <aside className="md:w-56 md:shrink-0">
        <p className="mb-2 hidden truncate text-sm font-bold md:block">{store.name}</p>
        <nav aria-label="Seller Center" className="flex gap-1 overflow-x-auto pb-1 md:flex-col md:overflow-visible">
          {NAV.map(([href, label]) => (
            <Link key={href} href={href} aria-current={current === href ? 'page' : undefined}
              className={`shrink-0 rounded-lg px-3 py-2 text-sm font-medium ${current === href ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'hover:bg-navy-50 dark:hover:bg-navy-700'}`}>{label}</Link>
          ))}
          <Link href={`/store/${store.slug}`} className="shrink-0 rounded-lg px-3 py-2 text-sm font-medium text-brand-purple">View public store ↗</Link>
        </nav>
      </aside>
      <section className="min-w-0 flex-1">{children}</section>
    </div>
  );
}
export default function SellerLayout({ children }: { children: ReactNode }) {
  return <AuthGuard roles={['seller']} requireVerified><SellerProvider><Shell>{children}</Shell></SellerProvider></AuthGuard>;
}
