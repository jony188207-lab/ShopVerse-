'use client';
import Link from 'next/link';
import { useEffect, useState, type FormEvent } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { Pill, textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { getMyApplication, slugLooksFree, submitApplication, toStoreSlug } from '@/services/sellerService';
import type { SellerApplication, SellerApplicationInput } from '@/types/seller';

const EMPTY: SellerApplicationInput = { storeName: '', slug: '', description: '', phone: '', email: '', country: '', city: '', address: '', returnPolicy: '', shippingInfo: '' };

function Inner() {
  const { user, role } = useAuth(); const toast = useToast();
  const [app, setApp] = useState<SellerApplication | null | undefined>(undefined);
  const [f, setF] = useState<SellerApplicationInput>({ ...EMPTY, email: user?.email ?? '' });
  const [logo, setLogo] = useState<File | null>(null); const [banner, setBanner] = useState<File | null>(null); const [busy, setBusy] = useState(false); const [slugTouched, setSlugTouched] = useState(false);
  const load = () => getMyApplication(user!.uid).then((a) => { setApp(a); if (a) setF({ storeName: a.storeName, slug: a.slug, description: a.description, phone: a.phone, email: a.email, country: a.country, city: a.city, address: a.address, returnPolicy: a.returnPolicy, shippingInfo: a.shippingInfo }); }).catch(() => setApp(null));
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  if (app === undefined) return <LoadingState />;
  if (role === 'seller') return <div className="mx-auto max-w-xl px-4"><Card className="space-y-2"><h1 className="text-xl font-extrabold">You are a seller</h1><Link className="font-semibold text-brand-purple underline" href="/seller">Open the Seller Center</Link></Card></div>;
  if (['moderator', 'admin', 'super_admin'].includes(role)) return <div className="mx-auto max-w-xl px-4"><Card>Staff accounts cannot be converted into seller accounts. Use a separate account to sell.</Card></div>;
  const editable = !app || app.status === 'pending' || app.status === 'rejected';
  const set = (k: keyof SellerApplicationInput) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF((x) => ({ ...x, [k]: e.target.value, ...(k === 'storeName' && !slugTouched ? { slug: toStoreSlug(e.target.value) } : {}) }));
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      if (app?.slug !== toStoreSlug(f.slug) && !(await slugLooksFree(toStoreSlug(f.slug)))) throw new Error('That store address is already taken. Choose another.');
      await submitApplication(user!.uid, f, logo, banner, app ?? null); toast('Application submitted', 'success'); setLogo(null); setBanner(null); await load();
    } catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="mx-auto max-w-2xl space-y-4 px-4">
      <h1 className="text-2xl font-extrabold">Become a seller</h1>
      {app ? <Card className="space-y-1"><p className="flex items-center gap-2 font-semibold">Application status <Pill status={app.status} /></p>
        {app.status === 'pending' ? <p className="text-sm">We are reviewing your application. You can still edit it below; you will get a notification when it is decided.</p> : null}
        {app.status === 'approved' ? <p className="text-sm">Approved! If you cannot see the Seller Center yet, sign out and back in.</p> : null}
        {app.status === 'rejected' ? <p className="text-sm text-red-700">Not approved: {app.reviewNote || 'no reason given'}. Fix the issues below and resubmit.</p> : null}
        {app.status === 'suspended' ? <p className="text-sm text-red-700">Your store is suspended: {app.reviewNote}. Contact support.</p> : null}</Card> : <p className="text-sm">Tell us about your store. An admin reviews every application; submitting does not make you a seller.</p>}
      {!user?.emailVerified ? <p role="alert" className="rounded-card border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">Verify your email first. <Link className="underline" href="/verify-email">Verify now</Link></p> : null}
      {editable ? (
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
          <Field label="Store name" required minLength={2} maxLength={80} value={f.storeName} onChange={set('storeName')} />
          <div><Field label="Store address (shopverse.com/store/…)" required minLength={3} maxLength={40} pattern="[a-z0-9]+(-[a-z0-9]+)*" value={f.slug} onChange={(e) => { setSlugTouched(true); setF({ ...f, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '') }); }} /></div>
          <div className="md:col-span-2"><label htmlFor="bd" className="text-sm font-medium">Store description</label><textarea id="bd" rows={4} maxLength={2000} value={f.description} onChange={set('description')} className={textareaCls} /></div>
          <Field label="Phone" required minLength={5} maxLength={25} autoComplete="tel" value={f.phone} onChange={set('phone')} />
          <Field label="Email" type="email" required value={f.email} onChange={set('email')} />
          <Field label="Country" required minLength={2} value={f.country} onChange={set('country')} />
          <Field label="City" required value={f.city} onChange={set('city')} />
          <div className="md:col-span-2"><Field label="Address" required minLength={3} maxLength={300} value={f.address} onChange={set('address')} /></div>
          <div><label htmlFor="rp" className="text-sm font-medium">Return policy</label><textarea id="rp" rows={3} maxLength={2000} value={f.returnPolicy} onChange={set('returnPolicy')} className={textareaCls} /></div>
          <div><label htmlFor="si" className="text-sm font-medium">Shipping information</label><textarea id="si" rows={3} maxLength={2000} value={f.shippingInfo} onChange={set('shippingInfo')} className={textareaCls} /></div>
          <div><label htmlFor="lg" className="text-sm font-medium">Logo{app?.logoUrl ? ' (saved — pick a file to replace)' : ''}</label><input id="lg" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setLogo(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
          <div><label htmlFor="bn" className="text-sm font-medium">Banner{app?.bannerUrl ? ' (saved — pick a file to replace)' : ''}</label><input id="bn" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setBanner(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
          <div className="md:col-span-2"><Button type="submit" loading={busy} disabled={!user?.emailVerified}>{app ? 'Update application' : 'Submit application'}</Button></div>
        </form>
      ) : null}
    </div>
  );
}
export default function Page() { return <AuthGuard><Inner /></AuthGuard>; }
