'use client';
import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { signUp } from '@/services/authService';
import { friendlyError } from '@/lib/firebase/errors';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';

export default function SignupPage() {
  const router = useRouter();
  const [f, setF] = useState({ displayName: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (f.password.length < 8) return setError('Use a password with at least 8 characters.');
    if (f.password !== f.confirm) return setError('Passwords do not match.');
    setBusy(true);
    try {
      await signUp({ email: f.email, password: f.password, displayName: f.displayName });
      router.replace('/verify-email');
    } catch (err) { setError(friendlyError(err)); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="mx-auto max-w-sm space-y-4 px-4 py-8 animate-fade-up motion-reduce:animate-none" aria-busy={busy}>
      <h1 className="text-2xl font-extrabold">Create your account</h1>
      <Field label="Name" autoComplete="name" required minLength={2} maxLength={60} value={f.displayName} onChange={set('displayName')} />
      <Field label="Email" type="email" autoComplete="email" required value={f.email} onChange={set('email')} />
      <Field label="Password" type="password" autoComplete="new-password" required minLength={8} value={f.password} onChange={set('password')} />
      <Field label="Confirm password" type="password" autoComplete="new-password" required value={f.confirm} onChange={set('confirm')} />
      {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
      <Button type="submit" loading={busy} className="w-full">Create account</Button>
      <p className="text-sm">Already have an account? <Link className="font-semibold text-brand-purple underline" href="/login">Sign in</Link></p>
    </form>
  );
}
