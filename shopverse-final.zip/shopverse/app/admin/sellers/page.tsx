'use client';
import Link from 'next/link';
import { useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { listApplications } from '@/services/sellerAdminService';

export default function Page() {
  const [status, setStatus] = useState('pending');
  const { items, more, error, busy, loadMore } = usePaged((c) => listApplications(status, c), [status]);
  return (
    <div>
      <PageHead title="Seller applications" />
      <label className="mb-3 block text-sm font-medium">Status <select value={status} onChange={(e) => setStatus(e.target.value)} className={selectCls}><option value="">All</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="suspended">Suspended</option></select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No applications">Nothing in this status.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((a) => (
            <li key={a.id}><Link href={`/admin/sellers/${a.id}`} className="flex flex-wrap items-center gap-2 p-3 hover:bg-navy-50 dark:hover:bg-navy-700">
              <div className="min-w-0 flex-1"><p className="font-semibold">{a.storeName}</p><p className="text-xs">/store/{a.slug} · {a.city}, {a.country} · {fmtDate(a.createdAt)}</p></div><Pill status={a.status} />
            </Link></li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
