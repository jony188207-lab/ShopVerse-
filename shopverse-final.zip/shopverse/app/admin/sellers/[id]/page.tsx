'use client';
import Image from 'next/image';
import { useParams } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { PageHead, Pill, fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { getApplicationById, getCommission, getStoreOfOwner, getStorePrivateAdmin, reviewApplication, setCommission } from '@/services/sellerAdminService';
import type { Store } from '@/types';
import type { SellerApplication, StorePrivate } from '@/types/seller';

export default function Page() {
  const { id } = useParams<{ id: string }>(); const { user } = useAuth(); const toast = useToast();
  const [app, setApp] = useState<SellerApplication | null | undefined>(undefined);
  const [store, setStore] = useState<Store | null>(null); const [priv, setPriv] = useState<StorePrivate | null>(null);
  const [busy, setBusy] = useState(false); const [rate, setRate] = useState('');
  const load = useCallback(async () => {
    try {
      const a = await getApplicationById(id); setApp(a);
      if (a) { const s = await getStoreOfOwner(a.id); setStore(s); setPriv(s ? await getStorePrivateAdmin(s.id) : null); if (s) { const c = await getCommission(s.id); if (c !== null) setRate(String(c)); } }
    } catch { setApp(null); }
  }, [id]);
  useEffect(() => { void load(); }, [load]);
  if (app === undefined) return <LoadingState />;
  if (!app) return <EmptyState title="Application not found" />;
  const act = async (action: 'approve' | 'reject' | 'suspend' | 'reactivate') => {
    let note = '';
    if (action === 'reject' || action === 'suspend') { const r = window.prompt(`Reason to ${action} (shown to the seller):`); if (!r || r.trim().length < 5) return toast('A reason of at least 5 characters is required', 'error'); note = r.trim(); }
    else if (!window.confirm(action === 'approve' ? `Approve “${app.storeName}”? This creates the store and gives the user the seller role.` : 'Reactivate this seller and restore their products?')) return;
    setBusy(true);
    try { await reviewApplication(app.id, action, note); toast(`Done: ${action}`, 'success'); await load(); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  const saveRate = async () => { try { await setCommission(user!.uid, store!.id, Number(rate)); toast('Commission updated (applies to future deliveries)', 'success'); } catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : friendlyError(e), 'error'); } };
  return (
    <div className="space-y-4">
      <PageHead title={app.storeName}><Pill status={app.status} /></PageHead>
      <Card className="space-y-2 text-sm">
        <div className="flex gap-3">{app.logoUrl ? <Image src={app.logoUrl} alt="Logo" width={64} height={64} className="h-16 w-16 rounded-full object-cover" /> : null}{app.bannerUrl ? <Image src={app.bannerUrl} alt="Banner" width={240} height={64} className="h-16 w-auto rounded-lg object-cover" /> : null}</div>
        <p><strong>Applicant uid:</strong> {app.id}</p><p><strong>Store address:</strong> /store/{app.slug}</p><p><strong>Phone:</strong> {app.phone} · <strong>Email:</strong> {app.email}</p>
        <p><strong>Location:</strong> {app.address}, {app.city}, {app.country}</p><p><strong>Applied:</strong> {fmtDate(app.createdAt)}</p>
        {app.description ? <p><strong>Description:</strong> {app.description}</p> : null}{app.returnPolicy ? <p><strong>Return policy:</strong> {app.returnPolicy}</p> : null}{app.shippingInfo ? <p><strong>Shipping:</strong> {app.shippingInfo}</p> : null}
        {app.reviewNote ? <p><strong>Last decision note:</strong> {app.reviewNote} ({fmtDate(app.reviewedAt)})</p> : null}
      </Card>
      <div className="flex flex-wrap gap-2">
        {app.status === 'pending' ? <><Button loading={busy} onClick={() => act('approve')}>Approve</Button><Button variant="danger" loading={busy} onClick={() => act('reject')}>Reject</Button></> : null}
        {app.status === 'approved' ? <Button variant="danger" loading={busy} onClick={() => act('suspend')}>Suspend seller</Button> : null}
        {app.status === 'suspended' ? <Button loading={busy} onClick={() => act('reactivate')}>Reactivate</Button> : null}
      </div>
      {store ? (
        <Card className="space-y-2 text-sm"><h2 className="font-semibold">Store</h2><p>Status <Pill status={store.status} /> · {store.followerCount} followers · rating {store.ratingAvg.toFixed(1)} ({store.ratingCount}) · <a className="text-brand-purple underline" href={`/store/${store.slug}`}>public page</a></p>
          {priv ? <p>Private contact: {priv.phone} · {priv.email} · {priv.address}</p> : null}
          <div className="flex items-end gap-2"><Field label="Platform commission %" type="number" min={0} max={50} step="0.5" value={rate} placeholder="10 (default)" onChange={(e) => setRate(e.target.value)} /><Button variant="secondary" onClick={saveRate} disabled={rate === ''}>Save</Button></div></Card>
      ) : null}
    </div>
  );
}
