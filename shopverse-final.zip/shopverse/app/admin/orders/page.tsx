'use client';
import { OrderAdmin } from '@/components/admin/OrderAdmin';
export default function Page() { return <OrderAdmin />; }
