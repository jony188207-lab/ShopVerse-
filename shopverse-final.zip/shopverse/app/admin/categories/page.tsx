'use client';
import Image from 'next/image';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { PageHead, Pill, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { setLiveCategories, type Category } from '@/config/categories';
import { deleteCategory, importDefaults, listCategories, saveCategory, setCategoryActive, swapOrder, type CategoryForm } from '@/services/categoryService';

const EMPTY: CategoryForm = { name: '', order: 0, active: true, parentId: '' };
export default function Page() {
  const { user } = useAuth(); const toast = useToast();
  const [list, setList] = useState<Category[] | null>(null); const [err, setErr] = useState('');
  const [f, setF] = useState<CategoryForm>(EMPTY); const [editId, setEditId] = useState<string | null>(null); const [img, setImg] = useState<File | null>(null); const [busy, setBusy] = useState(false);
  const load = useCallback(() => listCategories().then((l) => { setList(l); if (l.length) setLiveCategories(l); }).catch((e) => { setErr(friendlyError(e)); setList([]); }), []);
  useEffect(() => { void load(); }, [load]);
  const run = async (fn: () => Promise<unknown>, ok: string) => { try { await fn(); toast(ok, 'success'); await load(); } catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : friendlyError(e), 'error'); } };
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    await run(async () => { await saveCategory(user!.uid, editId, f, img, list?.find((c) => c.id === editId)?.imageUrl); setF({ ...EMPTY, order: (list?.length ?? 0) * 10 + 10 }); setEditId(null); setImg(null); }, 'Category saved');
    setBusy(false);
  };
  if (err) return <ErrorState message={err} />;
  if (list === null) return <LoadingState />;
  const tops = list.filter((c) => !c.parentId);
  return (
    <div className="space-y-4">
      <PageHead title="Categories" />
      {!list.length ? <EmptyState title="Using the built-in categories" action={<Button onClick={() => run(() => importDefaults(user!.uid), 'Default categories imported')}>Import the 15 default categories into Firestore</Button>}>Import them to start editing, reordering and adding images or subcategories. Until then the storefront uses the built-in list.</EmptyState> : null}
      <Card>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-4">
          <Field label="Name" required minLength={2} maxLength={60} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <Field label="Order (lower first)" type="number" min={0} step={10} value={f.order} onChange={(e) => setF({ ...f, order: Number(e.target.value) })} />
          <label className="text-sm font-medium">Parent (for a subcategory)<select value={f.parentId} onChange={(e) => setF({ ...f, parentId: e.target.value })} className={`mt-1 w-full ${selectCls}`}><option value="">None (top level)</option>{tops.filter((c) => c.id !== editId).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          <label className="flex min-h-11 items-center gap-2 self-end text-sm"><input type="checkbox" className="h-5 w-5" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />Active</label>
          <div className="md:col-span-2"><label htmlFor="ci" className="text-sm font-medium">Image / icon (max 2 MB)</label><input id="ci" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setImg(e.target.files?.[0] ?? null)} className="block text-sm" /></div>
          <div className="flex gap-2 md:col-span-2 md:items-end"><Button type="submit" loading={busy}>{editId ? 'Save category' : 'Add category'}</Button>{editId ? <Button type="button" variant="ghost" onClick={() => { setEditId(null); setF(EMPTY); }}>Cancel edit</Button> : null}</div>
        </form>
      </Card>
      {list.length ? (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {[...list].sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).map((c) => {
            const siblings = list.filter((x) => (x.parentId ?? '') === (c.parentId ?? '')).sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
            const i = siblings.findIndex((x) => x.id === c.id);
            return (
              <li key={c.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
                <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-navy-100 dark:bg-navy-700">{c.imageUrl ? <Image src={c.imageUrl} alt="" fill sizes="40px" className="object-cover" /> : null}</div>
                <div className="min-w-0 flex-1"><p className="font-semibold">{c.parentId ? '↳ ' : ''}{c.name}</p><p className="text-xs">{c.id} · order {c.order}{c.parentId ? ` · under ${list.find((x) => x.id === c.parentId)?.name ?? c.parentId}` : ''}</p></div>
                <Pill status={c.active ? 'approved' : 'draft'} label={c.active ? 'Active' : 'Inactive'} />
                <Button variant="ghost" disabled={i <= 0} aria-label="Move up" onClick={() => run(() => swapOrder(user!.uid, c, siblings[i - 1]), 'Moved')}>↑</Button>
                <Button variant="ghost" disabled={i < 0 || i >= siblings.length - 1} aria-label="Move down" onClick={() => run(() => swapOrder(user!.uid, c, siblings[i + 1]), 'Moved')}>↓</Button>
                <Button variant="ghost" onClick={() => { setEditId(c.id); setF({ name: c.name, order: c.order ?? 0, active: c.active !== false, parentId: c.parentId ?? '' }); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</Button>
                <Button variant="ghost" onClick={() => run(() => setCategoryActive(user!.uid, c.id, c.active === false), c.active === false ? 'Activated' : 'Deactivated')}>{c.active === false ? 'Activate' : 'Deactivate'}</Button>
                <Button variant="ghost" onClick={() => window.confirm(`Delete ${c.name}? Only possible when no product uses it.`) && run(() => deleteCategory(user!.uid, c.id), 'Deleted')}>Delete</Button>
              </li>
            );
          })}
        </ul>
      ) : null}
    </div>
  );
}
