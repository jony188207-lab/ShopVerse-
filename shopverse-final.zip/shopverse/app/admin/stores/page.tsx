'use client';
import { StoreAdmin } from '@/components/admin/StoreAdmin';
export default function Page() { return <StoreAdmin />; }
