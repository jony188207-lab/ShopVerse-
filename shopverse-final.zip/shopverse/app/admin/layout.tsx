'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { ReactNode } from 'react';
import { AuthGuard } from '@/components/AuthGuard';
import { ErrorState } from '@/components/ui/States';
import { ADMIN_SECTIONS } from '@/config/admin';
import { useAuth } from '@/hooks/useAuth';

function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { role } = useAuth();
  const visible = ADMIN_SECTIONS.filter((s) => s.roles.includes(role));
  // Longest matching href wins so /admin doesn't shadow /admin/ads.
  const current = [...ADMIN_SECTIONS].sort((a, b) => b.href.length - a.href.length).find((s) => (s.href === '/admin' ? pathname === '/admin' : pathname.startsWith(s.href)));
  const allowed = !current || current.roles.includes(role);
  return (
    <div className="flex flex-col gap-4 px-4 md:flex-row">
      <nav aria-label="Admin" className="flex gap-1 overflow-x-auto md:w-52 md:shrink-0 md:flex-col">
        {visible.map((s) => (
          <Link key={s.href} href={s.href} aria-current={current?.href === s.href ? 'page' : undefined}
            className={`shrink-0 rounded-lg px-3 py-2 text-sm font-medium ${current?.href === s.href ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'hover:bg-navy-50 dark:hover:bg-navy-700'}`}>{s.label}</Link>
        ))}
      </nav>
      <section className="min-w-0 flex-1">
        {allowed ? children : <ErrorState title="No access" message="This section needs a higher admin role." />}
      </section>
    </div>
  );
}
export default function AdminLayout({ children }: { children: ReactNode }) {
  return <AuthGuard roles={['moderator', 'admin', 'super_admin']} requireVerified><Shell>{children}</Shell></AuthGuard>;
}
