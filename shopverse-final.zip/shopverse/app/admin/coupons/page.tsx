'use client';
import { useState, type FormEvent } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { listCouponsAdmin, savePlatformCoupon, setCouponActiveAdmin, type AdminCoupon, type PlatformCouponForm } from '@/services/adminDataService';
import { formatMoney } from '@/utils/money';

const EMPTY: PlatformCouponForm = { code: '', discountType: 'percent', discountValue: 10, minOrder: 0, maxDiscount: 0, usageLimit: 0, startsAt: '', endsAt: '', active: true };
const local = (d: Date | null) => (d ? new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '');

export default function Page() {
  const { user } = useAuth(); const toast = useToast();
  const [scope, setScope] = useState<'platform' | 'all'>('platform');
  const { items, more, error, busy, loadMore, reload } = usePaged((c) => listCouponsAdmin(scope, c), [scope]);
  const [f, setF] = useState<PlatformCouponForm>(EMPTY); const [editing, setEditing] = useState(false); const [saving, setSaving] = useState(false);
  const set = <K extends keyof PlatformCouponForm>(k: K, v: PlatformCouponForm[K]) => setF((x) => ({ ...x, [k]: v }));
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setSaving(true);
    try { await savePlatformCoupon(user!.uid, f, editing); toast('Coupon saved', 'success'); setF(EMPTY); setEditing(false); await reload(); } catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setSaving(false); }
  };
  const toggle = async (c: AdminCoupon) => { try { await setCouponActiveAdmin(user!.uid, c.id, !c.active); await reload(); } catch (e) { toast(friendlyError(e), 'error'); } };
  return (
    <div className="space-y-4">
      <PageHead title="Coupons" />
      <p className="text-sm">Platform coupons work in any store&apos;s order and are <strong>funded by the platform</strong> (seller earnings are not reduced). If a store has its own coupon with the same code, the store&apos;s coupon is tried first. Discounts are validated and applied only by the server at checkout.</p>
      <Card>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-3">
          <Field label="Code (A–Z, 0–9)" required disabled={editing} maxLength={20} value={f.code} onChange={(e) => set('code', e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))} />
          <label className="text-sm font-medium">Type<select value={f.discountType} onChange={(e) => set('discountType', e.target.value as 'percent' | 'fixed')} className={`mt-1 w-full ${selectCls}`}><option value="percent">Percent off</option><option value="fixed">Fixed amount off</option></select></label>
          <Field label={f.discountType === 'percent' ? 'Percent (1–100)' : 'Amount off'} type="number" min={0.01} step="0.01" required value={f.discountValue || ''} onChange={(e) => set('discountValue', Number(e.target.value))} />
          <Field label="Minimum store order (0 = none)" type="number" min={0} step="0.01" value={f.minOrder} onChange={(e) => set('minOrder', Number(e.target.value))} />
          <Field label="Max discount per order (0 = no cap)" type="number" min={0} step="0.01" value={f.maxDiscount} onChange={(e) => set('maxDiscount', Number(e.target.value))} />
          <Field label="Usage limit — store orders (0 = unlimited)" type="number" min={0} step={1} value={f.usageLimit} onChange={(e) => set('usageLimit', Number(e.target.value))} />
          <Field label="Starts (optional)" type="datetime-local" value={f.startsAt} onChange={(e) => set('startsAt', e.target.value)} />
          <Field label="Ends (optional)" type="datetime-local" value={f.endsAt} onChange={(e) => set('endsAt', e.target.value)} />
          <label className="flex min-h-11 items-center gap-2 self-end text-sm"><input type="checkbox" className="h-5 w-5" checked={f.active} onChange={(e) => set('active', e.target.checked)} />Active</label>
          <div className="flex gap-2 md:col-span-3"><Button type="submit" loading={saving}>{editing ? 'Save coupon' : 'Create platform coupon'}</Button>{editing ? <Button type="button" variant="ghost" onClick={() => { setEditing(false); setF(EMPTY); }}>Cancel edit</Button> : null}</div>
        </form>
      </Card>
      <label className="block text-sm font-medium">Show <select value={scope} onChange={(e) => setScope(e.target.value as 'platform' | 'all')} className={selectCls}><option value="platform">Platform coupons</option><option value="all">All coupons (incl. sellers&apos;)</option></select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No coupons" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((c) => (
            <li key={c.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1"><p className="font-mono font-bold">{c.code} <span className="font-sans text-xs font-normal">{c.sellerId === 'platform' ? '· platform' : `· store ${c.sellerId.slice(0, 8)}`}</span></p>
                <p className="text-xs">{c.discountType === 'percent' ? `${c.discountValue}% off` : `${formatMoney(c.discountValue)} off`}{c.minOrder ? ` · min ${formatMoney(c.minOrder)}` : ''}{c.maxDiscount ? ` · cap ${formatMoney(c.maxDiscount)}` : ''} · used {c.usedCount}{c.usageLimit ? `/${c.usageLimit}` : ''} · {fmtDate(c.startsAt)} → {fmtDate(c.endsAt)}</p></div>
              <Pill status={c.active ? 'approved' : 'draft'} label={c.active ? 'Active' : 'Inactive'} />
              {c.sellerId === 'platform' ? <Button variant="ghost" onClick={() => { setEditing(true); setF({ code: c.code, discountType: c.discountType, discountValue: c.discountValue, minOrder: c.minOrder, maxDiscount: c.maxDiscount, usageLimit: c.usageLimit, startsAt: local(c.startsAt), endsAt: local(c.endsAt), active: c.active }); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</Button> : null}
              <Button variant="ghost" onClick={() => toggle(c)}>{c.active ? 'Deactivate' : 'Activate'}</Button>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
