'use client';
import { useParams } from 'next/navigation';
import { collection, doc, getDoc, getDocs, limit, orderBy, query } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { PageHead, fmtDate } from '@/components/seller/ui';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { db } from '@/lib/firebase/config';
import { friendlyError } from '@/lib/firebase/errors';
import { logAdmin } from '@/services/adminService';
import { mapConversation, mapMessage } from '@/services/chatService';
import type { ChatMessage, Conversation } from '@/types/chat';

/** Read-only evidence view for report review. Admin/Super admin only (rules); every open is written to the audit log. */
export default function Page() {
  const { id } = useParams<{ id: string }>(); const { user, role } = useAuth();
  const [c, setC] = useState<Conversation | null | undefined>(undefined); const [m, setM] = useState<ChatMessage[]>([]); const [err, setErr] = useState('');
  useEffect(() => {
    if (!user || !['admin', 'super_admin'].includes(role)) return;
    (async () => {
      try {
        const s = await getDoc(doc(db(), 'conversations', id)); if (!s.exists()) return setC(null);
        setC(mapConversation(s.id, s.data()));
        setM((await getDocs(query(collection(db(), 'conversations', id, 'messages'), orderBy('createdAt', 'asc'), limit(200)))).docs.map((d) => mapMessage(d.id, d.data())));
        void logAdmin(user.uid, 'conversation.view', 'conversation', id);
      } catch (e) { setErr(friendlyError(e)); setC(null); }
    })();
  }, [id, user, role]);
  if (!['admin', 'super_admin'].includes(role)) return <ErrorState title="No access" message="Only admins can read conversations." />;
  if (err) return <ErrorState message={err} />;
  if (c === undefined) return <LoadingState />;
  if (!c) return <EmptyState title="Conversation not found" />;
  return (
    <div className="space-y-3">
      <PageHead title="Conversation (read-only)" />
      <p className="text-xs">Buyer {c.buyerId.slice(0, 8)} ↔ seller {c.sellerId.slice(0, 8)} · store {c.storeId.slice(0, 8)}{c.blockedBy.length ? ` · blocked by ${c.blockedBy.map((b) => b.slice(0, 8)).join(', ')}` : ''}. Opening this page was logged.</p>
      <ul className="space-y-2">{m.map((x) => <li key={x.id} className={`max-w-[85%] rounded-xl p-2 text-sm ${x.senderId === c.buyerId ? 'bg-navy-50 dark:bg-navy-700' : 'ml-auto bg-purple-100 text-purple-900'}`}><p className="text-[10px]">{x.senderId === c.buyerId ? 'Buyer' : 'Seller'} · {fmtDate(x.createdAt)}{x.productId ? ` · product ${x.productId.slice(0, 6)}` : ''}{x.orderId ? ` · order ${x.orderId.slice(0, 6)}` : ''}</p><p className="whitespace-pre-wrap break-words">{x.text}</p></li>)}</ul>
    </div>
  );
}
