'use client';
import { useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { listPromotionsAdmin, reviewPromotion } from '@/services/sellerAdminService';
import type { Promotion } from '@/types/seller';

function SellerRequests() {
  const toast = useToast();
  const [status, setStatus] = useState('pending');
  const { items, more, error, busy, loadMore, reload } = usePaged((c) => listPromotionsAdmin(status, c), [status]);
  const act = async (p: Promotion, d: 'approved' | 'rejected') => {
    let note = '';
    if (d === 'rejected') { const r = window.prompt('Reason for rejecting (shown to the seller):'); if (!r || r.trim().length < 5) return toast('A reason of at least 5 characters is required', 'error'); note = r.trim(); }
    try { await reviewPromotion(p.id, d, note); toast(`Promotion ${d}`, 'success'); await reload(); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  return (
    <div>
      <label className="mb-3 block text-sm font-medium">Status <select value={status} onChange={(e) => setStatus(e.target.value)} className={selectCls}><option value="">All</option>{['pending', 'approved', 'rejected', 'cancelled', 'ended'].map((s) => <option key={s} value={s}>{s}</option>)}</select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No requests" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1"><p className="font-semibold">{p.type === 'featured' ? 'Featured' : 'Flash sale'} · <a className="text-brand-purple underline" href={`/product/${p.productId}`}>product</a></p><p className="text-xs">{fmtDate(p.startsAt)} → {fmtDate(p.endsAt)}{p.note ? ` · ${p.note}` : ''}</p></div>
              <Pill status={p.status} />
              {p.status === 'pending' ? <><Button variant="ghost" onClick={() => act(p, 'approved')}>Approve</Button><Button variant="danger" onClick={() => act(p, 'rejected')}>Reject</Button></> : null}
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}


// ---------------- platform campaigns (admin-created; separate from seller requests) ----------------
import { useCallback, useEffect, type FormEvent } from 'react';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { useAuth } from '@/hooks/useAuth';
import { useCategories } from '@/hooks/useCategories';
import { listStores as listStoresAdmin } from '@/services/adminService';
import { searchProducts } from '@/services/productService';
import { deletePlatformPromotion, listPlatformPromotions, savePlatformPromotion, setPlatformPromotionActive, type PPForm, type PlatformPromotion } from '@/services/adminDataService';
import type { Product, Store } from '@/types';

const EMPTY: PPForm = { title: '', type: 'featured', targetType: 'category', productIds: [], categoryId: '', storeOwnerId: '', startsAt: '', endsAt: '', active: true };
const local = (d: Date | null) => (d ? new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '');

function Campaigns() {
  const { user } = useAuth(); const toast = useToast(); const { categories } = useCategories();
  const [list, setList] = useState<PlatformPromotion[] | null>(null); const [err, setErr] = useState('');
  const [f, setF] = useState<PPForm>(EMPTY); const [editId, setEditId] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const [stores, setStores] = useState<Store[]>([]); const [q, setQ] = useState(''); const [found, setFound] = useState<Product[]>([]); const [picked, setPicked] = useState<Record<string, string>>({});
  const load = useCallback(() => listPlatformPromotions().then(setList).catch((e) => { setErr(friendlyError(e)); setList([]); }), []);
  useEffect(() => { void load(); listStoresAdmin().then(setStores).catch(() => undefined); }, [load]);
  useEffect(() => { if (q.trim().length < 2) { setFound([]); return; } const t = setTimeout(() => searchProducts(q, {}, null, 8).then((p) => setFound(p.items)).catch(() => setFound([])), 300); return () => clearTimeout(t); }, [q]);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await savePlatformPromotion(user!.uid, editId, { ...f, productIds: Object.keys(picked) }); toast('Campaign saved', 'success'); setF(EMPTY); setPicked({}); setEditId(null); await load(); }
    catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  const act = async (fn: () => Promise<void>) => { try { await fn(); await load(); } catch (x) { toast(friendlyError(x), 'error'); } };
  return (
    <div className="space-y-4">
      <p className="text-sm">Platform campaigns mark products as <strong>Featured</strong> or put them in the <strong>Flash sale</strong> rail for a time window (max 90 days), targeting chosen products, a whole category, or one seller (up to 100 approved products). They do not change prices — use platform coupons for discounts. Seller requests are a separate list and never mix with these.</p>
      <Card>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
          <Field label="Campaign title" required minLength={2} maxLength={80} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <label className="text-sm font-medium">Effect<select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value as PPForm['type'] })} className={`mt-1 w-full ${selectCls}`}><option value="featured">Featured on Home</option><option value="flash_sale">Flash sale rail</option></select></label>
          <label className="text-sm font-medium">Target<select value={f.targetType} onChange={(e) => setF({ ...f, targetType: e.target.value as PPForm['targetType'] })} className={`mt-1 w-full ${selectCls}`}><option value="category">A category</option><option value="seller">A seller</option><option value="products">Specific products</option></select></label>
          {f.targetType === 'category' ? <label className="text-sm font-medium">Category<select required value={f.categoryId} onChange={(e) => setF({ ...f, categoryId: e.target.value })} className={`mt-1 w-full ${selectCls}`}><option value="">Choose…</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label> : null}
          {f.targetType === 'seller' ? <label className="text-sm font-medium">Seller store<select required value={f.storeOwnerId} onChange={(e) => setF({ ...f, storeOwnerId: e.target.value })} className={`mt-1 w-full ${selectCls}`}><option value="">Choose…</option>{stores.map((s) => <option key={s.id} value={s.ownerId}>{s.name}</option>)}</select></label> : null}
          {f.targetType === 'products' ? (
            <div className="md:col-span-2 space-y-2"><Field label="Find products to add" value={q} onChange={(e) => setQ(e.target.value)} />
              {found.length ? <ul className="rounded-xl border border-navy-100 dark:border-navy-500">{found.map((p) => <li key={p.id}><button type="button" className="block w-full p-2 text-left text-sm hover:bg-navy-50 dark:hover:bg-navy-700" onClick={() => { setPicked((x) => ({ ...x, [p.id]: p.title })); setQ(''); }}>+ {p.title}</button></li>)}</ul> : null}
              <div className="flex flex-wrap gap-1">{Object.entries(picked).map(([id, t]) => <button key={id} type="button" onClick={() => setPicked((x) => { const n = { ...x }; delete n[id]; return n; })} className="rounded-full bg-navy-100 px-3 py-1 text-xs dark:bg-navy-700">{t} ✕</button>)}</div></div>
          ) : null}
          <Field label="Starts" type="datetime-local" required value={f.startsAt} onChange={(e) => setF({ ...f, startsAt: e.target.value })} />
          <Field label="Ends" type="datetime-local" required value={f.endsAt} onChange={(e) => setF({ ...f, endsAt: e.target.value })} />
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />Active</label>
          <div className="flex gap-2 md:col-span-2"><Button type="submit" loading={busy}>{editId ? 'Save campaign' : 'Create campaign'}</Button>{editId ? <Button type="button" variant="ghost" onClick={() => { setEditId(null); setF(EMPTY); setPicked({}); }}>Cancel edit</Button> : null}</div>
        </form>
      </Card>
      {err ? <ErrorState message={err} /> : list === null ? <LoadingState /> : !list.length ? <EmptyState title="No platform campaigns" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {list.map((c) => {
            const now = Date.now(); const state = !c.active ? 'inactive' : c.endsAt && now >= c.endsAt.getTime() ? 'ended' : c.startsAt && now < c.startsAt.getTime() ? 'scheduled' : 'live';
            return (
              <li key={c.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
                <div className="min-w-0 flex-1"><p className="font-semibold">{c.title}</p><p className="text-xs">{c.type === 'featured' ? 'Featured' : 'Flash sale'} · {c.targetType === 'category' ? `category ${c.categoryId}` : c.targetType === 'seller' ? 'one seller' : `${c.productIds.length} product(s)`} · {fmtDate(c.startsAt)} → {fmtDate(c.endsAt)}{c.applied ? ` · applied to ${c.appliedCount}` : ''}</p></div>
                <Pill status={state === 'live' ? 'approved' : state === 'scheduled' ? 'pending' : 'draft'} label={state} />
                <Button variant="ghost" onClick={() => { setEditId(c.id); setF({ title: c.title, type: c.type, targetType: c.targetType, productIds: c.productIds, categoryId: c.categoryId, storeOwnerId: c.storeOwnerId, startsAt: local(c.startsAt), endsAt: local(c.endsAt), active: c.active }); setPicked(Object.fromEntries(c.productIds.map((id) => [id, id]))); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</Button>
                <Button variant="ghost" onClick={() => act(() => setPlatformPromotionActive(user!.uid, c.id, !c.active))}>{c.active ? 'Deactivate' : 'Activate'}</Button>
                <Button variant="ghost" onClick={() => window.confirm('Delete this campaign? Products it applied are un-featured.') && act(() => deletePlatformPromotion(user!.uid, c.id))}>Delete</Button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

export default function Page() {
  const [tab, setTab] = useState<'campaigns' | 'requests'>('campaigns');
  return (
    <div className="space-y-3">
      <PageHead title="Promotions" />
      <div role="tablist" className="flex gap-1">{([['campaigns', 'Platform campaigns'], ['requests', 'Seller requests']] as const).map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`rounded-lg px-4 py-2 text-sm font-semibold ${tab === k ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'hover:bg-navy-50 dark:hover:bg-navy-700'}`}>{l}</button>)}</div>
      {tab === 'campaigns' ? <Campaigns /> : <SellerRequests />}
    </div>
  );
}
