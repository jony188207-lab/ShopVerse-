'use client';
import Link from 'next/link';
import { useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls, textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { REPORT_LABEL, REPORT_TARGETS, hideReportedContent, listReports, reportTargetLink, updateReport, type Report, type ReportStatus } from '@/services/adminDataService';

const TONE: Record<ReportStatus, string> = { open: 'pending', under_review: 'processing', resolved: 'approved', rejected: 'rejected' };

function Row({ r, onChanged }: { r: Report; onChanged: (r: Report) => void }) {
  const { user } = useAuth(); const toast = useToast();
  const [note, setNote] = useState(r.internalNote); const [busy, setBusy] = useState(false);
  const go = async (status: ReportStatus, action = '') => {
    setBusy(true);
    try {
      if (action === 'hide_content') await hideReportedContent(user!.uid, r);
      await updateReport(user!.uid, r, { status, internalNote: note, action: action || r.action, resolution: action === 'hide_content' ? 'Content hidden' : undefined });
      onChanged({ ...r, status, internalNote: note, action: action || r.action }); toast('Report updated', 'success');
    } catch (e) { toast(e instanceof Error && !('code' in e) ? e.message : friendlyError(e), 'error'); } finally { setBusy(false); }
  };
  const closed = r.status === 'resolved' || r.status === 'rejected';
  return (
    <li className="space-y-2 p-3 text-sm">
      <div className="flex flex-wrap items-center gap-2"><Pill status={TONE[r.status]} label={REPORT_LABEL[r.status]} /><span className="font-semibold capitalize">{r.targetType}</span><span className="text-xs">{fmtDate(r.createdAt)} · reporter {r.reporterId.slice(0, 8)}</span><Link href={reportTargetLink(r)} className="text-xs font-semibold text-brand-purple underline">Open target</Link></div>
      <p><strong>Reason:</strong> {r.reason}</p>
      {r.evidence ? <pre className="whitespace-pre-wrap rounded-lg bg-navy-50 p-2 text-xs dark:bg-navy-700">{r.evidence}</pre> : null}
      {r.action ? <p className="text-xs">Action taken: {r.action.replace('_', ' ')}</p> : null}
      <label className="block text-xs font-medium">Internal note (staff only)<textarea rows={2} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)} className={textareaCls} /></label>
      <div className="flex flex-wrap gap-1">
        {r.status === 'open' ? <Button variant="ghost" loading={busy} onClick={() => go('under_review')}>Start review</Button> : null}
        {!closed && (r.targetType === 'review' || r.targetType === 'comment') ? <Button variant="danger" loading={busy} onClick={() => window.confirm('Hide the reported content and resolve this report?') && go('resolved', 'hide_content')}>Hide content &amp; resolve</Button> : null}
        {!closed ? <Button variant="secondary" loading={busy} onClick={() => go('resolved')}>Resolve</Button> : null}
        {!closed ? <Button variant="ghost" loading={busy} onClick={() => go('rejected')}>Reject report</Button> : <Button variant="ghost" loading={busy} onClick={() => go('under_review')}>Reopen</Button>}
        {closed || note !== r.internalNote ? <Button variant="ghost" loading={busy} onClick={() => go(r.status)}>Save note</Button> : null}
      </div>
    </li>
  );
}

export default function Page() {
  const [status, setStatus] = useState('open'); const [type, setType] = useState('');
  const { items, setItems, more, error, busy, loadMore } = usePaged((c) => listReports(status, type, c), [status, type]);
  return (
    <div>
      <PageHead title="Reports & moderation" />
      <div className="mb-3 flex flex-wrap gap-2">
        <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status" className={selectCls}><option value="">All statuses</option>{(Object.keys(REPORT_LABEL) as ReportStatus[]).map((s) => <option key={s} value={s}>{REPORT_LABEL[s]}</option>)}</select>
        <select value={type} onChange={(e) => setType(e.target.value)} aria-label="Type" className={selectCls}><option value="">All types</option>{REPORT_TARGETS.map((t) => <option key={t} value={t}>{t}</option>)}</select>
      </div>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No reports" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">{items.map((r) => <Row key={r.id} r={r} onChanged={(n) => setItems((l) => l?.map((i) => (i.id === n.id ? n : i)) ?? null)} />)}</ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
