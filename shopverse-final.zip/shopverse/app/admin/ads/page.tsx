'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { AdFrame } from '@/components/AdNetworkBanner';
import { PageHead, Pill, fmtDate, selectCls, textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { deleteAd, listAds, saveAd, setAdActive, type AdConfig, type AdForm } from '@/services/adminDataService';

const EMPTY: AdForm = { networkName: '', adCode: '', adUrl: '', device: 'all', width: 320, height: 50, active: false, startDate: '', endDate: '' };
const local = (d: Date | null) => (d ? new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '');

export default function Page() {
  const { user, role } = useAuth(); const toast = useToast();
  const isSuper = role === 'super_admin';
  const [list, setList] = useState<AdConfig[] | null>(null); const [err, setErr] = useState('');
  const [f, setF] = useState<AdForm>(EMPTY); const [editId, setEditId] = useState<string | null>(null); const [busy, setBusy] = useState(false); const [preview, setPreview] = useState(false);
  const load = useCallback(() => listAds().then(setList).catch((e) => { setErr(friendlyError(e)); setList([]); }), []);
  useEffect(() => { void load(); }, [load]);
  const set = <K extends keyof AdForm>(k: K, v: AdForm[K]) => { setF((x) => ({ ...x, [k]: v })); setPreview(false); };
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await saveAd(user!.uid, editId, f); toast('Ad saved', 'success'); setF(EMPTY); setEditId(null); setPreview(false); await load(); } catch (x) { toast(x instanceof Error && !('code' in x) ? x.message : friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  const act = async (fn: () => Promise<void>) => { try { await fn(); await load(); } catch (x) { toast(friendlyError(x), 'error'); } };
  if (err) return <ErrorState message={err} />;
  if (list === null) return <LoadingState />;
  return (
    <div className="space-y-4">
      <PageHead title="Ad network (bottom banner)" />
      <Card className="space-y-1 text-sm">
        <p>Paste the embed code your ad network gives you, or an https ad URL. No network is built in. The ad appears at the bottom of storefront pages (not in checkout, seller or admin areas), never over the navigation or buttons.</p>
        <p><strong>Safety:</strong> ad code runs inside a sandboxed frame <em>without</em> access to ShopVerse cookies, storage or pages. Only a <strong>super admin</strong> can add or change code; any admin can pause an ad. Global on/off is in Settings.</p>
        <p><strong>Network rules:</strong> some networks (e.g. ones that require their tag on your own page, or that forbid iframes/custom wrappers) will not serve or may violate policy inside a sandboxed frame. Check your network&apos;s terms; use a network that supports iframe/HTML ad units. Banners also need a size that matches the unit you bought (320×50 mobile, 728×90 desktop are common).</p>
      </Card>
      {isSuper ? (
        <Card>
          <form onSubmit={submit} className="grid gap-3 md:grid-cols-3">
            <Field label="Network name" required maxLength={60} value={f.networkName} onChange={(e) => set('networkName', e.target.value)} />
            <label className="text-sm font-medium">Show on<select value={f.device} onChange={(e) => set('device', e.target.value as AdForm['device'])} className={`mt-1 w-full ${selectCls}`}><option value="all">Mobile + desktop</option><option value="mobile">Mobile only</option><option value="desktop">Desktop only</option></select></label>
            <div className="grid grid-cols-2 gap-2"><Field label="Width px" type="number" min={50} max={1200} value={f.width} onChange={(e) => set('width', Number(e.target.value))} /><Field label="Height px" type="number" min={30} max={600} value={f.height} onChange={(e) => set('height', Number(e.target.value))} /></div>
            <div className="md:col-span-3"><label htmlFor="ac" className="text-sm font-medium">Ad code (HTML / script / iframe embed from your network)</label><textarea id="ac" rows={5} spellCheck={false} value={f.adCode} onChange={(e) => set('adCode', e.target.value)} className={`${textareaCls} font-mono text-xs`} /></div>
            <div className="md:col-span-3"><Field label="…or external ad URL (https only, used when no code is pasted)" type="url" value={f.adUrl} onChange={(e) => set('adUrl', e.target.value)} /></div>
            <Field label="Starts (optional)" type="datetime-local" value={f.startDate} onChange={(e) => set('startDate', e.target.value)} />
            <Field label="Ends (optional)" type="datetime-local" value={f.endDate} onChange={(e) => set('endDate', e.target.value)} />
            <label className="flex min-h-11 items-center gap-2 self-end text-sm"><input type="checkbox" className="h-5 w-5" checked={f.active} onChange={(e) => set('active', e.target.checked)} />Active</label>
            <div className="flex flex-wrap gap-2 md:col-span-3"><Button type="submit" loading={busy}>{editId ? 'Save ad' : 'Add ad'}</Button><Button type="button" variant="secondary" onClick={() => setPreview((p) => !p)}>{preview ? 'Hide preview' : 'Preview'}</Button>{editId ? <Button type="button" variant="ghost" onClick={() => { setEditId(null); setF(EMPTY); setPreview(false); }}>Cancel edit</Button> : null}</div>
          </form>
          {preview ? <div className="mt-3 rounded-xl border border-dashed border-navy-100 dark:border-navy-500"><AdFrame ad={{ id: 'preview', networkName: f.networkName, adCode: f.adCode || undefined, adUrl: f.adUrl || undefined, width: f.width, height: f.height }} /></div> : null}
        </Card>
      ) : <p className="rounded-card border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">You can pause or resume ads. Adding or editing ad code requires a super admin.</p>}
      {!list.length ? <EmptyState title="No ads configured">The bottom ad slot stays empty until one is active.</EmptyState> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {list.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center gap-2 p-3 text-sm">
              <div className="min-w-0 flex-1"><p className="font-semibold">{a.networkName}</p><p className="text-xs">{a.device} · {a.width}×{a.height} · {a.adCode ? 'embed code' : 'URL'} · {fmtDate(a.startDate)} → {fmtDate(a.endDate)}</p></div>
              <Pill status={a.active ? 'approved' : 'draft'} label={a.active ? 'Active' : 'Paused'} />
              <Button variant="ghost" onClick={() => act(() => setAdActive(user!.uid, a.id, !a.active))}>{a.active ? 'Pause' : 'Activate'}</Button>
              {isSuper ? <><Button variant="ghost" onClick={() => { setEditId(a.id); setF({ networkName: a.networkName, adCode: a.adCode, adUrl: a.adUrl, device: a.device, width: a.width, height: a.height, active: a.active, startDate: local(a.startDate), endDate: local(a.endDate) }); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</Button>
                <Button variant="ghost" onClick={() => window.confirm(`Delete the ${a.networkName} ad?`) && act(() => deleteAd(user!.uid, a.id))}>Delete</Button></> : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
