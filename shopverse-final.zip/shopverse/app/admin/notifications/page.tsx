'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { PageHead, fmtDate, selectCls, textareaCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { listAnnouncements, sendAnnouncement, type Announcement } from '@/services/adminDataService';

export default function Page() {
  const toast = useToast();
  const [list, setList] = useState<Announcement[] | null>(null);
  const [f, setF] = useState({ audience: 'all' as 'all' | 'sellers' | 'user', kind: 'promotion' as 'promotion' | 'important', userId: '', title: '', body: '', link: '' }); const [busy, setBusy] = useState(false);
  const load = useCallback(() => listAnnouncements().then(setList).catch(() => setList([])), []);
  useEffect(() => { void load(); }, [load]);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const who = f.audience === 'all' ? 'ALL active users' : f.audience === 'sellers' ? 'all sellers' : 'this user';
    if (!window.confirm(`Send this announcement to ${who}? It cannot be recalled.`)) return;
    setBusy(true);
    try { const r = await sendAnnouncement({ ...f, userId: f.audience === 'user' ? f.userId.trim() : undefined, link: f.link.trim() || undefined }); toast(`Sent to ${r.data.recipients} recipient(s)`, 'success'); setF({ ...f, title: '', body: '', link: '' }); await load(); }
    catch (x) { toast(friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <PageHead title="Notifications" />
      <p className="text-sm">Order, seller, product, withdrawal, review and promotion notifications are sent automatically by the platform. Use this page for announcements (in-app, shown under the bell; up to 5,000 recipients each).</p>
      <Card>
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
          <label className="text-sm font-medium">Audience<select value={f.audience} onChange={(e) => setF({ ...f, audience: e.target.value as typeof f.audience })} className={`mt-1 w-full ${selectCls}`}><option value="all">All active users</option><option value="sellers">All sellers</option><option value="user">One user (by uid)</option></select></label>
          <label className="text-sm font-medium">Type<select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value as typeof f.kind })} className={`mt-1 w-full ${selectCls}`}><option value="promotion">Promotion (users can turn it off)</option><option value="important">Important notice (always delivered)</option></select></label>
          {f.audience === 'user' ? <Field label="User uid" required value={f.userId} onChange={(e) => setF({ ...f, userId: e.target.value })} /> : <Field label="Link (optional, e.g. /shop)" value={f.link} onChange={(e) => setF({ ...f, link: e.target.value })} />}
          <div className="md:col-span-2"><Field label="Title" required minLength={3} maxLength={80} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div className="md:col-span-2"><label htmlFor="nb" className="text-sm font-medium">Message</label><textarea id="nb" rows={3} required minLength={3} maxLength={400} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} className={textareaCls} /></div>
          <div className="md:col-span-2"><Button type="submit" loading={busy}>Send announcement</Button></div>
        </form>
      </Card>
      <h2 className="text-lg font-bold">History</h2>
      {list === null ? <LoadingState /> : !list.length ? <EmptyState title="No announcements sent yet" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">{list.map((a) => <li key={a.id} className="p-3 text-sm"><p className="font-semibold">{a.title}</p><p>{a.body}</p><p className="text-xs">{fmtDate(a.createdAt)} · {a.audience} · {a.recipients} recipients</p></li>)}</ul>
      )}
    </div>
  );
}
