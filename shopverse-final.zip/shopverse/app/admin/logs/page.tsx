'use client';
import { PageHead, fmtDate } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { listLogs } from '@/services/sellerAdminService';

export default function Page() {
  const { items, more, error, busy, loadMore } = usePaged((c) => listLogs(c), []);
  return (
    <div>
      <PageHead title="Audit logs" />
      <p className="mb-3 text-sm">Append-only. Nobody can edit or delete entries from the app.</p>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No entries yet" /> : (
        <div className="overflow-x-auto rounded-card border border-navy-100 dark:border-navy-500"><table className="w-full min-w-[560px] text-left text-sm"><thead className="bg-navy-50 dark:bg-navy-700"><tr><th className="p-2">When</th><th className="p-2">Action</th><th className="p-2">Target</th><th className="p-2">By</th><th className="p-2">Note</th></tr></thead>
          <tbody>{items.map((l) => <tr key={l.id} className="border-t border-navy-100 dark:border-navy-500"><td className="p-2">{fmtDate(l.createdAt)}</td><td className="p-2 font-mono text-xs">{l.action}</td><td className="p-2 text-xs">{l.targetType}/{l.targetId.slice(0, 12)}</td><td className="p-2 text-xs">{l.adminId.slice(0, 8)}</td><td className="p-2 text-xs">{l.note}</td></tr>)}</tbody></table></div>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
