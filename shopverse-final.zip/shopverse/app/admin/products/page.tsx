'use client';
import { ProductAdmin } from '@/components/admin/ProductAdmin';
export default function Page() { return <ProductAdmin />; }
