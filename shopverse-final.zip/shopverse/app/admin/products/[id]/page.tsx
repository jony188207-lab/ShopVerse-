'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { ProductForm } from '@/components/admin/ProductForm';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { getProductAdmin } from '@/services/adminService';
import type { Product } from '@/types';

export default function EditProductPage() {
  const { id } = useParams<{ id: string }>();
  const [p, setP] = useState<Product | null | undefined>(undefined);
  useEffect(() => { getProductAdmin(id).then(setP).catch(() => setP(null)); }, [id]);
  return (
    <AuthGuard roles={['admin', 'super_admin']}>
      {p === undefined ? <LoadingState /> : !p ? <EmptyState title="Product not found" /> : <div className="space-y-3"><h1 className="text-2xl font-extrabold">Edit product</h1><ProductForm existing={p} /></div>}
    </AuthGuard>
  );
}
