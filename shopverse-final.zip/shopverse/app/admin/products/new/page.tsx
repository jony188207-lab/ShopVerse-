'use client';
import { ProductForm } from '@/components/admin/ProductForm';
import { AuthGuard } from '@/components/AuthGuard';
export default function Page() { return <AuthGuard roles={['admin', 'super_admin']}><div className="space-y-3"><h1 className="text-2xl font-extrabold">Add product</h1><ProductForm existing={null} /></div></AuthGuard>; }
