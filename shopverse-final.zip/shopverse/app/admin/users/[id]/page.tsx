'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { getUserDetail, setUserRole, setUserStatus } from '@/services/adminDataService';

type Detail = Awaited<ReturnType<typeof getUserDetail>>;
export default function Page() {
  const { id } = useParams<{ id: string }>(); const { role: myRole } = useAuth(); const toast = useToast();
  const [d, setD] = useState<Detail | null | undefined>(undefined); const [busy, setBusy] = useState(false); const [newRole, setNewRole] = useState('user');
  const load = useCallback(() => getUserDetail(id).then((x) => { setD(x.user ? x : null); setNewRole(x.role === 'moderator' || x.role === 'admin' ? x.role : 'user'); }).catch(() => setD(null)), [id]);
  useEffect(() => { void load(); }, [load]);
  if (d === undefined) return <LoadingState />;
  if (!d?.user) return <EmptyState title="User not found" />;
  const u = d.user;
  const run = async (fn: () => Promise<unknown>, ok: string) => { setBusy(true); try { await fn(); toast(ok, 'success'); await load(); } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); } };
  const suspend = () => { const r = window.prompt(`Reason for suspending ${u.email}? They are signed out and cannot sign in.`); if (!r || r.trim().length < 5) return toast('A reason of at least 5 characters is required', 'error'); void run(() => setUserStatus(u.id, 'suspended', r.trim()), 'User suspended'); };
  return (
    <div className="space-y-4">
      <PageHead title={u.displayName || u.email}><Pill status={u.status === 'suspended' ? 'suspended' : 'approved'} label={u.status} /></PageHead>
      <Card className="space-y-1 text-sm">
        <p><strong>Email:</strong> {u.email}</p><p><strong>Joined:</strong> {fmtDate(u.createdAt)}</p><p><strong>Role:</strong> {d.role.replace('_', ' ')}{d.applicationStatus ? ` · seller application ${d.applicationStatus}` : ''}</p>
        {u.suspendReason ? <p className="text-red-700"><strong>Suspension reason:</strong> {u.suspendReason}</p> : null}
        <p className="pt-1 text-xs text-navy-500 dark:text-navy-100">Phone numbers and addresses are not shown here.</p>
      </Card>
      <div className="grid grid-cols-3 gap-3 text-center">
        <Card><p className="text-2xl font-extrabold">{d.orders}</p><p className="text-xs">orders placed</p></Card><Card><p className="text-2xl font-extrabold">{d.reviews}</p><p className="text-xs">reviews</p></Card><Card><p className="text-2xl font-extrabold">{d.reportsAgainst}</p><p className="text-xs">reports against</p></Card>
      </div>
      {d.applicationStatus ? <Link className="text-sm font-semibold text-brand-purple underline" href={`/admin/sellers/${u.id}`}>Open seller application / store</Link> : null}
      {d.role === 'user' ? (u.status === 'suspended' ? <Button loading={busy} onClick={() => run(() => setUserStatus(u.id, 'active'), 'User reactivated')}>Reactivate user</Button> : <Button variant="danger" loading={busy} onClick={suspend}>Suspend user</Button>) : <p className="text-sm">Staff and sellers cannot be suspended from this page.</p>}
      {myRole === 'super_admin' && (d.role === 'user' || d.role === 'moderator' || d.role === 'admin') ? (
        <Card className="space-y-2"><h2 className="font-semibold">Staff role (super admin)</h2>
          <div className="flex items-end gap-2"><select value={newRole} onChange={(e) => setNewRole(e.target.value)} className={selectCls}><option value="user">User</option><option value="moderator">Moderator</option><option value="admin">Admin</option></select>
            <Button variant="secondary" loading={busy} disabled={newRole === d.role} onClick={() => run(() => setUserRole(u.id, newRole as 'user' | 'moderator' | 'admin'), 'Role updated')}>Save role</Button></div>
          <p className="text-xs">Moderators can moderate products, reviews, videos, comments and reports only. Super admins are created in the Firebase Console.</p></Card>
      ) : null}
    </div>
  );
}
