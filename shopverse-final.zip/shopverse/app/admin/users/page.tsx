'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { listUsers } from '@/services/adminDataService';

export default function Page() {
  const [input, setInput] = useState(''); const [term, setTerm] = useState(''); const [status, setStatus] = useState('');
  useEffect(() => { const t = setTimeout(() => setTerm(input), 400); return () => clearTimeout(t); }, [input]);   // debounce
  const { items, more, error, busy, loadMore } = usePaged((c) => listUsers(term, status, c), [term, status]);
  return (
    <div>
      <PageHead title="Users" />
      <div className="mb-3 flex flex-wrap gap-2">
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Search email (prefix) or name (case-sensitive prefix)" aria-label="Search users" className="min-h-11 min-w-0 flex-1 rounded-xl border border-navy-100 bg-white px-3 dark:border-navy-500 dark:bg-navy-900" />
        <select value={status} onChange={(e) => setStatus(e.target.value)} disabled={!!term} aria-label="Status" className={selectCls}><option value="">All</option><option value="active">Active</option><option value="suspended">Suspended</option></select>
      </div>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No users found" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((u) => (
            <li key={u.id}><Link href={`/admin/users/${u.id}`} className="flex flex-wrap items-center gap-2 p-3 hover:bg-navy-50 dark:hover:bg-navy-700">
              <div className="min-w-0 flex-1"><p className="truncate font-semibold">{u.displayName || '(no name)'}</p><p className="truncate text-xs">{u.email} · joined {fmtDate(u.createdAt)}</p></div><Pill status={u.status === 'suspended' ? 'suspended' : 'approved'} label={u.status} />
            </Link></li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
