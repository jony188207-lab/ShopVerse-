'use client';
import Link from 'next/link';
import { useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { listVideosAdmin, moderateVideo, type AdminVideo } from '@/services/adminDataService';
import { VIDEO_STATUS_LABEL, type VideoStatus } from '@/types/video';

export default function Page() {
  const { user } = useAuth(); const toast = useToast();
  const [status, setStatus] = useState('pending_review');
  const { items, setItems, more, error, busy, loadMore } = usePaged((c) => listVideosAdmin(status, c), [status]);
  const act = async (v: AdminVideo, next: 'published' | 'rejected' | 'suspended', restore = false) => {
    let note = '';
    if (next !== 'published') { const r = window.prompt(`Reason to ${next === 'rejected' ? 'reject' : 'suspend'} “${v.title}” (shown to the seller):`); if (!r || r.trim().length < 5) return toast('A reason of at least 5 characters is required', 'error'); note = r.trim(); }
    try { await moderateVideo(user!.uid, v.id, next, note, restore); setItems((l) => (status ? l?.filter((x) => x.id !== v.id) : l?.map((x) => (x.id === v.id ? { ...x, status: next } : x))) ?? null); toast('Updated', 'success'); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  return (
    <div>
      <PageHead title="Videos" />
      <label className="mb-3 block text-sm font-medium">Status <select value={status} onChange={(e) => setStatus(e.target.value)} className={selectCls}><option value="">All</option>{(Object.keys(VIDEO_STATUS_LABEL) as VideoStatus[]).map((s) => <option key={s} value={s}>{VIDEO_STATUS_LABEL[s]}</option>)}</select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No videos here" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((v) => (
            <li key={v.id} className="flex flex-wrap gap-3 p-3 text-sm">
              <video src={v.videoUrl} poster={v.thumbnailUrl || undefined} controls preload="none" playsInline className="h-48 w-28 shrink-0 rounded-lg bg-black object-cover" />
              <div className="min-w-0 flex-1 space-y-1">
                <p className="font-semibold">{v.title || v.id}</p>{v.description ? <p className="line-clamp-3 text-xs">{v.description}</p> : null}
                <p className="text-xs">{fmtDate(v.createdAt)} · {v.visibility} · seller {v.ownerId.slice(0, 8)} · {v.productIds.length} linked product(s){v.productIds.length ? <> · <Link className="text-brand-purple underline" href={`/product/${v.productIds[0]}`}>first product</Link></> : null}</p>
                {v.moderationNote ? <p className="text-xs">Last note: {v.moderationNote}</p> : null}
                <div className="flex flex-wrap items-center gap-1"><Pill status={v.status === 'pending_review' ? 'pending' : v.status === 'published' ? 'approved' : v.status} label={VIDEO_STATUS_LABEL[v.status as VideoStatus] ?? v.status} />
                  {v.status === 'pending_review' || v.status === 'rejected' ? <Button variant="ghost" onClick={() => act(v, 'published')}>Approve</Button> : null}
                  {v.status === 'pending_review' ? <Button variant="ghost" onClick={() => act(v, 'rejected')}>Reject</Button> : null}
                  {v.status === 'published' ? <Button variant="danger" onClick={() => act(v, 'suspended')}>Suspend</Button> : null}
                  {v.status === 'suspended' ? <Button variant="secondary" onClick={() => act(v, 'published', true)}>Restore</Button> : null}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
