'use client';
import { useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { StarRating } from '@/components/StarRating';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { listReviewsAdmin, moderateReview } from '@/services/adminDataService';
import type { Review } from '@/types';

export default function Page() {
  const { user } = useAuth(); const toast = useToast();
  const [status, setStatus] = useState('published');
  const { items, setItems, more, error, busy, loadMore } = usePaged((c) => listReviewsAdmin(status, c), [status]);
  const act = async (r: Review, next: 'published' | 'hidden') => {
    let note = '';
    if (next === 'hidden') { const x = window.prompt('Reason for hiding this review:'); if (!x || x.trim().length < 5) return toast('A reason of at least 5 characters is required', 'error'); note = x.trim(); }
    try { await moderateReview(user!.uid, r.id, next, note); setItems((l) => l?.filter((i) => i.id !== r.id) ?? null); toast(next === 'hidden' ? 'Review hidden' : 'Review restored', 'success'); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  return (
    <div>
      <PageHead title="Reviews" />
      <label className="mb-3 block text-sm font-medium">Status <select value={status} onChange={(e) => setStatus(e.target.value)} className={selectCls}><option value="published">Published</option><option value="hidden">Hidden / removed</option></select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No reviews here" /> : (
        <ul className="space-y-3">
          {items.map((r) => (
            <li key={r.id} className="space-y-2 rounded-card border border-navy-100 p-3 text-sm dark:border-navy-500">
              <div className="flex flex-wrap items-center gap-2"><StarRating value={r.rating} />{r.verifiedPurchase ? <Pill status="approved" label="Verified purchase" /> : null}<Pill status={r.status === 'published' ? 'approved' : 'suspended'} label={r.status} /><span className="text-xs">{r.userName} · {fmtDate(r.createdAt)} · <a className="text-brand-purple underline" href={`/product/${r.productId}`}>product</a></span></div>
              {r.text ? <p>{r.text}</p> : null}
              {r.images.length ? <div className="flex gap-2">{r.images.map((u) => <a key={u} href={u} target="_blank" rel="noreferrer" className="text-xs text-brand-purple underline">image</a>)}</div> : null}
              {r.sellerResponse ? <p className="rounded-lg bg-navy-50 p-2 dark:bg-navy-700"><strong>Seller response:</strong> {r.sellerResponse}</p> : null}
              {r.status === 'published' ? <Button variant="danger" onClick={() => act(r, 'hidden')}>Hide</Button> : <Button variant="secondary" onClick={() => act(r, 'published')}>Restore</Button>}
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
