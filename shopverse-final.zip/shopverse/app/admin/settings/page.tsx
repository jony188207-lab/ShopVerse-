'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { PageHead } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { migrateStoreFinance } from '@/services/sellerAdminService';
import { DEFAULT_PLATFORM, DEFAULT_PUBLIC, getPlatformSettings, getPublicSettings, saveSettings, type PlatformSettings, type PublicSettings } from '@/services/adminDataService';

export default function Page() {
  const { user, role } = useAuth(); const toast = useToast(); const isSuper = role === 'super_admin';
  const [p, setP] = useState<PlatformSettings | null>(null); const [pub, setPub] = useState<PublicSettings>(DEFAULT_PUBLIC); const [busy, setBusy] = useState(false);
  useEffect(() => { Promise.all([getPlatformSettings().catch(() => DEFAULT_PLATFORM), getPublicSettings()]).then(([a, b]) => { setP(a); setPub(b); }); }, []);
  if (!p) return <LoadingState />;
  const num = <K extends keyof PlatformSettings>(k: K) => (e: React.ChangeEvent<HTMLInputElement>) => setP({ ...p, [k]: Number(e.target.value) });
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await saveSettings(user!.uid, { ...p, earningsHoldDays: Math.floor(p.earningsHoldDays), promotionMaxDays: Math.floor(p.promotionMaxDays) }, { ...pub, bannerRotateSeconds: Math.floor(pub.bannerRotateSeconds) }); toast('Settings saved', 'success'); }
    catch (x) { toast(friendlyError(x), 'error'); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-4">
      <PageHead title="Settings" />
      {!isSuper ? <p className="rounded-card border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">View only. Only a super admin can change settings.</p> : null}
      <fieldset disabled={!isSuper || busy} className="space-y-4">
        <Card className="space-y-3"><h2 className="font-semibold">Commission &amp; payouts</h2>
          <div className="grid gap-3 md:grid-cols-3">
            <Field label="Default commission % (new stores)" type="number" min={0} max={50} step="0.5" value={p.commissionDefaultPercent} onChange={num('commissionDefaultPercent')} />
            <Field label="Earnings hold (days)" type="number" min={0} max={60} step={1} value={p.earningsHoldDays} onChange={num('earningsHoldDays')} />
            <Field label="Minimum withdrawal" type="number" min={1} step="0.01" value={p.minWithdrawal} onChange={num('minWithdrawal')} />
          </div>
          <p className="text-xs">Changing the default affects stores approved afterwards; each store&apos;s own rate is edited on its seller page. The hold applies to earnings created after the change.</p></Card>
        <Card className="space-y-3"><h2 className="font-semibold">Promotions &amp; banners</h2>
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Max length of a seller promotion (days, 1–14)" type="number" min={1} max={14} step={1} value={p.promotionMaxDays} onChange={num('promotionMaxDays')} />
            <Field label="Banner rotation (seconds, 2–30)" type="number" min={2} max={30} step={1} value={pub.bannerRotateSeconds} onChange={(e) => setPub({ ...pub, bannerRotateSeconds: Number(e.target.value) })} />
          </div></Card>
        <Card className="space-y-3"><h2 className="font-semibold">Advertising &amp; notifications</h2>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={pub.adsEnabled} onChange={(e) => setPub({ ...pub, adsEnabled: e.target.checked })} />Show the bottom ad on the storefront (master switch)</label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={p.pushEnabled} onChange={(e) => setP({ ...p, pushEnabled: e.target.checked })} />Send push notifications (in-app notifications are always created)</label></Card>
        {isSuper ? <Button type="submit" loading={busy}>Save settings</Button> : null}
        {isSuper ? <Button type="button" variant="ghost" disabled={busy} onClick={async () => { try { const r = await migrateStoreFinance(); toast(`Moved ${r.data.moved} store commission value(s) out of public documents`, 'success'); } catch (x) { toast(friendlyError(x), 'error'); } }}>Move legacy commission fields</Button> : null}
      </fieldset>
      <p className="text-xs text-navy-500 dark:text-navy-100">Only settings that the platform actually uses are listed. Commission and payout rules live in an admin-only document; the storefront only reads the ad switch and banner speed.</p>
    </form>
  );
}
