'use client';
import { useState } from 'react';
import { PageHead, Pill, fmtDate, selectCls } from '@/components/seller/ui';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { usePaged } from '@/hooks/usePaged';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/firebase/errors';
import { listWithdrawalsAdmin, reviewWithdrawal } from '@/services/sellerAdminService';
import { formatMoney } from '@/utils/money';
import { PAYOUT_METHODS, WITHDRAWAL_LABEL, type Withdrawal } from '@/types/seller';

const NEXT: Record<string, ('approved' | 'processing' | 'completed' | 'rejected')[]> = { pending: ['approved', 'rejected'], approved: ['processing', 'rejected'], processing: ['completed', 'rejected'] };

export default function Page() {
  const toast = useToast();
  const [status, setStatus] = useState('pending');
  const { items, more, error, busy, loadMore, reload } = usePaged((c) => listWithdrawalsAdmin(status, c), [status]);
  const act = async (w: Withdrawal, s: 'approved' | 'processing' | 'completed' | 'rejected') => {
    let note = '';
    if (s === 'rejected') { const r = window.prompt('Reason for rejecting (shown to the seller):'); if (!r || r.trim().length < 5) return toast('A reason of at least 5 characters is required', 'error'); note = r.trim(); }
    else if (s === 'completed' && !window.confirm(`Confirm you have paid ${formatMoney(w.amount)} to ${w.storeName}?`)) return;
    try { await reviewWithdrawal(w.id, s, note); toast(`Marked ${s}`, 'success'); await reload(); } catch (e) { toast(friendlyError(e), 'error'); }
  };
  return (
    <div>
      <PageHead title="Withdrawals" />
      <label className="mb-3 block text-sm font-medium">Status <select value={status} onChange={(e) => setStatus(e.target.value)} className={selectCls}><option value="">All</option>{Object.entries(WITHDRAWAL_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
      {error ? <ErrorState message={error} /> : items === null ? <LoadingState /> : !items.length ? <EmptyState title="No withdrawals" /> : (
        <ul className="divide-y divide-navy-100 rounded-card border border-navy-100 dark:divide-navy-500 dark:border-navy-500">
          {items.map((w) => (
            <li key={w.id} className="space-y-1 p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2"><p className="min-w-0 flex-1 font-semibold">{w.storeName || w.sellerId} — {formatMoney(w.amount)}</p><Pill status={w.status} label={WITHDRAWAL_LABEL[w.status]} /></div>
              <p className="text-xs">{fmtDate(w.createdAt)} · {PAYOUT_METHODS.find((m) => m.id === w.method)?.label ?? w.method}</p>
              <p className="rounded-lg bg-navy-50 p-2 text-xs dark:bg-navy-700">Payout details: {w.details}</p>
              {w.note ? <p className="text-xs">Note: {w.note}</p> : null}
              <div className="flex flex-wrap gap-1">{(NEXT[w.status] ?? []).map((s) => <Button key={s} variant={s === 'rejected' ? 'danger' : 'ghost'} onClick={() => act(w, s)}>{WITHDRAWAL_LABEL[s]}</Button>)}</div>
            </li>
          ))}
        </ul>
      )}
      {more ? <Button variant="secondary" className="mt-3" loading={busy} onClick={loadMore}>Load more</Button> : null}
    </div>
  );
}
