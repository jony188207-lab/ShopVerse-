'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { PageHead, Stat } from '@/components/seller/ui';
import { LoadingState } from '@/components/ui/States';
import { useAuth } from '@/hooks/useAuth';
import { getDashboard, type Stat as S } from '@/services/adminDataService';
import { formatMoney } from '@/utils/money';

const CARDS: [string, string, string?, string?][] = [
  ['users', 'Total users', '/admin/users'], ['activeUsers', 'Active users', '/admin/users'], ['sellers', 'Sellers (approved stores)', '/admin/stores'], ['pendingApplications', 'Pending seller applications', '/admin/sellers'],
  ['products', 'Products', '/admin/products'], ['pendingProducts', 'Pending products', '/admin/products'], ['orders', 'Orders', '/admin/orders'], ['completedOrders', 'Completed orders', '/admin/orders'],
  ['cancelledOrders', 'Cancelled orders', '/admin/orders'], ['totalSales', 'Total sales (delivered)', '/admin/orders'], ['pendingWithdrawals', 'Pending withdrawals', '/admin/withdrawals'], ['videos', 'Videos', '/admin/videos'],
  ['reviews', 'Reviews', '/admin/reviews'], ['reports', 'Open reports', '/admin/reports'],
];

export default function AdminHome() {
  const { role } = useAuth();
  const [s, setS] = useState<Record<string, S> | null>(null);
  useEffect(() => { getDashboard().then(setS); }, []);
  if (!s) return <LoadingState />;
  return (
    <div className="space-y-4">
      <PageHead title="Dashboard" />
      <p className="text-sm">Live counts from Firestore, signed in as <strong>{role.replace('_', ' ')}</strong>. “—” means your role cannot read that data. Sales = sum of delivered orders.</p>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {CARDS.map(([k, label, href]) => {
          const v = s[k];
          return <Link key={k} href={href!} className="block"><Stat label={label} value={v?.value === null || v === undefined ? '—' : v.money ? formatMoney(v.value) : v.value.toLocaleString()} /></Link>;
        })}
      </div>
    </div>
  );
}
