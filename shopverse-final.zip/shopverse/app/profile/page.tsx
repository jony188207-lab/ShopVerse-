'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AuthGuard } from '@/components/AuthGuard';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { NotificationToggle } from '@/components/NotificationToggle';
import { InstallPrompt } from '@/components/InstallPrompt';
import { useAuth } from '@/hooks/useAuth';
import { logout } from '@/services/authService';

function ProfileInner() {
  const { user, role } = useAuth();
  const router = useRouter();
  if (!user) return null;
  const isStaff = ['moderator', 'admin', 'super_admin'].includes(role);
  return (
    <div className="mx-auto max-w-lg space-y-4 px-4">
      <h1 className="text-2xl font-extrabold">Profile</h1>
      <Card className="space-y-1">
        <p className="text-lg font-semibold">{user.displayName || 'Shopper'}</p>
        <p className="text-sm">{user.email}</p>
        {user.emailVerified ? <p className="text-sm text-green-700 dark:text-green-400">Email verified</p> : (
          <p className="text-sm">Email not verified. <Link className="font-semibold text-brand-purple underline" href="/verify-email">Verify now</Link></p>
        )}
      </Card>
      <Link href="/profile/addresses" className="block font-semibold text-brand-purple underline">My addresses</Link>
      <Link href="/orders" className="block font-semibold text-brand-purple underline">My orders</Link>
      {role === 'seller' ? <Link href="/seller" className="block font-semibold text-brand-purple underline">Open Seller Center</Link> : null}
      {isStaff ? <Link href="/admin" className="block font-semibold text-brand-purple underline">Open Admin Panel</Link> : null}
      <Card className="space-y-2"><h2 className="font-semibold">Notifications</h2><NotificationToggle uid={user.uid} /><Link href="/notifications/preferences" className="block text-sm font-semibold text-brand-purple underline">Choose what you get notified about</Link></Card>
      <InstallPrompt />
      <Button variant="ghost" onClick={async () => { await logout(); router.replace('/'); }}>Sign out</Button>
    </div>
  );
}
export default function ProfilePage() { return <AuthGuard><ProfileInner /></AuthGuard>; }
