import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onDocumentUpdated } from 'firebase-functions/v2/firestore';
import { audit, clean, db, getSettings, notify, requireAdmin } from './common';

type Action = 'approve' | 'reject' | 'suspend' | 'reactivate';

/** Suspends / restores the store's products in chunks (Firestore batch limit 500). Only touches products it marked itself. */
async function setStoreProductsHidden(storeId: string, hide: boolean): Promise<number> {
  let total = 0;
  for (;;) {
    const q = hide
      ? db.collection('products').where('storeId', '==', storeId).where('status', 'in', ['approved', 'out_of_stock']).limit(400)
      : db.collection('products').where('storeId', '==', storeId).where('suspendReason', '==', 'store_suspended').limit(400);
    const snap = await q.get();
    if (snap.empty) return total;
    const b = db.batch();
    snap.forEach((d) => b.update(d.ref, hide
      ? { status: 'suspended', suspendReason: 'store_suspended', updatedAt: Timestamp.now() }
      : { status: Number(d.get('stock')) > 0 ? 'approved' : 'out_of_stock', suspendReason: FieldValue.delete(), updatedAt: Timestamp.now() }));
    await b.commit();
    total += snap.size;
    if (snap.size < 400) return total;
  }
}

/**
 * The ONLY way a user becomes a seller. Admin-only (role verified server-side). Approve = role + store + private contact doc in one transaction.
 * applicationId is the applicant's uid (sellerApplications/{uid}).
 */
export const reviewSellerApplication = onCall(async (req) => {
  const adminId = await requireAdmin(req);
  const { applicationId, action } = (req.data ?? {}) as { applicationId?: unknown; action?: unknown };
  const note = clean((req.data as { note?: unknown })?.note, 500);
  if (typeof applicationId !== 'string' || !applicationId) throw new HttpsError('invalid-argument', 'Missing application.');
  if (!['approve', 'reject', 'suspend', 'reactivate'].includes(action as string)) throw new HttpsError('invalid-argument', 'Unknown action.');
  if ((action === 'reject' || action === 'suspend') && note.length < 5) throw new HttpsError('invalid-argument', 'Give a reason (at least 5 characters). The applicant will see it.');
  const act = action as Action;
  const defaultCommission = (await getSettings()).commissionDefaultPercent;
  const appRef = db.doc(`sellerApplications/${applicationId}`);
  const uid = applicationId;
  let storeId = '';
  let storeName = '';

  await db.runTransaction(async (tx) => {
    const app = await tx.get(appRef);
    if (!app.exists) throw new HttpsError('not-found', 'Application not found.');
    const status = app.get('status') as string;
    const roleSnap = await tx.get(db.doc(`roles/${uid}`));
    const role = roleSnap.exists ? String(roleSnap.get('role')) : 'user';
    const storeQ = await tx.get(db.collection('stores').where('ownerId', '==', uid).limit(1));
    const now = Timestamp.now();
    const decision = { reviewNote: note, reviewedBy: adminId, reviewedAt: now, updatedAt: now };
    storeName = String(app.get('storeName') ?? '');

    if (act === 'approve') {
      if (status !== 'pending') throw new HttpsError('failed-precondition', `Only pending applications can be approved (this one is ${status}).`);
      if (role !== 'user') throw new HttpsError('failed-precondition', `This account already has the “${role}” role and cannot be converted to a seller.`);
      if (!storeQ.empty) throw new HttpsError('failed-precondition', 'This account already owns a store.');
      const slugQ = await tx.get(db.collection('stores').where('slug', '==', app.get('slug')).limit(1));
      if (!slugQ.empty) throw new HttpsError('already-exists', `The store address “${app.get('slug')}” is already taken. Reject with a note asking for a different slug.`);
      const ref = db.collection('stores').doc();
      storeId = ref.id;
      tx.set(ref, {
        ownerId: uid, applicationId: uid, name: app.get('storeName'), slug: app.get('slug'), description: app.get('description') ?? '', logoUrl: app.get('logoUrl') ?? '', bannerUrl: app.get('bannerUrl') ?? '',
        city: app.get('city'), country: app.get('country'), returnPolicy: app.get('returnPolicy') ?? '', shippingInfo: app.get('shippingInfo') ?? '', shippingFee: 0,
        status: 'approved', ratingAvg: 0, ratingCount: 0, ratingSum: 0, followerCount: 0, salesCount: 0, createdAt: now, updatedAt: now,
      });
      tx.set(db.doc(`storeFinance/${ref.id}`), { commissionRate: defaultCommission, updatedAt: now });
      tx.set(db.doc(`storePrivate/${ref.id}`), { phone: app.get('phone'), email: app.get('email'), address: app.get('address'), createdAt: now, updatedAt: now });
      tx.set(db.doc(`roles/${uid}`), { role: 'seller', updatedAt: now, updatedBy: adminId });
      tx.update(appRef, { status: 'approved', storeId: ref.id, ...decision });
    } else if (act === 'reject') {
      if (status !== 'pending') throw new HttpsError('failed-precondition', `Only pending applications can be rejected (this one is ${status}).`);
      tx.update(appRef, { status: 'rejected', ...decision });
    } else if (act === 'suspend') {
      if (status !== 'approved' || storeQ.empty) throw new HttpsError('failed-precondition', 'Only approved sellers can be suspended.');
      storeId = storeQ.docs[0].id;
      tx.update(storeQ.docs[0].ref, { status: 'suspended', updatedAt: now });
      if (role === 'seller') tx.set(db.doc(`roles/${uid}`), { role: 'user', updatedAt: now, updatedBy: adminId });
      tx.update(appRef, { status: 'suspended', ...decision });
    } else {
      if (status !== 'suspended' || storeQ.empty) throw new HttpsError('failed-precondition', 'Only suspended sellers can be reactivated.');
      if (role !== 'user' && role !== 'seller') throw new HttpsError('failed-precondition', `The account now has the “${role}” role.`);
      storeId = storeQ.docs[0].id;
      tx.update(storeQ.docs[0].ref, { status: 'approved', updatedAt: now });
      tx.set(db.doc(`roles/${uid}`), { role: 'seller', updatedAt: now, updatedBy: adminId });
      tx.update(appRef, { status: 'approved', ...decision });
    }
  });

  let products = 0;
  if (act === 'suspend') products = await setStoreProductsHidden(storeId, true);
  if (act === 'reactivate') products = await setStoreProductsHidden(storeId, false);
  await audit(adminId, `seller.${act}`, 'sellerApplication', uid, { storeId, note, products });
  const msg = {
    approve: { title: 'Your store is approved', body: `“${storeName}” is live. Open the Seller Center to add products.`, link: '/seller' },
    reject: { title: 'Seller application not approved', body: note, link: '/become-seller' },
    suspend: { title: 'Your store was suspended', body: note, link: '/become-seller' },
    reactivate: { title: 'Your store was reactivated', body: `“${storeName}” is open again.`, link: '/seller' },
  }[act];
  await notify(uid, { type: `seller_${act}`, ...msg });
  return { ok: true, storeId, products };
});

/** Tells the seller when staff approve/reject/suspend one of their products (covers client-side moderation in /admin/products). */
export const onProductModerated = onDocumentUpdated('products/{productId}', async (event) => {
  const b = event.data?.before.data(), a = event.data?.after.data();
  if (!b || !a || b.status === a.status) return;
  const link = `/seller/products/${event.params.productId}/edit`;
  const note = a.moderationNote ? ` Note: ${a.moderationNote}` : '';
  if (b.status === 'pending_review' && a.status === 'approved') await notify(a.sellerId, { type: 'product_approved', title: 'Product approved', body: `“${a.title}” is now live.`, link });
  else if (a.status === 'rejected') await notify(a.sellerId, { type: 'product_rejected', title: 'Product rejected', body: `“${a.title}” needs changes.${note}`, link });
  else if (a.status === 'suspended' && a.suspendReason !== 'store_suspended') await notify(a.sellerId, { type: 'product_suspended', title: 'Product suspended', body: `“${a.title}” was suspended.${note}`, link });
  else if (b.status === 'suspended' && a.status === 'approved' && b.suspendReason !== 'store_suspended') await notify(a.sellerId, { type: 'product_restored', title: 'Product restored', body: `“${a.title}” is live again.`, link });
});
