// Offline tests for src/worker.js using node:test (built into Node 22; no packages).
// The Worker is run against an IN-MEMORY SIMULATION of Google's JWKS endpoint, OAuth token endpoint, Identity Toolkit and Firestore REST API.
// Crypto is real (RSA keys generated here; the simulated Google verifies the Worker's service-account assertion). The Firestore/REST behaviour is
// my reading of the documented API, so a passing run proves the Worker's logic and crypto, NOT compatibility with the live Firestore service.
import test, { beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import worker, { __resetCachesForTests } from '../src/worker.js';

const PROJECT = 'shopverse21-831fc';
const ORIGIN = 'https://admin.example.com';
const b64u = (b) => Buffer.from(b).toString('base64url');
const rsa = () => crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const fbKey = rsa();          // plays "Google's securetoken key"
const otherKey = rsa();       // an attacker's key
const saKey = rsa();          // the service account key
const SA_EMAIL = 'worker@shopverse21-831fc.iam.gserviceaccount.com';
const SA_JSON = JSON.stringify({ type: 'service_account', project_id: PROJECT, client_email: SA_EMAIL, private_key: saKey.privateKey.export({ type: 'pkcs8', format: 'pem' }) });
const PRIVATE_MARK = 'PRIVATE KEY';
const jwk = { ...fbKey.publicKey.export({ format: 'jwk' }), kid: 'kid1', alg: 'RS256', use: 'sig' };

function idToken(over = {}, key = fbKey.privateKey, kid = 'kid1') {
  const now = Math.floor(Date.now() / 1000);
  const payload = { aud: PROJECT, iss: `https://securetoken.google.com/${PROJECT}`, sub: 'admin1', iat: now - 5, auth_time: now - 5, exp: now + 3000, ...over };
  const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT', kid }));
  const body = b64u(JSON.stringify(payload));
  const sig = crypto.sign('RSA-SHA256', Buffer.from(`${head}.${body}`), key);
  return `${head}.${body}.${b64u(sig)}`;
}

/* ---- tiny independent Firestore value codec for the fake ---- */
const E = (v) => v === null ? { nullValue: null } : v instanceof Date ? { timestampValue: v.toISOString() } : typeof v === 'string' ? { stringValue: v } : typeof v === 'boolean' ? { booleanValue: v } : typeof v === 'number' ? (Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v }) : Array.isArray(v) ? { arrayValue: { values: v.map(E) } } : { mapValue: { fields: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, E(x)])) } };
const D = (v) => 'stringValue' in v ? v.stringValue : 'integerValue' in v ? Number(v.integerValue) : 'doubleValue' in v ? v.doubleValue : 'booleanValue' in v ? v.booleanValue : 'timestampValue' in v ? new Date(v.timestampValue) : 'arrayValue' in v ? (v.arrayValue.values ?? []).map(D) : 'mapValue' in v ? Object.fromEntries(Object.entries(v.mapValue.fields ?? {}).map(([k, x]) => [k, D(x)])) : null;

let db, authUsers, calls, abortNextCommit, lookupStatus, consoleOut;
const put = (path, obj) => db.set(path, Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, E(v)])));
const get = (path) => (db.has(path) ? Object.fromEntries(Object.entries(db.get(path)).map(([k, v]) => [k, D(v)])) : null);
const ids = (col) => [...db.keys()].filter((p) => p.startsWith(`${col}/`)).map((p) => p.split('/')[1]);
const ROOT = `projects/${PROJECT}/databases/(default)/documents`;

const respond = (status, body) => new Response(typeof body === 'string' ? body : JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

async function fakeFetch(input, init = {}) {
  const url = new URL(typeof input === 'string' ? input : input.url);
  const method = init.method ?? 'GET';
  const headers = init.headers ?? {};
  const auth = headers.Authorization ?? '';
  calls.push({ method, url: url.href, auth });
  if (url.href === 'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com') return respond(200, { keys: [jwk] });
  if (url.href === 'https://oauth2.googleapis.com/token') {
    const assertion = new URLSearchParams(init.body).get('assertion') ?? '';
    const [h, c, s] = assertion.split('.');
    const ok = crypto.verify('RSA-SHA256', Buffer.from(`${h}.${c}`), saKey.publicKey, Buffer.from(s, 'base64url'));
    const claims = JSON.parse(Buffer.from(c, 'base64url'));
    if (!ok || claims.iss !== SA_EMAIL || claims.aud !== 'https://oauth2.googleapis.com/token' || !claims.scope) return respond(400, { error: 'invalid_grant' });
    return respond(200, { access_token: 'sa-access-token', expires_in: 3600 });
  }
  if (auth !== 'Bearer sa-access-token') return respond(401, { error: { status: 'UNAUTHENTICATED' } }); // everything below requires the SERVICE ACCOUNT token
  if (url.hostname === 'identitytoolkit.googleapis.com') {
    if (lookupStatus !== 200) return respond(lookupStatus, { error: { message: 'denied' } });
    const { localId } = JSON.parse(init.body);
    const u = authUsers.get(localId[0]);
    return respond(200, u ? { users: [{ localId: localId[0], emailVerified: u.emailVerified }] } : {});
  }
  const path = decodeURIComponent(url.pathname.replace(/^\/v1\//, ''));
  if (method === 'GET') {
    const rel = path.slice(ROOT.length + 1);
    return db.has(rel) ? respond(200, { name: `${ROOT}/${rel}`, fields: db.get(rel) }) : respond(404, { error: { status: 'NOT_FOUND' } });
  }
  const body = JSON.parse(init.body ?? '{}');
  if (path.endsWith(':beginTransaction')) return respond(200, { transaction: `txn${calls.length}` });
  if (path.endsWith(':rollback')) return respond(200, {});
  if (path.endsWith(':runQuery')) {
    const q = body.structuredQuery;
    const col = q.from[0].collectionId;
    const match = (fields, f) => f.compositeFilter ? f.compositeFilter.filters.every((x) => match(fields, x)) : (() => {
      const { field, op, value } = f.fieldFilter; const have = fields[field.fieldPath];
      if (!have) return false;
      return op === 'EQUAL' ? JSON.stringify(have) === JSON.stringify(value) : value.arrayValue.values.some((x) => JSON.stringify(x) === JSON.stringify(have));
    })();
    const rows = [...db.entries()].filter(([p]) => p.split('/').length === 2 && p.startsWith(`${col}/`) && match(db.get(p), q.where)).slice(0, q.limit ?? 1000)
      .map(([p, fields]) => ({ document: { name: `${ROOT}/${p}`, fields } }));
    return respond(200, rows.length ? rows : [{ readTime: 'x' }]);
  }
  if (path.endsWith(':commit')) {
    if (body.transaction && abortNextCommit) { abortNextCommit = false; return respond(409, { error: { status: 'ABORTED' } }); }
    for (const w of body.writes) { // validate every precondition before applying anything (atomic)
      const rel = w.update.name.slice(ROOT.length + 1);
      if (w.currentDocument && w.currentDocument.exists !== db.has(rel)) return respond(400, { error: { status: 'FAILED_PRECONDITION', message: rel } });
    }
    for (const w of body.writes) {
      const rel = w.update.name.slice(ROOT.length + 1);
      if (w.updateMask) { const cur = { ...(db.get(rel) ?? {}) }; for (const f of w.updateMask.fieldPaths) { if (f in (w.update.fields ?? {})) cur[f] = w.update.fields[f]; else delete cur[f]; } db.set(rel, cur); }
      else db.set(rel, w.update.fields ?? {});
    }
    return respond(200, { writeResults: body.writes.map(() => ({})) });
  }
  return respond(404, { error: { status: 'NOT_FOUND' } });
}

const ENV = () => ({ FIREBASE_PROJECT_ID: PROJECT, ALLOWED_ORIGINS: ORIGIN, SERVICE_ACCOUNT_JSON: SA_JSON });
async function call(payload, { token = idToken(), origin = ORIGIN, env = ENV(), method = 'POST', path = '/seller/review', raw } = {}) {
  const headers = { 'Content-Type': 'application/json', ...(origin ? { Origin: origin } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) };
  const res = await worker.fetch(new Request(`https://api.example.workers.dev${path}`, { method, headers, body: method === 'POST' ? (raw ?? JSON.stringify(payload)) : undefined }), env);
  const text = await res.text();
  assert.ok(!text.includes(PRIVATE_MARK) && !text.includes('sa-access-token'), 'a secret leaked into a response');
  return { status: res.status, headers: res.headers, body: text ? JSON.parse(text) : null };
}

const realFetch = globalThis.fetch; const realErr = console.error;
beforeEach(() => {
  __resetCachesForTests();
  db = new Map(); authUsers = new Map(); calls = []; abortNextCommit = false; lookupStatus = 200; consoleOut = [];
  globalThis.fetch = fakeFetch;
  console.error = (...a) => { consoleOut.push(a.join(' ')); };
  put('roles/admin1', { role: 'admin' });
  put('users/applicant1', { displayName: 'Ann' });
  authUsers.set('applicant1', { emailVerified: true });
  put('sellerApplications/applicant1', { userId: 'applicant1', storeName: 'Ann Shop', slug: 'ann-shop', description: 'd', phone: '12345', email: 'a@b.com', country: 'US', city: 'NYC', address: '1 Main', returnPolicy: '', shippingInfo: '', logoUrl: '', bannerUrl: '', status: 'pending', createdAt: new Date('2026-01-01') });
});
test.after(() => { globalThis.fetch = realFetch; console.error = realErr; });

const wrote = () => calls.some((c) => c.url.endsWith(':commit'));

/* ================= authentication ================= */
test('health check answers without secrets', async () => {
  const r = await call(null, { method: 'GET', path: '/', token: null, origin: null });
  assert.equal(r.status, 200); assert.deepEqual(r.body, { ok: true, service: 'shopverse-seller-approval' });
});
test('no Authorization header -> 401, nothing touched', async () => {
  const r = await call({ applicationId: 'applicant1', action: 'reject', note: 'not ok enough' }, { token: null });
  assert.equal(r.status, 401); assert.equal(wrote(), false);
});
test('garbage and malformed tokens -> 401', async () => {
  for (const t of ['abc', 'a.b.c', `${b64u('{"alg":"none"}')}.${b64u('{}')}.`]) assert.equal((await call({}, { token: t })).status, 401);
});
test('token signed with a different key -> 401', async () => {
  assert.equal((await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' }, { token: idToken({}, otherKey.privateKey) })).status, 401);
});
test('wrong audience / wrong issuer / expired / future iat / empty sub -> 401', async () => {
  const now = Math.floor(Date.now() / 1000);
  for (const over of [{ aud: 'other-project' }, { iss: 'https://securetoken.google.com/other' }, { exp: now - 10 }, { iat: now + 4000 }, { sub: '' }]) {
    assert.equal((await call({}, { token: idToken(over) })).status, 401, JSON.stringify(over));
  }
  assert.equal(wrote(), false);
});
test('unknown key id -> 401', async () => { assert.equal((await call({}, { token: idToken({}, fbKey.privateKey, 'nope') })).status, 401); });

/* ================= authorization ================= */
test('signed-in users without an admin role get 403 BEFORE any input checks or writes', async () => {
  for (const role of [null, 'user', 'seller', 'moderator']) {
    db.delete('roles/admin1'); if (role) put('roles/admin1', { role });
    const r = await call({ applicationId: 'applicant1', action: 'approve' });
    assert.equal(r.status, 403, String(role)); assert.equal(r.body.error.code, 'permission-denied');
    assert.equal((await call({ garbage: true })).status, 403); // bad input must not reveal anything either
  }
  assert.equal(wrote(), false); assert.equal(get('sellerApplications/applicant1').status, 'pending');
});
test('a role string that merely resembles admin is refused ("super-admin", "Admin")', async () => {
  for (const role of ['super-admin', 'Admin', 'admin ']) { put('roles/admin1', { role }); assert.equal((await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' })).status, 403, role); }
});
test('the Worker reads the role with the SERVICE ACCOUNT token, never with the user token', async () => {
  await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' });
  const fsCalls = calls.filter((c) => c.url.includes('firestore.googleapis.com'));
  assert.ok(fsCalls.length > 0); assert.ok(fsCalls.every((c) => c.auth === 'Bearer sa-access-token'));
});

/* ================= input validation ================= */
test('bad input -> 400', async () => {
  for (const p of [{ action: 'approve' }, { applicationId: 'a/b', action: 'approve' }, { applicationId: 'applicant1', action: 'delete' }, { applicationId: 'applicant1', action: 'reject', note: 'abc' }, { applicationId: 'applicant1', action: 'suspend', note: '' }]) {
    assert.equal((await call(p)).status, 400, JSON.stringify(p));
  }
  assert.equal((await call(null, { raw: 'not json' })).status, 400);
  assert.equal(wrote(), false);
});
test('unknown application -> 404', async () => { assert.equal((await call({ applicationId: 'ghost', action: 'reject', note: 'valid note' })).status, 404); });

/* ================= reject ================= */
test('reject: application updated, audit + notification written, no store or role created', async () => {
  const r = await call({ applicationId: 'applicant1', action: 'reject', note: '  Please use a clearer logo.  ' });
  assert.equal(r.status, 200); assert.equal(r.body.ok, true);
  const app = get('sellerApplications/applicant1');
  assert.equal(app.status, 'rejected'); assert.equal(app.reviewNote, 'Please use a clearer logo.'); assert.equal(app.reviewedBy, 'admin1'); assert.ok(app.reviewedAt instanceof Date);
  assert.equal(app.storeName, 'Ann Shop'); // untouched fields survive (mask update)
  assert.deepEqual(ids('stores'), []); assert.equal(get('roles/applicant1'), null);
  const log = get(`adminLogs/${ids('adminLogs')[0]}`); assert.equal(log.action, 'seller.reject'); assert.equal(log.adminId, 'admin1'); assert.equal(log.targetId, 'applicant1');
  const n = get(`notifications/${ids('notifications')[0]}`); assert.equal(n.userId, 'applicant1'); assert.equal(n.type, 'seller_reject'); assert.equal(n.category, 'system'); assert.equal(n.read, false); assert.equal(n.link, '/become-seller');
});
test('reject twice: second attempt is refused', async () => {
  assert.equal((await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' })).status, 200);
  const r2 = await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' });
  assert.equal(r2.status, 409); assert.match(r2.body.error.message, /Only pending/);
});

/* ================= approve ================= */
test('approve (admin): creates store, finance, private contact, seller role and marks the application approved', async () => {
  const r = await call({ applicationId: 'applicant1', action: 'approve' });
  assert.equal(r.status, 200); const storeId = r.body.storeId; assert.match(storeId, /^[A-Za-z0-9]{20}$/);
  const s = get(`stores/${storeId}`);
  assert.deepEqual([s.ownerId, s.name, s.slug, s.status, s.shippingFee, s.ratingCount, s.followerCount], ['applicant1', 'Ann Shop', 'ann-shop', 'approved', 0, 0, 0]);
  assert.equal(s.city, 'NYC'); assert.ok(s.createdAt instanceof Date);
  assert.equal(get(`storeFinance/${storeId}`).commissionRate, 10);
  const priv = get(`storePrivate/${storeId}`); assert.deepEqual([priv.phone, priv.email, priv.address], ['12345', 'a@b.com', '1 Main']);
  assert.deepEqual([get('roles/applicant1').role, get('roles/applicant1').updatedBy], ['seller', 'admin1']);
  const app = get('sellerApplications/applicant1'); assert.deepEqual([app.status, app.storeId, app.reviewedBy], ['approved', storeId, 'admin1']);
  assert.equal(get('storeSlugs/ann-shop').uid, 'applicant1');
  assert.equal(get(`adminLogs/${ids('adminLogs')[0]}`).action, 'seller.approve');
  assert.equal(get(`notifications/${ids('notifications')[0]}`).title, 'Your store is approved');
});
test('approve (super_admin) works and the commission comes from platformSettings/main', async () => {
  put('roles/admin1', { role: 'super_admin' }); put('platformSettings/main', { commissionDefaultPercent: 15 });
  const r = await call({ applicationId: 'applicant1', action: 'approve' });
  assert.equal(r.status, 200); assert.equal(get(`storeFinance/${r.body.storeId}`).commissionRate, 15);
});
test('an out-of-range platform commission falls back to 10', async () => {
  put('platformSettings/main', { commissionDefaultPercent: 99 });
  const r = await call({ applicationId: 'applicant1', action: 'approve' }); assert.equal(get(`storeFinance/${r.body.storeId}`).commissionRate, 10);
});
test('approve is refused while the applicant email is unverified, with no writes', async () => {
  authUsers.set('applicant1', { emailVerified: false });
  const r = await call({ applicationId: 'applicant1', action: 'approve' });
  assert.equal(r.status, 409); assert.match(r.body.error.message, /not verified their email/);
  assert.equal(wrote(), false); assert.equal(get('sellerApplications/applicant1').status, 'pending'); assert.deepEqual(ids('stores'), []);
});
test('a deleted Auth user counts as unverified', async () => {
  authUsers.delete('applicant1'); assert.equal((await call({ applicationId: 'applicant1', action: 'approve' })).status, 409);
});
test('a failing Auth lookup is reported as a service error, NOT as "unverified"', async () => {
  lookupStatus = 403;
  const r = await call({ applicationId: 'applicant1', action: 'approve' });
  assert.equal(r.status, 500); assert.match(r.body.error.message, /Firebase Authentication Viewer/); assert.equal(wrote(), false);
});
test('approve twice: the second call is refused and nothing is duplicated', async () => {
  assert.equal((await call({ applicationId: 'applicant1', action: 'approve' })).status, 200);
  const r2 = await call({ applicationId: 'applicant1', action: 'approve' });
  assert.equal(r2.status, 409); assert.equal(ids('stores').length, 1); assert.equal(ids('adminLogs').length, 1);
});
test('approve is refused for every non-pending application status', async () => {
  for (const status of ['rejected', 'approved', 'suspended']) {
    put('sellerApplications/applicant1', { ...get('sellerApplications/applicant1'), status });
    const r = await call({ applicationId: 'applicant1', action: 'approve' });
    assert.equal(r.status, 409, status); assert.match(r.body.error.message, /Only pending applications can be approved/);
  }
  assert.deepEqual(ids('stores'), []); assert.equal(get('roles/applicant1'), null);
});
test('approve refused for accounts that already have a role, a store, or a taken slug', async () => {
  put('roles/applicant1', { role: 'moderator' });
  let r = await call({ applicationId: 'applicant1', action: 'approve' }); assert.equal(r.status, 409); assert.match(r.body.error.message, /already has the “moderator” role/);
  db.delete('roles/applicant1'); put('stores/s0', { ownerId: 'applicant1', slug: 'other', status: 'approved' });
  r = await call({ applicationId: 'applicant1', action: 'approve' }); assert.equal(r.status, 409); assert.match(r.body.error.message, /already owns a store/);
  db.delete('stores/s0'); put('stores/s1', { ownerId: 'someone', slug: 'ann-shop', status: 'approved' });
  r = await call({ applicationId: 'applicant1', action: 'approve' }); assert.equal(r.status, 409); assert.equal(r.body.error.code, 'already-exists');
  assert.equal(get('sellerApplications/applicant1').status, 'pending'); assert.equal(get('roles/applicant1'), null);
});
test('a transaction conflict (ABORTED) is retried once and the store is created exactly once', async () => {
  abortNextCommit = true;
  const r = await call({ applicationId: 'applicant1', action: 'approve' });
  assert.equal(r.status, 200); assert.equal(ids('stores').length, 1);
});

/* ================= suspend / reactivate ================= */
async function approved() { const r = await call({ applicationId: 'applicant1', action: 'approve' }); return r.body.storeId; }
test('suspend hides the store products, removes the seller role; reactivate restores them', async () => {
  const storeId = await approved();
  put('products/p1', { storeId, status: 'approved', stock: 5, title: 'A' });
  put('products/p2', { storeId, status: 'out_of_stock', stock: 0, title: 'B' });
  put('products/p3', { storeId, status: 'draft', stock: 3, title: 'C' });
  put('products/p4', { storeId: 'other', status: 'approved', stock: 3, title: 'D' });
  let r = await call({ applicationId: 'applicant1', action: 'suspend', note: 'Policy breach' });
  assert.equal(r.status, 200); assert.equal(r.body.products, 2);
  assert.equal(get(`stores/${storeId}`).status, 'suspended'); assert.equal(get('roles/applicant1').role, 'user'); assert.equal(get('sellerApplications/applicant1').status, 'suspended');
  assert.deepEqual([get('products/p1').status, get('products/p1').suspendReason, get('products/p2').status, get('products/p3').status, get('products/p4').status], ['suspended', 'store_suspended', 'suspended', 'draft', 'approved']);
  r = await call({ applicationId: 'applicant1', action: 'reactivate' });
  assert.equal(r.status, 200); assert.equal(r.body.products, 2);
  assert.equal(get(`stores/${storeId}`).status, 'approved'); assert.equal(get('roles/applicant1').role, 'seller'); assert.equal(get('sellerApplications/applicant1').status, 'approved');
  assert.equal(get('products/p1').status, 'approved'); assert.ok(!('suspendReason' in get('products/p1'))); assert.equal(get('products/p2').status, 'out_of_stock'); assert.equal(get('products/p3').status, 'draft');
  assert.deepEqual(ids('adminLogs').map((i) => get(`adminLogs/${i}`).action).sort(), ['seller.approve', 'seller.reactivate', 'seller.suspend']);
});
test('suspend/reactivate preconditions', async () => {
  assert.equal((await call({ applicationId: 'applicant1', action: 'suspend', note: 'valid reason' })).status, 409); // still pending
  await approved();
  assert.equal((await call({ applicationId: 'applicant1', action: 'reactivate' })).status, 409); // not suspended
});

/* ================= CORS and configuration ================= */
test('CORS: allowed origin is echoed; other origins are refused; preflight works', async () => {
  const ok = await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' });
  assert.equal(ok.headers.get('Access-Control-Allow-Origin'), ORIGIN);
  const bad = await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' }, { origin: 'https://evil.example' });
  assert.equal(bad.status, 403); assert.equal(bad.headers.get('Access-Control-Allow-Origin'), null);
  const pre = await worker.fetch(new Request('https://x.workers.dev/seller/review', { method: 'OPTIONS', headers: { Origin: ORIGIN } }), ENV());
  assert.equal(pre.status, 204); assert.equal(pre.headers.get('Access-Control-Allow-Origin'), ORIGIN); assert.match(pre.headers.get('Access-Control-Allow-Headers'), /Authorization/);
  const preBad = await worker.fetch(new Request('https://x.workers.dev/seller/review', { method: 'OPTIONS', headers: { Origin: 'https://evil.example' } }), ENV());
  assert.equal(preBad.headers.get('Access-Control-Allow-Origin'), null);
});
test('unconfigured or mismatched service account fails closed with a clear message', async () => {
  let r = await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' }, { env: { FIREBASE_PROJECT_ID: PROJECT, ALLOWED_ORIGINS: ORIGIN } });
  assert.equal(r.status, 500); assert.match(r.body.error.message, /not configured/);
  __resetCachesForTests();
  r = await call({ applicationId: 'applicant1', action: 'reject', note: 'valid note' }, { env: { ...ENV(), SERVICE_ACCOUNT_JSON: JSON.stringify({ ...JSON.parse(SA_JSON), project_id: 'some-other-project' }) } });
  assert.equal(r.status, 500); assert.match(r.body.error.message, /different Firebase project/);
  r = await call({}, { env: { SERVICE_ACCOUNT_JSON: SA_JSON } });
  assert.equal(r.status, 500); assert.equal(wrote(), false);
});
test('unknown routes and methods are rejected', async () => {
  assert.equal((await call({}, { path: '/other' })).status, 404);
  assert.equal((await call(null, { method: 'GET', path: '/seller/review', token: null })).status, 400);
});
test('the private key and tokens never reach the logs', async () => {
  await call({ applicationId: 'applicant1', action: 'approve' }); lookupStatus = 403; await call({ applicationId: 'applicant1', action: 'approve' });
  assert.ok(consoleOut.every((l) => !l.includes(PRIVATE_MARK) && !l.includes('sa-access-token') && !l.includes('eyJ')));
});
